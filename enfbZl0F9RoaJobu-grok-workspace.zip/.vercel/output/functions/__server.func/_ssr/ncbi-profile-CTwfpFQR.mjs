import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ncbi-profile-CTwfpFQR.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getNcbiProfile_createServerFn_handler = createServerRpc({
	id: "f903d5cd9423dc1ebdcfaaf528519f2e9c11cb7354272a5a0019a739fb3ecb19",
	name: "getNcbiProfile",
	filename: "src/data/ncbi-profile.ts"
}, (opts) => getNcbiProfile.__executeServer(opts));
var getNcbiProfile = createServerFn({ method: "GET" }).validator((input) => {
	const id = Number(input);
	if (!Number.isInteger(id) || id < 1 || id > 2e7) throw new Error("Taxid inválido");
	return id;
}).handler(getNcbiProfile_createServerFn_handler, async ({ data }) => {
	const { fetchNcbiProfile } = await import("./ncbi-profile.server-DKQsNSdx.mjs");
	return fetchNcbiProfile(data);
});
//#endregion
export { getNcbiProfile_createServerFn_handler };
