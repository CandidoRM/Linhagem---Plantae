import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as Search, r as ArrowLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BdbZGx5P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getNcbiProfile = createServerFn({ method: "GET" }).validator((input) => {
	const id = Number(input);
	if (!Number.isInteger(id) || id < 1 || id > 2e7) throw new Error("Taxid inválido");
	return id;
}).handler(createSsrRpc("f903d5cd9423dc1ebdcfaaf528519f2e9c11cb7354272a5a0019a739fb3ecb19"));
var SPECIES = [
	[
		"s2732280",
		"Acaena agnipila",
		"acaena",
		2732280
	],
	[
		"s2304396",
		"Acaena alpina",
		"acaena",
		2304396
	],
	[
		"s3083556",
		"Acaena andina",
		"acaena",
		3083556
	],
	[
		"s281857",
		"Acaena anserinifolia",
		"acaena",
		281857
	],
	[
		"s2732281",
		"Acaena antarctica",
		"acaena",
		2732281
	],
	[
		"s281858",
		"Acaena argentea",
		"acaena",
		281858
	],
	[
		"s3723844",
		"Acaena boliviana",
		"acaena",
		3723844
	],
	[
		"s493338",
		"Acaena buchananii",
		"acaena",
		493338
	],
	[
		"s137430",
		"Acaena caesiglauca",
		"acaena",
		137430
	],
	[
		"s2732282",
		"Acaena caespitosa",
		"acaena",
		2732282
	],
	[
		"s3723845",
		"Acaena confertissima",
		"acaena",
		3723845
	],
	[
		"s211872",
		"Acaena cylindristachya",
		"acaena",
		211872
	],
	[
		"s281859",
		"Acaena digitata",
		"acaena",
		281859
	],
	[
		"s2732272",
		"Acaena dumicola",
		"acaena",
		2732272
	],
	[
		"s281860",
		"Acaena echinata",
		"acaena",
		281860
	],
	[
		"s281861",
		"Acaena elongata",
		"acaena",
		281861
	],
	[
		"s2732273",
		"Acaena emittens",
		"acaena",
		2732273
	],
	[
		"s281862",
		"Acaena eupatoria",
		"acaena",
		281862
	],
	[
		"s2732283",
		"Acaena exigua",
		"acaena",
		2732283
	],
	[
		"s281863",
		"Acaena fissistipula",
		"acaena",
		281863
	],
	[
		"s3723846",
		"Acaena fuscescens",
		"acaena",
		3723846
	],
	[
		"s2732284",
		"Acaena glabra",
		"acaena",
		2732284
	],
	[
		"s3723847",
		"Acaena hirsutula",
		"acaena",
		3723847
	],
	[
		"s281864",
		"Acaena inermis",
		"acaena",
		281864
	],
	[
		"s2732285",
		"Acaena integerrima",
		"acaena",
		2732285
	],
	[
		"s2732274",
		"Acaena juvenca",
		"acaena",
		2732274
	],
	[
		"s211873",
		"Acaena laevigata",
		"acaena",
		211873
	],
	[
		"s281865",
		"Acaena latebrosa",
		"acaena",
		281865
	],
	[
		"s2732286",
		"Acaena leptacantha",
		"acaena",
		2732286
	],
	[
		"s3723848",
		"Acaena longiscapa",
		"acaena",
		3723848
	],
	[
		"s281866",
		"Acaena lucida",
		"acaena",
		281866
	],
	[
		"s281867",
		"Acaena macrocephala",
		"acaena",
		281867
	],
	[
		"s281911",
		"Acaena magellanica",
		"acaena",
		281911
	],
	[
		"s281868",
		"Acaena masafuerana",
		"acaena",
		281868
	],
	[
		"s493339",
		"Acaena microphylla",
		"acaena",
		493339
	],
	[
		"s2732275",
		"Acaena minor",
		"acaena",
		2732275
	],
	[
		"s281869",
		"Acaena montana",
		"acaena",
		281869
	],
	[
		"s281870",
		"Acaena multifida",
		"acaena",
		281870
	],
	[
		"s3083557",
		"Acaena myriophylla",
		"acaena",
		3083557
	],
	[
		"s281871",
		"Acaena novae-zelandiae",
		"acaena",
		281871
	],
	[
		"s281872",
		"Acaena ovalifolia",
		"acaena",
		281872
	],
	[
		"s2732287",
		"Acaena ovina",
		"acaena",
		2732287
	],
	[
		"s2732276",
		"Acaena pallida",
		"acaena",
		2732276
	],
	[
		"s2732288",
		"Acaena patagonica",
		"acaena",
		2732288
	],
	[
		"s281873",
		"Acaena pinnatifida",
		"acaena",
		281873
	],
	[
		"s2732289",
		"Acaena platyacantha",
		"acaena",
		2732289
	],
	[
		"s2024725",
		"Acaena poeppigiana",
		"acaena",
		2024725
	],
	[
		"s2732277",
		"Acaena profundeincisa",
		"acaena",
		2732277
	],
	[
		"s2732290",
		"Acaena pumila",
		"acaena",
		2732290
	],
	[
		"s1793799",
		"Acaena rorida",
		"acaena",
		1793799
	],
	[
		"s2732278",
		"Acaena saccaticupula",
		"acaena",
		2732278
	],
	[
		"s3471476",
		"Acaena sarmentosa",
		"acaena",
		3471476
	],
	[
		"s2732291",
		"Acaena sericea",
		"acaena",
		2732291
	],
	[
		"s281875",
		"Acaena splendens",
		"acaena",
		281875
	],
	[
		"s3471477",
		"Acaena stangii",
		"acaena",
		3471477
	],
	[
		"s3723849",
		"Acaena stricta",
		"acaena",
		3723849
	],
	[
		"s281876",
		"Acaena subincisa",
		"acaena",
		281876
	],
	[
		"s2846824",
		"Acaena tenera",
		"acaena",
		2846824
	],
	[
		"s2732279",
		"Acaena tesca",
		"acaena",
		2732279
	],
	[
		"s3723850",
		"Acaena torilicarpa",
		"acaena",
		3723850
	],
	[
		"s2732292",
		"Acaena trifida",
		"acaena",
		2732292
	],
	[
		"s281878",
		"Acaena x anserovina",
		"acaena",
		281878
	],
	[
		"s2739281",
		"Achudemia boniana",
		"achudemia",
		2739281
	],
	[
		"s3083558",
		"Achudemia japonica",
		"achudemia",
		3083558
	],
	[
		"s2739276",
		"Achudemia javanica",
		"achudemia",
		2739276
	],
	[
		"s140993",
		"Adenostoma fasciculatum",
		"adenostoma",
		140993
	],
	[
		"s32216",
		"Adenostoma sparsifolium",
		"adenostoma",
		32216
	],
	[
		"s73670",
		"Adolphia californica",
		"adolphia",
		73670
	],
	[
		"s106656",
		"Adolphia infesta",
		"adolphia",
		106656
	],
	[
		"s3054370",
		"Afromorus mesozygia",
		"afromorus",
		3054370
	],
	[
		"s3742686",
		"Agrimonia aitchisonii",
		"agrimonia",
		3742686
	],
	[
		"s3083639",
		"Agrimonia bracteata",
		"agrimonia",
		3083639
	],
	[
		"s1068670",
		"Agrimonia coreana",
		"agrimonia",
		1068670
	],
	[
		"s57912",
		"Agrimonia eupatoria",
		"agrimonia",
		57912
	],
	[
		"s3464967",
		"Agrimonia gorovoii",
		"agrimonia",
		3464967
	],
	[
		"s3742687",
		"Agrimonia granulosa",
		"agrimonia",
		3742687
	],
	[
		"s932091",
		"Agrimonia gryposepala",
		"agrimonia",
		932091
	],
	[
		"s1068671",
		"Agrimonia incisa",
		"agrimonia",
		1068671
	],
	[
		"s1969215",
		"Agrimonia microcarpa",
		"agrimonia",
		1969215
	],
	[
		"s176125",
		"Agrimonia nipponica",
		"agrimonia",
		176125
	],
	[
		"s2906007",
		"Agrimonia noguchii",
		"agrimonia",
		2906007
	],
	[
		"s32217",
		"Agrimonia parviflora",
		"agrimonia",
		32217
	],
	[
		"s74656",
		"Agrimonia pilosa",
		"agrimonia",
		74656
	],
	[
		"s2950231",
		"Agrimonia pringlei",
		"agrimonia",
		2950231
	],
	[
		"s1155245",
		"Agrimonia procera",
		"agrimonia",
		1155245
	],
	[
		"s1655175",
		"Agrimonia pubescens",
		"agrimonia",
		1655175
	],
	[
		"s1973284",
		"Agrimonia repens",
		"agrimonia",
		1973284
	],
	[
		"s1663594",
		"Agrimonia rostellata",
		"agrimonia",
		1663594
	],
	[
		"s1503866",
		"Agrimonia striata",
		"agrimonia",
		1503866
	],
	[
		"s3742688",
		"Agrimonia villosa",
		"agrimonia",
		3742688
	],
	[
		"s3746035",
		"Alchemilla abchasica",
		"alchemilla",
		3746035
	],
	[
		"s3746036",
		"Alchemilla abramovii",
		"alchemilla",
		3746036
	],
	[
		"s478286",
		"Alchemilla abyssinica",
		"alchemilla",
		478286
	],
	[
		"s3746037",
		"Alchemilla achtarowii",
		"alchemilla",
		3746037
	],
	[
		"s3746038",
		"Alchemilla acrodon",
		"alchemilla",
		3746038
	],
	[
		"s3746039",
		"Alchemilla acropsila",
		"alchemilla",
		3746039
	],
	[
		"s3746040",
		"Alchemilla acrostegia",
		"alchemilla",
		3746040
	],
	[
		"s3746041",
		"Alchemilla acuminatidens",
		"alchemilla",
		3746041
	],
	[
		"s3746042",
		"Alchemilla acutata",
		"alchemilla",
		3746042
	],
	[
		"s3083676",
		"Alchemilla acutidens",
		"alchemilla",
		3083676
	],
	[
		"s3746043",
		"Alchemilla acutiformis",
		"alchemilla",
		3746043
	],
	[
		"s1572672",
		"Alchemilla acutiloba",
		"alchemilla",
		1572672
	],
	[
		"s3746044",
		"Alchemilla adelodictya",
		"alchemilla",
		3746044
	],
	[
		"s3083677",
		"Alchemilla aemula",
		"alchemilla",
		3083677
	],
	[
		"s3083678",
		"Alchemilla aenostipula",
		"alchemilla",
		3083678
	],
	[
		"s3746045",
		"Alchemilla aequatoriensis",
		"alchemilla",
		3746045
	],
	[
		"s3746046",
		"Alchemilla aequidens",
		"alchemilla",
		3746046
	],
	[
		"s3746047",
		"Alchemilla aggregata",
		"alchemilla",
		3746047
	],
	[
		"s3746048",
		"Alchemilla aksharmae",
		"alchemilla",
		3746048
	],
	[
		"s3746049",
		"Alchemilla alba",
		"alchemilla",
		3746049
	],
	[
		"s3746050",
		"Alchemilla albinervia",
		"alchemilla",
		3746050
	],
	[
		"s3746051",
		"Alchemilla alneti",
		"alchemilla",
		3746051
	],
	[
		"s1532253",
		"Alchemilla alpigena",
		"alchemilla",
		1532253
	],
	[
		"s57943",
		"Alchemilla alpina",
		"alchemilla",
		57943
	],
	[
		"s3746052",
		"Alchemilla alpinula",
		"alchemilla",
		3746052
	],
	[
		"s3113367",
		"Alchemilla altaica",
		"alchemilla",
		3113367
	],
	[
		"s3746053",
		"Alchemilla amardica",
		"alchemilla",
		3746053
	],
	[
		"s3746054",
		"Alchemilla amauroptera",
		"alchemilla",
		3746054
	],
	[
		"s3746055",
		"Alchemilla amblyodes",
		"alchemilla",
		3746055
	],
	[
		"s3746056",
		"Alchemilla amicorum",
		"alchemilla",
		3746056
	],
	[
		"s3746057",
		"Alchemilla amoena",
		"alchemilla",
		3746057
	],
	[
		"s3746058",
		"Alchemilla amphiargyrea",
		"alchemilla",
		3746058
	],
	[
		"s3746059",
		"Alchemilla amphibola",
		"alchemilla",
		3746059
	],
	[
		"s3746060",
		"Alchemilla amphipsila",
		"alchemilla",
		3746060
	],
	[
		"s3083679",
		"Alchemilla amphisericea",
		"alchemilla",
		3083679
	],
	[
		"s3746061",
		"Alchemilla anceps",
		"alchemilla",
		3746061
	],
	[
		"s907216",
		"Alchemilla andina",
		"alchemilla",
		907216
	],
	[
		"s478287",
		"Alchemilla andringitrensis",
		"alchemilla",
		478287
	],
	[
		"s478288",
		"Alchemilla angustata",
		"alchemilla",
		478288
	],
	[
		"s3746065",
		"Alchemilla angustiserrata",
		"alchemilla",
		3746065
	],
	[
		"s3746066",
		"Alchemilla animosa",
		"alchemilla",
		3746066
	],
	[
		"s3083680",
		"Alchemilla anisiaca",
		"alchemilla",
		3083680
	],
	[
		"s3746067",
		"Alchemilla anisopoda",
		"alchemilla",
		3746067
	],
	[
		"s3746068",
		"Alchemilla antiropata",
		"alchemilla",
		3746068
	],
	[
		"s3746069",
		"Alchemilla aperta",
		"alchemilla",
		3746069
	],
	[
		"s478360",
		"Alchemilla aphanoides",
		"alchemilla",
		478360
	],
	[
		"s3746070",
		"Alchemilla appressipila",
		"alchemilla",
		3746070
	],
	[
		"s478289",
		"Alchemilla aranica",
		"alchemilla",
		478289
	],
	[
		"s3746071",
		"Alchemilla argentidens",
		"alchemilla",
		3746071
	],
	[
		"s3004061",
		"Alchemilla arguteserrata",
		"alchemilla",
		3004061
	],
	[
		"s478290",
		"Alchemilla argyrophylla",
		"alchemilla",
		478290
	],
	[
		"s3746072",
		"Alchemilla armeniaca",
		"alchemilla",
		3746072
	],
	[
		"s3746073",
		"Alchemilla aroanica",
		"alchemilla",
		3746073
	],
	[
		"s57945",
		"Alchemilla arvensis",
		"alchemilla",
		57945
	],
	[
		"s3746074",
		"Alchemilla aspera",
		"alchemilla",
		3746074
	],
	[
		"s3746075",
		"Alchemilla aspleniifolia",
		"alchemilla",
		3746075
	],
	[
		"s3746076",
		"Alchemilla asteroantha",
		"alchemilla",
		3746076
	],
	[
		"s3746077",
		"Alchemilla atlantica",
		"alchemilla",
		3746077
	],
	[
		"s478291",
		"Alchemilla atriuscula",
		"alchemilla",
		478291
	],
	[
		"s3746078",
		"Alchemilla atropurpurea",
		"alchemilla",
		3746078
	],
	[
		"s3083681",
		"Alchemilla atrovirens",
		"alchemilla",
		3083681
	],
	[
		"s3746079",
		"Alchemilla auriculata",
		"alchemilla",
		3746079
	],
	[
		"s3746080",
		"Alchemilla austroaltaica",
		"alchemilla",
		3746080
	],
	[
		"s3746081",
		"Alchemilla austroitalica",
		"alchemilla",
		3746081
	],
	[
		"s3746082",
		"Alchemilla babiogorensis",
		"alchemilla",
		3746082
	],
	[
		"s3746083",
		"Alchemilla bakeri",
		"alchemilla",
		3746083
	],
	[
		"s3746084",
		"Alchemilla bakurianica",
		"alchemilla",
		3746084
	],
	[
		"s1891439",
		"Alchemilla baltica",
		"alchemilla",
		1891439
	],
	[
		"s3746085",
		"Alchemilla bandericensis",
		"alchemilla",
		3746085
	],
	[
		"s3746086",
		"Alchemilla barbatiflora",
		"alchemilla",
		3746086
	],
	[
		"s3746087",
		"Alchemilla barbulata",
		"alchemilla",
		3746087
	],
	[
		"s3746088",
		"Alchemilla benasquensis",
		"alchemilla",
		3746088
	],
	[
		"s3746089",
		"Alchemilla bertiscea",
		"alchemilla",
		3746089
	],
	[
		"s3746090",
		"Alchemilla betuletorum",
		"alchemilla",
		3746090
	],
	[
		"s3746091",
		"Alchemilla bezengiensis",
		"alchemilla",
		3746091
	],
	[
		"s1750582",
		"Alchemilla bicarpellata",
		"alchemilla",
		1750582
	],
	[
		"s3746092",
		"Alchemilla biquadrata",
		"alchemilla",
		3746092
	],
	[
		"s3746093",
		"Alchemilla biradiata",
		"alchemilla",
		3746093
	],
	[
		"s3746094",
		"Alchemilla bogumilii",
		"alchemilla",
		3746094
	],
	[
		"s3746095",
		"Alchemilla boleslai",
		"alchemilla",
		3746095
	],
	[
		"s1750578",
		"Alchemilla bolusii",
		"alchemilla",
		1750578
	],
	[
		"s3746096",
		"Alchemilla bombycina",
		"alchemilla",
		3746096
	],
	[
		"s3746097",
		"Alchemilla bonae",
		"alchemilla",
		3746097
	],
	[
		"s3746098",
		"Alchemilla boratynskii",
		"alchemilla",
		3746098
	],
	[
		"s3746099",
		"Alchemilla borderei",
		"alchemilla",
		3746099
	],
	[
		"s1891440",
		"Alchemilla borealis",
		"alchemilla",
		1891440
	],
	[
		"s3746100",
		"Alchemilla bornmuelleri",
		"alchemilla",
		3746100
	],
	[
		"s3746101",
		"Alchemilla brachetiana",
		"alchemilla",
		3746101
	],
	[
		"s3746102",
		"Alchemilla brachycodon",
		"alchemilla",
		3746102
	],
	[
		"s3746103",
		"Alchemilla braun-blanquetii",
		"alchemilla",
		3746103
	],
	[
		"s3746104",
		"Alchemilla brevidens",
		"alchemilla",
		3746104
	],
	[
		"s3083682",
		"Alchemilla breviloba",
		"alchemilla",
		3083682
	],
	[
		"s3746105",
		"Alchemilla brevituba",
		"alchemilla",
		3746105
	],
	[
		"s3746106",
		"Alchemilla brummittii",
		"alchemilla",
		3746106
	],
	[
		"s3746107",
		"Alchemilla bucovinensis",
		"alchemilla",
		3746107
	],
	[
		"s3746108",
		"Alchemilla bulgarica",
		"alchemilla",
		3746108
	],
	[
		"s3083683",
		"Alchemilla bungei",
		"alchemilla",
		3083683
	],
	[
		"s3746109",
		"Alchemilla burgensis",
		"alchemilla",
		3746109
	],
	[
		"s3746110",
		"Alchemilla bursensis",
		"alchemilla",
		3746110
	],
	[
		"s3746111",
		"Alchemilla buschii",
		"alchemilla",
		3746111
	],
	[
		"s3746112",
		"Alchemilla buseri",
		"alchemilla",
		3746112
	],
	[
		"s3746113",
		"Alchemilla buseriana",
		"alchemilla",
		3746113
	],
	[
		"s3746114",
		"Alchemilla cadinensis",
		"alchemilla",
		3746114
	],
	[
		"s3746115",
		"Alchemilla calviflora",
		"alchemilla",
		3746115
	],
	[
		"s3746116",
		"Alchemilla calvifolia",
		"alchemilla",
		3746116
	],
	[
		"s3746117",
		"Alchemilla calviformis",
		"alchemilla",
		3746117
	],
	[
		"s3746118",
		"Alchemilla camptopoda",
		"alchemilla",
		3746118
	],
	[
		"s3746119",
		"Alchemilla canifolia",
		"alchemilla",
		3746119
	],
	[
		"s1750579",
		"Alchemilla capensis",
		"alchemilla",
		1750579
	],
	[
		"s3746120",
		"Alchemilla capillacea",
		"alchemilla",
		3746120
	],
	[
		"s3746121",
		"Alchemilla carinthiaca",
		"alchemilla",
		3746121
	],
	[
		"s3746122",
		"Alchemilla carniolica",
		"alchemilla",
		3746122
	],
	[
		"s3083684",
		"Alchemilla cartalinica",
		"alchemilla",
		3083684
	],
	[
		"s3746123",
		"Alchemilla cartilaginea",
		"alchemilla",
		3746123
	],
	[
		"s3746124",
		"Alchemilla cashmeriana",
		"alchemilla",
		3746124
	],
	[
		"s3746125",
		"Alchemilla catachnoa",
		"alchemilla",
		3746125
	],
	[
		"s3083685",
		"Alchemilla catalaunica",
		"alchemilla",
		3083685
	],
	[
		"s3746126",
		"Alchemilla cataractarum",
		"alchemilla",
		3746126
	],
	[
		"s478292",
		"Alchemilla catochnoa",
		"alchemilla",
		478292
	],
	[
		"s3083686",
		"Alchemilla caucasica",
		"alchemilla",
		3083686
	],
	[
		"s3746127",
		"Alchemilla cavillieri",
		"alchemilla",
		3746127
	],
	[
		"s3746128",
		"Alchemilla cecilii",
		"alchemilla",
		3746128
	],
	[
		"s3746129",
		"Alchemilla ceroniana",
		"alchemilla",
		3746129
	],
	[
		"s478344",
		"Alchemilla cf. subnivalis Gehrke BG-Af 362",
		"alchemilla",
		478344
	],
	[
		"s3746130",
		"Alchemilla chalarodesma",
		"alchemilla",
		3746130
	],
	[
		"s2908702",
		"Alchemilla changaica",
		"alchemilla",
		2908702
	],
	[
		"s478293",
		"Alchemilla charbonneliana",
		"alchemilla",
		478293
	],
	[
		"s3746131",
		"Alchemilla chatiparensis",
		"alchemilla",
		3746131
	],
	[
		"s3746132",
		"Alchemilla cheirochlora",
		"alchemilla",
		3746132
	],
	[
		"s3746133",
		"Alchemilla chilitricha",
		"alchemilla",
		3746133
	],
	[
		"s3746134",
		"Alchemilla chionophila",
		"alchemilla",
		3746134
	],
	[
		"s1532254",
		"Alchemilla chirophylla",
		"alchemilla",
		1532254
	],
	[
		"s3746135",
		"Alchemilla chlorosericea",
		"alchemilla",
		3746135
	],
	[
		"s3746136",
		"Alchemilla chthamalea",
		"alchemilla",
		3746136
	],
	[
		"s3746137",
		"Alchemilla ciminensis",
		"alchemilla",
		3746137
	],
	[
		"s3083687",
		"Alchemilla cinerea",
		"alchemilla",
		3083687
	],
	[
		"s3746138",
		"Alchemilla circassica",
		"alchemilla",
		3746138
	],
	[
		"s3004198",
		"Alchemilla circularis",
		"alchemilla",
		3004198
	],
	[
		"s3746139",
		"Alchemilla circumdentata",
		"alchemilla",
		3746139
	],
	[
		"s3746140",
		"Alchemilla citrina",
		"alchemilla",
		3746140
	],
	[
		"s478294",
		"Alchemilla colorata",
		"alchemilla",
		478294
	],
	[
		"s478295",
		"Alchemilla colura",
		"alchemilla",
		478295
	],
	[
		"s3746141",
		"Alchemilla commixta",
		"alchemilla",
		3746141
	],
	[
		"s3746142",
		"Alchemilla compactilis",
		"alchemilla",
		3746142
	],
	[
		"s3746143",
		"Alchemilla compta",
		"alchemilla",
		3746143
	],
	[
		"s3746144",
		"Alchemilla condensa",
		"alchemilla",
		3746144
	],
	[
		"s3746145",
		"Alchemilla confertula",
		"alchemilla",
		3746145
	],
	[
		"s3083688",
		"Alchemilla conglobata",
		"alchemilla",
		3083688
	],
	[
		"s1395544",
		"Alchemilla conjuncta",
		"alchemilla",
		1395544
	],
	[
		"s2717777",
		"Alchemilla connivens",
		"alchemilla",
		2717777
	],
	[
		"s3746146",
		"Alchemilla consobrina",
		"alchemilla",
		3746146
	],
	[
		"s3746147",
		"Alchemilla contractilis",
		"alchemilla",
		3746147
	],
	[
		"s3746148",
		"Alchemilla controversa",
		"alchemilla",
		3746148
	],
	[
		"s3746149",
		"Alchemilla corcontica",
		"alchemilla",
		3746149
	],
	[
		"s478296",
		"Alchemilla coriacea",
		"alchemilla",
		478296
	],
	[
		"s3746150",
		"Alchemilla coruscans",
		"alchemilla",
		3746150
	],
	[
		"s3746151",
		"Alchemilla crassa",
		"alchemilla",
		3746151
	],
	[
		"s3746152",
		"Alchemilla crassicaulis",
		"alchemilla",
		3746152
	],
	[
		"s3746153",
		"Alchemilla crebridens",
		"alchemilla",
		3746153
	],
	[
		"s3746154",
		"Alchemilla crenulata",
		"alchemilla",
		3746154
	],
	[
		"s478297",
		"Alchemilla crinita",
		"alchemilla",
		478297
	],
	[
		"s3746155",
		"Alchemilla croatica",
		"alchemilla",
		3746155
	],
	[
		"s478298",
		"Alchemilla cryptantha",
		"alchemilla",
		478298
	],
	[
		"s3746156",
		"Alchemilla cunctatrix",
		"alchemilla",
		3746156
	],
	[
		"s3746157",
		"Alchemilla curaica",
		"alchemilla",
		3746157
	],
	[
		"s3746158",
		"Alchemilla curta",
		"alchemilla",
		3746158
	],
	[
		"s3746159",
		"Alchemilla curtiloba",
		"alchemilla",
		3746159
	],
	[
		"s3746160",
		"Alchemilla curtischista",
		"alchemilla",
		3746160
	],
	[
		"s3746161",
		"Alchemilla curvidens",
		"alchemilla",
		3746161
	],
	[
		"s1891441",
		"Alchemilla cymatophylla",
		"alchemilla",
		1891441
	],
	[
		"s3004199",
		"Alchemilla cyrtopleura",
		"alchemilla",
		3004199
	],
	[
		"s3746162",
		"Alchemilla czamsinensis",
		"alchemilla",
		3746162
	],
	[
		"s3746163",
		"Alchemilla czaryschensis",
		"alchemilla",
		3746163
	],
	[
		"s3746164",
		"Alchemilla czywczynensis",
		"alchemilla",
		3746164
	],
	[
		"s3746165",
		"Alchemilla daghestanica",
		"alchemilla",
		3746165
	],
	[
		"s3746166",
		"Alchemilla damianicensis",
		"alchemilla",
		3746166
	],
	[
		"s3746167",
		"Alchemilla dasyclada",
		"alchemilla",
		3746167
	],
	[
		"s3083689",
		"Alchemilla dasycrater",
		"alchemilla",
		3083689
	],
	[
		"s3746168",
		"Alchemilla debilicaulis",
		"alchemilla",
		3746168
	],
	[
		"s3083690",
		"Alchemilla debilis",
		"alchemilla",
		3083690
	],
	[
		"s3083691",
		"Alchemilla decalvans",
		"alchemilla",
		3083691
	],
	[
		"s478299",
		"Alchemilla decumbens",
		"alchemilla",
		478299
	],
	[
		"s3746169",
		"Alchemilla decurrens",
		"alchemilla",
		3746169
	],
	[
		"s3746170",
		"Alchemilla delitescens",
		"alchemilla",
		3746170
	],
	[
		"s3746171",
		"Alchemilla delphinensis",
		"alchemilla",
		3746171
	],
	[
		"s3083692",
		"Alchemilla demissa",
		"alchemilla",
		3083692
	],
	[
		"s3083693",
		"Alchemilla denticulata",
		"alchemilla",
		3083693
	],
	[
		"s3083694",
		"Alchemilla depexa",
		"alchemilla",
		3083694
	],
	[
		"s3083695",
		"Alchemilla devestiens",
		"alchemilla",
		3083695
	],
	[
		"s1750580",
		"Alchemilla dewildemanii",
		"alchemilla",
		1750580
	],
	[
		"s3746172",
		"Alchemilla deylii",
		"alchemilla",
		3746172
	],
	[
		"s3746173",
		"Alchemilla diademata",
		"alchemilla",
		3746173
	],
	[
		"s3746174",
		"Alchemilla diglossa",
		"alchemilla",
		3746174
	],
	[
		"s3746175",
		"Alchemilla diluta",
		"alchemilla",
		3746175
	],
	[
		"s478361",
		"Alchemilla diplophylla",
		"alchemilla",
		478361
	],
	[
		"s3746176",
		"Alchemilla divaricans",
		"alchemilla",
		3746176
	],
	[
		"s3746177",
		"Alchemilla diversiloba",
		"alchemilla",
		3746177
	],
	[
		"s3083696",
		"Alchemilla diversipes",
		"alchemilla",
		3083696
	],
	[
		"s3746178",
		"Alchemilla dolichotoma",
		"alchemilla",
		3746178
	],
	[
		"s3083697",
		"Alchemilla dombaica",
		"alchemilla",
		3083697
	],
	[
		"s3746179",
		"Alchemilla domingensis",
		"alchemilla",
		3746179
	],
	[
		"s3746180",
		"Alchemilla dostalii",
		"alchemilla",
		3746180
	],
	[
		"s3083698",
		"Alchemilla dura",
		"alchemilla",
		3083698
	],
	[
		"s3746181",
		"Alchemilla duthieana",
		"alchemilla",
		3746181
	],
	[
		"s3083699",
		"Alchemilla dzhavakhetica",
		"alchemilla",
		3083699
	],
	[
		"s3746182",
		"Alchemilla echinogloba",
		"alchemilla",
		3746182
	],
	[
		"s3746183",
		"Alchemilla effusa",
		"alchemilla",
		3746183
	],
	[
		"s3746184",
		"Alchemilla elata",
		"alchemilla",
		3746184
	],
	[
		"s3746185",
		"Alchemilla elevitensis",
		"alchemilla",
		3746185
	],
	[
		"s478303",
		"Alchemilla elgonensis",
		"alchemilla",
		478303
	],
	[
		"s3746186",
		"Alchemilla elisabethae",
		"alchemilla",
		3746186
	],
	[
		"s478301",
		"Alchemilla ellenbeckii",
		"alchemilla",
		478301
	],
	[
		"s3746187",
		"Alchemilla ellenbergiana",
		"alchemilla",
		3746187
	],
	[
		"s478302",
		"Alchemilla elongata",
		"alchemilla",
		478302
	],
	[
		"s3746188",
		"Alchemilla epidasys",
		"alchemilla",
		3746188
	],
	[
		"s478304",
		"Alchemilla epipsila",
		"alchemilla",
		478304
	],
	[
		"s3083700",
		"Alchemilla erectilis",
		"alchemilla",
		3083700
	],
	[
		"s3746189",
		"Alchemilla ericoides",
		"alchemilla",
		3746189
	],
	[
		"s137431",
		"Alchemilla erythropoda",
		"alchemilla",
		137431
	],
	[
		"s3746190",
		"Alchemilla erythropodoides",
		"alchemilla",
		3746190
	],
	[
		"s3746191",
		"Alchemilla erzincanensis",
		"alchemilla",
		3746191
	],
	[
		"s3746192",
		"Alchemilla espotensis",
		"alchemilla",
		3746192
	],
	[
		"s3746193",
		"Alchemilla eugenii",
		"alchemilla",
		3746193
	],
	[
		"s3746194",
		"Alchemilla eurystoma",
		"alchemilla",
		3746194
	],
	[
		"s3746195",
		"Alchemilla exaperta",
		"alchemilla",
		3746195
	],
	[
		"s3746196",
		"Alchemilla excentrica",
		"alchemilla",
		3746196
	],
	[
		"s478305",
		"Alchemilla exigua",
		"alchemilla",
		478305
	],
	[
		"s3746197",
		"Alchemilla exilis",
		"alchemilla",
		3746197
	],
	[
		"s3746198",
		"Alchemilla exsanguis",
		"alchemilla",
		3746198
	],
	[
		"s3746199",
		"Alchemilla exsculpta",
		"alchemilla",
		3746199
	],
	[
		"s3746200",
		"Alchemilla exuens",
		"alchemilla",
		3746200
	],
	[
		"s3083701",
		"Alchemilla exul",
		"alchemilla",
		3083701
	],
	[
		"s478306",
		"Alchemilla faeroensis",
		"alchemilla",
		478306
	],
	[
		"s478307",
		"Alchemilla fallax",
		"alchemilla",
		478307
	],
	[
		"s3746201",
		"Alchemilla falsadenta",
		"alchemilla",
		3746201
	],
	[
		"s3746202",
		"Alchemilla farinosa",
		"alchemilla",
		3746202
	],
	[
		"s3746203",
		"Alchemilla federiciana",
		"alchemilla",
		3746203
	],
	[
		"s1155247",
		"Alchemilla filicaulis",
		"alchemilla",
		1155247
	],
	[
		"s3083702",
		"Alchemilla firma",
		"alchemilla",
		3083702
	],
	[
		"s3746204",
		"Alchemilla firminiana",
		"alchemilla",
		3746204
	],
	[
		"s478308",
		"Alchemilla fischeri",
		"alchemilla",
		478308
	],
	[
		"s478309",
		"Alchemilla fissa",
		"alchemilla",
		478309
	],
	[
		"s3746205",
		"Alchemilla fissimima",
		"alchemilla",
		3746205
	],
	[
		"s478310",
		"Alchemilla flabellata",
		"alchemilla",
		478310
	],
	[
		"s3083703",
		"Alchemilla flavescens",
		"alchemilla",
		3083703
	],
	[
		"s3746206",
		"Alchemilla flavicoma",
		"alchemilla",
		3746206
	],
	[
		"s3746207",
		"Alchemilla flavovirens",
		"alchemilla",
		3746207
	],
	[
		"s3746208",
		"Alchemilla flexicaulis",
		"alchemilla",
		3746208
	],
	[
		"s3083704",
		"Alchemilla florulenta",
		"alchemilla",
		3083704
	],
	[
		"s3746209",
		"Alchemilla fluminea",
		"alchemilla",
		3746209
	],
	[
		"s3083705",
		"Alchemilla fokinii",
		"alchemilla",
		3083705
	],
	[
		"s3746210",
		"Alchemilla fontinalis",
		"alchemilla",
		3746210
	],
	[
		"s3746211",
		"Alchemilla fontqueri",
		"alchemilla",
		3746211
	],
	[
		"s3083706",
		"Alchemilla frigens",
		"alchemilla",
		3083706
	],
	[
		"s3746212",
		"Alchemilla frondosa",
		"alchemilla",
		3746212
	],
	[
		"s3746213",
		"Alchemilla frost-olsenii",
		"alchemilla",
		3746213
	],
	[
		"s3083707",
		"Alchemilla fulgens",
		"alchemilla",
		3083707
	],
	[
		"s3083708",
		"Alchemilla fulgida",
		"alchemilla",
		3083708
	],
	[
		"s907219",
		"Alchemilla fulvescens",
		"alchemilla",
		907219
	],
	[
		"s3746214",
		"Alchemilla fusoidea",
		"alchemilla",
		3746214
	],
	[
		"s3746215",
		"Alchemilla gaillardiana",
		"alchemilla",
		3746215
	],
	[
		"s3746216",
		"Alchemilla galaninii",
		"alchemilla",
		3746216
	],
	[
		"s907210",
		"Alchemilla galioides",
		"alchemilla",
		907210
	],
	[
		"s3746217",
		"Alchemilla galkinae",
		"alchemilla",
		3746217
	],
	[
		"s3083709",
		"Alchemilla galpinii",
		"alchemilla",
		3083709
	],
	[
		"s3746218",
		"Alchemilla georgica",
		"alchemilla",
		3746218
	],
	[
		"s3083710",
		"Alchemilla gibberulosa",
		"alchemilla",
		3083710
	],
	[
		"s3746219",
		"Alchemilla giewontica",
		"alchemilla",
		3746219
	],
	[
		"s3746220",
		"Alchemilla gigantodus",
		"alchemilla",
		3746220
	],
	[
		"s3746221",
		"Alchemilla gilgitensis",
		"alchemilla",
		3746221
	],
	[
		"s3746222",
		"Alchemilla gingolphiana",
		"alchemilla",
		3746222
	],
	[
		"s1155248",
		"Alchemilla glabra",
		"alchemilla",
		1155248
	],
	[
		"s3746223",
		"Alchemilla glabricaulis",
		"alchemilla",
		3746223
	],
	[
		"s3746224",
		"Alchemilla glabriformis",
		"alchemilla",
		3746224
	],
	[
		"s478311",
		"Alchemilla glacialis",
		"alchemilla",
		478311
	],
	[
		"s667203",
		"Alchemilla glaucescens",
		"alchemilla",
		667203
	],
	[
		"s669616",
		"Alchemilla glomerulans",
		"alchemilla",
		669616
	],
	[
		"s3746225",
		"Alchemilla glyphodonta",
		"alchemilla",
		3746225
	],
	[
		"s3746226",
		"Alchemilla goloskokovii",
		"alchemilla",
		3746226
	],
	[
		"s3083711",
		"Alchemilla gorcensis",
		"alchemilla",
		3083711
	],
	[
		"s3746227",
		"Alchemilla gourzae",
		"alchemilla",
		3746227
	],
	[
		"s478312",
		"Alchemilla gracilipes",
		"alchemilla",
		478312
	],
	[
		"s2768805",
		"Alchemilla gracilis",
		"alchemilla",
		2768805
	],
	[
		"s3746228",
		"Alchemilla grandiceps",
		"alchemilla",
		3746228
	],
	[
		"s3746229",
		"Alchemilla grandidens",
		"alchemilla",
		3746229
	],
	[
		"s478313",
		"Alchemilla granvikii",
		"alchemilla",
		478313
	],
	[
		"s478314",
		"Alchemilla grenieri",
		"alchemilla",
		478314
	],
	[
		"s3746230",
		"Alchemilla gretae-gregorii",
		"alchemilla",
		3746230
	],
	[
		"s3090045",
		"Alchemilla grisebachiana",
		"alchemilla",
		3090045
	],
	[
		"s3083712",
		"Alchemilla grossheimii",
		"alchemilla",
		3083712
	],
	[
		"s3746231",
		"Alchemilla gruneica",
		"alchemilla",
		3746231
	],
	[
		"s3121464",
		"Alchemilla guatemalensis",
		"alchemilla",
		3121464
	],
	[
		"s2908916",
		"Alchemilla gubanovii",
		"alchemilla",
		2908916
	],
	[
		"s3746232",
		"Alchemilla gymnopoda",
		"alchemilla",
		3746232
	],
	[
		"s478315",
		"Alchemilla hageniae",
		"alchemilla",
		478315
	],
	[
		"s3746233",
		"Alchemilla hamzaoglui",
		"alchemilla",
		3746233
	],
	[
		"s3746234",
		"Alchemilla harae",
		"alchemilla",
		3746234
	],
	[
		"s3746235",
		"Alchemilla haraldii",
		"alchemilla",
		3746235
	],
	[
		"s478316",
		"Alchemilla haumanii",
		"alchemilla",
		478316
	],
	[
		"s3004200",
		"Alchemilla hebescens",
		"alchemilla",
		3004200
	],
	[
		"s3746236",
		"Alchemilla helenae",
		"alchemilla",
		3746236
	],
	[
		"s3083713",
		"Alchemilla hemicycla",
		"alchemilla",
		3083713
	],
	[
		"s3746237",
		"Alchemilla hendrickxii",
		"alchemilla",
		3746237
	],
	[
		"s478317",
		"Alchemilla heptagona",
		"alchemilla",
		478317
	],
	[
		"s3746238",
		"Alchemilla hessii",
		"alchemilla",
		3746238
	],
	[
		"s3746239",
		"Alchemilla heterophylla",
		"alchemilla",
		3746239
	],
	[
		"s3083714",
		"Alchemilla heteropoda",
		"alchemilla",
		3083714
	],
	[
		"s3746240",
		"Alchemilla heteroschista",
		"alchemilla",
		3746240
	],
	[
		"s3083715",
		"Alchemilla heterotricha",
		"alchemilla",
		3083715
	],
	[
		"s3083716",
		"Alchemilla hians",
		"alchemilla",
		3083716
	],
	[
		"s478318",
		"Alchemilla hildebrandtii",
		"alchemilla",
		478318
	],
	[
		"s1891444",
		"Alchemilla hirsuticaulis",
		"alchemilla",
		1891444
	],
	[
		"s3746241",
		"Alchemilla hirsutiflora",
		"alchemilla",
		3746241
	],
	[
		"s3746242",
		"Alchemilla hirsutissima",
		"alchemilla",
		3746242
	],
	[
		"s3083717",
		"Alchemilla hirsutopetiolata",
		"alchemilla",
		3083717
	],
	[
		"s907215",
		"Alchemilla hirta",
		"alchemilla",
		907215
	],
	[
		"s3083718",
		"Alchemilla hirtipedicellata",
		"alchemilla",
		3083718
	],
	[
		"s3746243",
		"Alchemilla hirtipes",
		"alchemilla",
		3746243
	],
	[
		"s478319",
		"Alchemilla hispanica",
		"alchemilla",
		478319
	],
	[
		"s478362",
		"Alchemilla hispidula",
		"alchemilla",
		478362
	],
	[
		"s3746244",
		"Alchemilla hissarica",
		"alchemilla",
		3746244
	],
	[
		"s3746245",
		"Alchemilla holobasis",
		"alchemilla",
		3746245
	],
	[
		"s3746246",
		"Alchemilla holocycla",
		"alchemilla",
		3746246
	],
	[
		"s478363",
		"Alchemilla holosericea",
		"alchemilla",
		478363
	],
	[
		"s3746247",
		"Alchemilla homoeophylla",
		"alchemilla",
		3746247
	],
	[
		"s3083719",
		"Alchemilla hoppeana",
		"alchemilla",
		3083719
	],
	[
		"s3746248",
		"Alchemilla hoppeaniformis",
		"alchemilla",
		3746248
	],
	[
		"s3746249",
		"Alchemilla hoverlensis",
		"alchemilla",
		3746249
	],
	[
		"s3746250",
		"Alchemilla humilicaulis",
		"alchemilla",
		3746250
	],
	[
		"s1532255",
		"Alchemilla hybrida",
		"alchemilla",
		1532255
	],
	[
		"s3746251",
		"Alchemilla hyperborea",
		"alchemilla",
		3746251
	],
	[
		"s3746252",
		"Alchemilla hypercycla",
		"alchemilla",
		3746252
	],
	[
		"s3746253",
		"Alchemilla hyperptycha",
		"alchemilla",
		3746253
	],
	[
		"s3746254",
		"Alchemilla hypochlora",
		"alchemilla",
		3746254
	],
	[
		"s3746255",
		"Alchemilla hypotricha",
		"alchemilla",
		3746255
	],
	[
		"s3746256",
		"Alchemilla hyrcana",
		"alchemilla",
		3746256
	],
	[
		"s478320",
		"Alchemilla ilerdensis",
		"alchemilla",
		478320
	],
	[
		"s3083720",
		"Alchemilla imberbis",
		"alchemilla",
		3083720
	],
	[
		"s3746257",
		"Alchemilla impedicellata",
		"alchemilla",
		3746257
	],
	[
		"s3083721",
		"Alchemilla impexa",
		"alchemilla",
		3083721
	],
	[
		"s3746258",
		"Alchemilla impolita",
		"alchemilla",
		3746258
	],
	[
		"s478321",
		"Alchemilla incisa",
		"alchemilla",
		478321
	],
	[
		"s3746259",
		"Alchemilla inconcinna",
		"alchemilla",
		3746259
	],
	[
		"s3746260",
		"Alchemilla incurvata",
		"alchemilla",
		3746260
	],
	[
		"s3746261",
		"Alchemilla indica",
		"alchemilla",
		3746261
	],
	[
		"s478322",
		"Alchemilla indivisa",
		"alchemilla",
		478322
	],
	[
		"s3746262",
		"Alchemilla indurata",
		"alchemilla",
		3746262
	],
	[
		"s3746263",
		"Alchemilla infravallesia",
		"alchemilla",
		3746263
	],
	[
		"s3083722",
		"Alchemilla iniquiformis",
		"alchemilla",
		3083722
	],
	[
		"s3746264",
		"Alchemilla insignis",
		"alchemilla",
		3746264
	],
	[
		"s3083723",
		"Alchemilla integribasis",
		"alchemilla",
		3083723
	],
	[
		"s3746265",
		"Alchemilla iratiana",
		"alchemilla",
		3746265
	],
	[
		"s3746266",
		"Alchemilla iremelica",
		"alchemilla",
		3746266
	],
	[
		"s3746267",
		"Alchemilla ischnocarpa",
		"alchemilla",
		3746267
	],
	[
		"s3746268",
		"Alchemilla isfarensis",
		"alchemilla",
		3746268
	],
	[
		"s3746269",
		"Alchemilla isodonta",
		"alchemilla",
		3746269
	],
	[
		"s3083724",
		"Alchemilla jailae",
		"alchemilla",
		3083724
	],
	[
		"s907217",
		"Alchemilla jamesonii",
		"alchemilla",
		907217
	],
	[
		"s176124",
		"Alchemilla japonica",
		"alchemilla",
		176124
	],
	[
		"s3746270",
		"Alchemilla jaquetiana",
		"alchemilla",
		3746270
	],
	[
		"s3746271",
		"Alchemilla jaroschenkoi",
		"alchemilla",
		3746271
	],
	[
		"s3746272",
		"Alchemilla jasiewiczii",
		"alchemilla",
		3746272
	],
	[
		"s478323",
		"Alchemilla johnstonii",
		"alchemilla",
		478323
	],
	[
		"s3746273",
		"Alchemilla jugensis",
		"alchemilla",
		3746273
	],
	[
		"s3746274",
		"Alchemilla jumrukczalica",
		"alchemilla",
		3746274
	],
	[
		"s3746275",
		"Alchemilla kazbekensis",
		"alchemilla",
		3746275
	],
	[
		"s3746276",
		"Alchemilla kemlensis",
		"alchemilla",
		3746276
	],
	[
		"s3083725",
		"Alchemilla kerneri",
		"alchemilla",
		3083725
	],
	[
		"s3746277",
		"Alchemilla killipii",
		"alchemilla",
		3746277
	],
	[
		"s3746278",
		"Alchemilla kishangangensis",
		"alchemilla",
		3746278
	],
	[
		"s478324",
		"Alchemilla kiwuensis",
		"alchemilla",
		478324
	],
	[
		"s3746279",
		"Alchemilla kolaensis",
		"alchemilla",
		3746279
	],
	[
		"s3746280",
		"Alchemilla kornasiana",
		"alchemilla",
		3746280
	],
	[
		"s3746281",
		"Alchemilla kosiarensis",
		"alchemilla",
		3746281
	],
	[
		"s3083726",
		"Alchemilla kozlovskii",
		"alchemilla",
		3083726
	],
	[
		"s3746282",
		"Alchemilla krassovskiana",
		"alchemilla",
		3746282
	],
	[
		"s3083727",
		"Alchemilla krylovii",
		"alchemilla",
		3083727
	],
	[
		"s3746283",
		"Alchemilla kulczynskii",
		"alchemilla",
		3746283
	],
	[
		"s3746284",
		"Alchemilla kungwatanensis",
		"alchemilla",
		3746284
	],
	[
		"s3746285",
		"Alchemilla kvarkushensis",
		"alchemilla",
		3746285
	],
	[
		"s3746286",
		"Alchemilla ladislai",
		"alchemilla",
		3746286
	],
	[
		"s3083728",
		"Alchemilla laeta",
		"alchemilla",
		3083728
	],
	[
		"s3746287",
		"Alchemilla laeticolor",
		"alchemilla",
		3746287
	],
	[
		"s3746288",
		"Alchemilla laevipes",
		"alchemilla",
		3746288
	],
	[
		"s3746289",
		"Alchemilla lainzii",
		"alchemilla",
		3746289
	],
	[
		"s3746290",
		"Alchemilla languescens",
		"alchemilla",
		3746290
	],
	[
		"s3083729",
		"Alchemilla languida",
		"alchemilla",
		3083729
	],
	[
		"s3746291",
		"Alchemilla lanuginosa",
		"alchemilla",
		3746291
	],
	[
		"s478325",
		"Alchemilla lapeyrousii",
		"alchemilla",
		478325
	],
	[
		"s3746292",
		"Alchemilla lasenii",
		"alchemilla",
		3746292
	],
	[
		"s3746293",
		"Alchemilla laxa",
		"alchemilla",
		3746293
	],
	[
		"s2998791",
		"Alchemilla laxescens",
		"alchemilla",
		2998791
	],
	[
		"s3746294",
		"Alchemilla ledebourii",
		"alchemilla",
		3746294
	],
	[
		"s3746295",
		"Alchemilla legionensis",
		"alchemilla",
		3746295
	],
	[
		"s3746296",
		"Alchemilla leiophylla",
		"alchemilla",
		3746296
	],
	[
		"s3746297",
		"Alchemilla leiophylloides",
		"alchemilla",
		3746297
	],
	[
		"s3083730",
		"Alchemilla leptoclada",
		"alchemilla",
		3083730
	],
	[
		"s3083731",
		"Alchemilla lessingiana",
		"alchemilla",
		3083731
	],
	[
		"s3746298",
		"Alchemilla leutei",
		"alchemilla",
		3746298
	],
	[
		"s3746299",
		"Alchemilla levichevii",
		"alchemilla",
		3746299
	],
	[
		"s3083732",
		"Alchemilla lindbergiana",
		"alchemilla",
		3083732
	],
	[
		"s3083733",
		"Alchemilla lineata",
		"alchemilla",
		3083733
	],
	[
		"s3746300",
		"Alchemilla lipschitzii",
		"alchemilla",
		3746300
	],
	[
		"s3083734",
		"Alchemilla lithophila",
		"alchemilla",
		3083734
	],
	[
		"s3746301",
		"Alchemilla litwinowii",
		"alchemilla",
		3746301
	],
	[
		"s478326",
		"Alchemilla longana",
		"alchemilla",
		478326
	],
	[
		"s3746302",
		"Alchemilla longidens",
		"alchemilla",
		3746302
	],
	[
		"s3083735",
		"Alchemilla longinodis",
		"alchemilla",
		3083735
	],
	[
		"s3746303",
		"Alchemilla longipedicellata",
		"alchemilla",
		3746303
	],
	[
		"s3083736",
		"Alchemilla longipes",
		"alchemilla",
		3083736
	],
	[
		"s3746304",
		"Alchemilla longituba",
		"alchemilla",
		3746304
	],
	[
		"s3746305",
		"Alchemilla longiuscula",
		"alchemilla",
		3746305
	],
	[
		"s3746306",
		"Alchemilla looseri",
		"alchemilla",
		3746306
	],
	[
		"s3746307",
		"Alchemilla lorata",
		"alchemilla",
		3746307
	],
	[
		"s3746308",
		"Alchemilla loxotropa",
		"alchemilla",
		3746308
	],
	[
		"s3746309",
		"Alchemilla lucida",
		"alchemilla",
		3746309
	],
	[
		"s3746310",
		"Alchemilla ludovitiana",
		"alchemilla",
		3746310
	],
	[
		"s3746311",
		"Alchemilla lunaria",
		"alchemilla",
		3746311
	],
	[
		"s3746312",
		"Alchemilla lusitanica",
		"alchemilla",
		3746312
	],
	[
		"s3746313",
		"Alchemilla lycopodioides",
		"alchemilla",
		3746313
	],
	[
		"s3746314",
		"Alchemilla lydiae",
		"alchemilla",
		3746314
	],
	[
		"s3746315",
		"Alchemilla macrescens",
		"alchemilla",
		3746315
	],
	[
		"s3746316",
		"Alchemilla macrochira",
		"alchemilla",
		3746316
	],
	[
		"s3746317",
		"Alchemilla macroclada",
		"alchemilla",
		3746317
	],
	[
		"s3746318",
		"Alchemilla madurensis",
		"alchemilla",
		3746318
	],
	[
		"s3746319",
		"Alchemilla malimontana",
		"alchemilla",
		3746319
	],
	[
		"s3746320",
		"Alchemilla malyi",
		"alchemilla",
		3746320
	],
	[
		"s478364",
		"Alchemilla mandoniana",
		"alchemilla",
		478364
	],
	[
		"s3746321",
		"Alchemilla mantoniae",
		"alchemilla",
		3746321
	],
	[
		"s3746322",
		"Alchemilla maradykovensis",
		"alchemilla",
		3746322
	],
	[
		"s3746323",
		"Alchemilla marginalis",
		"alchemilla",
		3746323
	],
	[
		"s3746324",
		"Alchemilla marginata",
		"alchemilla",
		3746324
	],
	[
		"s3746325",
		"Alchemilla marsica",
		"alchemilla",
		3746325
	],
	[
		"s3746326",
		"Alchemilla martinii",
		"alchemilla",
		3746326
	],
	[
		"s3746327",
		"Alchemilla mastodonta",
		"alchemilla",
		3746327
	],
	[
		"s3746328",
		"Alchemilla matreiensis",
		"alchemilla",
		3746328
	],
	[
		"s3746329",
		"Alchemilla maureri",
		"alchemilla",
		3746329
	],
	[
		"s3746330",
		"Alchemilla mazandarana",
		"alchemilla",
		3746330
	],
	[
		"s3746331",
		"Alchemilla mebii",
		"alchemilla",
		3746331
	],
	[
		"s3746332",
		"Alchemilla megalodonta",
		"alchemilla",
		3746332
	],
	[
		"s3746333",
		"Alchemilla melancholica",
		"alchemilla",
		3746333
	],
	[
		"s3746334",
		"Alchemilla melanoscytos",
		"alchemilla",
		3746334
	],
	[
		"s1572673",
		"Alchemilla micans",
		"alchemilla",
		1572673
	],
	[
		"s3746335",
		"Alchemilla michelsonii",
		"alchemilla",
		3746335
	],
	[
		"s478327",
		"Alchemilla microbetula",
		"alchemilla",
		478327
	],
	[
		"s1053328",
		"Alchemilla microcarpa",
		"alchemilla",
		1053328
	],
	[
		"s3746336",
		"Alchemilla microcephala",
		"alchemilla",
		3746336
	],
	[
		"s3083737",
		"Alchemilla microdictya",
		"alchemilla",
		3083737
	],
	[
		"s3746337",
		"Alchemilla microdonta",
		"alchemilla",
		3746337
	],
	[
		"s3746338",
		"Alchemilla microscopica",
		"alchemilla",
		3746338
	],
	[
		"s3746339",
		"Alchemilla microsphaerica",
		"alchemilla",
		3746339
	],
	[
		"s2998792",
		"Alchemilla mininzonii",
		"alchemilla",
		2998792
	],
	[
		"s478328",
		"Alchemilla minor",
		"alchemilla",
		478328
	],
	[
		"s3746340",
		"Alchemilla minusculiflora",
		"alchemilla",
		3746340
	],
	[
		"s3746341",
		"Alchemilla minutidens",
		"alchemilla",
		3746341
	],
	[
		"s3746342",
		"Alchemilla mollifolia",
		"alchemilla",
		3746342
	],
	[
		"s32218",
		"Alchemilla mollis",
		"alchemilla",
		32218
	],
	[
		"s3746343",
		"Alchemilla moncophila",
		"alchemilla",
		3746343
	],
	[
		"s1532256",
		"Alchemilla monticola",
		"alchemilla",
		1532256
	],
	[
		"s478329",
		"Alchemilla montserratii",
		"alchemilla",
		478329
	],
	[
		"s3746344",
		"Alchemilla muldaschevii",
		"alchemilla",
		3746344
	],
	[
		"s3746345",
		"Alchemilla multidens",
		"alchemilla",
		3746345
	],
	[
		"s3746346",
		"Alchemilla multiloba",
		"alchemilla",
		3746346
	],
	[
		"s1891445",
		"Alchemilla murbeckiana",
		"alchemilla",
		1891445
	],
	[
		"s3746347",
		"Alchemilla murisserica",
		"alchemilla",
		3746347
	],
	[
		"s3746348",
		"Alchemilla mutisii",
		"alchemilla",
		3746348
	],
	[
		"s3746349",
		"Alchemilla mystrostigma",
		"alchemilla",
		3746349
	],
	[
		"s3746350",
		"Alchemilla nafarroana",
		"alchemilla",
		3746350
	],
	[
		"s3083738",
		"Alchemilla natalensis",
		"alchemilla",
		3083738
	],
	[
		"s3746351",
		"Alchemilla neglecta",
		"alchemilla",
		3746351
	],
	[
		"s2969128",
		"Alchemilla nemoralis",
		"alchemilla",
		2969128
	],
	[
		"s3746352",
		"Alchemilla neomanifesta",
		"alchemilla",
		3746352
	],
	[
		"s3746353",
		"Alchemilla nicolsonii",
		"alchemilla",
		3746353
	],
	[
		"s3746354",
		"Alchemilla nietofelineri",
		"alchemilla",
		3746354
	],
	[
		"s3746355",
		"Alchemilla niltarensis",
		"alchemilla",
		3746355
	],
	[
		"s3746356",
		"Alchemilla niphogeton",
		"alchemilla",
		3746356
	],
	[
		"s478330",
		"Alchemilla nitida",
		"alchemilla",
		478330
	],
	[
		"s478365",
		"Alchemilla nivalis",
		"alchemilla",
		478365
	],
	[
		"s3746357",
		"Alchemilla norica",
		"alchemilla",
		3746357
	],
	[
		"s2793080",
		"Alchemilla norvegica",
		"alchemilla",
		2793080
	],
	[
		"s3746358",
		"Alchemilla nudans",
		"alchemilla",
		3746358
	],
	[
		"s3746359",
		"Alchemilla nydeggeriana",
		"alchemilla",
		3746359
	],
	[
		"s3746360",
		"Alchemilla obconiciflora",
		"alchemilla",
		3746360
	],
	[
		"s3746361",
		"Alchemilla obesa",
		"alchemilla",
		3746361
	],
	[
		"s3746362",
		"Alchemilla obscura",
		"alchemilla",
		3746362
	],
	[
		"s3746363",
		"Alchemilla obtegens",
		"alchemilla",
		3746363
	],
	[
		"s3083739",
		"Alchemilla obtusa",
		"alchemilla",
		3083739
	],
	[
		"s3746364",
		"Alchemilla obtusiformis",
		"alchemilla",
		3746364
	],
	[
		"s907218",
		"Alchemilla ocreata",
		"alchemilla",
		907218
	],
	[
		"s3746365",
		"Alchemilla oculimarina",
		"alchemilla",
		3746365
	],
	[
		"s2998793",
		"Alchemilla oirotica",
		"alchemilla",
		2998793
	],
	[
		"s3746366",
		"Alchemilla oligantha",
		"alchemilla",
		3746366
	],
	[
		"s3746367",
		"Alchemilla oligotricha",
		"alchemilla",
		3746367
	],
	[
		"s3746368",
		"Alchemilla omalophylla",
		"alchemilla",
		3746368
	],
	[
		"s3083740",
		"Alchemilla opaca",
		"alchemilla",
		3083740
	],
	[
		"s3746369",
		"Alchemilla ophioreina",
		"alchemilla",
		3746369
	],
	[
		"s3083741",
		"Alchemilla orbicans",
		"alchemilla",
		3083741
	],
	[
		"s478366",
		"Alchemilla orbiculata",
		"alchemilla",
		478366
	],
	[
		"s3746370",
		"Alchemilla orduensis",
		"alchemilla",
		3746370
	],
	[
		"s3746371",
		"Alchemilla oriturcica",
		"alchemilla",
		3746371
	],
	[
		"s3746372",
		"Alchemilla orizabensis",
		"alchemilla",
		3746372
	],
	[
		"s3746373",
		"Alchemilla orthotricha",
		"alchemilla",
		3746373
	],
	[
		"s478331",
		"Alchemilla oscensis",
		"alchemilla",
		478331
	],
	[
		"s3083742",
		"Alchemilla othmarii",
		"alchemilla",
		3083742
	],
	[
		"s2785552",
		"Alchemilla oxyodonta",
		"alchemilla",
		2785552
	],
	[
		"s3746374",
		"Alchemilla oxysepala",
		"alchemilla",
		3746374
	],
	[
		"s3746375",
		"Alchemilla ozana",
		"alchemilla",
		3746375
	],
	[
		"s3746376",
		"Alchemilla pachyphylla",
		"alchemilla",
		3746376
	],
	[
		"s3746377",
		"Alchemilla paeneglabra",
		"alchemilla",
		3746377
	],
	[
		"s3746378",
		"Alchemilla paicheana",
		"alchemilla",
		3746378
	],
	[
		"s3746379",
		"Alchemilla palii",
		"alchemilla",
		3746379
	],
	[
		"s3083743",
		"Alchemilla pallens",
		"alchemilla",
		3083743
	],
	[
		"s3746380",
		"Alchemilla paludicola",
		"alchemilla",
		3746380
	],
	[
		"s3746381",
		"Alchemilla panigrahiana",
		"alchemilla",
		3746381
	],
	[
		"s3746382",
		"Alchemilla parcipila",
		"alchemilla",
		3746382
	],
	[
		"s3746383",
		"Alchemilla parijae",
		"alchemilla",
		3746383
	],
	[
		"s3746384",
		"Alchemilla parodii",
		"alchemilla",
		3746384
	],
	[
		"s3746385",
		"Alchemilla patens",
		"alchemilla",
		3746385
	],
	[
		"s3746386",
		"Alchemilla paupercula",
		"alchemilla",
		3746386
	],
	[
		"s2908701",
		"Alchemilla pavlovii",
		"alchemilla",
		2908701
	],
	[
		"s3746387",
		"Alchemilla pawlowskii",
		"alchemilla",
		3746387
	],
	[
		"s478367",
		"Alchemilla pectinata",
		"alchemilla",
		478367
	],
	[
		"s3746388",
		"Alchemilla pectiniloba",
		"alchemilla",
		3746388
	],
	[
		"s478332",
		"Alchemilla pedata",
		"alchemilla",
		478332
	],
	[
		"s3746389",
		"Alchemilla pedicellata",
		"alchemilla",
		3746389
	],
	[
		"s478333",
		"Alchemilla pentaphyllea",
		"alchemilla",
		478333
	],
	[
		"s3746390",
		"Alchemilla peristerica",
		"alchemilla",
		3746390
	],
	[
		"s3746391",
		"Alchemilla perrieri",
		"alchemilla",
		3746391
	],
	[
		"s3003528",
		"Alchemilla persica",
		"alchemilla",
		3003528
	],
	[
		"s3746392",
		"Alchemilla perspicua",
		"alchemilla",
		3746392
	],
	[
		"s3746393",
		"Alchemilla petiolulans",
		"alchemilla",
		3746393
	],
	[
		"s3083744",
		"Alchemilla petraea",
		"alchemilla",
		3083744
	],
	[
		"s3746394",
		"Alchemilla phalacropoda",
		"alchemilla",
		3746394
	],
	[
		"s3746395",
		"Alchemilla phegophila",
		"alchemilla",
		3746395
	],
	[
		"s3746396",
		"Alchemilla philonotis",
		"alchemilla",
		3746396
	],
	[
		"s3746397",
		"Alchemilla pilosiplica",
		"alchemilla",
		3746397
	],
	[
		"s3746398",
		"Alchemilla pinguis",
		"alchemilla",
		3746398
	],
	[
		"s478368",
		"Alchemilla pinnata",
		"alchemilla",
		478368
	],
	[
		"s3746399",
		"Alchemilla pirinica",
		"alchemilla",
		3746399
	],
	[
		"s3746400",
		"Alchemilla platygyria",
		"alchemilla",
		3746400
	],
	[
		"s478334",
		"Alchemilla plicata",
		"alchemilla",
		478334
	],
	[
		"s3746401",
		"Alchemilla plicatissima",
		"alchemilla",
		3746401
	],
	[
		"s1679401",
		"Alchemilla plicatula",
		"alchemilla",
		1679401
	],
	[
		"s3746402",
		"Alchemilla plocekii",
		"alchemilla",
		3746402
	],
	[
		"s3746403",
		"Alchemilla pogonophora",
		"alchemilla",
		3746403
	],
	[
		"s3746404",
		"Alchemilla polatschekiana",
		"alchemilla",
		3746404
	],
	[
		"s3746405",
		"Alchemilla polemochora",
		"alchemilla",
		3746405
	],
	[
		"s3746406",
		"Alchemilla polessica",
		"alchemilla",
		3746406
	],
	[
		"s3746407",
		"Alchemilla polita",
		"alchemilla",
		3746407
	],
	[
		"s3746408",
		"Alchemilla polonica",
		"alchemilla",
		3746408
	],
	[
		"s3746409",
		"Alchemilla polychroma",
		"alchemilla",
		3746409
	],
	[
		"s907212",
		"Alchemilla polylepis",
		"alchemilla",
		907212
	],
	[
		"s3746410",
		"Alchemilla porrectidens",
		"alchemilla",
		3746410
	],
	[
		"s3746411",
		"Alchemilla prasina",
		"alchemilla",
		3746411
	],
	[
		"s3083745",
		"Alchemilla pratensis",
		"alchemilla",
		3083745
	],
	[
		"s3746412",
		"Alchemilla procerrima",
		"alchemilla",
		3746412
	],
	[
		"s907214",
		"Alchemilla procumbens",
		"alchemilla",
		907214
	],
	[
		"s1891446",
		"Alchemilla propinqua",
		"alchemilla",
		1891446
	],
	[
		"s3746413",
		"Alchemilla propinquoides",
		"alchemilla",
		3746413
	],
	[
		"s3083746",
		"Alchemilla pseudincisa",
		"alchemilla",
		3083746
	],
	[
		"s2998794",
		"Alchemilla pseudobungeana",
		"alchemilla",
		2998794
	],
	[
		"s3746414",
		"Alchemilla pseudocalycina",
		"alchemilla",
		3746414
	],
	[
		"s3083747",
		"Alchemilla pseudocartalinica",
		"alchemilla",
		3083747
	],
	[
		"s3746415",
		"Alchemilla pseudodecumbens",
		"alchemilla",
		3746415
	],
	[
		"s3746416",
		"Alchemilla pseudolaeticolor",
		"alchemilla",
		3746416
	],
	[
		"s3746417",
		"Alchemilla pseudotranscaucasica",
		"alchemilla",
		3746417
	],
	[
		"s3746418",
		"Alchemilla psilocaula",
		"alchemilla",
		3746418
	],
	[
		"s3746419",
		"Alchemilla psilomischa",
		"alchemilla",
		3746419
	],
	[
		"s3746420",
		"Alchemilla psiloneura",
		"alchemilla",
		3746420
	],
	[
		"s3746421",
		"Alchemilla ptyschensis",
		"alchemilla",
		3746421
	],
	[
		"s3746422",
		"Alchemilla purohitii",
		"alchemilla",
		3746422
	],
	[
		"s2998795",
		"Alchemilla pustynensis",
		"alchemilla",
		2998795
	],
	[
		"s3746423",
		"Alchemilla pycnantha",
		"alchemilla",
		3746423
	],
	[
		"s3746424",
		"Alchemilla pycnoloba",
		"alchemilla",
		3746424
	],
	[
		"s3083748",
		"Alchemilla pycnotricha",
		"alchemilla",
		3083748
	],
	[
		"s3746425",
		"Alchemilla quinqueloba",
		"alchemilla",
		3746425
	],
	[
		"s3746426",
		"Alchemilla racemulosa",
		"alchemilla",
		3746426
	],
	[
		"s3746427",
		"Alchemilla raddeana",
		"alchemilla",
		3746427
	],
	[
		"s3746428",
		"Alchemilla radiisecta",
		"alchemilla",
		3746428
	],
	[
		"s3746429",
		"Alchemilla reflexa",
		"alchemilla",
		3746429
	],
	[
		"s3746430",
		"Alchemilla rehmannii",
		"alchemilla",
		3746430
	],
	[
		"s3083749",
		"Alchemilla reniformis",
		"alchemilla",
		3083749
	],
	[
		"s3746431",
		"Alchemilla resupinata",
		"alchemilla",
		3746431
	],
	[
		"s3746432",
		"Alchemilla retinerviformis",
		"alchemilla",
		3746432
	],
	[
		"s478335",
		"Alchemilla retinervis",
		"alchemilla",
		478335
	],
	[
		"s3083750",
		"Alchemilla retropilosa",
		"alchemilla",
		3083750
	],
	[
		"s3746433",
		"Alchemilla reversantha",
		"alchemilla",
		3746433
	],
	[
		"s3083751",
		"Alchemilla rhiphaea",
		"alchemilla",
		3083751
	],
	[
		"s3746434",
		"Alchemilla rhodobasis",
		"alchemilla",
		3746434
	],
	[
		"s3746435",
		"Alchemilla rhodocycla",
		"alchemilla",
		3746435
	],
	[
		"s3746436",
		"Alchemilla rhododendrophila",
		"alchemilla",
		3746436
	],
	[
		"s478369",
		"Alchemilla rivulorum",
		"alchemilla",
		478369
	],
	[
		"s3746437",
		"Alchemilla rizensis",
		"alchemilla",
		3746437
	],
	[
		"s478336",
		"Alchemilla roccatii",
		"alchemilla",
		478336
	],
	[
		"s1750581",
		"Alchemilla rothii",
		"alchemilla",
		1750581
	],
	[
		"s3746438",
		"Alchemilla rothmaleri",
		"alchemilla",
		3746438
	],
	[
		"s3746439",
		"Alchemilla rubidula",
		"alchemilla",
		3746439
	],
	[
		"s3746440",
		"Alchemilla rubricaulis",
		"alchemilla",
		3746440
	],
	[
		"s3746441",
		"Alchemilla rubristipula",
		"alchemilla",
		3746441
	],
	[
		"s3746442",
		"Alchemilla rugulosa",
		"alchemilla",
		3746442
	],
	[
		"s478370",
		"Alchemilla rupestris",
		"alchemilla",
		478370
	],
	[
		"s3746443",
		"Alchemilla rusbyi",
		"alchemilla",
		3746443
	],
	[
		"s478337",
		"Alchemilla rutenbergii",
		"alchemilla",
		478337
	],
	[
		"s3746444",
		"Alchemilla sabauda",
		"alchemilla",
		3746444
	],
	[
		"s3746445",
		"Alchemilla saliceti",
		"alchemilla",
		3746445
	],
	[
		"s3746446",
		"Alchemilla samantaraii",
		"alchemilla",
		3746446
	],
	[
		"s3746447",
		"Alchemilla sandiensis",
		"alchemilla",
		3746447
	],
	[
		"s3746448",
		"Alchemilla sanguinolenta",
		"alchemilla",
		3746448
	],
	[
		"s3746449",
		"Alchemilla santanderiensis",
		"alchemilla",
		3746449
	],
	[
		"s2005300",
		"Alchemilla sarmatica",
		"alchemilla",
		2005300
	],
	[
		"s3746450",
		"Alchemilla sarojiniae",
		"alchemilla",
		3746450
	],
	[
		"s3746451",
		"Alchemilla sauri",
		"alchemilla",
		3746451
	],
	[
		"s478338",
		"Alchemilla saxatilis",
		"alchemilla",
		478338
	],
	[
		"s3746452",
		"Alchemilla scalaris",
		"alchemilla",
		3746452
	],
	[
		"s3746453",
		"Alchemilla schischkinii",
		"alchemilla",
		3746453
	],
	[
		"s3746454",
		"Alchemilla schistophylla",
		"alchemilla",
		3746454
	],
	[
		"s478339",
		"Alchemilla schizophylla",
		"alchemilla",
		478339
	],
	[
		"s3746455",
		"Alchemilla schlechteriana",
		"alchemilla",
		3746455
	],
	[
		"s3746456",
		"Alchemilla schmakovii",
		"alchemilla",
		3746456
	],
	[
		"s478340",
		"Alchemilla schmidelyana",
		"alchemilla",
		478340
	],
	[
		"s3746457",
		"Alchemilla sciadiophylla",
		"alchemilla",
		3746457
	],
	[
		"s3350319",
		"Alchemilla sciura",
		"alchemilla",
		3350319
	],
	[
		"s3746458",
		"Alchemilla sedelmeyeriana",
		"alchemilla",
		3746458
	],
	[
		"s3746459",
		"Alchemilla sejuncta",
		"alchemilla",
		3746459
	],
	[
		"s2005301",
		"Alchemilla semidivisa",
		"alchemilla",
		2005301
	],
	[
		"s1891447",
		"Alchemilla semilunaris",
		"alchemilla",
		1891447
	],
	[
		"s3746460",
		"Alchemilla semisecta",
		"alchemilla",
		3746460
	],
	[
		"s3746461",
		"Alchemilla semispoliata",
		"alchemilla",
		3746461
	],
	[
		"s3746462",
		"Alchemilla serbica",
		"alchemilla",
		3746462
	],
	[
		"s3746463",
		"Alchemilla sergii",
		"alchemilla",
		3746463
	],
	[
		"s3083752",
		"Alchemilla sericata",
		"alchemilla",
		3083752
	],
	[
		"s3083753",
		"Alchemilla sericoneura",
		"alchemilla",
		3083753
	],
	[
		"s3746464",
		"Alchemilla sericoneuroides",
		"alchemilla",
		3746464
	],
	[
		"s3746465",
		"Alchemilla serratisaxatilis",
		"alchemilla",
		3746465
	],
	[
		"s3083754",
		"Alchemilla sevangensis",
		"alchemilla",
		3083754
	],
	[
		"s3083755",
		"Alchemilla sibirica",
		"alchemilla",
		3083755
	],
	[
		"s3746466",
		"Alchemilla sibthorpioides",
		"alchemilla",
		3746466
	],
	[
		"s3746467",
		"Alchemilla sierrae",
		"alchemilla",
		3746467
	],
	[
		"s3746468",
		"Alchemilla sintenisii",
		"alchemilla",
		3746468
	],
	[
		"s3746469",
		"Alchemilla sinuata",
		"alchemilla",
		3746469
	],
	[
		"s3746470",
		"Alchemilla sirjaevii",
		"alchemilla",
		3746470
	],
	[
		"s3746471",
		"Alchemilla smaragdina",
		"alchemilla",
		3746471
	],
	[
		"s3083756",
		"Alchemilla smirnovii",
		"alchemilla",
		3083756
	],
	[
		"s3746472",
		"Alchemilla smytniensis",
		"alchemilla",
		3746472
	],
	[
		"s3746473",
		"Alchemilla snarskisii",
		"alchemilla",
		3746473
	],
	[
		"s3746474",
		"Alchemilla sokolowskii",
		"alchemilla",
		3746474
	],
	[
		"s3746475",
		"Alchemilla spathulata",
		"alchemilla",
		3746475
	],
	[
		"s3083757",
		"Alchemilla speciosa",
		"alchemilla",
		3083757
	],
	[
		"s3746476",
		"Alchemilla spectabilior",
		"alchemilla",
		3746476
	],
	[
		"s478341",
		"Alchemilla splendens",
		"alchemilla",
		478341
	],
	[
		"s907211",
		"Alchemilla sprucei",
		"alchemilla",
		907211
	],
	[
		"s3746477",
		"Alchemilla stanislaae",
		"alchemilla",
		3746477
	],
	[
		"s3083758",
		"Alchemilla stellaris",
		"alchemilla",
		3083758
	],
	[
		"s3746478",
		"Alchemilla stellulata",
		"alchemilla",
		3746478
	],
	[
		"s3746479",
		"Alchemilla stenantha",
		"alchemilla",
		3746479
	],
	[
		"s3746480",
		"Alchemilla stenoleuca",
		"alchemilla",
		3746480
	],
	[
		"s3746481",
		"Alchemilla stichotricha",
		"alchemilla",
		3746481
	],
	[
		"s3746482",
		"Alchemilla stiriaca",
		"alchemilla",
		3746482
	],
	[
		"s3093686",
		"Alchemilla straminea",
		"alchemilla",
		3093686
	],
	[
		"s3746483",
		"Alchemilla stricta",
		"alchemilla",
		3746483
	],
	[
		"s3746484",
		"Alchemilla strictissima",
		"alchemilla",
		3746484
	],
	[
		"s2717778",
		"Alchemilla strigosula",
		"alchemilla",
		2717778
	],
	[
		"s478342",
		"Alchemilla stuhlmannii",
		"alchemilla",
		478342
	],
	[
		"s3746485",
		"Alchemilla suavis",
		"alchemilla",
		3746485
	],
	[
		"s3746486",
		"Alchemilla subalpina",
		"alchemilla",
		3746486
	],
	[
		"s3746487",
		"Alchemilla subconnivens",
		"alchemilla",
		3746487
	],
	[
		"s1844630",
		"Alchemilla subcrenata",
		"alchemilla",
		1844630
	],
	[
		"s3746488",
		"Alchemilla subcrenatiformis",
		"alchemilla",
		3746488
	],
	[
		"s3083759",
		"Alchemilla subcrispata",
		"alchemilla",
		3083759
	],
	[
		"s3746489",
		"Alchemilla suberectipila",
		"alchemilla",
		3746489
	],
	[
		"s1891448",
		"Alchemilla subglobosa",
		"alchemilla",
		1891448
	],
	[
		"s478343",
		"Alchemilla subnivalis",
		"alchemilla",
		478343
	],
	[
		"s478345",
		"Alchemilla subsericea",
		"alchemilla",
		478345
	],
	[
		"s3746490",
		"Alchemilla subsessilis",
		"alchemilla",
		3746490
	],
	[
		"s3746491",
		"Alchemilla subsplendens",
		"alchemilla",
		3746491
	],
	[
		"s3083760",
		"Alchemilla substrigosa",
		"alchemilla",
		3083760
	],
	[
		"s3746492",
		"Alchemilla sukaczevii",
		"alchemilla",
		3746492
	],
	[
		"s3746493",
		"Alchemilla superata",
		"alchemilla",
		3746493
	],
	[
		"s3746494",
		"Alchemilla supina",
		"alchemilla",
		3746494
	],
	[
		"s3746495",
		"Alchemilla surculosa",
		"alchemilla",
		3746495
	],
	[
		"s3746496",
		"Alchemilla szaferi",
		"alchemilla",
		3746496
	],
	[
		"s3746497",
		"Alchemilla tacikii",
		"alchemilla",
		3746497
	],
	[
		"s1891449",
		"Alchemilla taernaensis",
		"alchemilla",
		1891449
	],
	[
		"s3746498",
		"Alchemilla tamarae",
		"alchemilla",
		3746498
	],
	[
		"s478371",
		"Alchemilla tanacetifolia",
		"alchemilla",
		478371
	],
	[
		"s3746499",
		"Alchemilla tatricola",
		"alchemilla",
		3746499
	],
	[
		"s3083761",
		"Alchemilla taurica",
		"alchemilla",
		3083761
	],
	[
		"s478346",
		"Alchemilla tenerifolia",
		"alchemilla",
		478346
	],
	[
		"s3746500",
		"Alchemilla tenerrima",
		"alchemilla",
		3746500
	],
	[
		"s478347",
		"Alchemilla tenuis",
		"alchemilla",
		478347
	],
	[
		"s3746501",
		"Alchemilla thaumasia",
		"alchemilla",
		3746501
	],
	[
		"s2082031",
		"Alchemilla tianschanica",
		"alchemilla",
		2082031
	],
	[
		"s3746502",
		"Alchemilla tichomirovii",
		"alchemilla",
		3746502
	],
	[
		"s3083762",
		"Alchemilla tirolensis",
		"alchemilla",
		3083762
	],
	[
		"s3746503",
		"Alchemilla tiryalensis",
		"alchemilla",
		3746503
	],
	[
		"s3746504",
		"Alchemilla tobolica",
		"alchemilla",
		3746504
	],
	[
		"s3746505",
		"Alchemilla transcaucasica",
		"alchemilla",
		3746505
	],
	[
		"s478348",
		"Alchemilla transiens",
		"alchemilla",
		478348
	],
	[
		"s3746506",
		"Alchemilla transiliensis",
		"alchemilla",
		3746506
	],
	[
		"s3083763",
		"Alchemilla transpolaris",
		"alchemilla",
		3083763
	],
	[
		"s3083764",
		"Alchemilla tredecimloba",
		"alchemilla",
		3083764
	],
	[
		"s3746507",
		"Alchemilla trichocrater",
		"alchemilla",
		3746507
	],
	[
		"s478349",
		"Alchemilla triphylla",
		"alchemilla",
		478349
	],
	[
		"s3746508",
		"Alchemilla trollii",
		"alchemilla",
		3746508
	],
	[
		"s3746509",
		"Alchemilla trullata",
		"alchemilla",
		3746509
	],
	[
		"s3746510",
		"Alchemilla trunciloba",
		"alchemilla",
		3746510
	],
	[
		"s3083765",
		"Alchemilla tubulosa",
		"alchemilla",
		3083765
	],
	[
		"s3746511",
		"Alchemilla turkulensis",
		"alchemilla",
		3746511
	],
	[
		"s3746512",
		"Alchemilla turuchanica",
		"alchemilla",
		3746512
	],
	[
		"s3083766",
		"Alchemilla tytthantha",
		"alchemilla",
		3083766
	],
	[
		"s3746513",
		"Alchemilla tzvelevii",
		"alchemilla",
		3746513
	],
	[
		"s3083767",
		"Alchemilla undulata",
		"alchemilla",
		3083767
	],
	[
		"s907220",
		"Alchemilla uniflora",
		"alchemilla",
		907220
	],
	[
		"s3746514",
		"Alchemilla urceolata",
		"alchemilla",
		3746514
	],
	[
		"s3746515",
		"Alchemilla vaccariana",
		"alchemilla",
		3746515
	],
	[
		"s3746516",
		"Alchemilla valdehirsuta",
		"alchemilla",
		3746516
	],
	[
		"s3083768",
		"Alchemilla velebitica",
		"alchemilla",
		3083768
	],
	[
		"s2071889",
		"Alchemilla venosa",
		"alchemilla",
		2071889
	],
	[
		"s3746517",
		"Alchemilla venosula",
		"alchemilla",
		3746517
	],
	[
		"s3746518",
		"Alchemilla ventiana",
		"alchemilla",
		3746518
	],
	[
		"s3746519",
		"Alchemilla verae",
		"alchemilla",
		3746519
	],
	[
		"s3083769",
		"Alchemilla veronicae",
		"alchemilla",
		3083769
	],
	[
		"s3083770",
		"Alchemilla versipila",
		"alchemilla",
		3083770
	],
	[
		"s3746520",
		"Alchemilla versipiloides",
		"alchemilla",
		3746520
	],
	[
		"s907213",
		"Alchemilla verticillata",
		"alchemilla",
		907213
	],
	[
		"s478350",
		"Alchemilla vetteri",
		"alchemilla",
		478350
	],
	[
		"s3746521",
		"Alchemilla villarii",
		"alchemilla",
		3746521
	],
	[
		"s3746522",
		"Alchemilla villosa",
		"alchemilla",
		3746522
	],
	[
		"s3083771",
		"Alchemilla vinacea",
		"alchemilla",
		3083771
	],
	[
		"s3746523",
		"Alchemilla vincekii",
		"alchemilla",
		3746523
	],
	[
		"s3746524",
		"Alchemilla virginea",
		"alchemilla",
		3746524
	],
	[
		"s3746525",
		"Alchemilla viridiflora",
		"alchemilla",
		3746525
	],
	[
		"s3746526",
		"Alchemilla viridifolia",
		"alchemilla",
		3746526
	],
	[
		"s3746527",
		"Alchemilla vizcayensis",
		"alchemilla",
		3746527
	],
	[
		"s478351",
		"Alchemilla volkensii",
		"alchemilla",
		478351
	],
	[
		"s2998796",
		"Alchemilla vorotnikovii",
		"alchemilla",
		2998796
	],
	[
		"s3746528",
		"Alchemilla vranicensis",
		"alchemilla",
		3746528
	],
	[
		"s478372",
		"Alchemilla vulcanica",
		"alchemilla",
		478372
	],
	[
		"s49855",
		"Alchemilla vulgaris",
		"alchemilla",
		49855
	],
	[
		"s3083772",
		"Alchemilla walasii",
		"alchemilla",
		3083772
	],
	[
		"s3746529",
		"Alchemilla wallischii",
		"alchemilla",
		3746529
	],
	[
		"s3746530",
		"Alchemilla waltersii",
		"alchemilla",
		3746530
	],
	[
		"s3746531",
		"Alchemilla weberi",
		"alchemilla",
		3746531
	],
	[
		"s1572674",
		"Alchemilla wichurae",
		"alchemilla",
		1572674
	],
	[
		"s3746532",
		"Alchemilla wischniewskii",
		"alchemilla",
		3746532
	],
	[
		"s478352",
		"Alchemilla woodii",
		"alchemilla",
		478352
	],
	[
		"s1155249",
		"Alchemilla xanthochlora",
		"alchemilla",
		1155249
	],
	[
		"s3746533",
		"Alchemilla ypsilotoma",
		"alchemilla",
		3746533
	],
	[
		"s3746534",
		"Alchemilla zapalowiczii",
		"alchemilla",
		3746534
	],
	[
		"s3746535",
		"Alchemilla ziganadagensis",
		"alchemilla",
		3746535
	],
	[
		"s2998797",
		"Alchemilla zimoenkensis",
		"alchemilla",
		2998797
	],
	[
		"s3746536",
		"Alchemilla zmudae",
		"alchemilla",
		3746536
	],
	[
		"s3746537",
		"Alchemilla zolotuchinii",
		"alchemilla",
		3746537
	],
	[
		"s36602",
		"Alniaria alnifolia",
		"alniaria",
		36602
	],
	[
		"s1008935",
		"Alniaria folgneri",
		"alniaria",
		1008935
	],
	[
		"s691245",
		"Alniaria tsinlingensis",
		"alniaria",
		691245
	],
	[
		"s691248",
		"Alniaria yuana",
		"alniaria",
		691248
	],
	[
		"s432374",
		"Alphitonia aff. incana Chase 2179",
		"alphitonia",
		432374
	],
	[
		"s3083798",
		"Alphitonia carolinensis",
		"alphitonia",
		3083798
	],
	[
		"s106658",
		"Alphitonia excelsa",
		"alphitonia",
		106658
	],
	[
		"s3747656",
		"Alphitonia franguloides",
		"alphitonia",
		3747656
	],
	[
		"s432372",
		"Alphitonia incana",
		"alphitonia",
		432372
	],
	[
		"s3083799",
		"Alphitonia macrocarpa",
		"alphitonia",
		3083799
	],
	[
		"s1663722",
		"Alphitonia marquesensis",
		"alphitonia",
		1663722
	],
	[
		"s1502677",
		"Alphitonia neocaledonica",
		"alphitonia",
		1502677
	],
	[
		"s1502678",
		"Alphitonia oblata",
		"alphitonia",
		1502678
	],
	[
		"s1312767",
		"Alphitonia petriei",
		"alphitonia",
		1312767
	],
	[
		"s2358445",
		"Alphitonia philippinensis",
		"alphitonia",
		2358445
	],
	[
		"s2358446",
		"Alphitonia pomaderroides",
		"alphitonia",
		2358446
	],
	[
		"s1502679",
		"Alphitonia ponderosa",
		"alphitonia",
		1502679
	],
	[
		"s1312768",
		"Alphitonia whitei",
		"alphitonia",
		1312768
	],
	[
		"s1502681",
		"Alphitonia zizyphoides",
		"alphitonia",
		1502681
	],
	[
		"s2743200",
		"Alvimiantha tricamerata",
		"alvimiantha",
		2743200
	],
	[
		"s2045009",
		"Amelanchier aff. bartramiana KC-2017",
		"amelanchier",
		2045009
	],
	[
		"s32219",
		"Amelanchier alnifolia",
		"amelanchier",
		32219
	],
	[
		"s2045008",
		"Amelanchier alnifolia var. semiintegrifolia x Amelanchier cusickii",
		"amelanchier",
		2045008
	],
	[
		"s2080249",
		"Amelanchier alnifolia x Amelanchier spicata",
		"amelanchier",
		2080249
	],
	[
		"s2071397",
		"Amelanchier amabilis",
		"amelanchier",
		2071397
	],
	[
		"s52521",
		"Amelanchier arborea",
		"amelanchier",
		52521
	],
	[
		"s52522",
		"Amelanchier asiatica",
		"amelanchier",
		52522
	],
	[
		"s35968",
		"Amelanchier bartramiana",
		"amelanchier",
		35968
	],
	[
		"s52523",
		"Amelanchier canadensis",
		"amelanchier",
		52523
	],
	[
		"s3748257",
		"Amelanchier cretica",
		"amelanchier",
		3748257
	],
	[
		"s52524",
		"Amelanchier cusickii",
		"amelanchier",
		52524
	],
	[
		"s52527",
		"Amelanchier fernaldii",
		"amelanchier",
		52527
	],
	[
		"s3748258",
		"Amelanchier gaspensis",
		"amelanchier",
		3748258
	],
	[
		"s52529",
		"Amelanchier humilis",
		"amelanchier",
		52529
	],
	[
		"s1768848",
		"Amelanchier hybrid cultivar",
		"amelanchier",
		1768848
	],
	[
		"s1143211",
		"Amelanchier interior",
		"amelanchier",
		1143211
	],
	[
		"s52530",
		"Amelanchier intermedia",
		"amelanchier",
		52530
	],
	[
		"s52531",
		"Amelanchier laevis",
		"amelanchier",
		52531
	],
	[
		"s1143212",
		"Amelanchier lamarckii",
		"amelanchier",
		1143212
	],
	[
		"s52532",
		"Amelanchier lucida",
		"amelanchier",
		52532
	],
	[
		"s52533",
		"Amelanchier nantucketensis",
		"amelanchier",
		52533
	],
	[
		"s52519",
		"Amelanchier neglecta",
		"amelanchier",
		52519
	],
	[
		"s2654663",
		"Amelanchier obovalis",
		"amelanchier",
		2654663
	],
	[
		"s1000415",
		"Amelanchier ovalis",
		"amelanchier",
		1000415
	],
	[
		"s1768849",
		"Amelanchier pallida",
		"amelanchier",
		1768849
	],
	[
		"s1768850",
		"Amelanchier parviflora",
		"amelanchier",
		1768850
	],
	[
		"s52535",
		"Amelanchier quinti-martii",
		"amelanchier",
		52535
	],
	[
		"s52536",
		"Amelanchier sanguinea",
		"amelanchier",
		52536
	],
	[
		"s1961191",
		"Amelanchier sinica",
		"amelanchier",
		1961191
	],
	[
		"s1143213",
		"Amelanchier spicata",
		"amelanchier",
		1143213
	],
	[
		"s2080248",
		"Amelanchier spicata x Amelanchier alnifolia",
		"amelanchier",
		2080248
	],
	[
		"s52538",
		"Amelanchier stolonifera",
		"amelanchier",
		52538
	],
	[
		"s3748259",
		"Amelanchier turkestanica",
		"amelanchier",
		3748259
	],
	[
		"s52539",
		"Amelanchier utahensis",
		"amelanchier",
		52539
	],
	[
		"s871966",
		"Amelanchier x grandiflora",
		"amelanchier",
		871966
	],
	[
		"s52540",
		"Amelanchier x wiegandii",
		"amelanchier",
		52540
	],
	[
		"s2732315",
		"Ampalis dimepate",
		"ampalis",
		2732315
	],
	[
		"s3128663",
		"Ampalis mauritiana",
		"ampalis",
		3128663
	],
	[
		"s3748530",
		"Ampelocera albertiae",
		"ampelocera",
		3748530
	],
	[
		"s3083807",
		"Ampelocera cubensis",
		"ampelocera",
		3083807
	],
	[
		"s1568982",
		"Ampelocera edentula",
		"ampelocera",
		1568982
	],
	[
		"s3083808",
		"Ampelocera glabra",
		"ampelocera",
		3083808
	],
	[
		"s63064",
		"Ampelocera hottlei",
		"ampelocera",
		63064
	],
	[
		"s2713446",
		"Ampelocera longissima",
		"ampelocera",
		2713446
	],
	[
		"s1428764",
		"Ampelocera macphersonii",
		"ampelocera",
		1428764
	],
	[
		"s1475369",
		"Ampelocera macrocarpa",
		"ampelocera",
		1475369
	],
	[
		"s3748531",
		"Ampelocera percyhernandezii",
		"ampelocera",
		3748531
	],
	[
		"s1904788",
		"Ampelocera ruizii",
		"ampelocera",
		1904788
	],
	[
		"s3748532",
		"Ampelocera verrucosa",
		"ampelocera",
		3748532
	],
	[
		"s106660",
		"Ampelozizyphus amazonicus",
		"ampelozizyphus",
		106660
	],
	[
		"s3083809",
		"Ampelozizyphus guaquirensis",
		"ampelozizyphus",
		3083809
	],
	[
		"s3748597",
		"Ampelozizyphus kuripacorum",
		"ampelozizyphus",
		3748597
	],
	[
		"s241857",
		"Antiaris toxicaria",
		"antiaris",
		241857
	],
	[
		"s241859",
		"Antiaropsis decipiens",
		"antiaropsis",
		241859
	],
	[
		"s3752392",
		"Antiaropsis uniflora",
		"antiaropsis",
		3752392
	],
	[
		"s63051",
		"Aphananthe aspera",
		"aphananthe",
		63051
	],
	[
		"s1679368",
		"Aphananthe cuspidata",
		"aphananthe",
		1679368
	],
	[
		"s63052",
		"Aphananthe monoica",
		"aphananthe",
		63052
	],
	[
		"s1184748",
		"Aphananthe philippinensis",
		"aphananthe",
		1184748
	],
	[
		"s1817787",
		"Aphananthe sakalava",
		"aphananthe",
		1817787
	],
	[
		"s2848363",
		"Aphanes australiana",
		"aphanes",
		2848363
	],
	[
		"s1155250",
		"Aphanes australis",
		"aphanes",
		1155250
	],
	[
		"s1750584",
		"Aphanes bachiti",
		"aphanes",
		1750584
	],
	[
		"s478353",
		"Aphanes cornucopioides",
		"aphanes",
		478353
	],
	[
		"s2052769",
		"Aphanes cotopaxiensis",
		"aphanes",
		2052769
	],
	[
		"s478354",
		"Aphanes floribunda",
		"aphanes",
		478354
	],
	[
		"s478355",
		"Aphanes inexpectata",
		"aphanes",
		478355
	],
	[
		"s478356",
		"Aphanes minutiflora",
		"aphanes",
		478356
	],
	[
		"s2042361",
		"Aphanes occidentalis",
		"aphanes",
		2042361
	],
	[
		"s3710748",
		"Araracuara vetusta",
		"araracuara",
		3710748
	],
	[
		"s1399655",
		"Archiboehmeria atrata",
		"archiboehmeria",
		1399655
	],
	[
		"s57914",
		"Aremonia agrimonioides",
		"aremonia",
		57914
	],
	[
		"s3756009",
		"Argentina achillea",
		"argentina",
		3756009
	],
	[
		"s3756010",
		"Argentina adinophylla",
		"argentina",
		3756010
	],
	[
		"s3756011",
		"Argentina adulterina",
		"argentina",
		3756011
	],
	[
		"s57926",
		"Argentina anserina",
		"argentina",
		57926
	],
	[
		"s1043713",
		"Argentina anserinoides",
		"argentina",
		1043713
	],
	[
		"s3756012",
		"Argentina archboldiana",
		"argentina",
		3756012
	],
	[
		"s3756013",
		"Argentina aristata",
		"argentina",
		3756013
	],
	[
		"s3756014",
		"Argentina assimilis",
		"argentina",
		3756014
	],
	[
		"s3756015",
		"Argentina baliemensis",
		"argentina",
		3756015
	],
	[
		"s3756016",
		"Argentina bidentula",
		"argentina",
		3756016
	],
	[
		"s3756017",
		"Argentina biloba",
		"argentina",
		3756017
	],
	[
		"s3756018",
		"Argentina borneensis",
		"argentina",
		3756018
	],
	[
		"s3756019",
		"Argentina brassii",
		"argentina",
		3756019
	],
	[
		"s3121453",
		"Argentina cardotiana",
		"argentina",
		3121453
	],
	[
		"s3756020",
		"Argentina commutata",
		"argentina",
		3756020
	],
	[
		"s3756021",
		"Argentina curta",
		"argentina",
		3756021
	],
	[
		"s3756022",
		"Argentina emodi",
		"argentina",
		3756022
	],
	[
		"s3121448",
		"Argentina fallens",
		"argentina",
		3121448
	],
	[
		"s3121457",
		"Argentina festiva",
		"argentina",
		3121457
	],
	[
		"s1570117",
		"Argentina glabriuscula",
		"argentina",
		1570117
	],
	[
		"s3121454",
		"Argentina gombalana",
		"argentina",
		3121454
	],
	[
		"s3756023",
		"Argentina gorokana",
		"argentina",
		3756023
	],
	[
		"s1571454",
		"Argentina gracilescens",
		"argentina",
		1571454
	],
	[
		"s3756024",
		"Argentina habbemana",
		"argentina",
		3756024
	],
	[
		"s3756025",
		"Argentina hooglandii",
		"argentina",
		3756025
	],
	[
		"s3756026",
		"Argentina indivisa",
		"argentina",
		3756026
	],
	[
		"s3756027",
		"Argentina interrupta",
		"argentina",
		3756027
	],
	[
		"s3756028",
		"Argentina irianensis",
		"argentina",
		3756028
	],
	[
		"s3756029",
		"Argentina kinabaluensis",
		"argentina",
		3756029
	],
	[
		"s667261",
		"Argentina leuconota",
		"argentina",
		667261
	],
	[
		"s3756030",
		"Argentina linilaciniata",
		"argentina",
		3756030
	],
	[
		"s3756031",
		"Argentina luteopilosa",
		"argentina",
		3756031
	],
	[
		"s3756032",
		"Argentina mangenii",
		"argentina",
		3756032
	],
	[
		"s3756033",
		"Argentina millefoliolata",
		"argentina",
		3756033
	],
	[
		"s3756034",
		"Argentina novoguineensis",
		"argentina",
		3756034
	],
	[
		"s3756035",
		"Argentina oxyodonta",
		"argentina",
		3756035
	],
	[
		"s654648",
		"Argentina pacifica",
		"argentina",
		654648
	],
	[
		"s3756036",
		"Argentina papuana",
		"argentina",
		3756036
	],
	[
		"s3153924",
		"Argentina parvula",
		"argentina",
		3153924
	],
	[
		"s3121451",
		"Argentina peduncularis",
		"argentina",
		3121451
	],
	[
		"s1570123",
		"Argentina phanerophlebia",
		"argentina",
		1570123
	],
	[
		"s3756037",
		"Argentina philippinensis",
		"argentina",
		3756037
	],
	[
		"s3121460",
		"Argentina polyphylla",
		"argentina",
		3121460
	],
	[
		"s3756038",
		"Argentina polyphylloides",
		"argentina",
		3756038
	],
	[
		"s3756039",
		"Argentina pycnophylla",
		"argentina",
		3756039
	],
	[
		"s3756040",
		"Argentina recognita",
		"argentina",
		3756040
	],
	[
		"s3756041",
		"Argentina scorpionis",
		"argentina",
		3756041
	],
	[
		"s3756042",
		"Argentina sericophylla",
		"argentina",
		3756042
	],
	[
		"s3756043",
		"Argentina shweliensis",
		"argentina",
		3756043
	],
	[
		"s3756044",
		"Argentina simulans",
		"argentina",
		3756044
	],
	[
		"s3121455",
		"Argentina smithiana",
		"argentina",
		3121455
	],
	[
		"s1570122",
		"Argentina songzhuensis",
		"argentina",
		1570122
	],
	[
		"s210862",
		"Argentina stenophylla",
		"argentina",
		210862
	],
	[
		"s3756045",
		"Argentina subarctica",
		"argentina",
		3756045
	],
	[
		"s3756046",
		"Argentina sumatrana",
		"argentina",
		3756046
	],
	[
		"s3121458",
		"Argentina taliensis",
		"argentina",
		3121458
	],
	[
		"s3756047",
		"Argentina tristis",
		"argentina",
		3756047
	],
	[
		"s3695198",
		"Argentina tugitakensis",
		"argentina",
		3695198
	],
	[
		"s3756048",
		"Argentina victorialis",
		"argentina",
		3756048
	],
	[
		"s3756049",
		"Argentina wanimboi",
		"argentina",
		3756049
	],
	[
		"s3756050",
		"Argentina wenchuensis",
		"argentina",
		3756050
	],
	[
		"s3756051",
		"Argentina wilhelminensis",
		"argentina",
		3756051
	],
	[
		"s3756052",
		"Argentina yonoweana",
		"argentina",
		3756052
	],
	[
		"s3373412",
		"Aria arvonicola",
		"aria",
		3373412
	],
	[
		"s3756362",
		"Aria avonensis",
		"aria",
		3756362
	],
	[
		"s3756363",
		"Aria baldaccii",
		"aria",
		3756363
	],
	[
		"s3870883",
		"Aria barrandienica",
		"aria",
		3870883
	],
	[
		"s3756364",
		"Aria busambarensis",
		"aria",
		3756364
	],
	[
		"s1155367",
		"Aria cambrensis",
		"aria",
		1155367
	],
	[
		"s1844640",
		"Aria cheddarensis",
		"aria",
		1844640
	],
	[
		"s3091536",
		"Aria colchica",
		"aria",
		3091536
	],
	[
		"s1902518",
		"Aria collina",
		"aria",
		1902518
	],
	[
		"s3756365",
		"Aria cucullifera",
		"aria",
		3756365
	],
	[
		"s1534658",
		"Aria danubialis",
		"aria",
		1534658
	],
	[
		"s2906878",
		"Aria edulis",
		"aria",
		2906878
	],
	[
		"s746472",
		"Aria eminens",
		"aria",
		746472
	],
	[
		"s1155370",
		"Aria eminentiformis",
		"aria",
		1155370
	],
	[
		"s1844641",
		"Aria eminentoides",
		"aria",
		1844641
	],
	[
		"s3756366",
		"Aria evansii",
		"aria",
		3756366
	],
	[
		"s3870881",
		"Aria eximia",
		"aria",
		3870881
	],
	[
		"s3091538",
		"Aria fedorovii",
		"aria",
		3091538
	],
	[
		"s1770155",
		"Aria graeca",
		"aria",
		1770155
	],
	[
		"s3756367",
		"Aria greenii",
		"aria",
		3756367
	],
	[
		"s3756368",
		"Aria herefordensis",
		"aria",
		3756368
	],
	[
		"s1155371",
		"Aria hibernica",
		"aria",
		1155371
	],
	[
		"s3756369",
		"Aria hungarica",
		"aria",
		3756369
	],
	[
		"s3756370",
		"Aria javorkana",
		"aria",
		3756370
	],
	[
		"s3756371",
		"Aria keszthelyensis",
		"aria",
		3756371
	],
	[
		"s1572686",
		"Aria lancastriensis",
		"aria",
		1572686
	],
	[
		"s1844642",
		"Aria leighensis",
		"aria",
		1844642
	],
	[
		"s3756372",
		"Aria madoniensis",
		"aria",
		3756372
	],
	[
		"s1844643",
		"Aria margaretae",
		"aria",
		1844643
	],
	[
		"s3756373",
		"Aria meridionalis",
		"aria",
		3756373
	],
	[
		"s3870884",
		"Aria milensis",
		"aria",
		3870884
	],
	[
		"s3756374",
		"Aria moravica",
		"aria",
		3756374
	],
	[
		"s3756375",
		"Aria obtusifolia",
		"aria",
		3756375
	],
	[
		"s3756376",
		"Aria orbiculata",
		"aria",
		3756376
	],
	[
		"s2604395",
		"Aria pannonica",
		"aria",
		2604395
	],
	[
		"s1844644",
		"Aria parviloba",
		"aria",
		1844644
	],
	[
		"s3756377",
		"Aria phitosiana",
		"aria",
		3756377
	],
	[
		"s3756378",
		"Aria pontis-satanae",
		"aria",
		3756378
	],
	[
		"s746474",
		"Aria porrigentiformis",
		"aria",
		746474
	],
	[
		"s3059407",
		"Aria richii",
		"aria",
		3059407
	],
	[
		"s2910179",
		"Aria rupicola",
		"aria",
		2910179
	],
	[
		"s1844646",
		"Aria rupicoloides",
		"aria",
		1844646
	],
	[
		"s1155375",
		"Aria saxicola",
		"aria",
		1155375
	],
	[
		"s3756379",
		"Aria spectans",
		"aria",
		3756379
	],
	[
		"s1155376",
		"Aria stenophylla",
		"aria",
		1155376
	],
	[
		"s1155377",
		"Aria stirtoniana",
		"aria",
		1155377
	],
	[
		"s3756380",
		"Aria subdanubialis",
		"aria",
		3756380
	],
	[
		"s3756381",
		"Aria taurica",
		"aria",
		3756381
	],
	[
		"s3756382",
		"Aria tergestina",
		"aria",
		3756382
	],
	[
		"s3756383",
		"Aria thaiszii",
		"aria",
		3756383
	],
	[
		"s3756384",
		"Aria thayensis",
		"aria",
		3756384
	],
	[
		"s3756385",
		"Aria ujhelyii",
		"aria",
		3756385
	],
	[
		"s3756386",
		"Aria ulmifolia",
		"aria",
		3756386
	],
	[
		"s2720251",
		"Aria umbellata",
		"aria",
		2720251
	],
	[
		"s3756387",
		"Aria vajdae",
		"aria",
		3756387
	],
	[
		"s3091550",
		"Aria velutina",
		"aria",
		3091550
	],
	[
		"s1572689",
		"Aria vexans",
		"aria",
		1572689
	],
	[
		"s746475",
		"Aria whiteana",
		"aria",
		746475
	],
	[
		"s746476",
		"Aria wilmottiana",
		"aria",
		746476
	],
	[
		"s3756388",
		"Aria wyensis",
		"aria",
		3756388
	],
	[
		"s1155372",
		"Aria x leptophylla",
		"aria",
		1155372
	],
	[
		"s3756389",
		"Aria yuarguta",
		"aria",
		3756389
	],
	[
		"s3756390",
		"Aria zolyomii",
		"aria",
		3756390
	],
	[
		"s36594",
		"Aronia arbutifolia",
		"aronia",
		36594
	],
	[
		"s661339",
		"Aronia melanocarpa",
		"aronia",
		661339
	],
	[
		"s1954238",
		"Aronia mitschurinii",
		"aronia",
		1954238
	],
	[
		"s2604224",
		"Aronia x floribunda",
		"aronia",
		2604224
	],
	[
		"s193298",
		"Aronia x prunifolia",
		"aronia",
		193298
	],
	[
		"s2675487",
		"Artocarpus aff. camansi EG 429",
		"artocarpus",
		2675487
	],
	[
		"s2675488",
		"Artocarpus aff. camansi Havel 15445",
		"artocarpus",
		2675488
	],
	[
		"s2675489",
		"Artocarpus aff. corneri Fuchs21347",
		"artocarpus",
		2675489
	],
	[
		"s2675490",
		"Artocarpus aff. dadah AA W882",
		"artocarpus",
		2675490
	],
	[
		"s2675491",
		"Artocarpus aff. horridus EG 437",
		"artocarpus",
		2675491
	],
	[
		"s1867350",
		"Artocarpus aff. lakoocha EMG-2016",
		"artocarpus",
		1867350
	],
	[
		"s2991010",
		"Artocarpus aff. nitidus SO-2022",
		"artocarpus",
		2991010
	],
	[
		"s2675492",
		"Artocarpus aff. scortechinii EG 333",
		"artocarpus",
		2675492
	],
	[
		"s2675505",
		"Artocarpus albobrunneus",
		"artocarpus",
		2675505
	],
	[
		"s194251",
		"Artocarpus altilis",
		"artocarpus",
		194251
	],
	[
		"s1727130",
		"Artocarpus altilis x Artocarpus mariannensis",
		"artocarpus",
		1727130
	],
	[
		"s1867279",
		"Artocarpus altissimus",
		"artocarpus",
		1867279
	],
	[
		"s709036",
		"Artocarpus anisophyllus",
		"artocarpus",
		709036
	],
	[
		"s709037",
		"Artocarpus annulatus",
		"artocarpus",
		709037
	],
	[
		"s2675537",
		"Artocarpus bergii",
		"artocarpus",
		2675537
	],
	[
		"s709038",
		"Artocarpus blancoi",
		"artocarpus",
		709038
	],
	[
		"s1856016",
		"Artocarpus brevipedunculatus",
		"artocarpus",
		1856016
	],
	[
		"s3756933",
		"Artocarpus buyangensis",
		"artocarpus",
		3756933
	],
	[
		"s709039",
		"Artocarpus camansi",
		"artocarpus",
		709039
	],
	[
		"s2675495",
		"Artocarpus cf. pinnatisectus PPI2376",
		"artocarpus",
		2675495
	],
	[
		"s1867282",
		"Artocarpus cf. pithecogallus EMG-2016",
		"artocarpus",
		1867282
	],
	[
		"s2501691",
		"Artocarpus cf. sepicanus SEM-2019",
		"artocarpus",
		2501691
	],
	[
		"s709040",
		"Artocarpus chama",
		"artocarpus",
		709040
	],
	[
		"s3756934",
		"Artocarpus clementis",
		"artocarpus",
		3756934
	],
	[
		"s2675493",
		"Artocarpus corneri",
		"artocarpus",
		2675493
	],
	[
		"s709041",
		"Artocarpus dadah",
		"artocarpus",
		709041
	],
	[
		"s3756935",
		"Artocarpus eberhardtii",
		"artocarpus",
		3756935
	],
	[
		"s709042",
		"Artocarpus elasticus",
		"artocarpus",
		709042
	],
	[
		"s709043",
		"Artocarpus excelsus",
		"artocarpus",
		709043
	],
	[
		"s1856017",
		"Artocarpus fretessii",
		"artocarpus",
		1856017
	],
	[
		"s2675535",
		"Artocarpus frutescens",
		"artocarpus",
		2675535
	],
	[
		"s709044",
		"Artocarpus fulvicortex",
		"artocarpus",
		709044
	],
	[
		"s709045",
		"Artocarpus glaucus",
		"artocarpus",
		709045
	],
	[
		"s1867283",
		"Artocarpus gomezianus",
		"artocarpus",
		1867283
	],
	[
		"s2675503",
		"Artocarpus gongshanensis",
		"artocarpus",
		2675503
	],
	[
		"s3489",
		"Artocarpus heterophyllus",
		"artocarpus",
		3489
	],
	[
		"s2304666",
		"Artocarpus heterophyllus x Artocarpus integer",
		"artocarpus",
		2304666
	],
	[
		"s291940",
		"Artocarpus hirsutus",
		"artocarpus",
		291940
	],
	[
		"s709046",
		"Artocarpus hispidus",
		"artocarpus",
		709046
	],
	[
		"s2675494",
		"Artocarpus horridus",
		"artocarpus",
		2675494
	],
	[
		"s1955528",
		"Artocarpus hypargyreus",
		"artocarpus",
		1955528
	],
	[
		"s3490",
		"Artocarpus integer",
		"artocarpus",
		3490
	],
	[
		"s2219698",
		"Artocarpus integer x Artocarpus heterophyllus",
		"artocarpus",
		2219698
	],
	[
		"s2675507",
		"Artocarpus jarrettiae",
		"artocarpus",
		2675507
	],
	[
		"s709047",
		"Artocarpus kemando",
		"artocarpus",
		709047
	],
	[
		"s382341",
		"Artocarpus lacucha",
		"artocarpus",
		382341
	],
	[
		"s3756936",
		"Artocarpus lamellosus",
		"artocarpus",
		3756936
	],
	[
		"s709049",
		"Artocarpus lanceifolius",
		"artocarpus",
		709049
	],
	[
		"s2675508",
		"Artocarpus longifolius",
		"artocarpus",
		2675508
	],
	[
		"s709050",
		"Artocarpus lowii",
		"artocarpus",
		709050
	],
	[
		"s709051",
		"Artocarpus maingayi",
		"artocarpus",
		709051
	],
	[
		"s709052",
		"Artocarpus mariannensis",
		"artocarpus",
		709052
	],
	[
		"s2675502",
		"Artocarpus melinoxylus",
		"artocarpus",
		2675502
	],
	[
		"s3756937",
		"Artocarpus montanus",
		"artocarpus",
		3756937
	],
	[
		"s2675510",
		"Artocarpus multifidus",
		"artocarpus",
		2675510
	],
	[
		"s1745975",
		"Artocarpus nanchuanensis",
		"artocarpus",
		1745975
	],
	[
		"s3756938",
		"Artocarpus nigrescens",
		"artocarpus",
		3756938
	],
	[
		"s3756939",
		"Artocarpus nigrifolius",
		"artocarpus",
		3756939
	],
	[
		"s709053",
		"Artocarpus nitidus",
		"artocarpus",
		709053
	],
	[
		"s1867284",
		"Artocarpus nitidus cf. subsp. humilis EMG-2016",
		"artocarpus",
		1867284
	],
	[
		"s2290778",
		"Artocarpus nobilis",
		"artocarpus",
		2290778
	],
	[
		"s1867285",
		"Artocarpus obtusus",
		"artocarpus",
		1867285
	],
	[
		"s709058",
		"Artocarpus odoratissimus",
		"artocarpus",
		709058
	],
	[
		"s709059",
		"Artocarpus ovatus",
		"artocarpus",
		709059
	],
	[
		"s2675518",
		"Artocarpus papuanus",
		"artocarpus",
		2675518
	],
	[
		"s3756940",
		"Artocarpus parvus",
		"artocarpus",
		3756940
	],
	[
		"s709060",
		"Artocarpus petelotii",
		"artocarpus",
		709060
	],
	[
		"s2675500",
		"Artocarpus pinnatisectus",
		"artocarpus",
		2675500
	],
	[
		"s1679377",
		"Artocarpus pithecogallus",
		"artocarpus",
		1679377
	],
	[
		"s1856019",
		"Artocarpus primackii",
		"artocarpus",
		1856019
	],
	[
		"s2675511",
		"Artocarpus reticulatus",
		"artocarpus",
		2675511
	],
	[
		"s709061",
		"Artocarpus rigidus",
		"artocarpus",
		709061
	],
	[
		"s3756941",
		"Artocarpus rubrosoccatus",
		"artocarpus",
		3756941
	],
	[
		"s1867286",
		"Artocarpus rubrovenius",
		"artocarpus",
		1867286
	],
	[
		"s2675513",
		"Artocarpus sarawakensis",
		"artocarpus",
		2675513
	],
	[
		"s709062",
		"Artocarpus scortechinii",
		"artocarpus",
		709062
	],
	[
		"s241860",
		"Artocarpus sepicanus",
		"artocarpus",
		241860
	],
	[
		"s709063",
		"Artocarpus sericicarpus",
		"artocarpus",
		709063
	],
	[
		"s1009334",
		"Artocarpus styracifolius",
		"artocarpus",
		1009334
	],
	[
		"s709064",
		"Artocarpus subrotundifolius",
		"artocarpus",
		709064
	],
	[
		"s2675514",
		"Artocarpus sumatranus",
		"artocarpus",
		2675514
	],
	[
		"s709065",
		"Artocarpus tamaran",
		"artocarpus",
		709065
	],
	[
		"s1856020",
		"Artocarpus teysmannii",
		"artocarpus",
		1856020
	],
	[
		"s1856021",
		"Artocarpus thailandicus",
		"artocarpus",
		1856021
	],
	[
		"s1867287",
		"Artocarpus tomentosulus",
		"artocarpus",
		1867287
	],
	[
		"s3492",
		"Artocarpus tonkinensis",
		"artocarpus",
		3492
	],
	[
		"s709066",
		"Artocarpus treculianus",
		"artocarpus",
		709066
	],
	[
		"s304392",
		"Artocarpus vriesianus",
		"artocarpus",
		304392
	],
	[
		"s1867288",
		"Artocarpus xanthocarpus",
		"artocarpus",
		1867288
	],
	[
		"s2675506",
		"Artocarpus zeylanicus",
		"artocarpus",
		2675506
	],
	[
		"s1161164",
		"Aruncus aethusifolius",
		"aruncus",
		1161164
	],
	[
		"s32220",
		"Aruncus dioicus",
		"aruncus",
		32220
	],
	[
		"s3695045",
		"Aruncus gombalanus",
		"aruncus",
		3695045
	],
	[
		"s133205",
		"Aruncus sylvester",
		"aruncus",
		133205
	],
	[
		"s1399657",
		"Astrothalamus reticulatus",
		"astrothalamus",
		1399657
	],
	[
		"s3758382",
		"Auerodendron acuminatum",
		"auerodendron",
		3758382
	],
	[
		"s1812987",
		"Auerodendron acunae",
		"auerodendron",
		1812987
	],
	[
		"s3084431",
		"Auerodendron cubense",
		"auerodendron",
		3084431
	],
	[
		"s3758383",
		"Auerodendron glaucescens",
		"auerodendron",
		3758383
	],
	[
		"s3084432",
		"Auerodendron jamaicense",
		"auerodendron",
		3084432
	],
	[
		"s3758384",
		"Auerodendron martii",
		"auerodendron",
		3758384
	],
	[
		"s3084433",
		"Auerodendron pauciflorum",
		"auerodendron",
		3084433
	],
	[
		"s3758385",
		"Auerodendron reticulatum",
		"auerodendron",
		3758385
	],
	[
		"s3758386",
		"Auerodendron truncatum",
		"auerodendron",
		3758386
	],
	[
		"s3084434",
		"Australina acuminata",
		"australina",
		3084434
	],
	[
		"s1399659",
		"Australina flaccida",
		"australina",
		1399659
	],
	[
		"s3084435",
		"Australina lanceolata",
		"australina",
		3084435
	],
	[
		"s1748861",
		"Australina pusilla",
		"australina",
		1748861
	],
	[
		"s241862",
		"Bagassa guianensis",
		"bagassa",
		241862
	],
	[
		"s48391",
		"Barbeya oleoides",
		"barbeya",
		48391
	],
	[
		"s3084454",
		"Bathiorhamnus capuronii",
		"bathiorhamnus",
		3084454
	],
	[
		"s106662",
		"Bathiorhamnus cryptophorus",
		"bathiorhamnus",
		106662
	],
	[
		"s3103823",
		"Bathiorhamnus dentatus",
		"bathiorhamnus",
		3103823
	],
	[
		"s3084455",
		"Bathiorhamnus louvelii",
		"bathiorhamnus",
		3084455
	],
	[
		"s3084456",
		"Bathiorhamnus macrocarpus",
		"bathiorhamnus",
		3084456
	],
	[
		"s3084457",
		"Bathiorhamnus reticulatus",
		"bathiorhamnus",
		3084457
	],
	[
		"s3084458",
		"Bathiorhamnus vohemarensis",
		"bathiorhamnus",
		3084458
	],
	[
		"s241864",
		"Batocarpus amazonicus",
		"batocarpus",
		241864
	],
	[
		"s241865",
		"Batocarpus costaricensis",
		"batocarpus",
		241865
	],
	[
		"s2676061",
		"Batocarpus orinocensis",
		"batocarpus",
		2676061
	],
	[
		"s137433",
		"Bencomia brachystachya",
		"bencomia",
		137433
	],
	[
		"s137434",
		"Bencomia caudata",
		"bencomia",
		137434
	],
	[
		"s137435",
		"Bencomia exstipulata",
		"bencomia",
		137435
	],
	[
		"s137436",
		"Bencomia sphaerocarpa",
		"bencomia",
		137436
	],
	[
		"s2939467",
		"Berchemia annamensis",
		"berchemia",
		2939467
	],
	[
		"s3761238",
		"Berchemia arisanensis",
		"berchemia",
		3761238
	],
	[
		"s3084571",
		"Berchemia barbigera",
		"berchemia",
		3084571
	],
	[
		"s2799814",
		"Berchemia brachycarpa",
		"berchemia",
		2799814
	],
	[
		"s3761239",
		"Berchemia burmanniana",
		"berchemia",
		3761239
	],
	[
		"s3761240",
		"Berchemia cinerascens",
		"berchemia",
		3761240
	],
	[
		"s3761241",
		"Berchemia compressicarpa",
		"berchemia",
		3761241
	],
	[
		"s1630241",
		"Berchemia edgeworthii",
		"berchemia",
		1630241
	],
	[
		"s3761242",
		"Berchemia elmeri",
		"berchemia",
		3761242
	],
	[
		"s3761243",
		"Berchemia fenchifuensis",
		"berchemia",
		3761243
	],
	[
		"s1812988",
		"Berchemia flavescens",
		"berchemia",
		1812988
	],
	[
		"s1226760",
		"Berchemia floribunda",
		"berchemia",
		1226760
	],
	[
		"s1812989",
		"Berchemia formosana",
		"berchemia",
		1812989
	],
	[
		"s3084572",
		"Berchemia giraldiana",
		"berchemia",
		3084572
	],
	[
		"s1341704",
		"Berchemia hirtella",
		"berchemia",
		1341704
	],
	[
		"s2799815",
		"Berchemia hispida",
		"berchemia",
		2799815
	],
	[
		"s1812990",
		"Berchemia huana",
		"berchemia",
		1812990
	],
	[
		"s3761244",
		"Berchemia jainiana",
		"berchemia",
		3761244
	],
	[
		"s1621222",
		"Berchemia kulingensis",
		"berchemia",
		1621222
	],
	[
		"s1603695",
		"Berchemia lineata",
		"berchemia",
		1603695
	],
	[
		"s2799816",
		"Berchemia longipedicellata",
		"berchemia",
		2799816
	],
	[
		"s3084573",
		"Berchemia longipes",
		"berchemia",
		3084573
	],
	[
		"s2799817",
		"Berchemia longiracemosa",
		"berchemia",
		2799817
	],
	[
		"s3761245",
		"Berchemia loureiroana",
		"berchemia",
		3761245
	],
	[
		"s2918399",
		"Berchemia magna",
		"berchemia",
		2918399
	],
	[
		"s3761246",
		"Berchemia medogensis",
		"berchemia",
		3761246
	],
	[
		"s3084574",
		"Berchemia nana",
		"berchemia",
		3084574
	],
	[
		"s2799818",
		"Berchemia omeiensis",
		"berchemia",
		2799818
	],
	[
		"s1630242",
		"Berchemia pakistanica",
		"berchemia",
		1630242
	],
	[
		"s3761247",
		"Berchemia paniculata",
		"berchemia",
		3761247
	],
	[
		"s860321",
		"Berchemia pauciflora",
		"berchemia",
		860321
	],
	[
		"s3761248",
		"Berchemia philippinensis",
		"berchemia",
		3761248
	],
	[
		"s3761249",
		"Berchemia poilanei",
		"berchemia",
		3761249
	],
	[
		"s1082498",
		"Berchemia polyphylla",
		"berchemia",
		1082498
	],
	[
		"s3761250",
		"Berchemia pubiflora",
		"berchemia",
		3761250
	],
	[
		"s1226761",
		"Berchemia racemosa",
		"berchemia",
		1226761
	],
	[
		"s860322",
		"Berchemia scandens",
		"berchemia",
		860322
	],
	[
		"s1621223",
		"Berchemia sinica",
		"berchemia",
		1621223
	],
	[
		"s2799819",
		"Berchemia yunnanensis",
		"berchemia",
		2799819
	],
	[
		"s3761251",
		"Berchemia zhejiangensis",
		"berchemia",
		3761251
	],
	[
		"s1813010",
		"Berchemiella berchemiifolia",
		"berchemiella",
		1813010
	],
	[
		"s325278",
		"Berchemiella wilsonii",
		"berchemiella",
		325278
	],
	[
		"s1898906",
		"Berchemiella yunnanensis",
		"berchemiella",
		1898906
	],
	[
		"s323939",
		"Blackallia nudiflora",
		"blackallia",
		323939
	],
	[
		"s3762565",
		"Bleekrodea insignis",
		"bleekrodea",
		3762565
	],
	[
		"s241867",
		"Bleekrodea madagascariensis",
		"bleekrodea",
		241867
	],
	[
		"s2306665",
		"Boehmeria allophylla",
		"boehmeria",
		2306665
	],
	[
		"s2282282",
		"Boehmeria aspera",
		"boehmeria",
		2282282
	],
	[
		"s3084579",
		"Boehmeria australis",
		"boehmeria",
		3084579
	],
	[
		"s3763036",
		"Boehmeria balslevii",
		"boehmeria",
		3763036
	],
	[
		"s3763037",
		"Boehmeria beyeri",
		"boehmeria",
		3763037
	],
	[
		"s106725",
		"Boehmeria biloba",
		"boehmeria",
		106725
	],
	[
		"s3084580",
		"Boehmeria brevirostris",
		"boehmeria",
		3084580
	],
	[
		"s2282283",
		"Boehmeria bullata",
		"boehmeria",
		2282283
	],
	[
		"s2807162",
		"Boehmeria burgeriana",
		"boehmeria",
		2807162
	],
	[
		"s226086",
		"Boehmeria calophleba",
		"boehmeria",
		226086
	],
	[
		"s1079186",
		"Boehmeria caudata",
		"boehmeria",
		1079186
	],
	[
		"s3084581",
		"Boehmeria celebica",
		"boehmeria",
		3084581
	],
	[
		"s2282284",
		"Boehmeria celtidifolia",
		"boehmeria",
		2282284
	],
	[
		"s471944",
		"Boehmeria clidemioides",
		"boehmeria",
		471944
	],
	[
		"s3763038",
		"Boehmeria conica",
		"boehmeria",
		3763038
	],
	[
		"s3084582",
		"Boehmeria coriacea",
		"boehmeria",
		3084582
	],
	[
		"s1503867",
		"Boehmeria cylindrica",
		"boehmeria",
		1503867
	],
	[
		"s1399660",
		"Boehmeria densiflora",
		"boehmeria",
		1399660
	],
	[
		"s644051",
		"Boehmeria densiglomerata",
		"boehmeria",
		644051
	],
	[
		"s3410260",
		"Boehmeria depauperata",
		"boehmeria",
		3410260
	],
	[
		"s3763039",
		"Boehmeria didymogyne",
		"boehmeria",
		3763039
	],
	[
		"s3025149",
		"Boehmeria dolichostachya",
		"boehmeria",
		3025149
	],
	[
		"s3084583",
		"Boehmeria excelsa",
		"boehmeria",
		3084583
	],
	[
		"s644052",
		"Boehmeria formosana",
		"boehmeria",
		644052
	],
	[
		"s458691",
		"Boehmeria frutescens",
		"boehmeria",
		458691
	],
	[
		"s1399661",
		"Boehmeria glomerulifera",
		"boehmeria",
		1399661
	],
	[
		"s644053",
		"Boehmeria gracilis",
		"boehmeria",
		644053
	],
	[
		"s194265",
		"Boehmeria grandis",
		"boehmeria",
		194265
	],
	[
		"s3084584",
		"Boehmeria grandissima",
		"boehmeria",
		3084584
	],
	[
		"s3084585",
		"Boehmeria hamiltoniana",
		"boehmeria",
		3084585
	],
	[
		"s3763040",
		"Boehmeria helferi",
		"boehmeria",
		3763040
	],
	[
		"s3084586",
		"Boehmeria holosericea",
		"boehmeria",
		3084586
	],
	[
		"s3084587",
		"Boehmeria ingjiangensis",
		"boehmeria",
		3084587
	],
	[
		"s2306666",
		"Boehmeria jamaicensis",
		"boehmeria",
		2306666
	],
	[
		"s1399662",
		"Boehmeria japonica",
		"boehmeria",
		1399662
	],
	[
		"s3763041",
		"Boehmeria kurzii",
		"boehmeria",
		3763041
	],
	[
		"s3763042",
		"Boehmeria lalashanensis",
		"boehmeria",
		3763042
	],
	[
		"s3084588",
		"Boehmeria lanceolata",
		"boehmeria",
		3084588
	],
	[
		"s644054",
		"Boehmeria leiophylla",
		"boehmeria",
		644054
	],
	[
		"s3763043",
		"Boehmeria leptostachya",
		"boehmeria",
		3763043
	],
	[
		"s3763044",
		"Boehmeria listeri",
		"boehmeria",
		3763044
	],
	[
		"s644055",
		"Boehmeria longispica",
		"boehmeria",
		644055
	],
	[
		"s3763045",
		"Boehmeria manipurensis",
		"boehmeria",
		3763045
	],
	[
		"s3763046",
		"Boehmeria multiflora",
		"boehmeria",
		3763046
	],
	[
		"s3084589",
		"Boehmeria nakashimae",
		"boehmeria",
		3084589
	],
	[
		"s83906",
		"Boehmeria nivea",
		"boehmeria",
		83906
	],
	[
		"s3763047",
		"Boehmeria ourantha",
		"boehmeria",
		3763047
	],
	[
		"s1049918",
		"Boehmeria pannosa",
		"boehmeria",
		1049918
	],
	[
		"s2282285",
		"Boehmeria pavonii",
		"boehmeria",
		2282285
	],
	[
		"s1077888",
		"Boehmeria penduliflora",
		"boehmeria",
		1077888
	],
	[
		"s644065",
		"Boehmeria pilosiuscula",
		"boehmeria",
		644065
	],
	[
		"s172313",
		"Boehmeria platanifolia",
		"boehmeria",
		172313
	],
	[
		"s647259",
		"Boehmeria platyphylla",
		"boehmeria",
		647259
	],
	[
		"s644066",
		"Boehmeria polystachya",
		"boehmeria",
		644066
	],
	[
		"s644067",
		"Boehmeria pseudotricuspis",
		"boehmeria",
		644067
	],
	[
		"s1751423",
		"Boehmeria quelpaertensis",
		"boehmeria",
		1751423
	],
	[
		"s3084590",
		"Boehmeria radiata",
		"boehmeria",
		3084590
	],
	[
		"s2306667",
		"Boehmeria ramiflora",
		"boehmeria",
		2306667
	],
	[
		"s644068",
		"Boehmeria siamensis",
		"boehmeria",
		644068
	],
	[
		"s2306668",
		"Boehmeria sieboldiana",
		"boehmeria",
		2306668
	],
	[
		"s644069",
		"Boehmeria silvestrii",
		"boehmeria",
		644069
	],
	[
		"s3763048",
		"Boehmeria songmaoensis",
		"boehmeria",
		3763048
	],
	[
		"s1303698",
		"Boehmeria spicata",
		"boehmeria",
		1303698
	],
	[
		"s3763049",
		"Boehmeria spicigera",
		"boehmeria",
		3763049
	],
	[
		"s644070",
		"Boehmeria strigosifolia",
		"boehmeria",
		644070
	],
	[
		"s3763050",
		"Boehmeria subintegra",
		"boehmeria",
		3763050
	],
	[
		"s3763051",
		"Boehmeria ternifolia",
		"boehmeria",
		3763051
	],
	[
		"s1399666",
		"Boehmeria tomentosa",
		"boehmeria",
		1399666
	],
	[
		"s644073",
		"Boehmeria tricuspis",
		"boehmeria",
		644073
	],
	[
		"s3015599",
		"Boehmeria tsaratananensis",
		"boehmeria",
		3015599
	],
	[
		"s3763052",
		"Boehmeria tungyuanshanensis",
		"boehmeria",
		3763052
	],
	[
		"s2282286",
		"Boehmeria ulmifolia",
		"boehmeria",
		2282286
	],
	[
		"s1002523",
		"Boehmeria umbrosa",
		"boehmeria",
		1002523
	],
	[
		"s3763053",
		"Boehmeria villosa",
		"boehmeria",
		3763053
	],
	[
		"s3017779",
		"Boehmeria virgata",
		"boehmeria",
		3017779
	],
	[
		"s1898923",
		"Boehmeria wattersii",
		"boehmeria",
		1898923
	],
	[
		"s3083230",
		"Boehmeria x arenicola",
		"boehmeria",
		3083230
	],
	[
		"s3083231",
		"Boehmeria x dura",
		"boehmeria",
		3083231
	],
	[
		"s3142651",
		"Boehmeria x kiusiana",
		"boehmeria",
		3142651
	],
	[
		"s2813834",
		"Boehmeria yaeyamensis",
		"boehmeria",
		2813834
	],
	[
		"s644074",
		"Boehmeria zollingeriana",
		"boehmeria",
		644074
	],
	[
		"s1899165",
		"Bosqueiopsis carvalhoana",
		"bosqueiopsis",
		1899165
	],
	[
		"s2604971",
		"Bosqueiopsis gilletii",
		"bosqueiopsis",
		2604971
	],
	[
		"s1835378",
		"Brosimum acutifolium",
		"brosimum",
		1835378
	],
	[
		"s194253",
		"Brosimum alicastrum",
		"brosimum",
		194253
	],
	[
		"s241937",
		"Brosimum amazonicum",
		"brosimum",
		241937
	],
	[
		"s1807093",
		"Brosimum costaricanum",
		"brosimum",
		1807093
	],
	[
		"s1620273",
		"Brosimum gaudichaudii",
		"brosimum",
		1620273
	],
	[
		"s2732301",
		"Brosimum glaucum",
		"brosimum",
		2732301
	],
	[
		"s1924159",
		"Brosimum glaziovii",
		"brosimum",
		1924159
	],
	[
		"s241868",
		"Brosimum guianense",
		"brosimum",
		241868
	],
	[
		"s241869",
		"Brosimum lactescens",
		"brosimum",
		241869
	],
	[
		"s2732302",
		"Brosimum longifolium",
		"brosimum",
		2732302
	],
	[
		"s3086205",
		"Brosimum melanopotamicum",
		"brosimum",
		3086205
	],
	[
		"s2732303",
		"Brosimum multinervium",
		"brosimum",
		2732303
	],
	[
		"s241938",
		"Brosimum oligandrum",
		"brosimum",
		241938
	],
	[
		"s1937415",
		"Brosimum parinarioides",
		"brosimum",
		1937415
	],
	[
		"s2732304",
		"Brosimum potabile",
		"brosimum",
		2732304
	],
	[
		"s241870",
		"Brosimum rubescens",
		"brosimum",
		241870
	],
	[
		"s241883",
		"Brosimum sprucei",
		"brosimum",
		241883
	],
	[
		"s3089649",
		"Brosimum steyermarkii",
		"brosimum",
		3089649
	],
	[
		"s241871",
		"Brosimum utile",
		"brosimum",
		241871
	],
	[
		"s1867290",
		"Broussonetia greveana",
		"broussonetia",
		1867290
	],
	[
		"s3764151",
		"Broussonetia harmandii",
		"broussonetia",
		3764151
	],
	[
		"s1566870",
		"Broussonetia kaempferi",
		"broussonetia",
		1566870
	],
	[
		"s66380",
		"Broussonetia kazinoki",
		"broussonetia",
		66380
	],
	[
		"s1736113",
		"Broussonetia kazinoki x Broussonetia papyrifera",
		"broussonetia",
		1736113
	],
	[
		"s1867291",
		"Broussonetia kurzii",
		"broussonetia",
		1867291
	],
	[
		"s1968119",
		"Broussonetia luzonica",
		"broussonetia",
		1968119
	],
	[
		"s1968120",
		"Broussonetia monoica",
		"broussonetia",
		1968120
	],
	[
		"s172644",
		"Broussonetia papyrifera",
		"broussonetia",
		172644
	],
	[
		"s2817436",
		"Broussonetia x hanjiana",
		"broussonetia",
		2817436
	],
	[
		"s3710501",
		"Calaunia negrosensis",
		"calaunia",
		3710501
	],
	[
		"s2705184",
		"Cannabis hybrid cultivar",
		"cannabis",
		2705184
	],
	[
		"s2358337",
		"Cannabis ruderalis",
		"cannabis",
		2358337
	],
	[
		"s3483",
		"Cannabis sativa",
		"cannabis",
		3483
	],
	[
		"s3711209",
		"Capsulea bashanensis",
		"capsulea",
		3711209
	],
	[
		"s194257",
		"Castilla elastica",
		"castilla",
		194257
	],
	[
		"s1568987",
		"Castilla tunu",
		"castilla",
		1568987
	],
	[
		"s241872",
		"Castilla ulei",
		"castilla",
		241872
	],
	[
		"s54778",
		"Ceanothus americanus",
		"ceanothus",
		54778
	],
	[
		"s73671",
		"Ceanothus arboreus",
		"ceanothus",
		73671
	],
	[
		"s1004054",
		"Ceanothus arcuatus",
		"ceanothus",
		1004054
	],
	[
		"s1004055",
		"Ceanothus bolensis",
		"ceanothus",
		1004055
	],
	[
		"s73672",
		"Ceanothus buxifolius",
		"ceanothus",
		73672
	],
	[
		"s72170",
		"Ceanothus caeruleus",
		"ceanothus",
		72170
	],
	[
		"s73673",
		"Ceanothus confusus",
		"ceanothus",
		73673
	],
	[
		"s54779",
		"Ceanothus cordulatus",
		"ceanothus",
		54779
	],
	[
		"s73674",
		"Ceanothus crassifolius",
		"ceanothus",
		73674
	],
	[
		"s54780",
		"Ceanothus cuneatus",
		"ceanothus",
		54780
	],
	[
		"s73675",
		"Ceanothus cyaneus",
		"ceanothus",
		73675
	],
	[
		"s3472728",
		"Ceanothus decornutus",
		"ceanothus",
		3472728
	],
	[
		"s73676",
		"Ceanothus dentatus",
		"ceanothus",
		73676
	],
	[
		"s3086247",
		"Ceanothus depressus",
		"ceanothus",
		3086247
	],
	[
		"s73677",
		"Ceanothus divergens",
		"ceanothus",
		73677
	],
	[
		"s73678",
		"Ceanothus diversifolius",
		"ceanothus",
		73678
	],
	[
		"s54781",
		"Ceanothus fendleri",
		"ceanothus",
		54781
	],
	[
		"s3769786",
		"Ceanothus fernandezii",
		"ceanothus",
		3769786
	],
	[
		"s73679",
		"Ceanothus ferrisiae",
		"ceanothus",
		73679
	],
	[
		"s73654",
		"Ceanothus foliosus",
		"ceanothus",
		73654
	],
	[
		"s73680",
		"Ceanothus fresnensis",
		"ceanothus",
		73680
	],
	[
		"s73660",
		"Ceanothus gloriosus",
		"ceanothus",
		73660
	],
	[
		"s73681",
		"Ceanothus griseus",
		"ceanothus",
		73681
	],
	[
		"s73682",
		"Ceanothus hearstiorum",
		"ceanothus",
		73682
	],
	[
		"s73683",
		"Ceanothus herbaceus",
		"ceanothus",
		73683
	],
	[
		"s73684",
		"Ceanothus impressus",
		"ceanothus",
		73684
	],
	[
		"s73685",
		"Ceanothus incanus",
		"ceanothus",
		73685
	],
	[
		"s54782",
		"Ceanothus integerrimus",
		"ceanothus",
		54782
	],
	[
		"s73666",
		"Ceanothus jepsonii",
		"ceanothus",
		73666
	],
	[
		"s73686",
		"Ceanothus lanuginosus",
		"ceanothus",
		73686
	],
	[
		"s73687",
		"Ceanothus lemmonii",
		"ceanothus",
		73687
	],
	[
		"s73688",
		"Ceanothus leucodermis",
		"ceanothus",
		73688
	],
	[
		"s73689",
		"Ceanothus maritimus",
		"ceanothus",
		73689
	],
	[
		"s73690",
		"Ceanothus martini",
		"ceanothus",
		73690
	],
	[
		"s73691",
		"Ceanothus masonii",
		"ceanothus",
		73691
	],
	[
		"s73692",
		"Ceanothus megacarpus",
		"ceanothus",
		73692
	],
	[
		"s1004066",
		"Ceanothus microphyllus",
		"ceanothus",
		1004066
	],
	[
		"s1004067",
		"Ceanothus ochraceus",
		"ceanothus",
		1004067
	],
	[
		"s73697",
		"Ceanothus oliganthus",
		"ceanothus",
		73697
	],
	[
		"s73700",
		"Ceanothus ophiochilus",
		"ceanothus",
		73700
	],
	[
		"s1004070",
		"Ceanothus otayensis",
		"ceanothus",
		1004070
	],
	[
		"s73701",
		"Ceanothus palmeri",
		"ceanothus",
		73701
	],
	[
		"s73702",
		"Ceanothus papillosus",
		"ceanothus",
		73702
	],
	[
		"s73705",
		"Ceanothus parryi",
		"ceanothus",
		73705
	],
	[
		"s73706",
		"Ceanothus parvifolius",
		"ceanothus",
		73706
	],
	[
		"s1004072",
		"Ceanothus pauciflorus",
		"ceanothus",
		1004072
	],
	[
		"s1004073",
		"Ceanothus perplexans",
		"ceanothus",
		1004073
	],
	[
		"s73707",
		"Ceanothus pinetorum",
		"ceanothus",
		73707
	],
	[
		"s54783",
		"Ceanothus prostratus",
		"ceanothus",
		54783
	],
	[
		"s54784",
		"Ceanothus pumilus",
		"ceanothus",
		54784
	],
	[
		"s73708",
		"Ceanothus purpureus",
		"ceanothus",
		73708
	],
	[
		"s73709",
		"Ceanothus roderickii",
		"ceanothus",
		73709
	],
	[
		"s32209",
		"Ceanothus sanguineus",
		"ceanothus",
		32209
	],
	[
		"s3769787",
		"Ceanothus serpyllifolius",
		"ceanothus",
		3769787
	],
	[
		"s73710",
		"Ceanothus sonomensis",
		"ceanothus",
		73710
	],
	[
		"s73711",
		"Ceanothus spinosus",
		"ceanothus",
		73711
	],
	[
		"s48245",
		"Ceanothus thyrsiflorus",
		"ceanothus",
		48245
	],
	[
		"s73712",
		"Ceanothus tomentosus",
		"ceanothus",
		73712
	],
	[
		"s54785",
		"Ceanothus velutinus",
		"ceanothus",
		54785
	],
	[
		"s73714",
		"Ceanothus verrucosus",
		"ceanothus",
		73714
	],
	[
		"s1004082",
		"Ceanothus vestitus",
		"ceanothus",
		1004082
	],
	[
		"s3084737",
		"Ceanothus x veitchianus",
		"ceanothus",
		3084737
	],
	[
		"s3733534",
		"Cecropia albicans",
		"cecropia",
		3733534
	],
	[
		"s1958839",
		"Cecropia andina",
		"cecropia",
		1958839
	],
	[
		"s3733535",
		"Cecropia angulata",
		"cecropia",
		3733535
	],
	[
		"s1958840",
		"Cecropia angustifolia",
		"cecropia",
		1958840
	],
	[
		"s1958841",
		"Cecropia annulata",
		"cecropia",
		1958841
	],
	[
		"s1958842",
		"Cecropia bullata",
		"cecropia",
		1958842
	],
	[
		"s3733536",
		"Cecropia candida",
		"cecropia",
		3733536
	],
	[
		"s3733537",
		"Cecropia chlorostachya",
		"cecropia",
		3733537
	],
	[
		"s1958843",
		"Cecropia concolor",
		"cecropia",
		1958843
	],
	[
		"s3733538",
		"Cecropia dealbata",
		"cecropia",
		3733538
	],
	[
		"s871997",
		"Cecropia distachya",
		"cecropia",
		871997
	],
	[
		"s1958844",
		"Cecropia elongata",
		"cecropia",
		1958844
	],
	[
		"s1958845",
		"Cecropia engleriana",
		"cecropia",
		1958845
	],
	[
		"s1078255",
		"Cecropia ficifolia",
		"cecropia",
		1078255
	],
	[
		"s1958846",
		"Cecropia gabrielis",
		"cecropia",
		1958846
	],
	[
		"s3733539",
		"Cecropia garciae",
		"cecropia",
		3733539
	],
	[
		"s1824952",
		"Cecropia glaziovii",
		"cecropia",
		1824952
	],
	[
		"s2116347",
		"Cecropia goudotiana",
		"cecropia",
		2116347
	],
	[
		"s1958847",
		"Cecropia granvilleana",
		"cecropia",
		1958847
	],
	[
		"s2116348",
		"Cecropia herthae",
		"cecropia",
		2116348
	],
	[
		"s3733540",
		"Cecropia heterochroma",
		"cecropia",
		3733540
	],
	[
		"s1568988",
		"Cecropia hispidissima",
		"cecropia",
		1568988
	],
	[
		"s1958848",
		"Cecropia hololeuca",
		"cecropia",
		1958848
	],
	[
		"s3733541",
		"Cecropia idroboi",
		"cecropia",
		3733541
	],
	[
		"s241854",
		"Cecropia insignis",
		"cecropia",
		241854
	],
	[
		"s3086248",
		"Cecropia kavanayensis",
		"cecropia",
		3086248
	],
	[
		"s1958849",
		"Cecropia latiloba",
		"cecropia",
		1958849
	],
	[
		"s1958850",
		"Cecropia litoralis",
		"cecropia",
		1958850
	],
	[
		"s681420",
		"Cecropia longipes",
		"cecropia",
		681420
	],
	[
		"s1781616",
		"Cecropia marginalis",
		"cecropia",
		1781616
	],
	[
		"s1958851",
		"Cecropia maxima",
		"cecropia",
		1958851
	],
	[
		"s3733542",
		"Cecropia megastachya",
		"cecropia",
		3733542
	],
	[
		"s1078256",
		"Cecropia membranacea",
		"cecropia",
		1078256
	],
	[
		"s2116349",
		"Cecropia metensis",
		"cecropia",
		2116349
	],
	[
		"s1958852",
		"Cecropia montana",
		"cecropia",
		1958852
	],
	[
		"s2116350",
		"Cecropia multisecta",
		"cecropia",
		2116350
	],
	[
		"s2116351",
		"Cecropia mutisiana",
		"cecropia",
		2116351
	],
	[
		"s688039",
		"Cecropia obtusa",
		"cecropia",
		688039
	],
	[
		"s241855",
		"Cecropia obtusifolia",
		"cecropia",
		241855
	],
	[
		"s1472306",
		"Cecropia pachystachya",
		"cecropia",
		1472306
	],
	[
		"s77072",
		"Cecropia palmata",
		"cecropia",
		77072
	],
	[
		"s2116352",
		"Cecropia pastasana",
		"cecropia",
		2116352
	],
	[
		"s210352",
		"Cecropia peltata",
		"cecropia",
		210352
	],
	[
		"s3086249",
		"Cecropia pittieri",
		"cecropia",
		3086249
	],
	[
		"s2116353",
		"Cecropia plicata",
		"cecropia",
		2116353
	],
	[
		"s1958853",
		"Cecropia polystachya",
		"cecropia",
		1958853
	],
	[
		"s3733543",
		"Cecropia purpurascens",
		"cecropia",
		3733543
	],
	[
		"s1781617",
		"Cecropia putumayonis",
		"cecropia",
		1781617
	],
	[
		"s1958854",
		"Cecropia reticulata",
		"cecropia",
		1958854
	],
	[
		"s2116354",
		"Cecropia sararensis",
		"cecropia",
		2116354
	],
	[
		"s3733544",
		"Cecropia saxatilis",
		"cecropia",
		3733544
	],
	[
		"s883769",
		"Cecropia schreberiana",
		"cecropia",
		883769
	],
	[
		"s1568989",
		"Cecropia sciadophylla",
		"cecropia",
		1568989
	],
	[
		"s1958855",
		"Cecropia silvae",
		"cecropia",
		1958855
	],
	[
		"s3733545",
		"Cecropia strigosa",
		"cecropia",
		3733545
	],
	[
		"s3733546",
		"Cecropia subintegra",
		"cecropia",
		3733546
	],
	[
		"s1781618",
		"Cecropia tacuna",
		"cecropia",
		1781618
	],
	[
		"s1781619",
		"Cecropia telealba",
		"cecropia",
		1781619
	],
	[
		"s1958856",
		"Cecropia telenitida",
		"cecropia",
		1958856
	],
	[
		"s3733547",
		"Cecropia ulei",
		"cecropia",
		3733547
	],
	[
		"s1958857",
		"Cecropia utcubambana",
		"cecropia",
		1958857
	],
	[
		"s3733548",
		"Cecropia velutinella",
		"cecropia",
		3733548
	],
	[
		"s3733549",
		"Cecropia virgusa",
		"cecropia",
		3733549
	],
	[
		"s1184749",
		"Celtis aculeata",
		"celtis",
		1184749
	],
	[
		"s2606464",
		"Celtis adolfi-friderici",
		"celtis",
		2606464
	],
	[
		"s266494",
		"Celtis africana",
		"celtis",
		266494
	],
	[
		"s3769788",
		"Celtis alnifolia",
		"celtis",
		3769788
	],
	[
		"s3769789",
		"Celtis atlantica",
		"celtis",
		3769789
	],
	[
		"s236733",
		"Celtis australis",
		"celtis",
		236733
	],
	[
		"s3769790",
		"Celtis balansae",
		"celtis",
		3769790
	],
	[
		"s3769791",
		"Celtis berteroana",
		"celtis",
		3769791
	],
	[
		"s3086250",
		"Celtis bifida",
		"celtis",
		3086250
	],
	[
		"s1184750",
		"Celtis biondii",
		"celtis",
		1184750
	],
	[
		"s1322069",
		"Celtis boninensis",
		"celtis",
		1322069
	],
	[
		"s2321265",
		"Celtis brasiliensis",
		"celtis",
		2321265
	],
	[
		"s198263",
		"Celtis bungeana",
		"celtis",
		198263
	],
	[
		"s2916632",
		"Celtis caucasica",
		"celtis",
		2916632
	],
	[
		"s2606465",
		"Celtis caudata",
		"celtis",
		2606465
	],
	[
		"s2662398",
		"Celtis cerasifera",
		"celtis",
		2662398
	],
	[
		"s2605624",
		"Celtis chekiangensis",
		"celtis",
		2605624
	],
	[
		"s2606466",
		"Celtis chichape",
		"celtis",
		2606466
	],
	[
		"s1803866",
		"Celtis choseniana",
		"celtis",
		1803866
	],
	[
		"s3769792",
		"Celtis clausseniana",
		"celtis",
		3769792
	],
	[
		"s3086251",
		"Celtis conferta",
		"celtis",
		3086251
	],
	[
		"s2606467",
		"Celtis cordifolia",
		"celtis",
		2606467
	],
	[
		"s3769793",
		"Celtis dichotoma",
		"celtis",
		3769793
	],
	[
		"s3769794",
		"Celtis diffusa",
		"celtis",
		3769794
	],
	[
		"s289393",
		"Celtis durandii",
		"celtis",
		289393
	],
	[
		"s2605625",
		"Celtis edulis",
		"celtis",
		2605625
	],
	[
		"s3769795",
		"Celtis eriocarpa",
		"celtis",
		3769795
	],
	[
		"s3769796",
		"Celtis flumeniana",
		"celtis",
		3769796
	],
	[
		"s2072225",
		"Celtis fluminensis",
		"celtis",
		2072225
	],
	[
		"s1262441",
		"Celtis formosana",
		"celtis",
		1262441
	],
	[
		"s3769797",
		"Celtis gardneri",
		"celtis",
		3769797
	],
	[
		"s241808",
		"Celtis glabrata",
		"celtis",
		241808
	],
	[
		"s1237421",
		"Celtis gomphophylla",
		"celtis",
		1237421
	],
	[
		"s3769798",
		"Celtis harperi",
		"celtis",
		3769798
	],
	[
		"s3769799",
		"Celtis hilariana",
		"celtis",
		3769799
	],
	[
		"s3086252",
		"Celtis hildebrandii",
		"celtis",
		3086252
	],
	[
		"s3086253",
		"Celtis hypoleuca",
		"celtis",
		3086253
	],
	[
		"s258491",
		"Celtis iguanaea",
		"celtis",
		258491
	],
	[
		"s2606468",
		"Celtis jamaicensis",
		"celtis",
		2606468
	],
	[
		"s2606469",
		"Celtis jessoensis",
		"celtis",
		2606469
	],
	[
		"s1817789",
		"Celtis julianae",
		"celtis",
		1817789
	],
	[
		"s198264",
		"Celtis koraiensis",
		"celtis",
		198264
	],
	[
		"s1399766",
		"Celtis kunmingensis",
		"celtis",
		1399766
	],
	[
		"s102692",
		"Celtis laevigata",
		"celtis",
		102692
	],
	[
		"s3769800",
		"Celtis lancifolia",
		"celtis",
		3769800
	],
	[
		"s384951",
		"Celtis latifolia",
		"celtis",
		384951
	],
	[
		"s3086254",
		"Celtis lindheimeri",
		"celtis",
		3086254
	],
	[
		"s3086255",
		"Celtis loxensis",
		"celtis",
		3086255
	],
	[
		"s3086256",
		"Celtis luzonica",
		"celtis",
		3086256
	],
	[
		"s1184751",
		"Celtis madagascariensis",
		"celtis",
		1184751
	],
	[
		"s3769801",
		"Celtis mauritiana",
		"celtis",
		3769801
	],
	[
		"s1237422",
		"Celtis mildbraedii",
		"celtis",
		1237422
	],
	[
		"s1963362",
		"Celtis neglecta",
		"celtis",
		1963362
	],
	[
		"s228587",
		"Celtis occidentalis",
		"celtis",
		228587
	],
	[
		"s2682028",
		"Celtis orthacanthos",
		"celtis",
		2682028
	],
	[
		"s3086257",
		"Celtis pacifica",
		"celtis",
		3086257
	],
	[
		"s2606470",
		"Celtis pallida",
		"celtis",
		2606470
	],
	[
		"s1382030",
		"Celtis paniculata",
		"celtis",
		1382030
	],
	[
		"s3769802",
		"Celtis petenensis",
		"celtis",
		3769802
	],
	[
		"s213552",
		"Celtis philippensis",
		"celtis",
		213552
	],
	[
		"s3086258",
		"Celtis prantlii",
		"celtis",
		3086258
	],
	[
		"s2364040",
		"Celtis pubescens",
		"celtis",
		2364040
	],
	[
		"s3769803",
		"Celtis punctata",
		"celtis",
		3769803
	],
	[
		"s2042378",
		"Celtis reticulata",
		"celtis",
		2042378
	],
	[
		"s3086259",
		"Celtis rigescens",
		"celtis",
		3086259
	],
	[
		"s3769804",
		"Celtis rubrovenia",
		"celtis",
		3769804
	],
	[
		"s3769805",
		"Celtis salomonensis",
		"celtis",
		3769805
	],
	[
		"s298313",
		"Celtis schippii",
		"celtis",
		298313
	],
	[
		"s2606471",
		"Celtis scotellioides",
		"celtis",
		2606471
	],
	[
		"s1184752",
		"Celtis sellowiana",
		"celtis",
		1184752
	],
	[
		"s2682029",
		"Celtis serratissima",
		"celtis",
		2682029
	],
	[
		"s63053",
		"Celtis sinensis",
		"celtis",
		63053
	],
	[
		"s3769806",
		"Celtis smallii",
		"celtis",
		3769806
	],
	[
		"s2606472",
		"Celtis spinosa",
		"celtis",
		2606472
	],
	[
		"s2682027",
		"Celtis spinosissima",
		"celtis",
		2682027
	],
	[
		"s3769807",
		"Celtis strychnoides",
		"celtis",
		3769807
	],
	[
		"s1184753",
		"Celtis tala",
		"celtis",
		1184753
	],
	[
		"s2071413",
		"Celtis tenuifolia",
		"celtis",
		2071413
	],
	[
		"s2605626",
		"Celtis tessmannii",
		"celtis",
		2605626
	],
	[
		"s1037060",
		"Celtis tetrandra",
		"celtis",
		1037060
	],
	[
		"s3769808",
		"Celtis tikalana",
		"celtis",
		3769808
	],
	[
		"s1679370",
		"Celtis timorensis",
		"celtis",
		1679370
	],
	[
		"s3085945",
		"Celtis toka",
		"celtis",
		3085945
	],
	[
		"s236732",
		"Celtis tournefortii",
		"celtis",
		236732
	],
	[
		"s3769809",
		"Celtis triflora",
		"celtis",
		3769809
	],
	[
		"s1465249",
		"Celtis trinervia",
		"celtis",
		1465249
	],
	[
		"s1963363",
		"Celtis vandervoetiana",
		"celtis",
		1963363
	],
	[
		"s3769810",
		"Celtis vitiensis",
		"celtis",
		3769810
	],
	[
		"s13409",
		"Celtis yunnanensis",
		"celtis",
		13409
	],
	[
		"s2606473",
		"Celtis zenkeri",
		"celtis",
		2606473
	],
	[
		"s140994",
		"Cercocarpus betuloides",
		"cercocarpus",
		140994
	],
	[
		"s3898561",
		"Cercocarpus breviflorus",
		"cercocarpus",
		3898561
	],
	[
		"s3086267",
		"Cercocarpus douglasii",
		"cercocarpus",
		3086267
	],
	[
		"s3898563",
		"Cercocarpus fonsecae",
		"cercocarpus",
		3898563
	],
	[
		"s2778667",
		"Cercocarpus fothergilloides",
		"cercocarpus",
		2778667
	],
	[
		"s3898566",
		"Cercocarpus henricksonianus",
		"cercocarpus",
		3898566
	],
	[
		"s1841639",
		"Cercocarpus intricatus",
		"cercocarpus",
		1841639
	],
	[
		"s32221",
		"Cercocarpus ledifolius",
		"cercocarpus",
		32221
	],
	[
		"s3898564",
		"Cercocarpus longipedicellatus",
		"cercocarpus",
		3898564
	],
	[
		"s3046118",
		"Cercocarpus macrophyllus",
		"cercocarpus",
		3046118
	],
	[
		"s3771179",
		"Cercocarpus mexicanus",
		"cercocarpus",
		3771179
	],
	[
		"s3771180",
		"Cercocarpus mojadensis",
		"cercocarpus",
		3771180
	],
	[
		"s457890",
		"Cercocarpus montanus",
		"cercocarpus",
		457890
	],
	[
		"s2778668",
		"Cercocarpus pringlei",
		"cercocarpus",
		2778668
	],
	[
		"s3771181",
		"Cercocarpus rotundifolius",
		"cercocarpus",
		3771181
	],
	[
		"s2778669",
		"Cercocarpus rzedowskii",
		"cercocarpus",
		2778669
	],
	[
		"s36604",
		"Chaenomeles cathayensis",
		"chaenomeles",
		36604
	],
	[
		"s320146",
		"Chaenomeles japonica",
		"chaenomeles",
		320146
	],
	[
		"s106546",
		"Chaenomeles speciosa",
		"chaenomeles",
		106546
	],
	[
		"s2054446",
		"Chaenomeles thibetica",
		"chaenomeles",
		2054446
	],
	[
		"s63056",
		"Chaetachme aristata",
		"chaetachme",
		63056
	],
	[
		"s1184754",
		"Chaetachme madagascariensis",
		"chaetachme",
		1184754
	],
	[
		"s1184755",
		"Chaetachme microcarpa",
		"chaetachme",
		1184755
	],
	[
		"s1204772",
		"Chamabainia cuspidata",
		"chamabainia",
		1204772
	],
	[
		"s3771503",
		"Chamabainia guanwuensis",
		"chamabainia",
		3771503
	],
	[
		"s3771507",
		"Chamaebatia australis",
		"chamaebatia",
		3771507
	],
	[
		"s140996",
		"Chamaebatia foliolosa",
		"chamaebatia",
		140996
	],
	[
		"s32222",
		"Chamaebatiaria millefolium",
		"chamaebatiaria",
		32222
	],
	[
		"s1541699",
		"Chamaecallis perpusilloides",
		"chamaecallis",
		1541699
	],
	[
		"s397657",
		"Chamaemeles coriacea",
		"chamaemeles",
		397657
	],
	[
		"s193300",
		"Chamaemespilus alpina",
		"chamaemespilus",
		193300
	],
	[
		"s2980421",
		"Chamaemespilus humilis",
		"chamaemespilus",
		2980421
	],
	[
		"s667205",
		"Chamaerhodos altaica",
		"chamaerhodos",
		667205
	],
	[
		"s2781643",
		"Chamaerhodos canescens",
		"chamaerhodos",
		2781643
	],
	[
		"s3771652",
		"Chamaerhodos corymbosa",
		"chamaerhodos",
		3771652
	],
	[
		"s57916",
		"Chamaerhodos erecta",
		"chamaerhodos",
		57916
	],
	[
		"s3085949",
		"Chamaerhodos grandiflora",
		"chamaerhodos",
		3085949
	],
	[
		"s637906",
		"Chamaerhodos mongholica",
		"chamaerhodos",
		637906
	],
	[
		"s637907",
		"Chamaerhodos nuttallii",
		"chamaerhodos",
		637907
	],
	[
		"s637908",
		"Chamaerhodos sabulosa",
		"chamaerhodos",
		637908
	],
	[
		"s2781644",
		"Chamaerhodos trifida",
		"chamaerhodos",
		2781644
	],
	[
		"s241874",
		"Clarisia biflora",
		"clarisia",
		241874
	],
	[
		"s241875",
		"Clarisia ilicifolia",
		"clarisia",
		241875
	],
	[
		"s871999",
		"Clarisia racemosa",
		"clarisia",
		871999
	],
	[
		"s550829",
		"Cliffortia acanthophylla",
		"cliffortia",
		550829
	],
	[
		"s3778274",
		"Cliffortia acockii",
		"cliffortia",
		3778274
	],
	[
		"s550830",
		"Cliffortia aculeata",
		"cliffortia",
		550830
	],
	[
		"s550831",
		"Cliffortia acutifolia",
		"cliffortia",
		550831
	],
	[
		"s3086276",
		"Cliffortia aequatorialis",
		"cliffortia",
		3086276
	],
	[
		"s550832",
		"Cliffortia alata",
		"cliffortia",
		550832
	],
	[
		"s550833",
		"Cliffortia amplexistipula",
		"cliffortia",
		550833
	],
	[
		"s550834",
		"Cliffortia anthospermoides",
		"cliffortia",
		550834
	],
	[
		"s550835",
		"Cliffortia apiculata",
		"cliffortia",
		550835
	],
	[
		"s550836",
		"Cliffortia arborea",
		"cliffortia",
		550836
	],
	[
		"s550837",
		"Cliffortia arcuata",
		"cliffortia",
		550837
	],
	[
		"s550838",
		"Cliffortia atrata",
		"cliffortia",
		550838
	],
	[
		"s550839",
		"Cliffortia baccans",
		"cliffortia",
		550839
	],
	[
		"s3778275",
		"Cliffortia berberidis",
		"cliffortia",
		3778275
	],
	[
		"s3778276",
		"Cliffortia bolusii",
		"cliffortia",
		3778276
	],
	[
		"s550840",
		"Cliffortia brevifolia",
		"cliffortia",
		550840
	],
	[
		"s550841",
		"Cliffortia browniana",
		"cliffortia",
		550841
	],
	[
		"s550842",
		"Cliffortia burchellii",
		"cliffortia",
		550842
	],
	[
		"s550843",
		"Cliffortia burgersii",
		"cliffortia",
		550843
	],
	[
		"s550844",
		"Cliffortia carinata",
		"cliffortia",
		550844
	],
	[
		"s550845",
		"Cliffortia castanea",
		"cliffortia",
		550845
	],
	[
		"s550846",
		"Cliffortia ceresana",
		"cliffortia",
		550846
	],
	[
		"s550847",
		"Cliffortia cervicornu",
		"cliffortia",
		550847
	],
	[
		"s550849",
		"Cliffortia cf. eriocephalina Whitehouse 188",
		"cliffortia",
		550849
	],
	[
		"s550850",
		"Cliffortia cf. glauca Whitehouse 214",
		"cliffortia",
		550850
	],
	[
		"s550851",
		"Cliffortia cf. glauca Whitehouse 78",
		"cliffortia",
		550851
	],
	[
		"s550852",
		"Cliffortia cf. polita Whitehouse 128",
		"cliffortia",
		550852
	],
	[
		"s550853",
		"Cliffortia cf. polita Whitehouse 301",
		"cliffortia",
		550853
	],
	[
		"s550854",
		"Cliffortia cf. pterocarpa Whitehouse 126",
		"cliffortia",
		550854
	],
	[
		"s550855",
		"Cliffortia cf. semiteres Whitehouse 231",
		"cliffortia",
		550855
	],
	[
		"s550856",
		"Cliffortia cf. verrucosa Whitehouse 89",
		"cliffortia",
		550856
	],
	[
		"s550857",
		"Cliffortia cf. virgata Whitehouse 264",
		"cliffortia",
		550857
	],
	[
		"s550858",
		"Cliffortia complanata",
		"cliffortia",
		550858
	],
	[
		"s3778277",
		"Cliffortia concinna",
		"cliffortia",
		3778277
	],
	[
		"s550859",
		"Cliffortia conifera",
		"cliffortia",
		550859
	],
	[
		"s550860",
		"Cliffortia crassinervis",
		"cliffortia",
		550860
	],
	[
		"s550861",
		"Cliffortia crenata",
		"cliffortia",
		550861
	],
	[
		"s550862",
		"Cliffortia cristata",
		"cliffortia",
		550862
	],
	[
		"s550863",
		"Cliffortia cruciata",
		"cliffortia",
		550863
	],
	[
		"s137438",
		"Cliffortia cuneata",
		"cliffortia",
		137438
	],
	[
		"s550866",
		"Cliffortia curvifolia",
		"cliffortia",
		550866
	],
	[
		"s550867",
		"Cliffortia cymbifolia",
		"cliffortia",
		550867
	],
	[
		"s550868",
		"Cliffortia densa",
		"cliffortia",
		550868
	],
	[
		"s281880",
		"Cliffortia dentata",
		"cliffortia",
		281880
	],
	[
		"s550869",
		"Cliffortia denticulata",
		"cliffortia",
		550869
	],
	[
		"s550870",
		"Cliffortia dichotoma",
		"cliffortia",
		550870
	],
	[
		"s550871",
		"Cliffortia dispar",
		"cliffortia",
		550871
	],
	[
		"s550872",
		"Cliffortia dodecandra",
		"cliffortia",
		550872
	],
	[
		"s554079",
		"Cliffortia dracomontana",
		"cliffortia",
		554079
	],
	[
		"s550873",
		"Cliffortia dregeana",
		"cliffortia",
		550873
	],
	[
		"s550824",
		"Cliffortia dregeana x Cliffortia pungens",
		"cliffortia",
		550824
	],
	[
		"s550874",
		"Cliffortia drepanoides",
		"cliffortia",
		550874
	],
	[
		"s550875",
		"Cliffortia erectisepala",
		"cliffortia",
		550875
	],
	[
		"s550876",
		"Cliffortia ericifolia",
		"cliffortia",
		550876
	],
	[
		"s550877",
		"Cliffortia eriocephalina",
		"cliffortia",
		550877
	],
	[
		"s550878",
		"Cliffortia esterhuyseniae",
		"cliffortia",
		550878
	],
	[
		"s550879",
		"Cliffortia exilifolia",
		"cliffortia",
		550879
	],
	[
		"s550880",
		"Cliffortia falcata",
		"cliffortia",
		550880
	],
	[
		"s550881",
		"Cliffortia ferricola",
		"cliffortia",
		550881
	],
	[
		"s550882",
		"Cliffortia ferruginea",
		"cliffortia",
		550882
	],
	[
		"s550883",
		"Cliffortia filicaulis",
		"cliffortia",
		550883
	],
	[
		"s550884",
		"Cliffortia filicauloides",
		"cliffortia",
		550884
	],
	[
		"s550885",
		"Cliffortia filifolia",
		"cliffortia",
		550885
	],
	[
		"s550888",
		"Cliffortia geniculata",
		"cliffortia",
		550888
	],
	[
		"s550889",
		"Cliffortia glauca",
		"cliffortia",
		550889
	],
	[
		"s550890",
		"Cliffortia gracillima",
		"cliffortia",
		550890
	],
	[
		"s281881",
		"Cliffortia graminea",
		"cliffortia",
		281881
	],
	[
		"s550891",
		"Cliffortia grandifolia",
		"cliffortia",
		550891
	],
	[
		"s550892",
		"Cliffortia hantamensis",
		"cliffortia",
		550892
	],
	[
		"s3778278",
		"Cliffortia hermaphroditica",
		"cliffortia",
		3778278
	],
	[
		"s281882",
		"Cliffortia heterophylla",
		"cliffortia",
		281882
	],
	[
		"s550893",
		"Cliffortia hexandra",
		"cliffortia",
		550893
	],
	[
		"s550894",
		"Cliffortia hirsuta",
		"cliffortia",
		550894
	],
	[
		"s550895",
		"Cliffortia hirta",
		"cliffortia",
		550895
	],
	[
		"s550896",
		"Cliffortia ilicifolia",
		"cliffortia",
		550896
	],
	[
		"s550899",
		"Cliffortia incana",
		"cliffortia",
		550899
	],
	[
		"s550900",
		"Cliffortia integerrima",
		"cliffortia",
		550900
	],
	[
		"s550901",
		"Cliffortia intermedia",
		"cliffortia",
		550901
	],
	[
		"s550902",
		"Cliffortia juniperina",
		"cliffortia",
		550902
	],
	[
		"s550825",
		"Cliffortia juniperina x Cliffortia ruscifolia",
		"cliffortia",
		550825
	],
	[
		"s550905",
		"Cliffortia lanata",
		"cliffortia",
		550905
	],
	[
		"s550906",
		"Cliffortia lanceolata",
		"cliffortia",
		550906
	],
	[
		"s550907",
		"Cliffortia lepida",
		"cliffortia",
		550907
	],
	[
		"s550908",
		"Cliffortia linearifolia",
		"cliffortia",
		550908
	],
	[
		"s550909",
		"Cliffortia longifolia",
		"cliffortia",
		550909
	],
	[
		"s550910",
		"Cliffortia marginata",
		"cliffortia",
		550910
	],
	[
		"s550911",
		"Cliffortia micrantha",
		"cliffortia",
		550911
	],
	[
		"s556485",
		"Cliffortia mirabilis",
		"cliffortia",
		556485
	],
	[
		"s550912",
		"Cliffortia monophylla",
		"cliffortia",
		550912
	],
	[
		"s550913",
		"Cliffortia montana",
		"cliffortia",
		550913
	],
	[
		"s550914",
		"Cliffortia multiformis",
		"cliffortia",
		550914
	],
	[
		"s550915",
		"Cliffortia neglecta",
		"cliffortia",
		550915
	],
	[
		"s550826",
		"Cliffortia neglecta x Cliffortia tuberculata",
		"cliffortia",
		550826
	],
	[
		"s137439",
		"Cliffortia nitidula",
		"cliffortia",
		137439
	],
	[
		"s550917",
		"Cliffortia nivenioides",
		"cliffortia",
		550917
	],
	[
		"s550918",
		"Cliffortia obcordata",
		"cliffortia",
		550918
	],
	[
		"s550919",
		"Cliffortia obovata",
		"cliffortia",
		550919
	],
	[
		"s281883",
		"Cliffortia odorata",
		"cliffortia",
		281883
	],
	[
		"s550827",
		"Cliffortia odorata x Cliffortia theodori-friesii",
		"cliffortia",
		550827
	],
	[
		"s550920",
		"Cliffortia oligodonta",
		"cliffortia",
		550920
	],
	[
		"s550921",
		"Cliffortia ovalis",
		"cliffortia",
		550921
	],
	[
		"s550922",
		"Cliffortia paucistaminea",
		"cliffortia",
		550922
	],
	[
		"s550925",
		"Cliffortia pedunculata",
		"cliffortia",
		550925
	],
	[
		"s550926",
		"Cliffortia perpendicularis",
		"cliffortia",
		550926
	],
	[
		"s550927",
		"Cliffortia phillipsii",
		"cliffortia",
		550927
	],
	[
		"s550928",
		"Cliffortia phyllanthoides",
		"cliffortia",
		550928
	],
	[
		"s550929",
		"Cliffortia pilifera",
		"cliffortia",
		550929
	],
	[
		"s550904",
		"Cliffortia pilosula",
		"cliffortia",
		550904
	],
	[
		"s550930",
		"Cliffortia polita",
		"cliffortia",
		550930
	],
	[
		"s550931",
		"Cliffortia polygonifolia",
		"cliffortia",
		550931
	],
	[
		"s550934",
		"Cliffortia prionota",
		"cliffortia",
		550934
	],
	[
		"s550935",
		"Cliffortia propinqua",
		"cliffortia",
		550935
	],
	[
		"s550936",
		"Cliffortia pterocarpa",
		"cliffortia",
		550936
	],
	[
		"s550937",
		"Cliffortia pulchella",
		"cliffortia",
		550937
	],
	[
		"s550938",
		"Cliffortia pungens",
		"cliffortia",
		550938
	],
	[
		"s550946",
		"Cliffortia purpurea",
		"cliffortia",
		550946
	],
	[
		"s550939",
		"Cliffortia ramosissima",
		"cliffortia",
		550939
	],
	[
		"s550940",
		"Cliffortia recurvata",
		"cliffortia",
		550940
	],
	[
		"s550941",
		"Cliffortia reniformis",
		"cliffortia",
		550941
	],
	[
		"s550942",
		"Cliffortia repens",
		"cliffortia",
		550942
	],
	[
		"s550943",
		"Cliffortia reticulata",
		"cliffortia",
		550943
	],
	[
		"s550944",
		"Cliffortia rigida",
		"cliffortia",
		550944
	],
	[
		"s550945",
		"Cliffortia robusta",
		"cliffortia",
		550945
	],
	[
		"s281884",
		"Cliffortia ruscifolia",
		"cliffortia",
		281884
	],
	[
		"s555757",
		"Cliffortia ruscifolia x Cliffortia integerrima",
		"cliffortia",
		555757
	],
	[
		"s555758",
		"Cliffortia ruscifolia x Cliffortia teretifolia",
		"cliffortia",
		555758
	],
	[
		"s550828",
		"Cliffortia ruscifolia x Cliffortia theodori-friesii",
		"cliffortia",
		550828
	],
	[
		"s550948",
		"Cliffortia scandens",
		"cliffortia",
		550948
	],
	[
		"s550949",
		"Cliffortia schlechteri",
		"cliffortia",
		550949
	],
	[
		"s553067",
		"Cliffortia semiteres",
		"cliffortia",
		553067
	],
	[
		"s281885",
		"Cliffortia sericea",
		"cliffortia",
		281885
	],
	[
		"s550950",
		"Cliffortia serpyllifolia",
		"cliffortia",
		550950
	],
	[
		"s550951",
		"Cliffortia setifolia",
		"cliffortia",
		550951
	],
	[
		"s550952",
		"Cliffortia sparsa",
		"cliffortia",
		550952
	],
	[
		"s550953",
		"Cliffortia spathulata",
		"cliffortia",
		550953
	],
	[
		"s550954",
		"Cliffortia stricta",
		"cliffortia",
		550954
	],
	[
		"s550955",
		"Cliffortia strigosa",
		"cliffortia",
		550955
	],
	[
		"s550956",
		"Cliffortia strobilifera",
		"cliffortia",
		550956
	],
	[
		"s550957",
		"Cliffortia subsetacea",
		"cliffortia",
		550957
	],
	[
		"s550958",
		"Cliffortia tenuis",
		"cliffortia",
		550958
	],
	[
		"s550959",
		"Cliffortia teretifolia",
		"cliffortia",
		550959
	],
	[
		"s550960",
		"Cliffortia theodori-friesii",
		"cliffortia",
		550960
	],
	[
		"s550961",
		"Cliffortia tricuspidata",
		"cliffortia",
		550961
	],
	[
		"s550962",
		"Cliffortia triloba",
		"cliffortia",
		550962
	],
	[
		"s550963",
		"Cliffortia tuberculata",
		"cliffortia",
		550963
	],
	[
		"s550964",
		"Cliffortia uncinata",
		"cliffortia",
		550964
	],
	[
		"s550965",
		"Cliffortia varians",
		"cliffortia",
		550965
	],
	[
		"s550966",
		"Cliffortia verrucosa",
		"cliffortia",
		550966
	],
	[
		"s550967",
		"Cliffortia virgata",
		"cliffortia",
		550967
	],
	[
		"s550968",
		"Cliffortia viridis",
		"cliffortia",
		550968
	],
	[
		"s550969",
		"Cliffortia weimarckii",
		"cliffortia",
		550969
	],
	[
		"s401069",
		"Coleogyne ramosissima",
		"coleogyne",
		401069
	],
	[
		"s262928",
		"Colletia hystrix",
		"colletia",
		262928
	],
	[
		"s262929",
		"Colletia paradoxa",
		"colletia",
		262929
	],
	[
		"s3761928",
		"Colletia spartioides",
		"colletia",
		3761928
	],
	[
		"s262930",
		"Colletia spinosissima",
		"colletia",
		262930
	],
	[
		"s48232",
		"Colletia ulicina",
		"colletia",
		48232
	],
	[
		"s3781097",
		"Colubrina acunae",
		"colubrina",
		3781097
	],
	[
		"s3781098",
		"Colubrina amazonica",
		"colubrina",
		3781098
	],
	[
		"s3781099",
		"Colubrina angustior",
		"colubrina",
		3781099
	],
	[
		"s1465290",
		"Colubrina arborescens",
		"colubrina",
		1465290
	],
	[
		"s3085955",
		"Colubrina articulata",
		"colubrina",
		3085955
	],
	[
		"s106664",
		"Colubrina asiatica",
		"colubrina",
		106664
	],
	[
		"s3086287",
		"Colubrina beccariana",
		"colubrina",
		3086287
	],
	[
		"s3086288",
		"Colubrina berteroana",
		"colubrina",
		3086288
	],
	[
		"s2042383",
		"Colubrina californica",
		"colubrina",
		2042383
	],
	[
		"s3085956",
		"Colubrina celtidifolia",
		"colubrina",
		3085956
	],
	[
		"s3103822",
		"Colubrina cogolloi (nom. ined.)",
		"colubrina",
		3103822
	],
	[
		"s2743235",
		"Colubrina cordifolia",
		"colubrina",
		2743235
	],
	[
		"s1969240",
		"Colubrina cubensis",
		"colubrina",
		1969240
	],
	[
		"s3085957",
		"Colubrina decipiens",
		"colubrina",
		3085957
	],
	[
		"s3086289",
		"Colubrina ehrenbergii",
		"colubrina",
		3086289
	],
	[
		"s1465291",
		"Colubrina elliptica",
		"colubrina",
		1465291
	],
	[
		"s3085958",
		"Colubrina faraloatra",
		"colubrina",
		3085958
	],
	[
		"s1125385",
		"Colubrina glandulosa",
		"colubrina",
		1125385
	],
	[
		"s3781100",
		"Colubrina greggii",
		"colubrina",
		3781100
	],
	[
		"s3085959",
		"Colubrina heteroneura",
		"colubrina",
		3085959
	],
	[
		"s3085960",
		"Colubrina humbertii",
		"colubrina",
		3085960
	],
	[
		"s1489629",
		"Colubrina javanica",
		"colubrina",
		1489629
	],
	[
		"s3086290",
		"Colubrina johnstonii",
		"colubrina",
		3086290
	],
	[
		"s3781101",
		"Colubrina lanceolata",
		"colubrina",
		3781101
	],
	[
		"s3781102",
		"Colubrina limae",
		"colubrina",
		3781102
	],
	[
		"s3085961",
		"Colubrina macrocarpa",
		"colubrina",
		3085961
	],
	[
		"s3781103",
		"Colubrina macrocarpoides",
		"colubrina",
		3781103
	],
	[
		"s3781104",
		"Colubrina mezquitalensis",
		"colubrina",
		3781104
	],
	[
		"s3781105",
		"Colubrina neoviridis",
		"colubrina",
		3781105
	],
	[
		"s3781106",
		"Colubrina nicholsonii",
		"colubrina",
		3781106
	],
	[
		"s3781107",
		"Colubrina obscura",
		"colubrina",
		3781107
	],
	[
		"s1812991",
		"Colubrina oppositifolia",
		"colubrina",
		1812991
	],
	[
		"s3781108",
		"Colubrina pedunculata",
		"colubrina",
		3781108
	],
	[
		"s106665",
		"Colubrina reclinata",
		"colubrina",
		106665
	],
	[
		"s3085962",
		"Colubrina retusa",
		"colubrina",
		3085962
	],
	[
		"s3086291",
		"Colubrina sordida",
		"colubrina",
		3086291
	],
	[
		"s1125386",
		"Colubrina spinosa",
		"colubrina",
		1125386
	],
	[
		"s3086292",
		"Colubrina stricta",
		"colubrina",
		3086292
	],
	[
		"s3781109",
		"Colubrina subsessilis",
		"colubrina",
		3781109
	],
	[
		"s3781110",
		"Colubrina tequila",
		"colubrina",
		3781110
	],
	[
		"s3085963",
		"Colubrina texensis",
		"colubrina",
		3085963
	],
	[
		"s3781111",
		"Colubrina travancorica",
		"colubrina",
		3781111
	],
	[
		"s1639856",
		"Colubrina triflora",
		"colubrina",
		1639856
	],
	[
		"s1465292",
		"Colubrina verrucosa",
		"colubrina",
		1465292
	],
	[
		"s3781112",
		"Colubrina villarrealii",
		"colubrina",
		3781112
	],
	[
		"s3781113",
		"Colubrina yucatanensis",
		"colubrina",
		3781113
	],
	[
		"s2936513",
		"Colubrina zhaoguangii",
		"colubrina",
		2936513
	],
	[
		"s148888",
		"Coluria geoides",
		"coluria",
		148888
	],
	[
		"s2911227",
		"Coluria longifolia",
		"coluria",
		2911227
	],
	[
		"s3781214",
		"Coluria oligocarpa",
		"coluria",
		3781214
	],
	[
		"s3465427",
		"Coluria omeiensis",
		"coluria",
		3465427
	],
	[
		"s57932",
		"Comarum palustre",
		"comarum",
		57932
	],
	[
		"s1226771",
		"Conalma mexicana",
		"conalma",
		1226771
	],
	[
		"s1226773",
		"Conalma pedunculata",
		"conalma",
		1226773
	],
	[
		"s1226774",
		"Conalma yucatanensis",
		"conalma",
		1226774
	],
	[
		"s3086296",
		"Condalia brandegeei",
		"condalia",
		3086296
	],
	[
		"s3781856",
		"Condalia buxifolia",
		"condalia",
		3781856
	],
	[
		"s3086297",
		"Condalia correllii",
		"condalia",
		3086297
	],
	[
		"s3781857",
		"Condalia cuencamensis",
		"condalia",
		3781857
	],
	[
		"s3085964",
		"Condalia ericoides",
		"condalia",
		3085964
	],
	[
		"s3086298",
		"Condalia fasciculata",
		"condalia",
		3086298
	],
	[
		"s2042384",
		"Condalia globosa",
		"condalia",
		2042384
	],
	[
		"s1812992",
		"Condalia henriquezii",
		"condalia",
		1812992
	],
	[
		"s3086299",
		"Condalia hookeri",
		"condalia",
		3086299
	],
	[
		"s3781858",
		"Condalia kearneyana",
		"condalia",
		3781858
	],
	[
		"s3085965",
		"Condalia lycioides",
		"condalia",
		3085965
	],
	[
		"s3086300",
		"Condalia megacarpa",
		"condalia",
		3086300
	],
	[
		"s1226762",
		"Condalia mexicana",
		"condalia",
		1226762
	],
	[
		"s106667",
		"Condalia microphylla",
		"condalia",
		106667
	],
	[
		"s3086301",
		"Condalia mirandana",
		"condalia",
		3086301
	],
	[
		"s3086302",
		"Condalia montana",
		"condalia",
		3086302
	],
	[
		"s3781859",
		"Condalia petalifera",
		"condalia",
		3781859
	],
	[
		"s3086303",
		"Condalia spathulata",
		"condalia",
		3086303
	],
	[
		"s3781860",
		"Condalia suchilensis",
		"condalia",
		3781860
	],
	[
		"s3086304",
		"Condalia thomasiana",
		"condalia",
		3086304
	],
	[
		"s1226763",
		"Condalia velutina",
		"condalia",
		1226763
	],
	[
		"s3086305",
		"Condalia viridis",
		"condalia",
		3086305
	],
	[
		"s3781861",
		"Condalia warnockii",
		"condalia",
		3781861
	],
	[
		"s2321274",
		"Condalia weberbaueri",
		"condalia",
		2321274
	],
	[
		"s3781862",
		"Condalia zamudioana",
		"condalia",
		3781862
	],
	[
		"s3710543",
		"Condaliopsis australis",
		"condaliopsis",
		3710543
	],
	[
		"s3710544",
		"Condaliopsis chihuahuana",
		"condaliopsis",
		3710544
	],
	[
		"s3710545",
		"Condaliopsis divaricata",
		"condaliopsis",
		3710545
	],
	[
		"s1226770",
		"Condaliopsis lloydii",
		"condaliopsis",
		1226770
	],
	[
		"s3710546",
		"Condaliopsis rigida",
		"condaliopsis",
		3710546
	],
	[
		"s3710547",
		"Condaliopsis supralloydii",
		"condaliopsis",
		3710547
	],
	[
		"s36606",
		"Cormus domestica",
		"cormus",
		36606
	],
	[
		"s690309",
		"Cotoneaster acuminatus",
		"cotoneaster",
		690309
	],
	[
		"s690308",
		"Cotoneaster acutifolius",
		"cotoneaster",
		690308
	],
	[
		"s690310",
		"Cotoneaster adpressus",
		"cotoneaster",
		690310
	],
	[
		"s487745",
		"Cotoneaster affinis",
		"cotoneaster",
		487745
	],
	[
		"s3783113",
		"Cotoneaster afghanicus",
		"cotoneaster",
		3783113
	],
	[
		"s3783114",
		"Cotoneaster aitchisonii",
		"cotoneaster",
		3783114
	],
	[
		"s3783115",
		"Cotoneaster alashanensis",
		"cotoneaster",
		3783115
	],
	[
		"s3783116",
		"Cotoneaster alatavicus",
		"cotoneaster",
		3783116
	],
	[
		"s3086318",
		"Cotoneaster alaunicus",
		"cotoneaster",
		3086318
	],
	[
		"s3783117",
		"Cotoneaster albokermesinus",
		"cotoneaster",
		3783117
	],
	[
		"s2764628",
		"Cotoneaster allochrous",
		"cotoneaster",
		2764628
	],
	[
		"s3783118",
		"Cotoneaster altaicus",
		"cotoneaster",
		3783118
	],
	[
		"s1143214",
		"Cotoneaster ambiguus",
		"cotoneaster",
		1143214
	],
	[
		"s3783119",
		"Cotoneaster anatolii",
		"cotoneaster",
		3783119
	],
	[
		"s193301",
		"Cotoneaster apiculatus",
		"cotoneaster",
		193301
	],
	[
		"s2828828",
		"Cotoneaster argenteus",
		"cotoneaster",
		2828828
	],
	[
		"s1143215",
		"Cotoneaster armenus",
		"cotoneaster",
		1143215
	],
	[
		"s3783120",
		"Cotoneaster ascendens",
		"cotoneaster",
		3783120
	],
	[
		"s3783121",
		"Cotoneaster assadii",
		"cotoneaster",
		3783121
	],
	[
		"s1143216",
		"Cotoneaster assamensis",
		"cotoneaster",
		1143216
	],
	[
		"s2828834",
		"Cotoneaster astrophoros",
		"cotoneaster",
		2828834
	],
	[
		"s3783122",
		"Cotoneaster ataensis",
		"cotoneaster",
		3783122
	],
	[
		"s1532748",
		"Cotoneaster atlanticus",
		"cotoneaster",
		1532748
	],
	[
		"s690311",
		"Cotoneaster atropurpureus",
		"cotoneaster",
		690311
	],
	[
		"s3783123",
		"Cotoneaster atrovinaceus",
		"cotoneaster",
		3783123
	],
	[
		"s3783124",
		"Cotoneaster atuntzensis",
		"cotoneaster",
		3783124
	],
	[
		"s3783125",
		"Cotoneaster aurantiacus",
		"cotoneaster",
		3783125
	],
	[
		"s3086319",
		"Cotoneaster bacillaris",
		"cotoneaster",
		3086319
	],
	[
		"s3783126",
		"Cotoneaster beimashanensis",
		"cotoneaster",
		3783126
	],
	[
		"s3783127",
		"Cotoneaster bis-ramianus",
		"cotoneaster",
		3783127
	],
	[
		"s3783128",
		"Cotoneaster bradyi",
		"cotoneaster",
		3783128
	],
	[
		"s3385970",
		"Cotoneaster brickellii",
		"cotoneaster",
		3385970
	],
	[
		"s1920638",
		"Cotoneaster browiczii",
		"cotoneaster",
		1920638
	],
	[
		"s690312",
		"Cotoneaster bullatus",
		"cotoneaster",
		690312
	],
	[
		"s3783129",
		"Cotoneaster bumthangensis",
		"cotoneaster",
		3783129
	],
	[
		"s3783130",
		"Cotoneaster burmanicus",
		"cotoneaster",
		3783130
	],
	[
		"s690313",
		"Cotoneaster buxifolius",
		"cotoneaster",
		690313
	],
	[
		"s1155262",
		"Cotoneaster cambricus",
		"cotoneaster",
		1155262
	],
	[
		"s3783131",
		"Cotoneaster camilli-schneideri",
		"cotoneaster",
		3783131
	],
	[
		"s3783132",
		"Cotoneaster campanulatus",
		"cotoneaster",
		3783132
	],
	[
		"s3783133",
		"Cotoneaster capsicinus",
		"cotoneaster",
		3783133
	],
	[
		"s3783134",
		"Cotoneaster cardinalis",
		"cotoneaster",
		3783134
	],
	[
		"s2828846",
		"Cotoneaster cf. chengkangensis KM-2021",
		"cotoneaster",
		2828846
	],
	[
		"s3783135",
		"Cotoneaster chadwellii",
		"cotoneaster",
		3783135
	],
	[
		"s2828835",
		"Cotoneaster chengkangensis",
		"cotoneaster",
		2828835
	],
	[
		"s3783136",
		"Cotoneaster chingshuiensis",
		"cotoneaster",
		3783136
	],
	[
		"s3783137",
		"Cotoneaster chuanus",
		"cotoneaster",
		3783137
	],
	[
		"s3783138",
		"Cotoneaster chulingensis",
		"cotoneaster",
		3783138
	],
	[
		"s3783139",
		"Cotoneaster chungtiensis",
		"cotoneaster",
		3783139
	],
	[
		"s2835573",
		"Cotoneaster cinnabarinus",
		"cotoneaster",
		2835573
	],
	[
		"s3783140",
		"Cotoneaster cinovskisii",
		"cotoneaster",
		3783140
	],
	[
		"s3783141",
		"Cotoneaster coadunatus",
		"cotoneaster",
		3783141
	],
	[
		"s2861301",
		"Cotoneaster cochleatus",
		"cotoneaster",
		2861301
	],
	[
		"s3095449",
		"Cotoneaster congestus",
		"cotoneaster",
		3095449
	],
	[
		"s690314",
		"Cotoneaster conspicuus",
		"cotoneaster",
		690314
	],
	[
		"s3783142",
		"Cotoneaster convexus",
		"cotoneaster",
		3783142
	],
	[
		"s3783143",
		"Cotoneaster cordifolius",
		"cotoneaster",
		3783143
	],
	[
		"s36608",
		"Cotoneaster coriaceus",
		"cotoneaster",
		36608
	],
	[
		"s2071425",
		"Cotoneaster crispii",
		"cotoneaster",
		2071425
	],
	[
		"s3783144",
		"Cotoneaster cuspidatus",
		"cotoneaster",
		3783144
	],
	[
		"s3783145",
		"Cotoneaster daliensis",
		"cotoneaster",
		3783145
	],
	[
		"s690315",
		"Cotoneaster dammeri",
		"cotoneaster",
		690315
	],
	[
		"s3783146",
		"Cotoneaster decandrus",
		"cotoneaster",
		3783146
	],
	[
		"s3783147",
		"Cotoneaster declinatus",
		"cotoneaster",
		3783147
	],
	[
		"s2828837",
		"Cotoneaster delavayanus",
		"cotoneaster",
		2828837
	],
	[
		"s1532749",
		"Cotoneaster delphinensis",
		"cotoneaster",
		1532749
	],
	[
		"s3106003",
		"Cotoneaster densiflorus",
		"cotoneaster",
		3106003
	],
	[
		"s690316",
		"Cotoneaster dielsianus",
		"cotoneaster",
		690316
	],
	[
		"s2006075",
		"Cotoneaster dielsianus x Cotoneaster glaucophyllus",
		"cotoneaster",
		2006075
	],
	[
		"s1143217",
		"Cotoneaster divaricatus",
		"cotoneaster",
		1143217
	],
	[
		"s3783148",
		"Cotoneaster drogochius",
		"cotoneaster",
		3783148
	],
	[
		"s3783149",
		"Cotoneaster emeiensis",
		"cotoneaster",
		3783149
	],
	[
		"s3783150",
		"Cotoneaster encavei",
		"cotoneaster",
		3783150
	],
	[
		"s3783151",
		"Cotoneaster erratus",
		"cotoneaster",
		3783151
	],
	[
		"s3783152",
		"Cotoneaster esfandiarii",
		"cotoneaster",
		3783152
	],
	[
		"s3695083",
		"Cotoneaster fangianus",
		"cotoneaster",
		3695083
	],
	[
		"s3783153",
		"Cotoneaster farreri",
		"cotoneaster",
		3783153
	],
	[
		"s3783154",
		"Cotoneaster fastigiatus",
		"cotoneaster",
		3783154
	],
	[
		"s3783155",
		"Cotoneaster favargeri",
		"cotoneaster",
		3783155
	],
	[
		"s3783156",
		"Cotoneaster flinckii",
		"cotoneaster",
		3783156
	],
	[
		"s3783157",
		"Cotoneaster floccosus",
		"cotoneaster",
		3783157
	],
	[
		"s3783158",
		"Cotoneaster floridus",
		"cotoneaster",
		3783158
	],
	[
		"s690317",
		"Cotoneaster foveolatus",
		"cotoneaster",
		690317
	],
	[
		"s1143218",
		"Cotoneaster franchetii",
		"cotoneaster",
		1143218
	],
	[
		"s690318",
		"Cotoneaster frigidus",
		"cotoneaster",
		690318
	],
	[
		"s3783159",
		"Cotoneaster fruticosus",
		"cotoneaster",
		3783159
	],
	[
		"s2828838",
		"Cotoneaster gamblei",
		"cotoneaster",
		2828838
	],
	[
		"s3783160",
		"Cotoneaster ganghobaensis",
		"cotoneaster",
		3783160
	],
	[
		"s1143219",
		"Cotoneaster giraldii",
		"cotoneaster",
		1143219
	],
	[
		"s3050849",
		"Cotoneaster glabratus",
		"cotoneaster",
		3050849
	],
	[
		"s1125981",
		"Cotoneaster glaucophyllus",
		"cotoneaster",
		1125981
	],
	[
		"s3783161",
		"Cotoneaster globosus",
		"cotoneaster",
		3783161
	],
	[
		"s1248454",
		"Cotoneaster glomerulatus",
		"cotoneaster",
		1248454
	],
	[
		"s3783162",
		"Cotoneaster goloskokovii",
		"cotoneaster",
		3783162
	],
	[
		"s3783163",
		"Cotoneaster gonggashanensis",
		"cotoneaster",
		3783163
	],
	[
		"s2576053",
		"Cotoneaster gracilis",
		"cotoneaster",
		2576053
	],
	[
		"s2720241",
		"Cotoneaster granatensis",
		"cotoneaster",
		2720241
	],
	[
		"s3783164",
		"Cotoneaster hajastanicus",
		"cotoneaster",
		3783164
	],
	[
		"s3086320",
		"Cotoneaster harrovianus",
		"cotoneaster",
		3086320
	],
	[
		"s1143220",
		"Cotoneaster harrysmithii",
		"cotoneaster",
		1143220
	],
	[
		"s1248455",
		"Cotoneaster hebephyllus",
		"cotoneaster",
		1248455
	],
	[
		"s3783165",
		"Cotoneaster hedegaardii",
		"cotoneaster",
		3783165
	],
	[
		"s3783166",
		"Cotoneaster hersianus",
		"cotoneaster",
		3783166
	],
	[
		"s3783167",
		"Cotoneaster hicksii",
		"cotoneaster",
		3783167
	],
	[
		"s3783168",
		"Cotoneaster hillieri",
		"cotoneaster",
		3783168
	],
	[
		"s2591395",
		"Cotoneaster hissaricus",
		"cotoneaster",
		2591395
	],
	[
		"s3086321",
		"Cotoneaster hjelmqvistii",
		"cotoneaster",
		3086321
	],
	[
		"s3783169",
		"Cotoneaster hodjingensis",
		"cotoneaster",
		3783169
	],
	[
		"s690320",
		"Cotoneaster horizontalis",
		"cotoneaster",
		690320
	],
	[
		"s2824815",
		"Cotoneaster huahongdongensis",
		"cotoneaster",
		2824815
	],
	[
		"s3783170",
		"Cotoneaster hualiensis",
		"cotoneaster",
		3783170
	],
	[
		"s3086322",
		"Cotoneaster hupehensis",
		"cotoneaster",
		3086322
	],
	[
		"s3783171",
		"Cotoneaster hylanderi",
		"cotoneaster",
		3783171
	],
	[
		"s3783172",
		"Cotoneaster hypocarpus",
		"cotoneaster",
		3783172
	],
	[
		"s3783173",
		"Cotoneaster ichangensis",
		"cotoneaster",
		3783173
	],
	[
		"s3086323",
		"Cotoneaster ignavus",
		"cotoneaster",
		3086323
	],
	[
		"s3783174",
		"Cotoneaster ignescens",
		"cotoneaster",
		3783174
	],
	[
		"s3783175",
		"Cotoneaster ignotus",
		"cotoneaster",
		3783175
	],
	[
		"s3086324",
		"Cotoneaster induratus",
		"cotoneaster",
		3086324
	],
	[
		"s3783176",
		"Cotoneaster inexspectatus",
		"cotoneaster",
		3783176
	],
	[
		"s3783177",
		"Cotoneaster insculptus",
		"cotoneaster",
		3783177
	],
	[
		"s3086325",
		"Cotoneaster insignis",
		"cotoneaster",
		3086325
	],
	[
		"s2981865",
		"Cotoneaster insolitus",
		"cotoneaster",
		2981865
	],
	[
		"s690321",
		"Cotoneaster integerrimus",
		"cotoneaster",
		690321
	],
	[
		"s3059406",
		"Cotoneaster integrifolius",
		"cotoneaster",
		3059406
	],
	[
		"s1532750",
		"Cotoneaster juranus",
		"cotoneaster",
		1532750
	],
	[
		"s3783178",
		"Cotoneaster kangdingensis",
		"cotoneaster",
		3783178
	],
	[
		"s3783179",
		"Cotoneaster karatavicus",
		"cotoneaster",
		3783179
	],
	[
		"s3783180",
		"Cotoneaster kaschkarovii",
		"cotoneaster",
		3783180
	],
	[
		"s3783181",
		"Cotoneaster kingdonii",
		"cotoneaster",
		3783181
	],
	[
		"s3783182",
		"Cotoneaster kitaibelii",
		"cotoneaster",
		3783182
	],
	[
		"s3783183",
		"Cotoneaster konishii",
		"cotoneaster",
		3783183
	],
	[
		"s3783184",
		"Cotoneaster kotschyi",
		"cotoneaster",
		3783184
	],
	[
		"s3783185",
		"Cotoneaster krasnovii",
		"cotoneaster",
		3783185
	],
	[
		"s3783186",
		"Cotoneaster kuanensis",
		"cotoneaster",
		3783186
	],
	[
		"s3783187",
		"Cotoneaster lambertii",
		"cotoneaster",
		3783187
	],
	[
		"s3783188",
		"Cotoneaster lancasteri",
		"cotoneaster",
		3783188
	],
	[
		"s2828840",
		"Cotoneaster langei",
		"cotoneaster",
		2828840
	],
	[
		"s3783189",
		"Cotoneaster latifolius",
		"cotoneaster",
		3783189
	],
	[
		"s2071890",
		"Cotoneaster laxiflorus",
		"cotoneaster",
		2071890
	],
	[
		"s2828831",
		"Cotoneaster leveillei",
		"cotoneaster",
		2828831
	],
	[
		"s3086326",
		"Cotoneaster ludlowii",
		"cotoneaster",
		3086326
	],
	[
		"s3783190",
		"Cotoneaster luristanicus",
		"cotoneaster",
		3783190
	],
	[
		"s3783191",
		"Cotoneaster magnificus",
		"cotoneaster",
		3783191
	],
	[
		"s3086327",
		"Cotoneaster mairei",
		"cotoneaster",
		3086327
	],
	[
		"s3783192",
		"Cotoneaster majoricensis",
		"cotoneaster",
		3783192
	],
	[
		"s2828841",
		"Cotoneaster marginatus",
		"cotoneaster",
		2828841
	],
	[
		"s3783193",
		"Cotoneaster marquandii",
		"cotoneaster",
		3783193
	],
	[
		"s3783194",
		"Cotoneaster marroninus",
		"cotoneaster",
		3783194
	],
	[
		"s3783195",
		"Cotoneaster mazandaranicus",
		"cotoneaster",
		3783195
	],
	[
		"s1735026",
		"Cotoneaster megalocarpus",
		"cotoneaster",
		1735026
	],
	[
		"s3086328",
		"Cotoneaster meyeri",
		"cotoneaster",
		3086328
	],
	[
		"s3783196",
		"Cotoneaster microcarpus",
		"cotoneaster",
		3783196
	],
	[
		"s690323",
		"Cotoneaster microphyllus",
		"cotoneaster",
		690323
	],
	[
		"s3095551",
		"Cotoneaster milkedandaensis",
		"cotoneaster",
		3095551
	],
	[
		"s3783197",
		"Cotoneaster miniatus",
		"cotoneaster",
		3783197
	],
	[
		"s1143222",
		"Cotoneaster mongolicus",
		"cotoneaster",
		1143222
	],
	[
		"s1143223",
		"Cotoneaster monopyrenus",
		"cotoneaster",
		1143223
	],
	[
		"s690324",
		"Cotoneaster morrisonensis",
		"cotoneaster",
		690324
	],
	[
		"s3086329",
		"Cotoneaster morulus",
		"cotoneaster",
		3086329
	],
	[
		"s690325",
		"Cotoneaster moupinensis",
		"cotoneaster",
		690325
	],
	[
		"s690326",
		"Cotoneaster multiflorus",
		"cotoneaster",
		690326
	],
	[
		"s3783199",
		"Cotoneaster nan-shan",
		"cotoneaster",
		3783199
	],
	[
		"s3783198",
		"Cotoneaster naninitens",
		"cotoneaster",
		3783198
	],
	[
		"s3783200",
		"Cotoneaster nantouensis",
		"cotoneaster",
		3783200
	],
	[
		"s3783201",
		"Cotoneaster naoujanensis",
		"cotoneaster",
		3783201
	],
	[
		"s3783202",
		"Cotoneaster narynensis",
		"cotoneaster",
		3783202
	],
	[
		"s3783342",
		"Cotoneaster natmataungensis",
		"cotoneaster",
		3783342
	],
	[
		"s3086330",
		"Cotoneaster nebrodensis",
		"cotoneaster",
		3086330
	],
	[
		"s3783203",
		"Cotoneaster nedoluzhkoi",
		"cotoneaster",
		3783203
	],
	[
		"s3783204",
		"Cotoneaster nefedovii",
		"cotoneaster",
		3783204
	],
	[
		"s3783205",
		"Cotoneaster neoantoninae",
		"cotoneaster",
		3783205
	],
	[
		"s3783206",
		"Cotoneaster neopopovii",
		"cotoneaster",
		3783206
	],
	[
		"s1143224",
		"Cotoneaster niger",
		"cotoneaster",
		1143224
	],
	[
		"s3783207",
		"Cotoneaster nima-yushijii",
		"cotoneaster",
		3783207
	],
	[
		"s1248456",
		"Cotoneaster nitens",
		"cotoneaster",
		1248456
	],
	[
		"s3086331",
		"Cotoneaster nitidifolius",
		"cotoneaster",
		3086331
	],
	[
		"s1143225",
		"Cotoneaster nitidus",
		"cotoneaster",
		1143225
	],
	[
		"s3783208",
		"Cotoneaster nohelii",
		"cotoneaster",
		3783208
	],
	[
		"s3086332",
		"Cotoneaster nummularioides",
		"cotoneaster",
		3086332
	],
	[
		"s1804980",
		"Cotoneaster nummularius",
		"cotoneaster",
		1804980
	],
	[
		"s690327",
		"Cotoneaster obscurus",
		"cotoneaster",
		690327
	],
	[
		"s3783209",
		"Cotoneaster ogisui",
		"cotoneaster",
		3783209
	],
	[
		"s690328",
		"Cotoneaster oliganthus",
		"cotoneaster",
		690328
	],
	[
		"s3783210",
		"Cotoneaster omissus",
		"cotoneaster",
		3783210
	],
	[
		"s1851000",
		"Cotoneaster orbicularis",
		"cotoneaster",
		1851e3
	],
	[
		"s3086333",
		"Cotoneaster ovatus",
		"cotoneaster",
		3086333
	],
	[
		"s3783211",
		"Cotoneaster pangiensis",
		"cotoneaster",
		3783211
	],
	[
		"s143397",
		"Cotoneaster pannosus",
		"cotoneaster",
		143397
	],
	[
		"s3783212",
		"Cotoneaster paradoxus",
		"cotoneaster",
		3783212
	],
	[
		"s3783213",
		"Cotoneaster parkinsonii",
		"cotoneaster",
		3783213
	],
	[
		"s3783214",
		"Cotoneaster peduncularis",
		"cotoneaster",
		3783214
	],
	[
		"s3783215",
		"Cotoneaster persicus",
		"cotoneaster",
		3783215
	],
	[
		"s3783216",
		"Cotoneaster pojarkovae",
		"cotoneaster",
		3783216
	],
	[
		"s1248457",
		"Cotoneaster poluninii",
		"cotoneaster",
		1248457
	],
	[
		"s3783217",
		"Cotoneaster polyanthemus",
		"cotoneaster",
		3783217
	],
	[
		"s3783218",
		"Cotoneaster potaninii",
		"cotoneaster",
		3783218
	],
	[
		"s690330",
		"Cotoneaster procumbens",
		"cotoneaster",
		690330
	],
	[
		"s690331",
		"Cotoneaster przewalskii",
		"cotoneaster",
		690331
	],
	[
		"s3783219",
		"Cotoneaster pseudomultiflorus",
		"cotoneaster",
		3783219
	],
	[
		"s3783220",
		"Cotoneaster pseudoobscurus",
		"cotoneaster",
		3783220
	],
	[
		"s3783221",
		"Cotoneaster purpurascens",
		"cotoneaster",
		3783221
	],
	[
		"s2071426",
		"Cotoneaster qungbixiensis",
		"cotoneaster",
		2071426
	],
	[
		"s1532751",
		"Cotoneaster raboutensis",
		"cotoneaster",
		1532751
	],
	[
		"s690332",
		"Cotoneaster racemiflorus",
		"cotoneaster",
		690332
	],
	[
		"s3783222",
		"Cotoneaster radicans",
		"cotoneaster",
		3783222
	],
	[
		"s1143226",
		"Cotoneaster rehderi",
		"cotoneaster",
		1143226
	],
	[
		"s690333",
		"Cotoneaster reticulatus",
		"cotoneaster",
		690333
	],
	[
		"s3783223",
		"Cotoneaster rhytidophyllus",
		"cotoneaster",
		3783223
	],
	[
		"s2844933",
		"Cotoneaster roborowskii",
		"cotoneaster",
		2844933
	],
	[
		"s2828842",
		"Cotoneaster rockii",
		"cotoneaster",
		2828842
	],
	[
		"s1143227",
		"Cotoneaster roseus",
		"cotoneaster",
		1143227
	],
	[
		"s2994360",
		"Cotoneaster rosiflorus",
		"cotoneaster",
		2994360
	],
	[
		"s690334",
		"Cotoneaster rotundifolius",
		"cotoneaster",
		690334
	],
	[
		"s2675830",
		"Cotoneaster rubens",
		"cotoneaster",
		2675830
	],
	[
		"s3086334",
		"Cotoneaster rugosus",
		"cotoneaster",
		3086334
	],
	[
		"s690335",
		"Cotoneaster salicifolius",
		"cotoneaster",
		690335
	],
	[
		"s3783224",
		"Cotoneaster sandakphuensis",
		"cotoneaster",
		3783224
	],
	[
		"s3783225",
		"Cotoneaster sanguineus",
		"cotoneaster",
		3783225
	],
	[
		"s3086335",
		"Cotoneaster saxatilis",
		"cotoneaster",
		3086335
	],
	[
		"s2704055",
		"Cotoneaster schantungensis",
		"cotoneaster",
		2704055
	],
	[
		"s3783226",
		"Cotoneaster schubertii",
		"cotoneaster",
		3783226
	],
	[
		"s3783227",
		"Cotoneaster shannanensis",
		"cotoneaster",
		3783227
	],
	[
		"s2828843",
		"Cotoneaster shansiensis",
		"cotoneaster",
		2828843
	],
	[
		"s2824816",
		"Cotoneaster sherriffii",
		"cotoneaster",
		2824816
	],
	[
		"s3783228",
		"Cotoneaster sichuanensis",
		"cotoneaster",
		3783228
	],
	[
		"s1248458",
		"Cotoneaster silvestrii",
		"cotoneaster",
		1248458
	],
	[
		"s1572675",
		"Cotoneaster simonsii",
		"cotoneaster",
		1572675
	],
	[
		"s3783229",
		"Cotoneaster siyuanensis",
		"cotoneaster",
		3783229
	],
	[
		"s690336",
		"Cotoneaster soongoricus",
		"cotoneaster",
		690336
	],
	[
		"s3783230",
		"Cotoneaster soulieanus",
		"cotoneaster",
		3783230
	],
	[
		"s3783231",
		"Cotoneaster splendens",
		"cotoneaster",
		3783231
	],
	[
		"s3783232",
		"Cotoneaster spongbergii",
		"cotoneaster",
		3783232
	],
	[
		"s3783233",
		"Cotoneaster staintonii",
		"cotoneaster",
		3783233
	],
	[
		"s2071427",
		"Cotoneaster sternianus",
		"cotoneaster",
		2071427
	],
	[
		"s3783234",
		"Cotoneaster subacutus",
		"cotoneaster",
		3783234
	],
	[
		"s1248459",
		"Cotoneaster subadpressus",
		"cotoneaster",
		1248459
	],
	[
		"s690337",
		"Cotoneaster submultiflorus",
		"cotoneaster",
		690337
	],
	[
		"s3783235",
		"Cotoneaster svenhedinii",
		"cotoneaster",
		3783235
	],
	[
		"s2071428",
		"Cotoneaster symondsii",
		"cotoneaster",
		2071428
	],
	[
		"s3783236",
		"Cotoneaster taiwanensis",
		"cotoneaster",
		3783236
	],
	[
		"s3783237",
		"Cotoneaster talgaricus",
		"cotoneaster",
		3783237
	],
	[
		"s3783238",
		"Cotoneaster tanpaensis",
		"cotoneaster",
		3783238
	],
	[
		"s1143229",
		"Cotoneaster taoensis",
		"cotoneaster",
		1143229
	],
	[
		"s3783239",
		"Cotoneaster taofuensis",
		"cotoneaster",
		3783239
	],
	[
		"s3783240",
		"Cotoneaster tardiflorus",
		"cotoneaster",
		3783240
	],
	[
		"s3783241",
		"Cotoneaster tauricus",
		"cotoneaster",
		3783241
	],
	[
		"s2675831",
		"Cotoneaster taylorii",
		"cotoneaster",
		2675831
	],
	[
		"s3783242",
		"Cotoneaster teijiashanensis",
		"cotoneaster",
		3783242
	],
	[
		"s3086336",
		"Cotoneaster tengyuehensis",
		"cotoneaster",
		3086336
	],
	[
		"s2828844",
		"Cotoneaster tenuipes",
		"cotoneaster",
		2828844
	],
	[
		"s3783243",
		"Cotoneaster tetrapetalus",
		"cotoneaster",
		3783243
	],
	[
		"s3783244",
		"Cotoneaster thimphuensis",
		"cotoneaster",
		3783244
	],
	[
		"s3783245",
		"Cotoneaster tjuliniae",
		"cotoneaster",
		3783245
	],
	[
		"s1143230",
		"Cotoneaster tomentosus",
		"cotoneaster",
		1143230
	],
	[
		"s1799569",
		"Cotoneaster transcaucasicus",
		"cotoneaster",
		1799569
	],
	[
		"s3783246",
		"Cotoneaster tripyrenus",
		"cotoneaster",
		3783246
	],
	[
		"s3783247",
		"Cotoneaster tsarongensis",
		"cotoneaster",
		3783247
	],
	[
		"s1248460",
		"Cotoneaster turbinatus",
		"cotoneaster",
		1248460
	],
	[
		"s3086337",
		"Cotoneaster turcomanicus",
		"cotoneaster",
		3086337
	],
	[
		"s3783248",
		"Cotoneaster tytthocarpus",
		"cotoneaster",
		3783248
	],
	[
		"s3783249",
		"Cotoneaster undulatus",
		"cotoneaster",
		3783249
	],
	[
		"s3086338",
		"Cotoneaster uniflorus",
		"cotoneaster",
		3086338
	],
	[
		"s2828832",
		"Cotoneaster vandelaarii",
		"cotoneaster",
		2828832
	],
	[
		"s3783250",
		"Cotoneaster verokotschyi",
		"cotoneaster",
		3783250
	],
	[
		"s690338",
		"Cotoneaster verruculosus",
		"cotoneaster",
		690338
	],
	[
		"s3085968",
		"Cotoneaster vestitus",
		"cotoneaster",
		3085968
	],
	[
		"s2828833",
		"Cotoneaster villosulus",
		"cotoneaster",
		2828833
	],
	[
		"s3783251",
		"Cotoneaster wanbooyensis",
		"cotoneaster",
		3783251
	],
	[
		"s1143231",
		"Cotoneaster wardii",
		"cotoneaster",
		1143231
	],
	[
		"s3783252",
		"Cotoneaster washanensis",
		"cotoneaster",
		3783252
	],
	[
		"s3783253",
		"Cotoneaster wattii",
		"cotoneaster",
		3783253
	],
	[
		"s2716537",
		"Cotoneaster wilsonii",
		"cotoneaster",
		2716537
	],
	[
		"s3086974",
		"Cotoneaster x watereri",
		"cotoneaster",
		3086974
	],
	[
		"s3783254",
		"Cotoneaster yakuticus",
		"cotoneaster",
		3783254
	],
	[
		"s3783255",
		"Cotoneaster yalungensis",
		"cotoneaster",
		3783255
	],
	[
		"s3783256",
		"Cotoneaster yinchangensis",
		"cotoneaster",
		3783256
	],
	[
		"s3783257",
		"Cotoneaster yui",
		"cotoneaster",
		3783257
	],
	[
		"s3783258",
		"Cotoneaster yulingkongensis",
		"cotoneaster",
		3783258
	],
	[
		"s2291117",
		"Cotoneaster zabelii",
		"cotoneaster",
		2291117
	],
	[
		"s3783259",
		"Cotoneaster zangezuricus",
		"cotoneaster",
		3783259
	],
	[
		"s3086339",
		"Cotoneaster zeravschanicus",
		"cotoneaster",
		3086339
	],
	[
		"s3783754",
		"Coussapoa angustifolia",
		"coussapoa",
		3783754
	],
	[
		"s3783755",
		"Coussapoa arachnoidea",
		"coussapoa",
		3783755
	],
	[
		"s3783756",
		"Coussapoa argentea",
		"coussapoa",
		3783756
	],
	[
		"s1958858",
		"Coussapoa asperifolia",
		"coussapoa",
		1958858
	],
	[
		"s3783757",
		"Coussapoa batavorum",
		"coussapoa",
		3783757
	],
	[
		"s3086340",
		"Coussapoa brevipes",
		"coussapoa",
		3086340
	],
	[
		"s3783758",
		"Coussapoa chocoensis",
		"coussapoa",
		3783758
	],
	[
		"s3783759",
		"Coussapoa cinnamomea",
		"coussapoa",
		3783759
	],
	[
		"s3086341",
		"Coussapoa cinnamomifolia",
		"coussapoa",
		3086341
	],
	[
		"s3086342",
		"Coussapoa contorta",
		"coussapoa",
		3086342
	],
	[
		"s1958859",
		"Coussapoa crassivenosa",
		"coussapoa",
		1958859
	],
	[
		"s3783760",
		"Coussapoa cupularis",
		"coussapoa",
		3783760
	],
	[
		"s3783761",
		"Coussapoa curranii",
		"coussapoa",
		3783761
	],
	[
		"s3783762",
		"Coussapoa darienensis",
		"coussapoa",
		3783762
	],
	[
		"s1958860",
		"Coussapoa david-smithii",
		"coussapoa",
		1958860
	],
	[
		"s3783763",
		"Coussapoa dolichandra",
		"coussapoa",
		3783763
	],
	[
		"s3783764",
		"Coussapoa duquei",
		"coussapoa",
		3783764
	],
	[
		"s3783765",
		"Coussapoa echinata",
		"coussapoa",
		3783765
	],
	[
		"s3783766",
		"Coussapoa ferruginea",
		"coussapoa",
		3783766
	],
	[
		"s2497803",
		"Coussapoa floccosa",
		"coussapoa",
		2497803
	],
	[
		"s3783767",
		"Coussapoa fulvescens",
		"coussapoa",
		3783767
	],
	[
		"s2306669",
		"Coussapoa glaberrima",
		"coussapoa",
		2306669
	],
	[
		"s3783768",
		"Coussapoa herthae",
		"coussapoa",
		3783768
	],
	[
		"s3783769",
		"Coussapoa jatun-sachensis",
		"coussapoa",
		3783769
	],
	[
		"s242039",
		"Coussapoa latifolia",
		"coussapoa",
		242039
	],
	[
		"s3783770",
		"Coussapoa leprieurii",
		"coussapoa",
		3783770
	],
	[
		"s3783771",
		"Coussapoa macerrima",
		"coussapoa",
		3783771
	],
	[
		"s3783772",
		"Coussapoa manuensis",
		"coussapoa",
		3783772
	],
	[
		"s242042",
		"Coussapoa microcarpa",
		"coussapoa",
		242042
	],
	[
		"s3783773",
		"Coussapoa microcephala",
		"coussapoa",
		3783773
	],
	[
		"s3086343",
		"Coussapoa nitida",
		"coussapoa",
		3086343
	],
	[
		"s242040",
		"Coussapoa nymphaeifolia",
		"coussapoa",
		242040
	],
	[
		"s3086344",
		"Coussapoa oligocephala",
		"coussapoa",
		3086344
	],
	[
		"s3086345",
		"Coussapoa orthoneura",
		"coussapoa",
		3086345
	],
	[
		"s194323",
		"Coussapoa ovalifolia",
		"coussapoa",
		194323
	],
	[
		"s3086346",
		"Coussapoa pachyphylla",
		"coussapoa",
		3086346
	],
	[
		"s242041",
		"Coussapoa panamensis",
		"coussapoa",
		242041
	],
	[
		"s1781620",
		"Coussapoa parviceps",
		"coussapoa",
		1781620
	],
	[
		"s1399667",
		"Coussapoa parvifolia",
		"coussapoa",
		1399667
	],
	[
		"s3783774",
		"Coussapoa peruviana",
		"coussapoa",
		3783774
	],
	[
		"s3086347",
		"Coussapoa purpusii",
		"coussapoa",
		3086347
	],
	[
		"s3783775",
		"Coussapoa scabra",
		"coussapoa",
		3783775
	],
	[
		"s3086348",
		"Coussapoa sprucei",
		"coussapoa",
		3086348
	],
	[
		"s3783776",
		"Coussapoa tessmannii",
		"coussapoa",
		3783776
	],
	[
		"s3783777",
		"Coussapoa tolimensis",
		"coussapoa",
		3783777
	],
	[
		"s1076877",
		"Coussapoa trinervia",
		"coussapoa",
		1076877
	],
	[
		"s3783778",
		"Coussapoa valaria",
		"coussapoa",
		3783778
	],
	[
		"s3783779",
		"Coussapoa vannifolia",
		"coussapoa",
		3783779
	],
	[
		"s242043",
		"Coussapoa villosa",
		"coussapoa",
		242043
	],
	[
		"s3086349",
		"Coussapoa viridifolia",
		"coussapoa",
		3086349
	],
	[
		"s3086353",
		"Crataegus acutiserrata",
		"crataegus",
		3086353
	],
	[
		"s1286291",
		"Crataegus aemula",
		"crataegus",
		1286291
	],
	[
		"s416279",
		"Crataegus aestivalis",
		"crataegus",
		416279
	],
	[
		"s510709",
		"Crataegus agrestina",
		"crataegus",
		510709
	],
	[
		"s510710",
		"Crataegus albanica",
		"crataegus",
		510710
	],
	[
		"s3086354",
		"Crataegus alma",
		"crataegus",
		3086354
	],
	[
		"s510711",
		"Crataegus almaatensis",
		"crataegus",
		510711
	],
	[
		"s510712",
		"Crataegus altaica",
		"crataegus",
		510712
	],
	[
		"s3086355",
		"Crataegus ambigua",
		"crataegus",
		3086355
	],
	[
		"s3086356",
		"Crataegus apiomorpha",
		"crataegus",
		3086356
	],
	[
		"s3086357",
		"Crataegus aprica",
		"crataegus",
		3086357
	],
	[
		"s1286292",
		"Crataegus aquacervensis",
		"crataegus",
		1286292
	],
	[
		"s3086358",
		"Crataegus arborea",
		"crataegus",
		3086358
	],
	[
		"s3086359",
		"Crataegus arnoldiana",
		"crataegus",
		3086359
	],
	[
		"s3784143",
		"Crataegus artzachensis",
		"crataegus",
		3784143
	],
	[
		"s510713",
		"Crataegus ashei",
		"crataegus",
		510713
	],
	[
		"s3784144",
		"Crataegus asperifolia",
		"crataegus",
		3784144
	],
	[
		"s3086360",
		"Crataegus atrorubens",
		"crataegus",
		3086360
	],
	[
		"s1389468",
		"Crataegus atrovirens",
		"crataegus",
		1389468
	],
	[
		"s3108492",
		"Crataegus aurantia",
		"crataegus",
		3108492
	],
	[
		"s3086361",
		"Crataegus aurescens",
		"crataegus",
		3086361
	],
	[
		"s3784145",
		"Crataegus austromontana",
		"crataegus",
		3784145
	],
	[
		"s298644",
		"Crataegus azarolus",
		"crataegus",
		298644
	],
	[
		"s1150873",
		"Crataegus babakhanloui",
		"crataegus",
		1150873
	],
	[
		"s3784146",
		"Crataegus baroussana",
		"crataegus",
		3784146
	],
	[
		"s3086362",
		"Crataegus basilica",
		"crataegus",
		3086362
	],
	[
		"s3784147",
		"Crataegus beadlei",
		"crataegus",
		3784147
	],
	[
		"s1638379",
		"Crataegus beata",
		"crataegus",
		1638379
	],
	[
		"s3086363",
		"Crataegus berberifolia",
		"crataegus",
		3086363
	],
	[
		"s3086364",
		"Crataegus biltmoreana",
		"crataegus",
		3086364
	],
	[
		"s2894908",
		"Crataegus bipinnatifida",
		"crataegus",
		2894908
	],
	[
		"s3086365",
		"Crataegus bona",
		"crataegus",
		3086365
	],
	[
		"s3784148",
		"Crataegus boyntonii",
		"crataegus",
		3784148
	],
	[
		"s416280",
		"Crataegus brachyacantha",
		"crataegus",
		416280
	],
	[
		"s2071429",
		"Crataegus brainerdii",
		"crataegus",
		2071429
	],
	[
		"s1638380",
		"Crataegus brazoria",
		"crataegus",
		1638380
	],
	[
		"s2231970",
		"Crataegus bretschneideri",
		"crataegus",
		2231970
	],
	[
		"s3784149",
		"Crataegus brittonii",
		"crataegus",
		3784149
	],
	[
		"s2593463",
		"Crataegus calycina",
		"crataegus",
		2593463
	],
	[
		"s3086366",
		"Crataegus canadensis",
		"crataegus",
		3086366
	],
	[
		"s510714",
		"Crataegus castlegarensis",
		"crataegus",
		510714
	],
	[
		"s3784150",
		"Crataegus caucasica",
		"crataegus",
		3784150
	],
	[
		"s510703",
		"Crataegus cf. flava 2003_46",
		"crataegus",
		510703
	],
	[
		"s510705",
		"Crataegus cf. flava 2003_52",
		"crataegus",
		510705
	],
	[
		"s2844934",
		"Crataegus chlorocarpa",
		"crataegus",
		2844934
	],
	[
		"s416282",
		"Crataegus chlorosarca",
		"crataegus",
		416282
	],
	[
		"s510715",
		"Crataegus chrysocarpa",
		"crataegus",
		510715
	],
	[
		"s1961193",
		"Crataegus chungtienensis",
		"crataegus",
		1961193
	],
	[
		"s356593",
		"Crataegus coccinea",
		"crataegus",
		356593
	],
	[
		"s1638381",
		"Crataegus coccinioides",
		"crataegus",
		1638381
	],
	[
		"s2071430",
		"Crataegus cognata",
		"crataegus",
		2071430
	],
	[
		"s3784151",
		"Crataegus coleae",
		"crataegus",
		3784151
	],
	[
		"s510716",
		"Crataegus collina",
		"crataegus",
		510716
	],
	[
		"s32223",
		"Crataegus columbiana",
		"crataegus",
		32223
	],
	[
		"s510717",
		"Crataegus compacta",
		"crataegus",
		510717
	],
	[
		"s3086367",
		"Crataegus condigna",
		"crataegus",
		3086367
	],
	[
		"s3784152",
		"Crataegus coriifolia",
		"crataegus",
		3784152
	],
	[
		"s216036",
		"Crataegus crus-galli",
		"crataegus",
		216036
	],
	[
		"s2741994",
		"Crataegus cuneata",
		"crataegus",
		2741994
	],
	[
		"s1286294",
		"Crataegus cupressocollina",
		"crataegus",
		1286294
	],
	[
		"s298648",
		"Crataegus curvisepala",
		"crataegus",
		298648
	],
	[
		"s416283",
		"Crataegus dahurica",
		"crataegus",
		416283
	],
	[
		"s3086368",
		"Crataegus dallasiana",
		"crataegus",
		3086368
	],
	[
		"s3784153",
		"Crataegus delawarensis",
		"crataegus",
		3784153
	],
	[
		"s3086369",
		"Crataegus dilatata",
		"crataegus",
		3086369
	],
	[
		"s1286295",
		"Crataegus dispar",
		"crataegus",
		1286295
	],
	[
		"s2527798",
		"Crataegus disperma",
		"crataegus",
		2527798
	],
	[
		"s2520621",
		"Crataegus dissona",
		"crataegus",
		2520621
	],
	[
		"s3784154",
		"Crataegus distincta",
		"crataegus",
		3784154
	],
	[
		"s510718",
		"Crataegus dodgei",
		"crataegus",
		510718
	],
	[
		"s510719",
		"Crataegus douglasii",
		"crataegus",
		510719
	],
	[
		"s3784155",
		"Crataegus drepanensis",
		"crataegus",
		3784155
	],
	[
		"s3784156",
		"Crataegus dzhairensis",
		"crataegus",
		3784156
	],
	[
		"s3784157",
		"Crataegus egglestonii",
		"crataegus",
		3784157
	],
	[
		"s3086370",
		"Crataegus egregia",
		"crataegus",
		3086370
	],
	[
		"s510720",
		"Crataegus enderbyensis",
		"crataegus",
		510720
	],
	[
		"s510721",
		"Crataegus engelmannii",
		"crataegus",
		510721
	],
	[
		"s3784158",
		"Crataegus erythrocarpa",
		"crataegus",
		3784158
	],
	[
		"s510722",
		"Crataegus erythropoda",
		"crataegus",
		510722
	],
	[
		"s1286296",
		"Crataegus extraria",
		"crataegus",
		1286296
	],
	[
		"s3784159",
		"Crataegus ferganensis",
		"crataegus",
		3784159
	],
	[
		"s510723",
		"Crataegus flabellata",
		"crataegus",
		510723
	],
	[
		"s510746",
		"Crataegus flava",
		"crataegus",
		510746
	],
	[
		"s510724",
		"Crataegus flavida",
		"crataegus",
		510724
	],
	[
		"s1638382",
		"Crataegus florifera",
		"crataegus",
		1638382
	],
	[
		"s1638383",
		"Crataegus fluviatilis",
		"crataegus",
		1638383
	],
	[
		"s3086371",
		"Crataegus foetida",
		"crataegus",
		3086371
	],
	[
		"s3784160",
		"Crataegus forbesiae",
		"crataegus",
		3784160
	],
	[
		"s1638384",
		"Crataegus formosa",
		"crataegus",
		1638384
	],
	[
		"s3086372",
		"Crataegus fulleriana",
		"crataegus",
		3086372
	],
	[
		"s3086373",
		"Crataegus furtiva",
		"crataegus",
		3086373
	],
	[
		"s3086374",
		"Crataegus gattingeri",
		"crataegus",
		3086374
	],
	[
		"s1286297",
		"Crataegus gaylussacia",
		"crataegus",
		1286297
	],
	[
		"s3086375",
		"Crataegus glabriuscula",
		"crataegus",
		3086375
	],
	[
		"s3784161",
		"Crataegus glareosa",
		"crataegus",
		3784161
	],
	[
		"s2052714",
		"Crataegus gracilior",
		"crataegus",
		2052714
	],
	[
		"s3086376",
		"Crataegus grandifolia",
		"crataegus",
		3086376
	],
	[
		"s1297629",
		"Crataegus grandis",
		"crataegus",
		1297629
	],
	[
		"s3086377",
		"Crataegus greggiana",
		"crataegus",
		3086377
	],
	[
		"s3784162",
		"Crataegus gregorianii",
		"crataegus",
		3784162
	],
	[
		"s1159755",
		"Crataegus grossidentata",
		"crataegus",
		1159755
	],
	[
		"s510726",
		"Crataegus harbisonii",
		"crataegus",
		510726
	],
	[
		"s3784163",
		"Crataegus hatamii",
		"crataegus",
		3784163
	],
	[
		"s416284",
		"Crataegus heldreichii",
		"crataegus",
		416284
	],
	[
		"s3784164",
		"Crataegus heterophylloides",
		"crataegus",
		3784164
	],
	[
		"s3086378",
		"Crataegus hissarica",
		"crataegus",
		3086378
	],
	[
		"s2071431",
		"Crataegus holmesiana",
		"crataegus",
		2071431
	],
	[
		"s416285",
		"Crataegus hupehensis",
		"crataegus",
		416285
	],
	[
		"s2231971",
		"Crataegus hybrid cultivar",
		"crataegus",
		2231971
	],
	[
		"s3086379",
		"Crataegus ignava",
		"crataegus",
		3086379
	],
	[
		"s3784165",
		"Crataegus incaedua",
		"crataegus",
		3784165
	],
	[
		"s3784166",
		"Crataegus indicens",
		"crataegus",
		3784166
	],
	[
		"s3085973",
		"Crataegus integra",
		"crataegus",
		3085973
	],
	[
		"s3086380",
		"Crataegus integriloba",
		"crataegus",
		3086380
	],
	[
		"s1638385",
		"Crataegus intricata",
		"crataegus",
		1638385
	],
	[
		"s3086381",
		"Crataegus invicta",
		"crataegus",
		3086381
	],
	[
		"s1286298",
		"Crataegus iracunda",
		"crataegus",
		1286298
	],
	[
		"s510727",
		"Crataegus irrasa",
		"crataegus",
		510727
	],
	[
		"s3784167",
		"Crataegus isfajramensis",
		"crataegus",
		3784167
	],
	[
		"s3086382",
		"Crataegus jackii",
		"crataegus",
		3086382
	],
	[
		"s2527799",
		"Crataegus jesupii",
		"crataegus",
		2527799
	],
	[
		"s1638386",
		"Crataegus jonesiae",
		"crataegus",
		1638386
	],
	[
		"s416286",
		"Crataegus kansuensis",
		"crataegus",
		416286
	],
	[
		"s3784168",
		"Crataegus karadaghensis",
		"crataegus",
		3784168
	],
	[
		"s3784169",
		"Crataegus keepii",
		"crataegus",
		3784169
	],
	[
		"s3784170",
		"Crataegus kelloggii",
		"crataegus",
		3784170
	],
	[
		"s3784171",
		"Crataegus khatamsazae",
		"crataegus",
		3784171
	],
	[
		"s3784172",
		"Crataegus knorringiana",
		"crataegus",
		3784172
	],
	[
		"s3784173",
		"Crataegus kurdistanica",
		"crataegus",
		3784173
	],
	[
		"s2720242",
		"Crataegus laciniata",
		"crataegus",
		2720242
	],
	[
		"s3086383",
		"Crataegus lacrimata",
		"crataegus",
		3086383
	],
	[
		"s298643",
		"Crataegus laevigata",
		"crataegus",
		298643
	],
	[
		"s3086384",
		"Crataegus lancei",
		"crataegus",
		3086384
	],
	[
		"s3086385",
		"Crataegus lanuginosa",
		"crataegus",
		3086385
	],
	[
		"s416287",
		"Crataegus lassa",
		"crataegus",
		416287
	],
	[
		"s2664617",
		"Crataegus laurentiana",
		"crataegus",
		2664617
	],
	[
		"s3086386",
		"Crataegus levis",
		"crataegus",
		3086386
	],
	[
		"s3086387",
		"Crataegus limnophila",
		"crataegus",
		3086387
	],
	[
		"s3784174",
		"Crataegus longipes",
		"crataegus",
		3784174
	],
	[
		"s2520622",
		"Crataegus lucorum",
		"crataegus",
		2520622
	],
	[
		"s2071432",
		"Crataegus lumaria",
		"crataegus",
		2071432
	],
	[
		"s510728",
		"Crataegus macracantha",
		"crataegus",
		510728
	],
	[
		"s2591758",
		"Crataegus macrocarpa",
		"crataegus",
		2591758
	],
	[
		"s1539863",
		"Crataegus macrosperma",
		"crataegus",
		1539863
	],
	[
		"s1638387",
		"Crataegus magniflora",
		"crataegus",
		1638387
	],
	[
		"s3784175",
		"Crataegus margaretta",
		"crataegus",
		3784175
	],
	[
		"s2071433",
		"Crataegus margarettae",
		"crataegus",
		2071433
	],
	[
		"s416288",
		"Crataegus marshallii",
		"crataegus",
		416288
	],
	[
		"s416289",
		"Crataegus maximowiczii",
		"crataegus",
		416289
	],
	[
		"s510729",
		"Crataegus media",
		"crataegus",
		510729
	],
	[
		"s3784176",
		"Crataegus menandiana",
		"crataegus",
		3784176
	],
	[
		"s3086388",
		"Crataegus mendosa",
		"crataegus",
		3086388
	],
	[
		"s3086389",
		"Crataegus meridionalis",
		"crataegus",
		3086389
	],
	[
		"s1094392",
		"Crataegus mexicana",
		"crataegus",
		1094392
	],
	[
		"s510730",
		"Crataegus meyeri",
		"crataegus",
		510730
	],
	[
		"s1620035",
		"Crataegus michauxii",
		"crataegus",
		1620035
	],
	[
		"s3086390",
		"Crataegus microphylla",
		"crataegus",
		3086390
	],
	[
		"s36593",
		"Crataegus mollis",
		"crataegus",
		36593
	],
	[
		"s1638378",
		"Crataegus mollis x Crataegus viridis",
		"crataegus",
		1638378
	],
	[
		"s140997",
		"Crataegus monogyna",
		"crataegus",
		140997
	],
	[
		"s1286304",
		"Crataegus monogyna x Crataegus punctata",
		"crataegus",
		1286304
	],
	[
		"s1286305",
		"Crataegus monogyna x Crataegus suksdorfii",
		"crataegus",
		1286305
	],
	[
		"s510731",
		"Crataegus munda",
		"crataegus",
		510731
	],
	[
		"s3086391",
		"Crataegus nananixonii",
		"crataegus",
		3086391
	],
	[
		"s3784177",
		"Crataegus necopinata",
		"crataegus",
		3784177
	],
	[
		"s3784178",
		"Crataegus nelsonii",
		"crataegus",
		3784178
	],
	[
		"s3086392",
		"Crataegus neobushii",
		"crataegus",
		3086392
	],
	[
		"s510732",
		"Crataegus nevadensis",
		"crataegus",
		510732
	],
	[
		"s298649",
		"Crataegus nigra",
		"crataegus",
		298649
	],
	[
		"s3085974",
		"Crataegus nitida",
		"crataegus",
		3085974
	],
	[
		"s3086393",
		"Crataegus nitidula",
		"crataegus",
		3086393
	],
	[
		"s3086394",
		"Crataegus nuda",
		"crataegus",
		3086394
	],
	[
		"s3784179",
		"Crataegus oakesiana",
		"crataegus",
		3784179
	],
	[
		"s1389467",
		"Crataegus okanaganensis",
		"crataegus",
		1389467
	],
	[
		"s510733",
		"Crataegus okennonii",
		"crataegus",
		510733
	],
	[
		"s416290",
		"Crataegus opaca",
		"crataegus",
		416290
	],
	[
		"s3086395",
		"Crataegus opima",
		"crataegus",
		3086395
	],
	[
		"s3784180",
		"Crataegus opulens",
		"crataegus",
		3784180
	],
	[
		"s1389469",
		"Crataegus orbicularis",
		"crataegus",
		1389469
	],
	[
		"s3784181",
		"Crataegus oreophila",
		"crataegus",
		3784181
	],
	[
		"s2967324",
		"Crataegus oresbia",
		"crataegus",
		2967324
	],
	[
		"s510734",
		"Crataegus orientalis",
		"crataegus",
		510734
	],
	[
		"s3086396",
		"Crataegus ouachitensis",
		"crataegus",
		3086396
	],
	[
		"s3086397",
		"Crataegus padifolia",
		"crataegus",
		3086397
	],
	[
		"s3086398",
		"Crataegus pallasii",
		"crataegus",
		3086398
	],
	[
		"s3086399",
		"Crataegus paludosa",
		"crataegus",
		3086399
	],
	[
		"s3784182",
		"Crataegus pamiroalaica",
		"crataegus",
		3784182
	],
	[
		"s3086400",
		"Crataegus pearsonii",
		"crataegus",
		3086400
	],
	[
		"s2527800",
		"Crataegus pedicellata",
		"crataegus",
		2527800
	],
	[
		"s3086401",
		"Crataegus pennsylvanica",
		"crataegus",
		3086401
	],
	[
		"s416291",
		"Crataegus pentagyna",
		"crataegus",
		416291
	],
	[
		"s3784183",
		"Crataegus pequotorum",
		"crataegus",
		3784183
	],
	[
		"s1638390",
		"Crataegus perjucunda",
		"crataegus",
		1638390
	],
	[
		"s356591",
		"Crataegus persimilis",
		"crataegus",
		356591
	],
	[
		"s3784184",
		"Crataegus petrodavisii",
		"crataegus",
		3784184
	],
	[
		"s3784185",
		"Crataegus pexa",
		"crataegus",
		3784185
	],
	[
		"s416292",
		"Crataegus phaenopyrum",
		"crataegus",
		416292
	],
	[
		"s1286300",
		"Crataegus phippsii",
		"crataegus",
		1286300
	],
	[
		"s510735",
		"Crataegus pinnatifida",
		"crataegus",
		510735
	],
	[
		"s3238312",
		"Crataegus piperi",
		"crataegus",
		3238312
	],
	[
		"s3784186",
		"Crataegus pisifera",
		"crataegus",
		3784186
	],
	[
		"s1117089",
		"Crataegus pontica",
		"crataegus",
		1117089
	],
	[
		"s2071434",
		"Crataegus populnea",
		"crataegus",
		2071434
	],
	[
		"s3086402",
		"Crataegus porrecta",
		"crataegus",
		3086402
	],
	[
		"s3086403",
		"Crataegus pringlei",
		"crataegus",
		3086403
	],
	[
		"s3086404",
		"Crataegus prona",
		"crataegus",
		3086404
	],
	[
		"s2071435",
		"Crataegus pruinosa",
		"crataegus",
		2071435
	],
	[
		"s510736",
		"Crataegus pseudoheterophylla",
		"crataegus",
		510736
	],
	[
		"s3784187",
		"Crataegus pseudosanguinea",
		"crataegus",
		3784187
	],
	[
		"s416293",
		"Crataegus pubescens",
		"crataegus",
		416293
	],
	[
		"s3086405",
		"Crataegus pulcherrima",
		"crataegus",
		3086405
	],
	[
		"s416294",
		"Crataegus punctata",
		"crataegus",
		416294
	],
	[
		"s1638391",
		"Crataegus purpurella",
		"crataegus",
		1638391
	],
	[
		"s3784188",
		"Crataegus putata",
		"crataegus",
		3784188
	],
	[
		"s510737",
		"Crataegus pycnoloba",
		"crataegus",
		510737
	],
	[
		"s3784189",
		"Crataegus quaesita",
		"crataegus",
		3784189
	],
	[
		"s3784190",
		"Crataegus ravida",
		"crataegus",
		3784190
	],
	[
		"s2781244",
		"Crataegus remotilobata",
		"crataegus",
		2781244
	],
	[
		"s510738",
		"Crataegus rhipidophylla",
		"crataegus",
		510738
	],
	[
		"s3406579",
		"Crataegus rhodamae-loveae",
		"crataegus",
		3406579
	],
	[
		"s3086406",
		"Crataegus rigens",
		"crataegus",
		3086406
	],
	[
		"s193313",
		"Crataegus rivularis",
		"crataegus",
		193313
	],
	[
		"s1297754",
		"Crataegus rivuloadamensis",
		"crataegus",
		1297754
	],
	[
		"s1286301",
		"Crataegus rivulopugnensis",
		"crataegus",
		1286301
	],
	[
		"s1297626",
		"Crataegus robur",
		"crataegus",
		1297626
	],
	[
		"s3784191",
		"Crataegus roribacca",
		"crataegus",
		3784191
	],
	[
		"s985672",
		"Crataegus rosei",
		"crataegus",
		985672
	],
	[
		"s3086407",
		"Crataegus rubella",
		"crataegus",
		3086407
	],
	[
		"s1638392",
		"Crataegus rubribracteolata",
		"crataegus",
		1638392
	],
	[
		"s510739",
		"Crataegus rufula",
		"crataegus",
		510739
	],
	[
		"s510740",
		"Crataegus russanovii",
		"crataegus",
		510740
	],
	[
		"s3784192",
		"Crataegus sakranensis",
		"crataegus",
		3784192
	],
	[
		"s416295",
		"Crataegus saligna",
		"crataegus",
		416295
	],
	[
		"s416296",
		"Crataegus sanguinea",
		"crataegus",
		416296
	],
	[
		"s510741",
		"Crataegus sargentii",
		"crataegus",
		510741
	],
	[
		"s1638393",
		"Crataegus scabrida",
		"crataegus",
		1638393
	],
	[
		"s1826781",
		"Crataegus scabrifolia",
		"crataegus",
		1826781
	],
	[
		"s3784193",
		"Crataegus schizophylla",
		"crataegus",
		3784193
	],
	[
		"s1638394",
		"Crataegus schuettei",
		"crataegus",
		1638394
	],
	[
		"s3086408",
		"Crataegus secreta",
		"crataegus",
		3086408
	],
	[
		"s3342057",
		"Crataegus shandongensis",
		"crataegus",
		3342057
	],
	[
		"s1638395",
		"Crataegus sheila-phippsiae",
		"crataegus",
		1638395
	],
	[
		"s3465343",
		"Crataegus shensiensis",
		"crataegus",
		3465343
	],
	[
		"s1638396",
		"Crataegus sheridana",
		"crataegus",
		1638396
	],
	[
		"s3784194",
		"Crataegus shinnersii",
		"crataegus",
		3784194
	],
	[
		"s1297755",
		"Crataegus shuswapensis",
		"crataegus",
		1297755
	],
	[
		"s3784195",
		"Crataegus silvestris",
		"crataegus",
		3784195
	],
	[
		"s298646",
		"Crataegus sinaica",
		"crataegus",
		298646
	],
	[
		"s416297",
		"Crataegus songarica",
		"crataegus",
		416297
	],
	[
		"s1286302",
		"Crataegus sororia",
		"crataegus",
		1286302
	],
	[
		"s416298",
		"Crataegus spathulata",
		"crataegus",
		416298
	],
	[
		"s3784196",
		"Crataegus spes-aestatum",
		"crataegus",
		3784196
	],
	[
		"s3086409",
		"Crataegus sphaenophylla",
		"crataegus",
		3086409
	],
	[
		"s3784197",
		"Crataegus spissa",
		"crataegus",
		3784197
	],
	[
		"s3784198",
		"Crataegus stankovii",
		"crataegus",
		3784198
	],
	[
		"s3086410",
		"Crataegus stenosepala",
		"crataegus",
		3086410
	],
	[
		"s3784199",
		"Crataegus stevenii",
		"crataegus",
		3784199
	],
	[
		"s2071436",
		"Crataegus stolonifera",
		"crataegus",
		2071436
	],
	[
		"s3784200",
		"Crataegus stonei",
		"crataegus",
		3784200
	],
	[
		"s3784201",
		"Crataegus subheterophylla",
		"crataegus",
		3784201
	],
	[
		"s356592",
		"Crataegus submollis",
		"crataegus",
		356592
	],
	[
		"s2071437",
		"Crataegus suborbiculata",
		"crataegus",
		2071437
	],
	[
		"s1143232",
		"Crataegus succulenta",
		"crataegus",
		1143232
	],
	[
		"s416299",
		"Crataegus suksdorfii",
		"crataegus",
		416299
	],
	[
		"s3086411",
		"Crataegus sulfurea",
		"crataegus",
		3086411
	],
	[
		"s3784202",
		"Crataegus talyschensis",
		"crataegus",
		3784202
	],
	[
		"s659337",
		"Crataegus tanacetifolia",
		"crataegus",
		659337
	],
	[
		"s3784203",
		"Crataegus tanuphylla",
		"crataegus",
		3784203
	],
	[
		"s3086412",
		"Crataegus taurica",
		"crataegus",
		3086412
	],
	[
		"s3086413",
		"Crataegus tecta",
		"crataegus",
		3086413
	],
	[
		"s510742",
		"Crataegus tenax",
		"crataegus",
		510742
	],
	[
		"s3784204",
		"Crataegus tenuior",
		"crataegus",
		3784204
	],
	[
		"s3086414",
		"Crataegus texana",
		"crataegus",
		3086414
	],
	[
		"s3784205",
		"Crataegus theodori",
		"crataegus",
		3784205
	],
	[
		"s3784206",
		"Crataegus thermopegaea",
		"crataegus",
		3784206
	],
	[
		"s3086415",
		"Crataegus tianschanica",
		"crataegus",
		3086415
	],
	[
		"s3784207",
		"Crataegus tinctoria",
		"crataegus",
		3784207
	],
	[
		"s3784208",
		"Crataegus tkatschenkoi",
		"crataegus",
		3784208
	],
	[
		"s416300",
		"Crataegus triflora",
		"crataegus",
		416300
	],
	[
		"s3086416",
		"Crataegus tripartita",
		"crataegus",
		3086416
	],
	[
		"s3402870",
		"Crataegus turcicus",
		"crataegus",
		3402870
	],
	[
		"s3784209",
		"Crataegus turkestanica",
		"crataegus",
		3784209
	],
	[
		"s1297628",
		"Crataegus turnerorum",
		"crataegus",
		1297628
	],
	[
		"s3784210",
		"Crataegus tzvelevii",
		"crataegus",
		3784210
	],
	[
		"s3086417",
		"Crataegus ucrainica",
		"crataegus",
		3086417
	],
	[
		"s3784211",
		"Crataegus umbratilis",
		"crataegus",
		3784211
	],
	[
		"s416301",
		"Crataegus uniflora",
		"crataegus",
		416301
	],
	[
		"s2071438",
		"Crataegus ursopedensis",
		"crataegus",
		2071438
	],
	[
		"s3086418",
		"Crataegus uvaldensis",
		"crataegus",
		3086418
	],
	[
		"s3086419",
		"Crataegus venusta",
		"crataegus",
		3086419
	],
	[
		"s416302",
		"Crataegus viridis",
		"crataegus",
		416302
	],
	[
		"s1286303",
		"Crataegus visenda",
		"crataegus",
		1286303
	],
	[
		"s3086421",
		"Crataegus vulsa",
		"crataegus",
		3086421
	],
	[
		"s3086422",
		"Crataegus warneri",
		"crataegus",
		3086422
	],
	[
		"s510743",
		"Crataegus wattiana",
		"crataegus",
		510743
	],
	[
		"s3784212",
		"Crataegus whitakeri",
		"crataegus",
		3784212
	],
	[
		"s1297627",
		"Crataegus williamsii",
		"crataegus",
		1297627
	],
	[
		"s416303",
		"Crataegus wilsonii",
		"crataegus",
		416303
	],
	[
		"s3086423",
		"Crataegus wootoniana",
		"crataegus",
		3086423
	],
	[
		"s2979720",
		"Crataegus x bornmuelleri",
		"crataegus",
		2979720
	],
	[
		"s1286306",
		"Crataegus x canescens",
		"crataegus",
		1286306
	],
	[
		"s3406578",
		"Crataegus x cogswellii",
		"crataegus",
		3406578
	],
	[
		"s1470403",
		"Crataegus x degenii",
		"crataegus",
		1470403
	],
	[
		"s3086973",
		"Crataegus x grignonensis",
		"crataegus",
		3086973
	],
	[
		"s510691",
		"Crataegus x killinica",
		"crataegus",
		510691
	],
	[
		"s3086972",
		"Crataegus x kyrtostyla",
		"crataegus",
		3086972
	],
	[
		"s3238315",
		"Crataegus x lavalleei",
		"crataegus",
		3238315
	],
	[
		"s2592571",
		"Crataegus x macrocarpa",
		"crataegus",
		2592571
	],
	[
		"s3406577",
		"Crataegus x ninae-celottiae",
		"crataegus",
		3406577
	],
	[
		"s510692",
		"Crataegus x peloponnesiaca",
		"crataegus",
		510692
	],
	[
		"s3086970",
		"Crataegus x pseudoazarolus",
		"crataegus",
		3086970
	],
	[
		"s3784213",
		"Crataegus yaltirikii",
		"crataegus",
		3784213
	],
	[
		"s3784214",
		"Crataegus zagrica",
		"crataegus",
		3784214
	],
	[
		"s3784215",
		"Crataegus zichichii",
		"crataegus",
		3784215
	],
	[
		"s3086491",
		"Crumenaria decumbens",
		"crumenaria",
		3086491
	],
	[
		"s106669",
		"Crumenaria erecta",
		"crumenaria",
		106669
	],
	[
		"s3086492",
		"Crumenaria glaziovii",
		"crumenaria",
		3086492
	],
	[
		"s3086493",
		"Crumenaria lilloi",
		"crumenaria",
		3086493
	],
	[
		"s1812993",
		"Crumenaria polygaloides",
		"crumenaria",
		1812993
	],
	[
		"s2985958",
		"Cryptandra aff. amara 'Russell'",
		"cryptandra",
		2985958
	],
	[
		"s323923",
		"Cryptandra alpina",
		"cryptandra",
		323923
	],
	[
		"s149376",
		"Cryptandra amara",
		"cryptandra",
		149376
	],
	[
		"s2985829",
		"Cryptandra apetala",
		"cryptandra",
		2985829
	],
	[
		"s323928",
		"Cryptandra arbutiflora",
		"cryptandra",
		323928
	],
	[
		"s3786124",
		"Cryptandra aridicola",
		"cryptandra",
		3786124
	],
	[
		"s2985833",
		"Cryptandra armata",
		"cryptandra",
		2985833
	],
	[
		"s2985834",
		"Cryptandra beverleyensis",
		"cryptandra",
		2985834
	],
	[
		"s2985835",
		"Cryptandra campanulata",
		"cryptandra",
		2985835
	],
	[
		"s2985836",
		"Cryptandra ciliata",
		"cryptandra",
		2985836
	],
	[
		"s2985837",
		"Cryptandra congesta",
		"cryptandra",
		2985837
	],
	[
		"s323943",
		"Cryptandra connata",
		"cryptandra",
		323943
	],
	[
		"s3786125",
		"Cryptandra coronata",
		"cryptandra",
		3786125
	],
	[
		"s3786126",
		"Cryptandra craigiae",
		"cryptandra",
		3786126
	],
	[
		"s2985838",
		"Cryptandra crispula",
		"cryptandra",
		2985838
	],
	[
		"s2985839",
		"Cryptandra debilis",
		"cryptandra",
		2985839
	],
	[
		"s323934",
		"Cryptandra dielsii",
		"cryptandra",
		323934
	],
	[
		"s2985840",
		"Cryptandra distigma",
		"cryptandra",
		2985840
	],
	[
		"s323924",
		"Cryptandra ericoides",
		"cryptandra",
		323924
	],
	[
		"s2985841",
		"Cryptandra exilis",
		"cryptandra",
		2985841
	],
	[
		"s2985842",
		"Cryptandra exserta",
		"cryptandra",
		2985842
	],
	[
		"s2992115",
		"Cryptandra filiformis",
		"cryptandra",
		2992115
	],
	[
		"s323929",
		"Cryptandra gemmata",
		"cryptandra",
		323929
	],
	[
		"s2985843",
		"Cryptandra glabriflora",
		"cryptandra",
		2985843
	],
	[
		"s3786127",
		"Cryptandra graniticola",
		"cryptandra",
		3786127
	],
	[
		"s323925",
		"Cryptandra hispidula",
		"cryptandra",
		323925
	],
	[
		"s1806639",
		"Cryptandra imbricata",
		"cryptandra",
		1806639
	],
	[
		"s2985844",
		"Cryptandra inconspicua",
		"cryptandra",
		2985844
	],
	[
		"s2985845",
		"Cryptandra intermedia",
		"cryptandra",
		2985845
	],
	[
		"s2985846",
		"Cryptandra intonsa",
		"cryptandra",
		2985846
	],
	[
		"s323931",
		"Cryptandra intratropica",
		"cryptandra",
		323931
	],
	[
		"s323926",
		"Cryptandra lanosiflora",
		"cryptandra",
		323926
	],
	[
		"s323981",
		"Cryptandra leucophracta",
		"cryptandra",
		323981
	],
	[
		"s2985847",
		"Cryptandra leucopogon",
		"cryptandra",
		2985847
	],
	[
		"s2985848",
		"Cryptandra longistaminea",
		"cryptandra",
		2985848
	],
	[
		"s2985849",
		"Cryptandra magniflora",
		"cryptandra",
		2985849
	],
	[
		"s323927",
		"Cryptandra micrantha",
		"cryptandra",
		323927
	],
	[
		"s2985850",
		"Cryptandra minutifolia",
		"cryptandra",
		2985850
	],
	[
		"s2985852",
		"Cryptandra monticola",
		"cryptandra",
		2985852
	],
	[
		"s2985853",
		"Cryptandra multispina",
		"cryptandra",
		2985853
	],
	[
		"s323933",
		"Cryptandra mutila",
		"cryptandra",
		323933
	],
	[
		"s432430",
		"Cryptandra myriantha",
		"cryptandra",
		432430
	],
	[
		"s323930",
		"Cryptandra nola",
		"cryptandra",
		323930
	],
	[
		"s2985854",
		"Cryptandra nutans",
		"cryptandra",
		2985854
	],
	[
		"s2985855",
		"Cryptandra orbicularis",
		"cryptandra",
		2985855
	],
	[
		"s2985856",
		"Cryptandra pendula",
		"cryptandra",
		2985856
	],
	[
		"s2985857",
		"Cryptandra pogonoloba",
		"cryptandra",
		2985857
	],
	[
		"s3086496",
		"Cryptandra polyclada",
		"cryptandra",
		3086496
	],
	[
		"s2985859",
		"Cryptandra propinqua",
		"cryptandra",
		2985859
	],
	[
		"s323932",
		"Cryptandra pungens",
		"cryptandra",
		323932
	],
	[
		"s2985860",
		"Cryptandra recurva",
		"cryptandra",
		2985860
	],
	[
		"s3786128",
		"Cryptandra rigida",
		"cryptandra",
		3786128
	],
	[
		"s2985861",
		"Cryptandra scoparia",
		"cryptandra",
		2985861
	],
	[
		"s2985820",
		"Cryptandra setifera",
		"cryptandra",
		2985820
	],
	[
		"s2985862",
		"Cryptandra speciosa",
		"cryptandra",
		2985862
	],
	[
		"s2985864",
		"Cryptandra spinescens",
		"cryptandra",
		2985864
	],
	[
		"s106671",
		"Cryptandra spyridioides",
		"cryptandra",
		106671
	],
	[
		"s2985865",
		"Cryptandra stellulata",
		"cryptandra",
		2985865
	],
	[
		"s2985821",
		"Cryptandra subtilis",
		"cryptandra",
		2985821
	],
	[
		"s2985866",
		"Cryptandra tomentosa",
		"cryptandra",
		2985866
	],
	[
		"s456986",
		"Cryptandra triplex",
		"cryptandra",
		456986
	],
	[
		"s2985867",
		"Cryptandra wilsonii",
		"cryptandra",
		2985867
	],
	[
		"s36610",
		"Cydonia oblonga",
		"cydonia",
		36610
	],
	[
		"s344761",
		"Cypholophus aff. trapula Pullen 5962",
		"cypholophus",
		344761
	],
	[
		"s3787742",
		"Cypholophus anisoneurus",
		"cypholophus",
		3787742
	],
	[
		"s3086525",
		"Cypholophus brunneolus",
		"cypholophus",
		3086525
	],
	[
		"s3787813",
		"Cypholophus chamaephyton",
		"cypholophus",
		3787813
	],
	[
		"s3086526",
		"Cypholophus decipiens",
		"cypholophus",
		3086526
	],
	[
		"s3787755",
		"Cypholophus ellipticus",
		"cypholophus",
		3787755
	],
	[
		"s3086527",
		"Cypholophus englerianus",
		"cypholophus",
		3086527
	],
	[
		"s2501680",
		"Cypholophus friesianus",
		"cypholophus",
		2501680
	],
	[
		"s3787812",
		"Cypholophus gjellerupii",
		"cypholophus",
		3787812
	],
	[
		"s2306670",
		"Cypholophus heterophyllus",
		"cypholophus",
		2306670
	],
	[
		"s3787811",
		"Cypholophus integer",
		"cypholophus",
		3787811
	],
	[
		"s3086528",
		"Cypholophus kerewensis",
		"cypholophus",
		3086528
	],
	[
		"s3085983",
		"Cypholophus latifolius",
		"cypholophus",
		3085983
	],
	[
		"s3787810",
		"Cypholophus ledermannii",
		"cypholophus",
		3787810
	],
	[
		"s3085984",
		"Cypholophus lutescens",
		"cypholophus",
		3085984
	],
	[
		"s647260",
		"Cypholophus macrocephalus",
		"cypholophus",
		647260
	],
	[
		"s3787802",
		"Cypholophus melanocarpoides",
		"cypholophus",
		3787802
	],
	[
		"s3787741",
		"Cypholophus melanocarpus",
		"cypholophus",
		3787741
	],
	[
		"s3787584",
		"Cypholophus microphyllus",
		"cypholophus",
		3787584
	],
	[
		"s1898924",
		"Cypholophus moluccanus",
		"cypholophus",
		1898924
	],
	[
		"s2306671",
		"Cypholophus montanus",
		"cypholophus",
		2306671
	],
	[
		"s3787809",
		"Cypholophus nummularis",
		"cypholophus",
		3787809
	],
	[
		"s3787808",
		"Cypholophus pachycarpus",
		"cypholophus",
		3787808
	],
	[
		"s3787807",
		"Cypholophus patens",
		"cypholophus",
		3787807
	],
	[
		"s3787740",
		"Cypholophus prostratus",
		"cypholophus",
		3787740
	],
	[
		"s3787806",
		"Cypholophus pulleanus",
		"cypholophus",
		3787806
	],
	[
		"s3787805",
		"Cypholophus radicans",
		"cypholophus",
		3787805
	],
	[
		"s3787804",
		"Cypholophus reticulatus",
		"cypholophus",
		3787804
	],
	[
		"s3086529",
		"Cypholophus rotundifolius",
		"cypholophus",
		3086529
	],
	[
		"s3787781",
		"Cypholophus rudis",
		"cypholophus",
		3787781
	],
	[
		"s3086530",
		"Cypholophus stipulatus",
		"cypholophus",
		3086530
	],
	[
		"s344864",
		"Cypholophus trapula",
		"cypholophus",
		344864
	],
	[
		"s3086531",
		"Cypholophus treubii",
		"cypholophus",
		3086531
	],
	[
		"s3787803",
		"Cypholophus vaccinioides",
		"cypholophus",
		3787803
	],
	[
		"s3086532",
		"Cypholophus velutinus",
		"cypholophus",
		3086532
	],
	[
		"s3787739",
		"Cypholophus vestitus",
		"cypholophus",
		3787739
	],
	[
		"s3086533",
		"Cypholophus warburgianus",
		"cypholophus",
		3086533
	],
	[
		"s1226764",
		"Dallachya vitiensis",
		"dallachya",
		1226764
	],
	[
		"s1806919",
		"Dasiphora arbuscula",
		"dasiphora",
		1806919
	],
	[
		"s637890",
		"Dasiphora davurica",
		"dasiphora",
		637890
	],
	[
		"s32239",
		"Dasiphora fruticosa",
		"dasiphora",
		32239
	],
	[
		"s3789341",
		"Dasiphora galantha",
		"dasiphora",
		3789341
	],
	[
		"s1429983",
		"Dasiphora glabra",
		"dasiphora",
		1429983
	],
	[
		"s3789402",
		"Dasiphora gorovoii",
		"dasiphora",
		3789402
	],
	[
		"s637891",
		"Dasiphora phyllocalyx",
		"dasiphora",
		637891
	],
	[
		"s3789340",
		"Dasiphora spectabilis",
		"dasiphora",
		3789340
	],
	[
		"s2848452",
		"Debregeasia australis",
		"debregeasia",
		2848452
	],
	[
		"s647261",
		"Debregeasia dichotoma",
		"debregeasia",
		647261
	],
	[
		"s540247",
		"Debregeasia edulis",
		"debregeasia",
		540247
	],
	[
		"s540248",
		"Debregeasia elliptica",
		"debregeasia",
		540248
	],
	[
		"s2836439",
		"Debregeasia hekouensis",
		"debregeasia",
		2836439
	],
	[
		"s242038",
		"Debregeasia longifolia",
		"debregeasia",
		242038
	],
	[
		"s1399668",
		"Debregeasia orientalis",
		"debregeasia",
		1399668
	],
	[
		"s1037061",
		"Debregeasia saeneb",
		"debregeasia",
		1037061
	],
	[
		"s210330",
		"Debregeasia salicifolia",
		"debregeasia",
		210330
	],
	[
		"s1399670",
		"Debregeasia squamata",
		"debregeasia",
		1399670
	],
	[
		"s137441",
		"Dendriopoterium menendezii",
		"dendriopoterium",
		137441
	],
	[
		"s137442",
		"Dendriopoterium pulidoi",
		"dendriopoterium",
		137442
	],
	[
		"s3790808",
		"Dendrocnide amplissima",
		"dendrocnide",
		3790808
	],
	[
		"s1303705",
		"Dendrocnide basirotunda",
		"dendrocnide",
		1303705
	],
	[
		"s3086584",
		"Dendrocnide carriana",
		"dendrocnide",
		3086584
	],
	[
		"s3790753",
		"Dendrocnide celebica",
		"dendrocnide",
		3790753
	],
	[
		"s3790807",
		"Dendrocnide contracta",
		"dendrocnide",
		3790807
	],
	[
		"s3085997",
		"Dendrocnide corallodesme",
		"dendrocnide",
		3085997
	],
	[
		"s1085358",
		"Dendrocnide cordata",
		"dendrocnide",
		1085358
	],
	[
		"s3790806",
		"Dendrocnide cordifolia",
		"dendrocnide",
		3790806
	],
	[
		"s3790805",
		"Dendrocnide crassifolia",
		"dendrocnide",
		3790805
	],
	[
		"s3790804",
		"Dendrocnide densiflora",
		"dendrocnide",
		3790804
	],
	[
		"s3085998",
		"Dendrocnide elliptica",
		"dendrocnide",
		3085998
	],
	[
		"s647263",
		"Dendrocnide excelsa",
		"dendrocnide",
		647263
	],
	[
		"s3790803",
		"Dendrocnide gigantea",
		"dendrocnide",
		3790803
	],
	[
		"s3085999",
		"Dendrocnide harveyi",
		"dendrocnide",
		3085999
	],
	[
		"s3790752",
		"Dendrocnide kajewskii",
		"dendrocnide",
		3790752
	],
	[
		"s3790751",
		"Dendrocnide kjellbergii",
		"dendrocnide",
		3790751
	],
	[
		"s3086000",
		"Dendrocnide kotoensis",
		"dendrocnide",
		3086e3
	],
	[
		"s3086001",
		"Dendrocnide latifolia",
		"dendrocnide",
		3086001
	],
	[
		"s1085359",
		"Dendrocnide longifolia",
		"dendrocnide",
		1085359
	],
	[
		"s3790802",
		"Dendrocnide luzonensis",
		"dendrocnide",
		3790802
	],
	[
		"s1399671",
		"Dendrocnide meyeniana",
		"dendrocnide",
		1399671
	],
	[
		"s3790801",
		"Dendrocnide microstigma",
		"dendrocnide",
		3790801
	],
	[
		"s3790800",
		"Dendrocnide mirabilis",
		"dendrocnide",
		3790800
	],
	[
		"s3086585",
		"Dendrocnide morobensis",
		"dendrocnide",
		3086585
	],
	[
		"s1842752",
		"Dendrocnide moroides",
		"dendrocnide",
		1842752
	],
	[
		"s3086586",
		"Dendrocnide nervosa",
		"dendrocnide",
		3086586
	],
	[
		"s3790799",
		"Dendrocnide oblanceolata",
		"dendrocnide",
		3790799
	],
	[
		"s3086002",
		"Dendrocnide peltata",
		"dendrocnide",
		3086002
	],
	[
		"s1382163",
		"Dendrocnide photinophylla",
		"dendrocnide",
		1382163
	],
	[
		"s3086587",
		"Dendrocnide pruritivus",
		"dendrocnide",
		3086587
	],
	[
		"s3790798",
		"Dendrocnide rechingeri",
		"dendrocnide",
		3790798
	],
	[
		"s3790797",
		"Dendrocnide rigidifolia",
		"dendrocnide",
		3790797
	],
	[
		"s3086588",
		"Dendrocnide schlechteri",
		"dendrocnide",
		3086588
	],
	[
		"s3790796",
		"Dendrocnide sessiliflora",
		"dendrocnide",
		3790796
	],
	[
		"s647264",
		"Dendrocnide sinuata",
		"dendrocnide",
		647264
	],
	[
		"s647265",
		"Dendrocnide stimulans",
		"dendrocnide",
		647265
	],
	[
		"s3086004",
		"Dendrocnide subclausa",
		"dendrocnide",
		3086004
	],
	[
		"s3790795",
		"Dendrocnide ternatensis",
		"dendrocnide",
		3790795
	],
	[
		"s3790794",
		"Dendrocnide torricellensis",
		"dendrocnide",
		3790794
	],
	[
		"s1303704",
		"Dendrocnide urentissima",
		"dendrocnide",
		1303704
	],
	[
		"s3790793",
		"Dendrocnide venosa",
		"dendrocnide",
		3790793
	],
	[
		"s193303",
		"Dichotomanthes tristaniicarpa",
		"dichotomanthes",
		193303
	],
	[
		"s378933",
		"Didymodoxa afra",
		"didymodoxa",
		378933
	],
	[
		"s647266",
		"Didymodoxa capensis",
		"didymodoxa",
		647266
	],
	[
		"s72160",
		"Dirachma socotrana",
		"dirachma",
		72160
	],
	[
		"s3794053",
		"Dirachma somalensis",
		"dirachma",
		3794053
	],
	[
		"s262931",
		"Discaria americana",
		"discaria",
		262931
	],
	[
		"s262932",
		"Discaria articulata",
		"discaria",
		262932
	],
	[
		"s48244",
		"Discaria chacaye",
		"discaria",
		48244
	],
	[
		"s262934",
		"Discaria nitida",
		"discaria",
		262934
	],
	[
		"s262935",
		"Discaria pubescens",
		"discaria",
		262935
	],
	[
		"s140582",
		"Discaria toumatou",
		"discaria",
		140582
	],
	[
		"s3086030",
		"Discaria x andina",
		"discaria",
		3086030
	],
	[
		"s3086031",
		"Discaria x serratifolia",
		"discaria",
		3086031
	],
	[
		"s344763",
		"Discocnide mexicana",
		"discocnide",
		344763
	],
	[
		"s106673",
		"Doerpfeldia cubensis",
		"doerpfeldia",
		106673
	],
	[
		"s2877896",
		"Dorstenia acangatara",
		"dorstenia",
		2877896
	],
	[
		"s984793",
		"Dorstenia africana",
		"dorstenia",
		984793
	],
	[
		"s3795183",
		"Dorstenia afromontana",
		"dorstenia",
		3795183
	],
	[
		"s2877897",
		"Dorstenia albertii",
		"dorstenia",
		2877897
	],
	[
		"s3795184",
		"Dorstenia annua",
		"dorstenia",
		3795184
	],
	[
		"s2604973",
		"Dorstenia appendiculata",
		"dorstenia",
		2604973
	],
	[
		"s3795185",
		"Dorstenia arachniformis",
		"dorstenia",
		3795185
	],
	[
		"s241876",
		"Dorstenia arifolia",
		"dorstenia",
		241876
	],
	[
		"s2604974",
		"Dorstenia aristeguietae",
		"dorstenia",
		2604974
	],
	[
		"s2604975",
		"Dorstenia astyanactis",
		"dorstenia",
		2604975
	],
	[
		"s382339",
		"Dorstenia bahiensis",
		"dorstenia",
		382339
	],
	[
		"s2604976",
		"Dorstenia barnimiana",
		"dorstenia",
		2604976
	],
	[
		"s2604977",
		"Dorstenia barteri",
		"dorstenia",
		2604977
	],
	[
		"s3086670",
		"Dorstenia belizensis",
		"dorstenia",
		3086670
	],
	[
		"s984795",
		"Dorstenia benguellensis",
		"dorstenia",
		984795
	],
	[
		"s3795186",
		"Dorstenia bergiana",
		"dorstenia",
		3795186
	],
	[
		"s3086671",
		"Dorstenia bicaudata",
		"dorstenia",
		3086671
	],
	[
		"s2604978",
		"Dorstenia bonijesu",
		"dorstenia",
		2604978
	],
	[
		"s2604979",
		"Dorstenia bowmaniana",
		"dorstenia",
		2604979
	],
	[
		"s3795187",
		"Dorstenia bowmanniana",
		"dorstenia",
		3795187
	],
	[
		"s984796",
		"Dorstenia brasiliensis",
		"dorstenia",
		984796
	],
	[
		"s3795188",
		"Dorstenia brevipetiolata",
		"dorstenia",
		3795188
	],
	[
		"s984797",
		"Dorstenia brownii",
		"dorstenia",
		984797
	],
	[
		"s2604980",
		"Dorstenia buchananii",
		"dorstenia",
		2604980
	],
	[
		"s2877898",
		"Dorstenia caatingae",
		"dorstenia",
		2877898
	],
	[
		"s2604981",
		"Dorstenia caimitensis",
		"dorstenia",
		2604981
	],
	[
		"s2877899",
		"Dorstenia capricorniana",
		"dorstenia",
		2877899
	],
	[
		"s2604982",
		"Dorstenia carautae",
		"dorstenia",
		2604982
	],
	[
		"s984798",
		"Dorstenia cayapia",
		"dorstenia",
		984798
	],
	[
		"s241877",
		"Dorstenia choconiana",
		"dorstenia",
		241877
	],
	[
		"s2984561",
		"Dorstenia christenhuszii",
		"dorstenia",
		2984561
	],
	[
		"s2604984",
		"Dorstenia ciliata",
		"dorstenia",
		2604984
	],
	[
		"s3086672",
		"Dorstenia colombiana",
		"dorstenia",
		3086672
	],
	[
		"s2877900",
		"Dorstenia conceptionis",
		"dorstenia",
		2877900
	],
	[
		"s3795189",
		"Dorstenia contensis",
		"dorstenia",
		3795189
	],
	[
		"s984801",
		"Dorstenia contrajerva",
		"dorstenia",
		984801
	],
	[
		"s3086673",
		"Dorstenia convexa",
		"dorstenia",
		3086673
	],
	[
		"s3795190",
		"Dorstenia crenulata",
		"dorstenia",
		3795190
	],
	[
		"s984802",
		"Dorstenia cuspidata",
		"dorstenia",
		984802
	],
	[
		"s2604986",
		"Dorstenia dinklagei",
		"dorstenia",
		2604986
	],
	[
		"s3795191",
		"Dorstenia dionga",
		"dorstenia",
		3795191
	],
	[
		"s984803",
		"Dorstenia djettii",
		"dorstenia",
		984803
	],
	[
		"s2604987",
		"Dorstenia dorstenioides",
		"dorstenia",
		2604987
	],
	[
		"s984804",
		"Dorstenia drakena",
		"dorstenia",
		984804
	],
	[
		"s984805",
		"Dorstenia elata",
		"dorstenia",
		984805
	],
	[
		"s2604988",
		"Dorstenia ellenbeckiana",
		"dorstenia",
		2604988
	],
	[
		"s984806",
		"Dorstenia elliptica",
		"dorstenia",
		984806
	],
	[
		"s3795192",
		"Dorstenia embergeri",
		"dorstenia",
		3795192
	],
	[
		"s2604989",
		"Dorstenia erythrandra",
		"dorstenia",
		2604989
	],
	[
		"s984807",
		"Dorstenia excentrica",
		"dorstenia",
		984807
	],
	[
		"s984808",
		"Dorstenia fawcettii",
		"dorstenia",
		984808
	],
	[
		"s2877901",
		"Dorstenia fischeri",
		"dorstenia",
		2877901
	],
	[
		"s2604990",
		"Dorstenia flagellifera",
		"dorstenia",
		2604990
	],
	[
		"s984809",
		"Dorstenia foetida",
		"dorstenia",
		984809
	],
	[
		"s3795193",
		"Dorstenia gigas",
		"dorstenia",
		3795193
	],
	[
		"s2604991",
		"Dorstenia goetzei",
		"dorstenia",
		2604991
	],
	[
		"s2877902",
		"Dorstenia gracilis",
		"dorstenia",
		2877902
	],
	[
		"s2877903",
		"Dorstenia grazielae",
		"dorstenia",
		2877903
	],
	[
		"s3795194",
		"Dorstenia gypsophila",
		"dorstenia",
		3795194
	],
	[
		"s241878",
		"Dorstenia hildebrandtii",
		"dorstenia",
		241878
	],
	[
		"s2877904",
		"Dorstenia hildegardis",
		"dorstenia",
		2877904
	],
	[
		"s984810",
		"Dorstenia hirta",
		"dorstenia",
		984810
	],
	[
		"s984811",
		"Dorstenia holstii",
		"dorstenia",
		984811
	],
	[
		"s3795195",
		"Dorstenia horwoodii",
		"dorstenia",
		3795195
	],
	[
		"s2604993",
		"Dorstenia indica",
		"dorstenia",
		2604993
	],
	[
		"s3795196",
		"Dorstenia involuta",
		"dorstenia",
		3795196
	],
	[
		"s3086674",
		"Dorstenia jamaicensis",
		"dorstenia",
		3086674
	],
	[
		"s984812",
		"Dorstenia kameruniana",
		"dorstenia",
		984812
	],
	[
		"s3795197",
		"Dorstenia lanei",
		"dorstenia",
		3795197
	],
	[
		"s3795198",
		"Dorstenia lavrani",
		"dorstenia",
		3795198
	],
	[
		"s3795199",
		"Dorstenia letestui",
		"dorstenia",
		3795199
	],
	[
		"s984813",
		"Dorstenia lindeniana",
		"dorstenia",
		984813
	],
	[
		"s2604994",
		"Dorstenia lujae",
		"dorstenia",
		2604994
	],
	[
		"s194258",
		"Dorstenia mannii",
		"dorstenia",
		194258
	],
	[
		"s2877905",
		"Dorstenia mariae",
		"dorstenia",
		2877905
	],
	[
		"s3795200",
		"Dorstenia marijan-matokii",
		"dorstenia",
		3795200
	],
	[
		"s2877906",
		"Dorstenia maris",
		"dorstenia",
		2877906
	],
	[
		"s984814",
		"Dorstenia milaneziana",
		"dorstenia",
		984814
	],
	[
		"s984815",
		"Dorstenia nummularia",
		"dorstenia",
		984815
	],
	[
		"s3795201",
		"Dorstenia nyungwensis",
		"dorstenia",
		3795201
	],
	[
		"s2604998",
		"Dorstenia oligogyna",
		"dorstenia",
		2604998
	],
	[
		"s3086675",
		"Dorstenia panamensis",
		"dorstenia",
		3086675
	],
	[
		"s3795202",
		"Dorstenia paucibracteata",
		"dorstenia",
		3795202
	],
	[
		"s3086676",
		"Dorstenia peltata",
		"dorstenia",
		3086676
	],
	[
		"s984816",
		"Dorstenia peruviana",
		"dorstenia",
		984816
	],
	[
		"s2604999",
		"Dorstenia petraea",
		"dorstenia",
		2604999
	],
	[
		"s984817",
		"Dorstenia picta",
		"dorstenia",
		984817
	],
	[
		"s2605000",
		"Dorstenia poinsettiifolia",
		"dorstenia",
		2605e3
	],
	[
		"s2605001",
		"Dorstenia prorepens",
		"dorstenia",
		2605001
	],
	[
		"s106723",
		"Dorstenia psilurus",
		"dorstenia",
		106723
	],
	[
		"s2605002",
		"Dorstenia ramosa",
		"dorstenia",
		2605002
	],
	[
		"s3795203",
		"Dorstenia renulata",
		"dorstenia",
		3795203
	],
	[
		"s3795204",
		"Dorstenia richardii",
		"dorstenia",
		3795204
	],
	[
		"s3795205",
		"Dorstenia rocana",
		"dorstenia",
		3795205
	],
	[
		"s984819",
		"Dorstenia roigii",
		"dorstenia",
		984819
	],
	[
		"s2877907",
		"Dorstenia romaniucii",
		"dorstenia",
		2877907
	],
	[
		"s2605006",
		"Dorstenia schliebenii",
		"dorstenia",
		2605006
	],
	[
		"s3795206",
		"Dorstenia setosa",
		"dorstenia",
		3795206
	],
	[
		"s3795207",
		"Dorstenia socotrana",
		"dorstenia",
		3795207
	],
	[
		"s2605007",
		"Dorstenia soerensenii",
		"dorstenia",
		2605007
	],
	[
		"s3795208",
		"Dorstenia solheidii",
		"dorstenia",
		3795208
	],
	[
		"s3795209",
		"Dorstenia stellaris",
		"dorstenia",
		3795209
	],
	[
		"s3795210",
		"Dorstenia subdentata",
		"dorstenia",
		3795210
	],
	[
		"s3795211",
		"Dorstenia subrhombiformis",
		"dorstenia",
		3795211
	],
	[
		"s2877908",
		"Dorstenia sucrei",
		"dorstenia",
		2877908
	],
	[
		"s984820",
		"Dorstenia tayloriana",
		"dorstenia",
		984820
	],
	[
		"s2605009",
		"Dorstenia tenera",
		"dorstenia",
		2605009
	],
	[
		"s3795212",
		"Dorstenia tentaculata",
		"dorstenia",
		3795212
	],
	[
		"s3795213",
		"Dorstenia tenuiradiata",
		"dorstenia",
		3795213
	],
	[
		"s2605010",
		"Dorstenia tenuis",
		"dorstenia",
		2605010
	],
	[
		"s3795214",
		"Dorstenia tessmannii",
		"dorstenia",
		3795214
	],
	[
		"s3795215",
		"Dorstenia thikaensis",
		"dorstenia",
		3795215
	],
	[
		"s3795216",
		"Dorstenia triseriata",
		"dorstenia",
		3795216
	],
	[
		"s3795217",
		"Dorstenia tuberosa",
		"dorstenia",
		3795217
	],
	[
		"s2877909",
		"Dorstenia turnerifolia",
		"dorstenia",
		2877909
	],
	[
		"s3795218",
		"Dorstenia ulugurensis",
		"dorstenia",
		3795218
	],
	[
		"s2605011",
		"Dorstenia umbricola",
		"dorstenia",
		2605011
	],
	[
		"s2605012",
		"Dorstenia urceolata",
		"dorstenia",
		2605012
	],
	[
		"s3086677",
		"Dorstenia uxpanapana",
		"dorstenia",
		3086677
	],
	[
		"s984822",
		"Dorstenia variifolia",
		"dorstenia",
		984822
	],
	[
		"s3795219",
		"Dorstenia vivipara",
		"dorstenia",
		3795219
	],
	[
		"s2605013",
		"Dorstenia warneckei",
		"dorstenia",
		2605013
	],
	[
		"s2605014",
		"Dorstenia yambuyaensis",
		"dorstenia",
		2605014
	],
	[
		"s3795220",
		"Dorstenia yangambiensis",
		"dorstenia",
		3795220
	],
	[
		"s3795221",
		"Dorstenia zambesiaca",
		"dorstenia",
		3795221
	],
	[
		"s2605015",
		"Dorstenia zanzibarica",
		"dorstenia",
		2605015
	],
	[
		"s2605016",
		"Dorstenia zenkeri",
		"dorstenia",
		2605016
	],
	[
		"s379230",
		"Droguetia ambigua",
		"droguetia",
		379230
	],
	[
		"s3086678",
		"Droguetia debilis",
		"droguetia",
		3086678
	],
	[
		"s3795509",
		"Droguetia gaudichaudiana",
		"droguetia",
		3795509
	],
	[
		"s3795510",
		"Droguetia hildebrandtii",
		"droguetia",
		3795510
	],
	[
		"s3795511",
		"Droguetia humbertii",
		"droguetia",
		3795511
	],
	[
		"s344765",
		"Droguetia iners",
		"droguetia",
		344765
	],
	[
		"s3086033",
		"Droguetia leptostachys",
		"droguetia",
		3086033
	],
	[
		"s669668",
		"Dryas ajanensis",
		"dryas",
		669668
	],
	[
		"s2071455",
		"Dryas alaskensis",
		"dryas",
		2071455
	],
	[
		"s2071456",
		"Dryas crenulata",
		"dryas",
		2071456
	],
	[
		"s48231",
		"Dryas drummondii",
		"dryas",
		48231
	],
	[
		"s1233958",
		"Dryas grandis",
		"dryas",
		1233958
	],
	[
		"s2071457",
		"Dryas hookeriana",
		"dryas",
		2071457
	],
	[
		"s669669",
		"Dryas incisa",
		"dryas",
		669669
	],
	[
		"s395290",
		"Dryas integrifolia",
		"dryas",
		395290
	],
	[
		"s1763601",
		"Dryas integrifolia x Dryas octopetala",
		"dryas",
		1763601
	],
	[
		"s57948",
		"Dryas octopetala",
		"dryas",
		57948
	],
	[
		"s2781077",
		"Dryas octopetala x Dryas alaskensis",
		"dryas",
		2781077
	],
	[
		"s2781076",
		"Dryas octopetala x Dryas integrifolia",
		"dryas",
		2781076
	],
	[
		"s3086679",
		"Dryas oxyodonta",
		"dryas",
		3086679
	],
	[
		"s669670",
		"Dryas punctata",
		"dryas",
		669670
	],
	[
		"s3737466",
		"Dryas sumneviczii",
		"dryas",
		3737466
	],
	[
		"s3086680",
		"Dryas viscosa",
		"dryas",
		3086680
	],
	[
		"s3737464",
		"Dryas x lewinii",
		"dryas",
		3737464
	],
	[
		"s57927",
		"Drymocallis arguta",
		"drymocallis",
		57927
	],
	[
		"s3795773",
		"Drymocallis arizonica",
		"drymocallis",
		3795773
	],
	[
		"s3795774",
		"Drymocallis ashlandica",
		"drymocallis",
		3795774
	],
	[
		"s3795775",
		"Drymocallis calycina",
		"drymocallis",
		3795775
	],
	[
		"s667206",
		"Drymocallis campanulata",
		"drymocallis",
		667206
	],
	[
		"s667207",
		"Drymocallis convallaria",
		"drymocallis",
		667207
	],
	[
		"s637893",
		"Drymocallis corsica",
		"drymocallis",
		637893
	],
	[
		"s3795776",
		"Drymocallis cuneifolia",
		"drymocallis",
		3795776
	],
	[
		"s3795777",
		"Drymocallis damghanensis",
		"drymocallis",
		3795777
	],
	[
		"s1819503",
		"Drymocallis deseretica",
		"drymocallis",
		1819503
	],
	[
		"s687993",
		"Drymocallis fissa",
		"drymocallis",
		687993
	],
	[
		"s3086034",
		"Drymocallis geoides",
		"drymocallis",
		3086034
	],
	[
		"s667208",
		"Drymocallis glabrata",
		"drymocallis",
		667208
	],
	[
		"s457911",
		"Drymocallis glandulosa",
		"drymocallis",
		457911
	],
	[
		"s637894",
		"Drymocallis glutinosa",
		"drymocallis",
		637894
	],
	[
		"s3795778",
		"Drymocallis halacsyana",
		"drymocallis",
		3795778
	],
	[
		"s3795779",
		"Drymocallis hansenii",
		"drymocallis",
		3795779
	],
	[
		"s667210",
		"Drymocallis lactea",
		"drymocallis",
		667210
	],
	[
		"s3795780",
		"Drymocallis longisepala",
		"drymocallis",
		3795780
	],
	[
		"s3795781",
		"Drymocallis malacophylla",
		"drymocallis",
		3795781
	],
	[
		"s3795782",
		"Drymocallis micropetala",
		"drymocallis",
		3795782
	],
	[
		"s3795783",
		"Drymocallis modocana",
		"drymocallis",
		3795783
	],
	[
		"s1433390",
		"Drymocallis poteriifolia",
		"drymocallis",
		1433390
	],
	[
		"s458139",
		"Drymocallis pseudorupestris",
		"drymocallis",
		458139
	],
	[
		"s3795784",
		"Drymocallis regisborisii",
		"drymocallis",
		3795784
	],
	[
		"s3795785",
		"Drymocallis rhomboidea",
		"drymocallis",
		3795785
	],
	[
		"s637895",
		"Drymocallis rupestris",
		"drymocallis",
		637895
	],
	[
		"s2774609",
		"Drymocallis saviczii",
		"drymocallis",
		2774609
	],
	[
		"s661364",
		"Dunnaria dunnii",
		"dunnaria",
		661364
	],
	[
		"s3796695",
		"Elaeagnus angustata",
		"elaeagnus",
		3796695
	],
	[
		"s36777",
		"Elaeagnus angustifolia",
		"elaeagnus",
		36777
	],
	[
		"s3796696",
		"Elaeagnus annamensis",
		"elaeagnus",
		3796696
	],
	[
		"s3796697",
		"Elaeagnus arakiana",
		"elaeagnus",
		3796697
	],
	[
		"s3050852",
		"Elaeagnus argyi",
		"elaeagnus",
		3050852
	],
	[
		"s3086689",
		"Elaeagnus bambusetorum",
		"elaeagnus",
		3086689
	],
	[
		"s193514",
		"Elaeagnus bockii",
		"elaeagnus",
		193514
	],
	[
		"s3796698",
		"Elaeagnus bonii",
		"elaeagnus",
		3796698
	],
	[
		"s3086690",
		"Elaeagnus calcarea",
		"elaeagnus",
		3086690
	],
	[
		"s2785306",
		"Elaeagnus caudata",
		"elaeagnus",
		2785306
	],
	[
		"s3796699",
		"Elaeagnus cinnamomifolia",
		"elaeagnus",
		3796699
	],
	[
		"s573509",
		"Elaeagnus commutata",
		"elaeagnus",
		573509
	],
	[
		"s1672629",
		"Elaeagnus conferta",
		"elaeagnus",
		1672629
	],
	[
		"s3054240",
		"Elaeagnus courtoisii",
		"elaeagnus",
		3054240
	],
	[
		"s3796700",
		"Elaeagnus darenensis",
		"elaeagnus",
		3796700
	],
	[
		"s3695121",
		"Elaeagnus delavayi",
		"elaeagnus",
		3695121
	],
	[
		"s2855402",
		"Elaeagnus difficilis",
		"elaeagnus",
		2855402
	],
	[
		"s3796701",
		"Elaeagnus elongatus",
		"elaeagnus",
		3796701
	],
	[
		"s2918401",
		"Elaeagnus epitricha",
		"elaeagnus",
		2918401
	],
	[
		"s361661",
		"Elaeagnus formosana",
		"elaeagnus",
		361661
	],
	[
		"s3086691",
		"Elaeagnus formosensis",
		"elaeagnus",
		3086691
	],
	[
		"s3796702",
		"Elaeagnus geniculata",
		"elaeagnus",
		3796702
	],
	[
		"s276777",
		"Elaeagnus glabra",
		"elaeagnus",
		276777
	],
	[
		"s1370099",
		"Elaeagnus gonyanthes",
		"elaeagnus",
		1370099
	],
	[
		"s2803492",
		"Elaeagnus grandifolia",
		"elaeagnus",
		2803492
	],
	[
		"s3086692",
		"Elaeagnus griffithii",
		"elaeagnus",
		3086692
	],
	[
		"s3796703",
		"Elaeagnus grijsii",
		"elaeagnus",
		3796703
	],
	[
		"s3086693",
		"Elaeagnus guizhouensis",
		"elaeagnus",
		3086693
	],
	[
		"s2291119",
		"Elaeagnus henryi",
		"elaeagnus",
		2291119
	],
	[
		"s3796704",
		"Elaeagnus heterophylla",
		"elaeagnus",
		3796704
	],
	[
		"s3796705",
		"Elaeagnus hunanensis",
		"elaeagnus",
		3796705
	],
	[
		"s3086694",
		"Elaeagnus indica",
		"elaeagnus",
		3086694
	],
	[
		"s3796706",
		"Elaeagnus infundibularis",
		"elaeagnus",
		3796706
	],
	[
		"s3086695",
		"Elaeagnus jiangxiensis",
		"elaeagnus",
		3086695
	],
	[
		"s3086696",
		"Elaeagnus jingdonensis",
		"elaeagnus",
		3086696
	],
	[
		"s3796707",
		"Elaeagnus kanaii",
		"elaeagnus",
		3796707
	],
	[
		"s2291120",
		"Elaeagnus lanceolata",
		"elaeagnus",
		2291120
	],
	[
		"s3086697",
		"Elaeagnus lanpingensis",
		"elaeagnus",
		3086697
	],
	[
		"s3086698",
		"Elaeagnus laosensis",
		"elaeagnus",
		3086698
	],
	[
		"s1537678",
		"Elaeagnus latifolia",
		"elaeagnus",
		1537678
	],
	[
		"s3796708",
		"Elaeagnus lipoensis",
		"elaeagnus",
		3796708
	],
	[
		"s2918428",
		"Elaeagnus liukiuensis",
		"elaeagnus",
		2918428
	],
	[
		"s3086699",
		"Elaeagnus liuzhouensis",
		"elaeagnus",
		3086699
	],
	[
		"s3796709",
		"Elaeagnus longiloba",
		"elaeagnus",
		3796709
	],
	[
		"s2184934",
		"Elaeagnus loureirii",
		"elaeagnus",
		2184934
	],
	[
		"s3796710",
		"Elaeagnus luoxiangensis",
		"elaeagnus",
		3796710
	],
	[
		"s3086701",
		"Elaeagnus luxiensis",
		"elaeagnus",
		3086701
	],
	[
		"s652976",
		"Elaeagnus macrantha",
		"elaeagnus",
		652976
	],
	[
		"s796727",
		"Elaeagnus macrophylla",
		"elaeagnus",
		796727
	],
	[
		"s3045819",
		"Elaeagnus macrophylla x Elaeagnus pungens",
		"elaeagnus",
		3045819
	],
	[
		"s3086043",
		"Elaeagnus magna",
		"elaeagnus",
		3086043
	],
	[
		"s2826880",
		"Elaeagnus matsunoana",
		"elaeagnus",
		2826880
	],
	[
		"s3796711",
		"Elaeagnus maximowiczii",
		"elaeagnus",
		3796711
	],
	[
		"s3796712",
		"Elaeagnus micrantha",
		"elaeagnus",
		3796712
	],
	[
		"s1642857",
		"Elaeagnus mollis",
		"elaeagnus",
		1642857
	],
	[
		"s2819801",
		"Elaeagnus montana",
		"elaeagnus",
		2819801
	],
	[
		"s427841",
		"Elaeagnus moorcroftii",
		"elaeagnus",
		427841
	],
	[
		"s3086702",
		"Elaeagnus morrisonensis",
		"elaeagnus",
		3086702
	],
	[
		"s99570",
		"Elaeagnus multiflora",
		"elaeagnus",
		99570
	],
	[
		"s3796713",
		"Elaeagnus murakamiana",
		"elaeagnus",
		3796713
	],
	[
		"s3086703",
		"Elaeagnus nanchuanensis",
		"elaeagnus",
		3086703
	],
	[
		"s3796714",
		"Elaeagnus numajiriana",
		"elaeagnus",
		3796714
	],
	[
		"s3086704",
		"Elaeagnus obovatifolia",
		"elaeagnus",
		3086704
	],
	[
		"s3086705",
		"Elaeagnus obtusa",
		"elaeagnus",
		3086705
	],
	[
		"s669305",
		"Elaeagnus oldhamii",
		"elaeagnus",
		669305
	],
	[
		"s3796715",
		"Elaeagnus ovata",
		"elaeagnus",
		3796715
	],
	[
		"s1136770",
		"Elaeagnus oxycarpa",
		"elaeagnus",
		1136770
	],
	[
		"s3086706",
		"Elaeagnus pallidiflora",
		"elaeagnus",
		3086706
	],
	[
		"s3086707",
		"Elaeagnus parvifolia",
		"elaeagnus",
		3086707
	],
	[
		"s3086708",
		"Elaeagnus pilostyla",
		"elaeagnus",
		3086708
	],
	[
		"s3796716",
		"Elaeagnus pingnanensis",
		"elaeagnus",
		3796716
	],
	[
		"s693372",
		"Elaeagnus pungens",
		"elaeagnus",
		693372
	],
	[
		"s3796717",
		"Elaeagnus pyriformis",
		"elaeagnus",
		3796717
	],
	[
		"s3796718",
		"Elaeagnus retrostyla",
		"elaeagnus",
		3796718
	],
	[
		"s3796719",
		"Elaeagnus rivularis",
		"elaeagnus",
		3796719
	],
	[
		"s1322076",
		"Elaeagnus rotundata",
		"elaeagnus",
		1322076
	],
	[
		"s3796720",
		"Elaeagnus s-stylata",
		"elaeagnus",
		3796720
	],
	[
		"s2613335",
		"Elaeagnus sarmentosa",
		"elaeagnus",
		2613335
	],
	[
		"s3086709",
		"Elaeagnus schlechtendalii",
		"elaeagnus",
		3086709
	],
	[
		"s3086710",
		"Elaeagnus stellipila",
		"elaeagnus",
		3086710
	],
	[
		"s3796721",
		"Elaeagnus taliensis",
		"elaeagnus",
		3796721
	],
	[
		"s2803493",
		"Elaeagnus tarokoensis",
		"elaeagnus",
		2803493
	],
	[
		"s1262439",
		"Elaeagnus thunbergii",
		"elaeagnus",
		1262439
	],
	[
		"s3796722",
		"Elaeagnus tonkinensis",
		"elaeagnus",
		3796722
	],
	[
		"s3796723",
		"Elaeagnus tricholepis",
		"elaeagnus",
		3796723
	],
	[
		"s1382055",
		"Elaeagnus triflora",
		"elaeagnus",
		1382055
	],
	[
		"s3086711",
		"Elaeagnus tubiflora",
		"elaeagnus",
		3086711
	],
	[
		"s3086712",
		"Elaeagnus tutcheri",
		"elaeagnus",
		3086712
	],
	[
		"s43233",
		"Elaeagnus umbellata",
		"elaeagnus",
		43233
	],
	[
		"s3086713",
		"Elaeagnus viridis",
		"elaeagnus",
		3086713
	],
	[
		"s3086714",
		"Elaeagnus wenshanensis",
		"elaeagnus",
		3086714
	],
	[
		"s3086715",
		"Elaeagnus wushanensis",
		"elaeagnus",
		3086715
	],
	[
		"s1161920",
		"Elaeagnus x maritima",
		"elaeagnus",
		1161920
	],
	[
		"s3086969",
		"Elaeagnus x reflexa",
		"elaeagnus",
		3086969
	],
	[
		"s1161921",
		"Elaeagnus x submacrophylla",
		"elaeagnus",
		1161921
	],
	[
		"s3086716",
		"Elaeagnus xichouensis",
		"elaeagnus",
		3086716
	],
	[
		"s3796724",
		"Elaeagnus xingwenensis",
		"elaeagnus",
		3796724
	],
	[
		"s3796725",
		"Elaeagnus xizangensis",
		"elaeagnus",
		3796725
	],
	[
		"s2918429",
		"Elaeagnus yakusimensis",
		"elaeagnus",
		2918429
	],
	[
		"s2902192",
		"Elaeagnus yoshinoi",
		"elaeagnus",
		2902192
	],
	[
		"s3796726",
		"Elaeagnus yunnanensis",
		"elaeagnus",
		3796726
	],
	[
		"s3797099",
		"Elatostema abangense",
		"elatostema",
		3797099
	],
	[
		"s3797100",
		"Elatostema acrophilum",
		"elatostema",
		3797100
	],
	[
		"s3797101",
		"Elatostema actinodromum",
		"elatostema",
		3797101
	],
	[
		"s3797102",
		"Elatostema actinotrichum",
		"elatostema",
		3797102
	],
	[
		"s3797103",
		"Elatostema acuminatissimum",
		"elatostema",
		3797103
	],
	[
		"s226090",
		"Elatostema acuminatum",
		"elatostema",
		226090
	],
	[
		"s1661585",
		"Elatostema acuteserratum",
		"elatostema",
		1661585
	],
	[
		"s3237176",
		"Elatostema acutidentatum",
		"elatostema",
		3237176
	],
	[
		"s3797104",
		"Elatostema acutitepalum",
		"elatostema",
		3797104
	],
	[
		"s3797105",
		"Elatostema adenophorum",
		"elatostema",
		3797105
	],
	[
		"s226288",
		"Elatostema aff. strigosum Hadiah 178",
		"elatostema",
		226288
	],
	[
		"s226286",
		"Elatostema aff. velutinicaule Hadiah 183",
		"elatostema",
		226286
	],
	[
		"s3797106",
		"Elatostema agasthyanum",
		"elatostema",
		3797106
	],
	[
		"s3797107",
		"Elatostema agusanense",
		"elatostema",
		3797107
	],
	[
		"s3797108",
		"Elatostema albistipulum",
		"elatostema",
		3797108
	],
	[
		"s1785611",
		"Elatostema albopilosoides",
		"elatostema",
		1785611
	],
	[
		"s1399674",
		"Elatostema albopilosum",
		"elatostema",
		1399674
	],
	[
		"s3797109",
		"Elatostema albovillosum",
		"elatostema",
		3797109
	],
	[
		"s3797110",
		"Elatostema aliferum",
		"elatostema",
		3797110
	],
	[
		"s3797111",
		"Elatostema alnifolium",
		"elatostema",
		3797111
	],
	[
		"s3797112",
		"Elatostema ambiguum",
		"elatostema",
		3797112
	],
	[
		"s3797113",
		"Elatostema amoenum",
		"elatostema",
		3797113
	],
	[
		"s1785612",
		"Elatostema androstachyum",
		"elatostema",
		1785612
	],
	[
		"s3797114",
		"Elatostema angulare",
		"elatostema",
		3797114
	],
	[
		"s3797115",
		"Elatostema angulaticaule",
		"elatostema",
		3797115
	],
	[
		"s3797116",
		"Elatostema angulosum",
		"elatostema",
		3797116
	],
	[
		"s3797117",
		"Elatostema angustatum",
		"elatostema",
		3797117
	],
	[
		"s3797118",
		"Elatostema angustibracteum",
		"elatostema",
		3797118
	],
	[
		"s3797119",
		"Elatostema angustitepalum",
		"elatostema",
		3797119
	],
	[
		"s3797120",
		"Elatostema anlongense",
		"elatostema",
		3797120
	],
	[
		"s3797121",
		"Elatostema annulatum",
		"elatostema",
		3797121
	],
	[
		"s3797122",
		"Elatostema antonii",
		"elatostema",
		3797122
	],
	[
		"s3797123",
		"Elatostema apicicrassum",
		"elatostema",
		3797123
	],
	[
		"s3797124",
		"Elatostema apoense",
		"elatostema",
		3797124
	],
	[
		"s3797125",
		"Elatostema appendiculatum",
		"elatostema",
		3797125
	],
	[
		"s3797126",
		"Elatostema arcuans",
		"elatostema",
		3797126
	],
	[
		"s3797127",
		"Elatostema arcuatipes",
		"elatostema",
		3797127
	],
	[
		"s3797128",
		"Elatostema arcuatobracteatum",
		"elatostema",
		3797128
	],
	[
		"s3797129",
		"Elatostema articulatum",
		"elatostema",
		3797129
	],
	[
		"s1785613",
		"Elatostema asterocephalum",
		"elatostema",
		1785613
	],
	[
		"s1399675",
		"Elatostema atropurpureum",
		"elatostema",
		1399675
	],
	[
		"s3797130",
		"Elatostema atrostriatum",
		"elatostema",
		3797130
	],
	[
		"s3086718",
		"Elatostema atroviride",
		"elatostema",
		3086718
	],
	[
		"s3797131",
		"Elatostema attenuatoides",
		"elatostema",
		3797131
	],
	[
		"s3797132",
		"Elatostema attenuatum",
		"elatostema",
		3797132
	],
	[
		"s3797133",
		"Elatostema auriculatifolium",
		"elatostema",
		3797133
	],
	[
		"s3086719",
		"Elatostema auriculatum",
		"elatostema",
		3086719
	],
	[
		"s1785614",
		"Elatostema australe",
		"elatostema",
		1785614
	],
	[
		"s3237177",
		"Elatostema austrosinense",
		"elatostema",
		3237177
	],
	[
		"s3797134",
		"Elatostema austroyunnanense",
		"elatostema",
		3797134
	],
	[
		"s3797135",
		"Elatostema backanense",
		"elatostema",
		3797135
	],
	[
		"s647267",
		"Elatostema backeri",
		"elatostema",
		647267
	],
	[
		"s3086720",
		"Elatostema baiseense",
		"elatostema",
		3086720
	],
	[
		"s1785615",
		"Elatostema balansae",
		"elatostema",
		1785615
	],
	[
		"s3797136",
		"Elatostema bamaense",
		"elatostema",
		3797136
	],
	[
		"s1785616",
		"Elatostema banahaense",
		"elatostema",
		1785616
	],
	[
		"s3797137",
		"Elatostema baoshanense",
		"elatostema",
		3797137
	],
	[
		"s3797138",
		"Elatostema barbarufa",
		"elatostema",
		3797138
	],
	[
		"s3797139",
		"Elatostema barbatum",
		"elatostema",
		3797139
	],
	[
		"s3797140",
		"Elatostema baruringense",
		"elatostema",
		3797140
	],
	[
		"s3797141",
		"Elatostema basiandrum",
		"elatostema",
		3797141
	],
	[
		"s3086721",
		"Elatostema beccarii",
		"elatostema",
		3086721
	],
	[
		"s3797142",
		"Elatostema beibengense",
		"elatostema",
		3797142
	],
	[
		"s3797143",
		"Elatostema belense",
		"elatostema",
		3797143
	],
	[
		"s3086722",
		"Elatostema benguetense",
		"elatostema",
		3086722
	],
	[
		"s3797144",
		"Elatostema bidiense",
		"elatostema",
		3797144
	],
	[
		"s3797145",
		"Elatostema biformibracteolatum",
		"elatostema",
		3797145
	],
	[
		"s3797146",
		"Elatostema biglomeratum",
		"elatostema",
		3797146
	],
	[
		"s1785617",
		"Elatostema binatum",
		"elatostema",
		1785617
	],
	[
		"s3797147",
		"Elatostema binerve",
		"elatostema",
		3797147
	],
	[
		"s3797148",
		"Elatostema bioppositum",
		"elatostema",
		3797148
	],
	[
		"s3797149",
		"Elatostema blechnoides",
		"elatostema",
		3797149
	],
	[
		"s3797150",
		"Elatostema boehmerioides",
		"elatostema",
		3797150
	],
	[
		"s3797151",
		"Elatostema boholense",
		"elatostema",
		3797151
	],
	[
		"s3797152",
		"Elatostema bojongense",
		"elatostema",
		3797152
	],
	[
		"s3797153",
		"Elatostema bomiense",
		"elatostema",
		3797153
	],
	[
		"s3797154",
		"Elatostema bontocense",
		"elatostema",
		3797154
	],
	[
		"s3797155",
		"Elatostema borneense",
		"elatostema",
		3797155
	],
	[
		"s1785618",
		"Elatostema brachyodontum",
		"elatostema",
		1785618
	],
	[
		"s3797156",
		"Elatostema brachyurum",
		"elatostema",
		3797156
	],
	[
		"s3797157",
		"Elatostema bracteosum",
		"elatostema",
		3797157
	],
	[
		"s3797158",
		"Elatostema breviacuminatum",
		"elatostema",
		3797158
	],
	[
		"s3797159",
		"Elatostema brevicaudatum",
		"elatostema",
		3797159
	],
	[
		"s3132613",
		"Elatostema brevifolium",
		"elatostema",
		3132613
	],
	[
		"s3086723",
		"Elatostema brevipedunculatum",
		"elatostema",
		3086723
	],
	[
		"s3086724",
		"Elatostema brongniartianum",
		"elatostema",
		3086724
	],
	[
		"s3797160",
		"Elatostema brunneinerve",
		"elatostema",
		3797160
	],
	[
		"s3797161",
		"Elatostema brunneobracteolatum",
		"elatostema",
		3797161
	],
	[
		"s3797162",
		"Elatostema brunneolum",
		"elatostema",
		3797162
	],
	[
		"s3797163",
		"Elatostema brunneostriolatum",
		"elatostema",
		3797163
	],
	[
		"s3797164",
		"Elatostema brunonianum",
		"elatostema",
		3797164
	],
	[
		"s3797165",
		"Elatostema bulbiferum",
		"elatostema",
		3797165
	],
	[
		"s3797166",
		"Elatostema bulbothrix",
		"elatostema",
		3797166
	],
	[
		"s3086725",
		"Elatostema bullatum",
		"elatostema",
		3086725
	],
	[
		"s3797167",
		"Elatostema bulusanense",
		"elatostema",
		3797167
	],
	[
		"s3797168",
		"Elatostema burmanicum",
		"elatostema",
		3797168
	],
	[
		"s1785619",
		"Elatostema calcareum",
		"elatostema",
		1785619
	],
	[
		"s3797169",
		"Elatostema calophyllum",
		"elatostema",
		3797169
	],
	[
		"s3797170",
		"Elatostema capizense",
		"elatostema",
		3797170
	],
	[
		"s3797171",
		"Elatostema catanduanense",
		"elatostema",
		3797171
	],
	[
		"s3797172",
		"Elatostema cataractum",
		"elatostema",
		3797172
	],
	[
		"s3797173",
		"Elatostema caudatoacuminatum",
		"elatostema",
		3797173
	],
	[
		"s3797174",
		"Elatostema caudatum",
		"elatostema",
		3797174
	],
	[
		"s3797175",
		"Elatostema caudiculatum",
		"elatostema",
		3797175
	],
	[
		"s3797176",
		"Elatostema caudifolium",
		"elatostema",
		3797176
	],
	[
		"s3237175",
		"Elatostema caulialatum",
		"elatostema",
		3237175
	],
	[
		"s3797177",
		"Elatostema cauliflorum",
		"elatostema",
		3797177
	],
	[
		"s3797178",
		"Elatostema celaticaule",
		"elatostema",
		3797178
	],
	[
		"s3797179",
		"Elatostema celingense",
		"elatostema",
		3797179
	],
	[
		"s226287",
		"Elatostema cf. rostratum Hadiah 141",
		"elatostema",
		226287
	],
	[
		"s3797180",
		"Elatostema chapaense",
		"elatostema",
		3797180
	],
	[
		"s3797181",
		"Elatostema cheirophyllum",
		"elatostema",
		3797181
	],
	[
		"s3797182",
		"Elatostema chiwuanum",
		"elatostema",
		3797182
	],
	[
		"s3797183",
		"Elatostema cikaiense",
		"elatostema",
		3797183
	],
	[
		"s3797184",
		"Elatostema ciliatum",
		"elatostema",
		3797184
	],
	[
		"s3797185",
		"Elatostema clarkei",
		"elatostema",
		3797185
	],
	[
		"s3797186",
		"Elatostema clemensii",
		"elatostema",
		3797186
	],
	[
		"s3797187",
		"Elatostema cochinchinense",
		"elatostema",
		3797187
	],
	[
		"s3797188",
		"Elatostema comptonioides",
		"elatostema",
		3797188
	],
	[
		"s2747788",
		"Elatostema conduplicatum",
		"elatostema",
		2747788
	],
	[
		"s3797189",
		"Elatostema contiguum",
		"elatostema",
		3797189
	],
	[
		"s2747789",
		"Elatostema coriaceifolium",
		"elatostema",
		2747789
	],
	[
		"s3797190",
		"Elatostema cornutum",
		"elatostema",
		3797190
	],
	[
		"s3797191",
		"Elatostema costatoalatum",
		"elatostema",
		3797191
	],
	[
		"s3797192",
		"Elatostema crassicostatum",
		"elatostema",
		3797192
	],
	[
		"s3797193",
		"Elatostema crassimucronatum",
		"elatostema",
		3797193
	],
	[
		"s2306672",
		"Elatostema crassiusculum",
		"elatostema",
		2306672
	],
	[
		"s3797194",
		"Elatostema crenatum",
		"elatostema",
		3797194
	],
	[
		"s3797195",
		"Elatostema crispulihirtellum",
		"elatostema",
		3797195
	],
	[
		"s3797196",
		"Elatostema crispulum",
		"elatostema",
		3797196
	],
	[
		"s3797197",
		"Elatostema cucullatonaviculare",
		"elatostema",
		3797197
	],
	[
		"s3797198",
		"Elatostema cuipingfengense",
		"elatostema",
		3797198
	],
	[
		"s3797199",
		"Elatostema cultratum",
		"elatostema",
		3797199
	],
	[
		"s2306673",
		"Elatostema cuneatum",
		"elatostema",
		2306673
	],
	[
		"s3797200",
		"Elatostema cuneiforme",
		"elatostema",
		3797200
	],
	[
		"s3797201",
		"Elatostema cupreoviride",
		"elatostema",
		3797201
	],
	[
		"s3797202",
		"Elatostema cupulare",
		"elatostema",
		3797202
	],
	[
		"s3797203",
		"Elatostema curvitepalum",
		"elatostema",
		3797203
	],
	[
		"s1399677",
		"Elatostema cuspidatum",
		"elatostema",
		1399677
	],
	[
		"s3797204",
		"Elatostema cyrtandra",
		"elatostema",
		3797204
	],
	[
		"s3797205",
		"Elatostema cyrtandrifolioides",
		"elatostema",
		3797205
	],
	[
		"s1399676",
		"Elatostema cyrtandrifolium",
		"elatostema",
		1399676
	],
	[
		"s3797206",
		"Elatostema cyrtophyllum",
		"elatostema",
		3797206
	],
	[
		"s3797207",
		"Elatostema dactylocephalum",
		"elatostema",
		3797207
	],
	[
		"s3797208",
		"Elatostema dallasense",
		"elatostema",
		3797208
	],
	[
		"s3797209",
		"Elatostema daxinense",
		"elatostema",
		3797209
	],
	[
		"s3797210",
		"Elatostema decipiens",
		"elatostema",
		3797210
	],
	[
		"s3086726",
		"Elatostema delicatum",
		"elatostema",
		3086726
	],
	[
		"s1399679",
		"Elatostema densistriolatum",
		"elatostema",
		1399679
	],
	[
		"s3797211",
		"Elatostema dentatocaudatum",
		"elatostema",
		3797211
	],
	[
		"s3797212",
		"Elatostema didymocephalum",
		"elatostema",
		3797212
	],
	[
		"s3797213",
		"Elatostema dielsii",
		"elatostema",
		3797213
	],
	[
		"s3797214",
		"Elatostema discolor",
		"elatostema",
		3797214
	],
	[
		"s3797215",
		"Elatostema dissectoides",
		"elatostema",
		3797215
	],
	[
		"s1785620",
		"Elatostema dissectum",
		"elatostema",
		1785620
	],
	[
		"s3797216",
		"Elatostema divaricatum",
		"elatostema",
		3797216
	],
	[
		"s3797217",
		"Elatostema diversilimbum",
		"elatostema",
		3797217
	],
	[
		"s3797218",
		"Elatostema doormanianum",
		"elatostema",
		3797218
	],
	[
		"s3797219",
		"Elatostema drepanophyllum",
		"elatostema",
		3797219
	],
	[
		"s3797220",
		"Elatostema dulongense",
		"elatostema",
		3797220
	],
	[
		"s3797221",
		"Elatostema duyunense",
		"elatostema",
		3797221
	],
	[
		"s3797222",
		"Elatostema eberhardtii",
		"elatostema",
		3797222
	],
	[
		"s3797223",
		"Elatostema edanoii",
		"elatostema",
		3797223
	],
	[
		"s1661586",
		"Elatostema edule",
		"elatostema",
		1661586
	],
	[
		"s3797224",
		"Elatostema elegans",
		"elatostema",
		3797224
	],
	[
		"s1785621",
		"Elatostema ellipticum",
		"elatostema",
		1785621
	],
	[
		"s3797225",
		"Elatostema elmeri",
		"elatostema",
		3797225
	],
	[
		"s3797226",
		"Elatostema elongatobracteolatum",
		"elatostema",
		3797226
	],
	[
		"s3797227",
		"Elatostema elongatopeduncellatum",
		"elatostema",
		3797227
	],
	[
		"s3797228",
		"Elatostema eludens",
		"elatostema",
		3797228
	],
	[
		"s3797229",
		"Elatostema epallocaulum",
		"elatostema",
		3797229
	],
	[
		"s3797230",
		"Elatostema erectum",
		"elatostema",
		3797230
	],
	[
		"s3086727",
		"Elatostema eriocephalum",
		"elatostema",
		3086727
	],
	[
		"s3797231",
		"Elatostema euphlebium",
		"elatostema",
		3797231
	],
	[
		"s3797232",
		"Elatostema eurhynchum",
		"elatostema",
		3797232
	],
	[
		"s3797233",
		"Elatostema fagifolium",
		"elatostema",
		3797233
	],
	[
		"s3797234",
		"Elatostema feddeanum",
		"elatostema",
		3797234
	],
	[
		"s3797235",
		"Elatostema femineocymosum",
		"elatostema",
		3797235
	],
	[
		"s1785622",
		"Elatostema fengshanense",
		"elatostema",
		1785622
	],
	[
		"s3797236",
		"Elatostema fenkolense",
		"elatostema",
		3797236
	],
	[
		"s3797237",
		"Elatostema ferrugineum",
		"elatostema",
		3797237
	],
	[
		"s1586304",
		"Elatostema ficoides",
		"elatostema",
		1586304
	],
	[
		"s3797238",
		"Elatostema filicinum",
		"elatostema",
		3797238
	],
	[
		"s3797239",
		"Elatostema filipes",
		"elatostema",
		3797239
	],
	[
		"s3797240",
		"Elatostema finisterrae",
		"elatostema",
		3797240
	],
	[
		"s3797241",
		"Elatostema flavovirens",
		"elatostema",
		3797241
	],
	[
		"s3797242",
		"Elatostema flexuosicaule",
		"elatostema",
		3797242
	],
	[
		"s3086728",
		"Elatostema flumineorupestre",
		"elatostema",
		3086728
	],
	[
		"s3797243",
		"Elatostema fragile",
		"elatostema",
		3797243
	],
	[
		"s1785623",
		"Elatostema fruticosum",
		"elatostema",
		1785623
	],
	[
		"s3797244",
		"Elatostema fugongense",
		"elatostema",
		3797244
	],
	[
		"s3797245",
		"Elatostema fulvobracteolatum",
		"elatostema",
		3797245
	],
	[
		"s3797246",
		"Elatostema funingense",
		"elatostema",
		3797246
	],
	[
		"s3797247",
		"Elatostema furcatibracteum",
		"elatostema",
		3797247
	],
	[
		"s3797248",
		"Elatostema furcatiramosum",
		"elatostema",
		3797248
	],
	[
		"s1661587",
		"Elatostema garrettii",
		"elatostema",
		1661587
	],
	[
		"s3085923",
		"Elatostema gibbsiae",
		"elatostema",
		3085923
	],
	[
		"s3797249",
		"Elatostema gigantifolianum",
		"elatostema",
		3797249
	],
	[
		"s3797250",
		"Elatostema gillespiei",
		"elatostema",
		3797250
	],
	[
		"s3797251",
		"Elatostema gitingense",
		"elatostema",
		3797251
	],
	[
		"s3797252",
		"Elatostema glaberrimum",
		"elatostema",
		3797252
	],
	[
		"s3797253",
		"Elatostema glabratum",
		"elatostema",
		3797253
	],
	[
		"s3797254",
		"Elatostema glabribracteum",
		"elatostema",
		3797254
	],
	[
		"s3797255",
		"Elatostema glanduliferum",
		"elatostema",
		3797255
	],
	[
		"s3797256",
		"Elatostema glaucescens",
		"elatostema",
		3797256
	],
	[
		"s3797257",
		"Elatostema globosostigmatum",
		"elatostema",
		3797257
	],
	[
		"s3797258",
		"Elatostema glomeratum",
		"elatostema",
		3797258
	],
	[
		"s3797259",
		"Elatostema goniocephalum",
		"elatostema",
		3797259
	],
	[
		"s1785624",
		"Elatostema goudotianum",
		"elatostema",
		1785624
	],
	[
		"s3797260",
		"Elatostema gracile",
		"elatostema",
		3797260
	],
	[
		"s3797261",
		"Elatostema gracilifolium",
		"elatostema",
		3797261
	],
	[
		"s1785625",
		"Elatostema gracilipes",
		"elatostema",
		1785625
	],
	[
		"s3797262",
		"Elatostema graeffei",
		"elatostema",
		3797262
	],
	[
		"s3797263",
		"Elatostema grammicum",
		"elatostema",
		3797263
	],
	[
		"s647268",
		"Elatostema grande",
		"elatostema",
		647268
	],
	[
		"s1785626",
		"Elatostema grandidentatum",
		"elatostema",
		1785626
	],
	[
		"s1785627",
		"Elatostema grandifolium",
		"elatostema",
		1785627
	],
	[
		"s3797264",
		"Elatostema greenwoodii",
		"elatostema",
		3797264
	],
	[
		"s3797265",
		"Elatostema griffithii",
		"elatostema",
		3797265
	],
	[
		"s3237174",
		"Elatostema grijsii",
		"elatostema",
		3237174
	],
	[
		"s3090537",
		"Elatostema guangxiense",
		"elatostema",
		3090537
	],
	[
		"s3797266",
		"Elatostema guanwuense",
		"elatostema",
		3797266
	],
	[
		"s3797267",
		"Elatostema gueilinense",
		"elatostema",
		3797267
	],
	[
		"s3086729",
		"Elatostema gungshanense",
		"elatostema",
		3086729
	],
	[
		"s1785628",
		"Elatostema gyrocephalum",
		"elatostema",
		1785628
	],
	[
		"s3797268",
		"Elatostema gyronanophyllum",
		"elatostema",
		3797268
	],
	[
		"s3797269",
		"Elatostema halconense",
		"elatostema",
		3797269
	],
	[
		"s3797270",
		"Elatostema hallieri",
		"elatostema",
		3797270
	],
	[
		"s3797271",
		"Elatostema halophyllum",
		"elatostema",
		3797271
	],
	[
		"s3797272",
		"Elatostema hanseatum",
		"elatostema",
		3797272
	],
	[
		"s3797273",
		"Elatostema hastatum",
		"elatostema",
		3797273
	],
	[
		"s1785630",
		"Elatostema hechiense",
		"elatostema",
		1785630
	],
	[
		"s3797274",
		"Elatostema hekouense",
		"elatostema",
		3797274
	],
	[
		"s3797275",
		"Elatostema heterocladum",
		"elatostema",
		3797275
	],
	[
		"s3797276",
		"Elatostema heterogrammicum",
		"elatostema",
		3797276
	],
	[
		"s2747790",
		"Elatostema heterolobum",
		"elatostema",
		2747790
	],
	[
		"s3797277",
		"Elatostema heterophyllum",
		"elatostema",
		3797277
	],
	[
		"s3090341",
		"Elatostema heyneanum",
		"elatostema",
		3090341
	],
	[
		"s1785631",
		"Elatostema hezhouense",
		"elatostema",
		1785631
	],
	[
		"s3797278",
		"Elatostema himantophyllum",
		"elatostema",
		3797278
	],
	[
		"s3797279",
		"Elatostema hirsutum",
		"elatostema",
		3797279
	],
	[
		"s1661588",
		"Elatostema hirtellipedunculatum",
		"elatostema",
		1661588
	],
	[
		"s3797280",
		"Elatostema hirtellum",
		"elatostema",
		3797280
	],
	[
		"s3797281",
		"Elatostema hoelscherianum",
		"elatostema",
		3797281
	],
	[
		"s3797282",
		"Elatostema hoffmannianum",
		"elatostema",
		3797282
	],
	[
		"s1785632",
		"Elatostema hookerianum",
		"elatostema",
		1785632
	],
	[
		"s3797283",
		"Elatostema huanglianshanicum",
		"elatostema",
		3797283
	],
	[
		"s1785633",
		"Elatostema huanjiangense",
		"elatostema",
		1785633
	],
	[
		"s3797284",
		"Elatostema humblotii",
		"elatostema",
		3797284
	],
	[
		"s1355407",
		"Elatostema hybrid cultivar",
		"elatostema",
		1355407
	],
	[
		"s3797285",
		"Elatostema hygrophilifolium",
		"elatostema",
		3797285
	],
	[
		"s3797286",
		"Elatostema hymenophyllum",
		"elatostema",
		3797286
	],
	[
		"s1661589",
		"Elatostema hypoglaucum",
		"elatostema",
		1661589
	],
	[
		"s3086731",
		"Elatostema ichangense",
		"elatostema",
		3086731
	],
	[
		"s3086732",
		"Elatostema imbricans",
		"elatostema",
		3086732
	],
	[
		"s3797287",
		"Elatostema inaequifolium",
		"elatostema",
		3797287
	],
	[
		"s3797288",
		"Elatostema inaequilobum",
		"elatostema",
		3797288
	],
	[
		"s3797289",
		"Elatostema incisoserratum",
		"elatostema",
		3797289
	],
	[
		"s1785634",
		"Elatostema incisum",
		"elatostema",
		1785634
	],
	[
		"s3797290",
		"Elatostema inconstans",
		"elatostema",
		3797290
	],
	[
		"s1661590",
		"Elatostema insulare",
		"elatostema",
		1661590
	],
	[
		"s3797291",
		"Elatostema intanondense",
		"elatostema",
		3797291
	],
	[
		"s1785635",
		"Elatostema integrifolium",
		"elatostema",
		1785635
	],
	[
		"s1785636",
		"Elatostema involucratum",
		"elatostema",
		1785636
	],
	[
		"s3797292",
		"Elatostema iridense",
		"elatostema",
		3797292
	],
	[
		"s3797293",
		"Elatostema janowskyi",
		"elatostema",
		3797293
	],
	[
		"s1785637",
		"Elatostema japonicum",
		"elatostema",
		1785637
	],
	[
		"s3797294",
		"Elatostema jiangjinense",
		"elatostema",
		3797294
	],
	[
		"s3797295",
		"Elatostema jianshanicum",
		"elatostema",
		3797295
	],
	[
		"s3797296",
		"Elatostema jingxiense",
		"elatostema",
		3797296
	],
	[
		"s3797297",
		"Elatostema jinpingense",
		"elatostema",
		3797297
	],
	[
		"s3797298",
		"Elatostema junghuhnianum",
		"elatostema",
		3797298
	],
	[
		"s3086733",
		"Elatostema kabayense",
		"elatostema",
		3086733
	],
	[
		"s3797299",
		"Elatostema kachiense",
		"elatostema",
		3797299
	],
	[
		"s3797300",
		"Elatostema kalingaense",
		"elatostema",
		3797300
	],
	[
		"s3797301",
		"Elatostema kaweesakii",
		"elatostema",
		3797301
	],
	[
		"s3797302",
		"Elatostema kesselii",
		"elatostema",
		3797302
	],
	[
		"s3797303",
		"Elatostema kietanum",
		"elatostema",
		3797303
	],
	[
		"s3797304",
		"Elatostema kimhyense",
		"elatostema",
		3797304
	],
	[
		"s3797305",
		"Elatostema kinabaluense",
		"elatostema",
		3797305
	],
	[
		"s1785638",
		"Elatostema kraemeri",
		"elatostema",
		1785638
	],
	[
		"s3797306",
		"Elatostema krauseanum",
		"elatostema",
		3797306
	],
	[
		"s3797307",
		"Elatostema kuchingense",
		"elatostema",
		3797307
	],
	[
		"s3797308",
		"Elatostema kupeiense",
		"elatostema",
		3797308
	],
	[
		"s3086734",
		"Elatostema kusaiense",
		"elatostema",
		3086734
	],
	[
		"s3797309",
		"Elatostema laciniatum",
		"elatostema",
		3797309
	],
	[
		"s1785639",
		"Elatostema laetevirens",
		"elatostema",
		1785639
	],
	[
		"s3797310",
		"Elatostema laevicaule",
		"elatostema",
		3797310
	],
	[
		"s1785640",
		"Elatostema laevissimum",
		"elatostema",
		1785640
	],
	[
		"s3797311",
		"Elatostema lagunense",
		"elatostema",
		3797311
	],
	[
		"s3797312",
		"Elatostema lalashanense",
		"elatostema",
		3797312
	],
	[
		"s3797313",
		"Elatostema lanaense",
		"elatostema",
		3797313
	],
	[
		"s3797314",
		"Elatostema lanceolatum",
		"elatostema",
		3797314
	],
	[
		"s3797315",
		"Elatostema lancifolium",
		"elatostema",
		3797315
	],
	[
		"s3797316",
		"Elatostema lasiocephalum",
		"elatostema",
		3797316
	],
	[
		"s3797317",
		"Elatostema lasioneurum",
		"elatostema",
		3797317
	],
	[
		"s3089777",
		"Elatostema latifolium",
		"elatostema",
		3089777
	],
	[
		"s3797318",
		"Elatostema latistipulum",
		"elatostema",
		3797318
	],
	[
		"s3797319",
		"Elatostema latitepalum",
		"elatostema",
		3797319
	],
	[
		"s3797320",
		"Elatostema lauterbachii",
		"elatostema",
		3797320
	],
	[
		"s3797321",
		"Elatostema laxicymosum",
		"elatostema",
		3797321
	],
	[
		"s3797322",
		"Elatostema laxiflorum",
		"elatostema",
		3797322
	],
	[
		"s3797323",
		"Elatostema laxisericeum",
		"elatostema",
		3797323
	],
	[
		"s3797324",
		"Elatostema ledermannii",
		"elatostema",
		3797324
	],
	[
		"s3089620",
		"Elatostema leiocarpum",
		"elatostema",
		3089620
	],
	[
		"s3797325",
		"Elatostema lepidotulum",
		"elatostema",
		3797325
	],
	[
		"s3797326",
		"Elatostema leucocephalum",
		"elatostema",
		3797326
	],
	[
		"s3797327",
		"Elatostema liboense",
		"elatostema",
		3797327
	],
	[
		"s3797328",
		"Elatostema lignescens",
		"elatostema",
		3797328
	],
	[
		"s3797329",
		"Elatostema lignosum",
		"elatostema",
		3797329
	],
	[
		"s3086735",
		"Elatostema lihengianum",
		"elatostema",
		3086735
	],
	[
		"s1785641",
		"Elatostema lineare",
		"elatostema",
		1785641
	],
	[
		"s3797330",
		"Elatostema linearicorniculatum",
		"elatostema",
		3797330
	],
	[
		"s1355400",
		"Elatostema lineolatum",
		"elatostema",
		1355400
	],
	[
		"s3797331",
		"Elatostema lingelsheimii",
		"elatostema",
		3797331
	],
	[
		"s1785642",
		"Elatostema lithoneurum",
		"elatostema",
		1785642
	],
	[
		"s3797332",
		"Elatostema litseifolium",
		"elatostema",
		3797332
	],
	[
		"s3797333",
		"Elatostema liutangshuii",
		"elatostema",
		3797333
	],
	[
		"s1785643",
		"Elatostema lonchophyllum",
		"elatostema",
		1785643
	],
	[
		"s1399680",
		"Elatostema longibracteatum",
		"elatostema",
		1399680
	],
	[
		"s3797334",
		"Elatostema longicaudatum",
		"elatostema",
		3797334
	],
	[
		"s3797335",
		"Elatostema longiciliatum",
		"elatostema",
		3797335
	],
	[
		"s3797336",
		"Elatostema longicollum",
		"elatostema",
		3797336
	],
	[
		"s3797337",
		"Elatostema longicuspe",
		"elatostema",
		3797337
	],
	[
		"s3797338",
		"Elatostema longifolium",
		"elatostema",
		3797338
	],
	[
		"s3086736",
		"Elatostema longipes",
		"elatostema",
		3086736
	],
	[
		"s2564001",
		"Elatostema longipetiolatum",
		"elatostema",
		2564001
	],
	[
		"s3797339",
		"Elatostema longirostre",
		"elatostema",
		3797339
	],
	[
		"s1785644",
		"Elatostema longistipulum",
		"elatostema",
		1785644
	],
	[
		"s3797340",
		"Elatostema longitepalum",
		"elatostema",
		3797340
	],
	[
		"s3237152",
		"Elatostema longpingii",
		"elatostema",
		3237152
	],
	[
		"s3797341",
		"Elatostema luchunense",
		"elatostema",
		3797341
	],
	[
		"s3797342",
		"Elatostema lui",
		"elatostema",
		3797342
	],
	[
		"s1785645",
		"Elatostema lungzhouense",
		"elatostema",
		1785645
	],
	[
		"s3797343",
		"Elatostema luoi",
		"elatostema",
		3797343
	],
	[
		"s3797344",
		"Elatostema lushuiheense",
		"elatostema",
		3797344
	],
	[
		"s1785646",
		"Elatostema lutescens",
		"elatostema",
		1785646
	],
	[
		"s3797345",
		"Elatostema luxiense",
		"elatostema",
		3797345
	],
	[
		"s3797346",
		"Elatostema luzonense",
		"elatostema",
		3797346
	],
	[
		"s3797347",
		"Elatostema mabienense",
		"elatostema",
		3797347
	],
	[
		"s3797348",
		"Elatostema macgregorii",
		"elatostema",
		3797348
	],
	[
		"s1785647",
		"Elatostema macintyrei",
		"elatostema",
		1785647
	],
	[
		"s226275",
		"Elatostema macrophyllum",
		"elatostema",
		226275
	],
	[
		"s3797349",
		"Elatostema macropus",
		"elatostema",
		3797349
	],
	[
		"s3797350",
		"Elatostema maculatum",
		"elatostema",
		3797350
	],
	[
		"s1785648",
		"Elatostema madagascariense",
		"elatostema",
		1785648
	],
	[
		"s3797351",
		"Elatostema mafuluense",
		"elatostema",
		3797351
	],
	[
		"s3797352",
		"Elatostema magni-auriculatum",
		"elatostema",
		3797352
	],
	[
		"s3797353",
		"Elatostema maguanense",
		"elatostema",
		3797353
	],
	[
		"s1785649",
		"Elatostema malacotrichum",
		"elatostema",
		1785649
	],
	[
		"s3797354",
		"Elatostema malipoense",
		"elatostema",
		3797354
	],
	[
		"s3797355",
		"Elatostema manhaoense",
		"elatostema",
		3797355
	],
	[
		"s3797356",
		"Elatostema mannii",
		"elatostema",
		3797356
	],
	[
		"s3797357",
		"Elatostema maquilingense",
		"elatostema",
		3797357
	],
	[
		"s3086737",
		"Elatostema maraiparaiense",
		"elatostema",
		3086737
	],
	[
		"s3797358",
		"Elatostema mashanense",
		"elatostema",
		3797358
	],
	[
		"s3797359",
		"Elatostema medogense",
		"elatostema",
		3797359
	],
	[
		"s3086738",
		"Elatostema megacephalum",
		"elatostema",
		3086738
	],
	[
		"s3086739",
		"Elatostema megaphyllum",
		"elatostema",
		3086739
	],
	[
		"s3797360",
		"Elatostema melanocarpum",
		"elatostema",
		3797360
	],
	[
		"s3797361",
		"Elatostema melanocephalum",
		"elatostema",
		3797361
	],
	[
		"s3797362",
		"Elatostema melanoceras",
		"elatostema",
		3797362
	],
	[
		"s3797363",
		"Elatostema melanophyllum",
		"elatostema",
		3797363
	],
	[
		"s3797364",
		"Elatostema menghaiense",
		"elatostema",
		3797364
	],
	[
		"s3797365",
		"Elatostema menglunense",
		"elatostema",
		3797365
	],
	[
		"s3797366",
		"Elatostema microcarpum",
		"elatostema",
		3797366
	],
	[
		"s1661591",
		"Elatostema microcephalanthum",
		"elatostema",
		1661591
	],
	[
		"s3797367",
		"Elatostema microdontum",
		"elatostema",
		3797367
	],
	[
		"s3797368",
		"Elatostema microphyllum",
		"elatostema",
		3797368
	],
	[
		"s3797369",
		"Elatostema microprocris",
		"elatostema",
		3797369
	],
	[
		"s3797370",
		"Elatostema microtrichum",
		"elatostema",
		3797370
	],
	[
		"s3797371",
		"Elatostema mindanaense",
		"elatostema",
		3797371
	],
	[
		"s3797372",
		"Elatostema minus",
		"elatostema",
		3797372
	],
	[
		"s3797373",
		"Elatostema minutiflorum",
		"elatostema",
		3797373
	],
	[
		"s3797374",
		"Elatostema minutifolianum",
		"elatostema",
		3797374
	],
	[
		"s3797375",
		"Elatostema minutifurfuraceum",
		"elatostema",
		3797375
	],
	[
		"s3086740",
		"Elatostema molle",
		"elatostema",
		3086740
	],
	[
		"s1785650",
		"Elatostema monandrum",
		"elatostema",
		1785650
	],
	[
		"s3797376",
		"Elatostema mongiensis",
		"elatostema",
		3797376
	],
	[
		"s1785651",
		"Elatostema monticola",
		"elatostema",
		1785651
	],
	[
		"s1785652",
		"Elatostema morobense",
		"elatostema",
		1785652
	],
	[
		"s1785653",
		"Elatostema multicaule",
		"elatostema",
		1785653
	],
	[
		"s3797377",
		"Elatostema multinervium",
		"elatostema",
		3797377
	],
	[
		"s3797378",
		"Elatostema muluense",
		"elatostema",
		3797378
	],
	[
		"s1785654",
		"Elatostema myrtillus",
		"elatostema",
		1785654
	],
	[
		"s3086741",
		"Elatostema nanchuanense",
		"elatostema",
		3086741
	],
	[
		"s3797379",
		"Elatostema nanhumontanum",
		"elatostema",
		3797379
	],
	[
		"s3797380",
		"Elatostema nanxiense",
		"elatostema",
		3797380
	],
	[
		"s3797381",
		"Elatostema napoense",
		"elatostema",
		3797381
	],
	[
		"s1785655",
		"Elatostema nasutum",
		"elatostema",
		1785655
	],
	[
		"s3797382",
		"Elatostema nemorosum",
		"elatostema",
		3797382
	],
	[
		"s3797383",
		"Elatostema neobaviense",
		"elatostema",
		3797383
	],
	[
		"s3797384",
		"Elatostema neriifolium",
		"elatostema",
		3797384
	],
	[
		"s3797385",
		"Elatostema nianbense",
		"elatostema",
		3797385
	],
	[
		"s226276",
		"Elatostema nigrescens",
		"elatostema",
		226276
	],
	[
		"s3797386",
		"Elatostema nigribracteatum",
		"elatostema",
		3797386
	],
	[
		"s3086742",
		"Elatostema novae-britanniae",
		"elatostema",
		3086742
	],
	[
		"s3086743",
		"Elatostema novoguineense",
		"elatostema",
		3086743
	],
	[
		"s3797387",
		"Elatostema oblanceolatum",
		"elatostema",
		3797387
	],
	[
		"s3086744",
		"Elatostema obliquifolium",
		"elatostema",
		3086744
	],
	[
		"s1661592",
		"Elatostema oblongifolium",
		"elatostema",
		1661592
	],
	[
		"s3797388",
		"Elatostema obovatum",
		"elatostema",
		3797388
	],
	[
		"s3797389",
		"Elatostema obscurinerve",
		"elatostema",
		3797389
	],
	[
		"s3797390",
		"Elatostema obtusidentatum",
		"elatostema",
		3797390
	],
	[
		"s3797391",
		"Elatostema obtusiusculum",
		"elatostema",
		3797391
	],
	[
		"s1661593",
		"Elatostema obtusum",
		"elatostema",
		1661593
	],
	[
		"s3797392",
		"Elatostema odontopterum",
		"elatostema",
		3797392
	],
	[
		"s3797393",
		"Elatostema oligodon",
		"elatostema",
		3797393
	],
	[
		"s1785656",
		"Elatostema oligophlebium",
		"elatostema",
		1785656
	],
	[
		"s3797394",
		"Elatostema oligotrichum",
		"elatostema",
		3797394
	],
	[
		"s3797395",
		"Elatostema omeiense",
		"elatostema",
		3797395
	],
	[
		"s3797396",
		"Elatostema oppositum",
		"elatostema",
		3797396
	],
	[
		"s3797397",
		"Elatostema oreocnidioides",
		"elatostema",
		3797397
	],
	[
		"s1785657",
		"Elatostema orientale",
		"elatostema",
		1785657
	],
	[
		"s3797398",
		"Elatostema ornithorrhynchum",
		"elatostema",
		3797398
	],
	[
		"s3797399",
		"Elatostema oshimense",
		"elatostema",
		3797399
	],
	[
		"s3797400",
		"Elatostema oxyodontum",
		"elatostema",
		3797400
	],
	[
		"s3797401",
		"Elatostema pachycephalum",
		"elatostema",
		3797401
	],
	[
		"s3797402",
		"Elatostema pachyceras",
		"elatostema",
		3797402
	],
	[
		"s3797403",
		"Elatostema pachypodum",
		"elatostema",
		3797403
	],
	[
		"s3797404",
		"Elatostema pacificum",
		"elatostema",
		3797404
	],
	[
		"s1785658",
		"Elatostema paivaeanum",
		"elatostema",
		1785658
	],
	[
		"s3797405",
		"Elatostema pallidinerve",
		"elatostema",
		3797405
	],
	[
		"s3086745",
		"Elatostema palustre",
		"elatostema",
		3086745
	],
	[
		"s3797406",
		"Elatostema panayense",
		"elatostema",
		3797406
	],
	[
		"s3797407",
		"Elatostema papillosum",
		"elatostema",
		3797407
	],
	[
		"s3797408",
		"Elatostema paracuminatum",
		"elatostema",
		3797408
	],
	[
		"s3086746",
		"Elatostema paramelanum",
		"elatostema",
		3086746
	],
	[
		"s2516484",
		"Elatostema parasiticum",
		"elatostema",
		2516484
	],
	[
		"s3797409",
		"Elatostema parvioides",
		"elatostema",
		3797409
	],
	[
		"s226091",
		"Elatostema parvum",
		"elatostema",
		226091
	],
	[
		"s3797410",
		"Elatostema paucicystatum",
		"elatostema",
		3797410
	],
	[
		"s1399717",
		"Elatostema paucidentatum",
		"elatostema",
		1399717
	],
	[
		"s3797411",
		"Elatostema pauciflorum",
		"elatostema",
		3797411
	],
	[
		"s3797412",
		"Elatostema paucifolium",
		"elatostema",
		3797412
	],
	[
		"s3797413",
		"Elatostema pauperatum",
		"elatostema",
		3797413
	],
	[
		"s3086747",
		"Elatostema paxii",
		"elatostema",
		3086747
	],
	[
		"s3797414",
		"Elatostema pedicellatum",
		"elatostema",
		3797414
	],
	[
		"s226277",
		"Elatostema pedunculosum",
		"elatostema",
		226277
	],
	[
		"s3797415",
		"Elatostema pellionioides",
		"elatostema",
		3797415
	],
	[
		"s3797416",
		"Elatostema peltifolium",
		"elatostema",
		3797416
	],
	[
		"s1785659",
		"Elatostema penibukanense",
		"elatostema",
		1785659
	],
	[
		"s3797417",
		"Elatostema penninerve",
		"elatostema",
		3797417
	],
	[
		"s3797418",
		"Elatostema peperomioides",
		"elatostema",
		3797418
	],
	[
		"s2555699",
		"Elatostema pergameneum",
		"elatostema",
		2555699
	],
	[
		"s3797419",
		"Elatostema perlongifolium",
		"elatostema",
		3797419
	],
	[
		"s3797420",
		"Elatostema perpusillum",
		"elatostema",
		3797420
	],
	[
		"s1399682",
		"Elatostema petelotii",
		"elatostema",
		1399682
	],
	[
		"s3797421",
		"Elatostema petiolare",
		"elatostema",
		3797421
	],
	[
		"s3797422",
		"Elatostema petiolatum",
		"elatostema",
		3797422
	],
	[
		"s3086748",
		"Elatostema phanerophlebium",
		"elatostema",
		3086748
	],
	[
		"s3086749",
		"Elatostema philippinense",
		"elatostema",
		3086749
	],
	[
		"s3797423",
		"Elatostema pianmaense",
		"elatostema",
		3797423
	],
	[
		"s3797424",
		"Elatostema pilosum",
		"elatostema",
		3797424
	],
	[
		"s3797425",
		"Elatostema piluliferum",
		"elatostema",
		3797425
	],
	[
		"s3797426",
		"Elatostema pingbianense",
		"elatostema",
		3797426
	],
	[
		"s3797427",
		"Elatostema pinnatinervium",
		"elatostema",
		3797427
	],
	[
		"s3797428",
		"Elatostema pinnativenium",
		"elatostema",
		3797428
	],
	[
		"s3797429",
		"Elatostema planinerve",
		"elatostema",
		3797429
	],
	[
		"s3797430",
		"Elatostema platycarpum",
		"elatostema",
		3797430
	],
	[
		"s3797431",
		"Elatostema platyceras",
		"elatostema",
		3797431
	],
	[
		"s1355398",
		"Elatostema platyphylloides",
		"elatostema",
		1355398
	],
	[
		"s1661594",
		"Elatostema platyphyllum",
		"elatostema",
		1661594
	],
	[
		"s3797432",
		"Elatostema pleiophlebium",
		"elatostema",
		3797432
	],
	[
		"s3086750",
		"Elatostema plumbeum",
		"elatostema",
		3086750
	],
	[
		"s3797433",
		"Elatostema podophyllum",
		"elatostema",
		3797433
	],
	[
		"s3797434",
		"Elatostema polypodioides",
		"elatostema",
		3797434
	],
	[
		"s3797435",
		"Elatostema polystachyoides",
		"elatostema",
		3797435
	],
	[
		"s3797436",
		"Elatostema poteriifolium",
		"elatostema",
		3797436
	],
	[
		"s3797437",
		"Elatostema procridifolium",
		"elatostema",
		3797437
	],
	[
		"s3797438",
		"Elatostema procridioides",
		"elatostema",
		3797438
	],
	[
		"s3797439",
		"Elatostema prunifolium",
		"elatostema",
		3797439
	],
	[
		"s3797440",
		"Elatostema pseudobrachyodontum",
		"elatostema",
		3797440
	],
	[
		"s3086751",
		"Elatostema pseudocuspidatum",
		"elatostema",
		3086751
	],
	[
		"s3086752",
		"Elatostema pseudodissectum",
		"elatostema",
		3086752
	],
	[
		"s3086753",
		"Elatostema pseudoficoides",
		"elatostema",
		3086753
	],
	[
		"s3797441",
		"Elatostema pseudolongipes",
		"elatostema",
		3797441
	],
	[
		"s3797442",
		"Elatostema pseudonanchuanense",
		"elatostema",
		3797442
	],
	[
		"s3797443",
		"Elatostema pseudonasutum",
		"elatostema",
		3797443
	],
	[
		"s3797444",
		"Elatostema pseudooblongifolium",
		"elatostema",
		3797444
	],
	[
		"s3797445",
		"Elatostema pseudoplatyphyllum",
		"elatostema",
		3797445
	],
	[
		"s3797446",
		"Elatostema pubipes",
		"elatostema",
		3797446
	],
	[
		"s3086754",
		"Elatostema pulchellum",
		"elatostema",
		3086754
	],
	[
		"s3797447",
		"Elatostema pulleanum",
		"elatostema",
		3797447
	],
	[
		"s3797448",
		"Elatostema punctatum",
		"elatostema",
		3797448
	],
	[
		"s3797449",
		"Elatostema purpurascens",
		"elatostema",
		3797449
	],
	[
		"s3797450",
		"Elatostema purpureolineolatum",
		"elatostema",
		3797450
	],
	[
		"s3086755",
		"Elatostema purpureum",
		"elatostema",
		3086755
	],
	[
		"s1785660",
		"Elatostema pusillum",
		"elatostema",
		1785660
	],
	[
		"s3086756",
		"Elatostema pycnodontum",
		"elatostema",
		3086756
	],
	[
		"s2794062",
		"Elatostema qinzhouense",
		"elatostema",
		2794062
	],
	[
		"s3797451",
		"Elatostema quadribracteatum",
		"elatostema",
		3797451
	],
	[
		"s3797452",
		"Elatostema quinquecostatum",
		"elatostema",
		3797452
	],
	[
		"s3797453",
		"Elatostema quinquetepalum",
		"elatostema",
		3797453
	],
	[
		"s2516485",
		"Elatostema raapii",
		"elatostema",
		2516485
	],
	[
		"s2747791",
		"Elatostema radicans",
		"elatostema",
		2747791
	],
	[
		"s3797454",
		"Elatostema ramosissimum",
		"elatostema",
		3797454
	],
	[
		"s3086757",
		"Elatostema ramosum",
		"elatostema",
		3086757
	],
	[
		"s3797455",
		"Elatostema ranongense",
		"elatostema",
		3797455
	],
	[
		"s3797456",
		"Elatostema rechingeri",
		"elatostema",
		3797456
	],
	[
		"s3797457",
		"Elatostema recticaudatum",
		"elatostema",
		3797457
	],
	[
		"s3797458",
		"Elatostema recurviramum",
		"elatostema",
		3797458
	],
	[
		"s3797459",
		"Elatostema reiterianum",
		"elatostema",
		3797459
	],
	[
		"s226279",
		"Elatostema reticulatum",
		"elatostema",
		226279
	],
	[
		"s3797460",
		"Elatostema retinervium",
		"elatostema",
		3797460
	],
	[
		"s2306677",
		"Elatostema retrohirtum",
		"elatostema",
		2306677
	],
	[
		"s3797461",
		"Elatostema retrorstrigulosum",
		"elatostema",
		3797461
	],
	[
		"s3797462",
		"Elatostema retrostrigulosoides",
		"elatostema",
		3797462
	],
	[
		"s3797463",
		"Elatostema rhizomatosum",
		"elatostema",
		3797463
	],
	[
		"s3797464",
		"Elatostema rhombiforme",
		"elatostema",
		3797464
	],
	[
		"s3797465",
		"Elatostema ridleyanum",
		"elatostema",
		3797465
	],
	[
		"s3797466",
		"Elatostema rigidiusculum",
		"elatostema",
		3797466
	],
	[
		"s1661595",
		"Elatostema rivulare",
		"elatostema",
		1661595
	],
	[
		"s3797467",
		"Elatostema robinsonii",
		"elatostema",
		3797467
	],
	[
		"s2747784",
		"Elatostema robustipes",
		"elatostema",
		2747784
	],
	[
		"s3797468",
		"Elatostema ronganense",
		"elatostema",
		3797468
	],
	[
		"s226280",
		"Elatostema rostratum",
		"elatostema",
		226280
	],
	[
		"s3797469",
		"Elatostema rubricaule",
		"elatostema",
		3797469
	],
	[
		"s3086758",
		"Elatostema rubrostipulatum",
		"elatostema",
		3086758
	],
	[
		"s3797470",
		"Elatostema rudicaule",
		"elatostema",
		3797470
	],
	[
		"s1785661",
		"Elatostema rugosum",
		"elatostema",
		1785661
	],
	[
		"s3086044",
		"Elatostema rupestre",
		"elatostema",
		3086044
	],
	[
		"s3797471",
		"Elatostema rupicola",
		"elatostema",
		3797471
	],
	[
		"s3086759",
		"Elatostema salomonense",
		"elatostema",
		3086759
	],
	[
		"s2306678",
		"Elatostema salvinioides",
		"elatostema",
		2306678
	],
	[
		"s1785662",
		"Elatostema samoense",
		"elatostema",
		1785662
	],
	[
		"s3797472",
		"Elatostema savaiiense",
		"elatostema",
		3797472
	],
	[
		"s3797473",
		"Elatostema saxatile",
		"elatostema",
		3797473
	],
	[
		"s3797474",
		"Elatostema scabriusculum",
		"elatostema",
		3797474
	],
	[
		"s3797475",
		"Elatostema scapigerum",
		"elatostema",
		3797475
	],
	[
		"s2747785",
		"Elatostema scaposum",
		"elatostema",
		2747785
	],
	[
		"s3797476",
		"Elatostema schizodiscum",
		"elatostema",
		3797476
	],
	[
		"s3797477",
		"Elatostema schroeteri",
		"elatostema",
		3797477
	],
	[
		"s3797478",
		"Elatostema scriptum",
		"elatostema",
		3797478
	],
	[
		"s3086760",
		"Elatostema seemannianum",
		"elatostema",
		3086760
	],
	[
		"s3797479",
		"Elatostema septemcostatum",
		"elatostema",
		3797479
	],
	[
		"s3797480",
		"Elatostema septemflorum",
		"elatostema",
		3797480
	],
	[
		"s3797481",
		"Elatostema serpentinicola",
		"elatostema",
		3797481
	],
	[
		"s1785663",
		"Elatostema serra",
		"elatostema",
		1785663
	],
	[
		"s226281",
		"Elatostema sesquifolium",
		"elatostema",
		226281
	],
	[
		"s3086761",
		"Elatostema sessile",
		"elatostema",
		3086761
	],
	[
		"s2555700",
		"Elatostema setulosum",
		"elatostema",
		2555700
	],
	[
		"s3797482",
		"Elatostema sexcostatum",
		"elatostema",
		3797482
	],
	[
		"s3086762",
		"Elatostema shanglinense",
		"elatostema",
		3086762
	],
	[
		"s3797483",
		"Elatostema shuii",
		"elatostema",
		3797483
	],
	[
		"s3797484",
		"Elatostema sikkimense",
		"elatostema",
		3797484
	],
	[
		"s3797485",
		"Elatostema simaoense",
		"elatostema",
		3797485
	],
	[
		"s3797486",
		"Elatostema simianshanicum",
		"elatostema",
		3797486
	],
	[
		"s3797487",
		"Elatostema simplicissimum",
		"elatostema",
		3797487
	],
	[
		"s3797488",
		"Elatostema simulans",
		"elatostema",
		3797488
	],
	[
		"s1785664",
		"Elatostema sinense",
		"elatostema",
		1785664
	],
	[
		"s1785667",
		"Elatostema sinopurpureum",
		"elatostema",
		1785667
	],
	[
		"s647269",
		"Elatostema sinuatum",
		"elatostema",
		647269
	],
	[
		"s3797489",
		"Elatostema siyuanwukouense",
		"elatostema",
		3797489
	],
	[
		"s3797490",
		"Elatostema smilacinum",
		"elatostema",
		3797490
	],
	[
		"s3086763",
		"Elatostema sorsogonense",
		"elatostema",
		3086763
	],
	[
		"s3797491",
		"Elatostema spinulosum",
		"elatostema",
		3797491
	],
	[
		"s3797492",
		"Elatostema stellatum",
		"elatostema",
		3797492
	],
	[
		"s3797493",
		"Elatostema stenocarpum",
		"elatostema",
		3797493
	],
	[
		"s3797494",
		"Elatostema stenophyllum",
		"elatostema",
		3797494
	],
	[
		"s1399684",
		"Elatostema stewardii",
		"elatostema",
		1399684
	],
	[
		"s3086764",
		"Elatostema stigmatosum",
		"elatostema",
		3086764
	],
	[
		"s226282",
		"Elatostema stipitatum",
		"elatostema",
		226282
	],
	[
		"s3086765",
		"Elatostema stoloniforme",
		"elatostema",
		3086765
	],
	[
		"s1785668",
		"Elatostema strictum",
		"elatostema",
		1785668
	],
	[
		"s1661597",
		"Elatostema strigillosum",
		"elatostema",
		1661597
	],
	[
		"s226283",
		"Elatostema strigosum",
		"elatostema",
		226283
	],
	[
		"s3086766",
		"Elatostema strigulosum",
		"elatostema",
		3086766
	],
	[
		"s1661598",
		"Elatostema subcoriaceum",
		"elatostema",
		1661598
	],
	[
		"s3797495",
		"Elatostema subcuspidatum",
		"elatostema",
		3797495
	],
	[
		"s3797496",
		"Elatostema subfavosum",
		"elatostema",
		3797496
	],
	[
		"s3797497",
		"Elatostema subincisum",
		"elatostema",
		3797497
	],
	[
		"s3797498",
		"Elatostema subintegrum",
		"elatostema",
		3797498
	],
	[
		"s3797499",
		"Elatostema sublignosum",
		"elatostema",
		3797499
	],
	[
		"s1785669",
		"Elatostema sublineare",
		"elatostema",
		1785669
	],
	[
		"s3797500",
		"Elatostema suborbiculare",
		"elatostema",
		3797500
	],
	[
		"s3797501",
		"Elatostema subpenninerve",
		"elatostema",
		3797501
	],
	[
		"s3797502",
		"Elatostema subscabrum",
		"elatostema",
		3797502
	],
	[
		"s1399685",
		"Elatostema subtrichotomum",
		"elatostema",
		1399685
	],
	[
		"s3237154",
		"Elatostema subundulatum",
		"elatostema",
		3237154
	],
	[
		"s3797503",
		"Elatostema subvillosum",
		"elatostema",
		3797503
	],
	[
		"s3797504",
		"Elatostema sukungianum",
		"elatostema",
		3797504
	],
	[
		"s3797505",
		"Elatostema surigaoense",
		"elatostema",
		3797505
	],
	[
		"s1785670",
		"Elatostema suzukii",
		"elatostema",
		1785670
	],
	[
		"s3086767",
		"Elatostema sylvanum",
		"elatostema",
		3086767
	],
	[
		"s3797506",
		"Elatostema taiwanense",
		"elatostema",
		3797506
	],
	[
		"s3797507",
		"Elatostema taoyuanense",
		"elatostema",
		3797507
	],
	[
		"s3086768",
		"Elatostema tenellum",
		"elatostema",
		3086768
	],
	[
		"s3797508",
		"Elatostema tenuibracteatum",
		"elatostema",
		3797508
	],
	[
		"s3797509",
		"Elatostema tenuicaudatoides",
		"elatostema",
		3797509
	],
	[
		"s1399687",
		"Elatostema tenuicaudatum",
		"elatostema",
		1399687
	],
	[
		"s3797510",
		"Elatostema tenuicaule",
		"elatostema",
		3797510
	],
	[
		"s3086769",
		"Elatostema tenuicornutum",
		"elatostema",
		3086769
	],
	[
		"s3797511",
		"Elatostema tenuifolium",
		"elatostema",
		3797511
	],
	[
		"s1785671",
		"Elatostema tenuinerve",
		"elatostema",
		1785671
	],
	[
		"s3797512",
		"Elatostema tenuireceptaculum",
		"elatostema",
		3797512
	],
	[
		"s3797513",
		"Elatostema tenuistipulatum",
		"elatostema",
		3797513
	],
	[
		"s3797514",
		"Elatostema tetratepalum",
		"elatostema",
		3797514
	],
	[
		"s1785672",
		"Elatostema thalictroides",
		"elatostema",
		1785672
	],
	[
		"s3797515",
		"Elatostema thomense",
		"elatostema",
		3797515
	],
	[
		"s1785673",
		"Elatostema tianeense",
		"elatostema",
		1785673
	],
	[
		"s3797516",
		"Elatostema tianlinense",
		"elatostema",
		3797516
	],
	[
		"s3797517",
		"Elatostema tiechangense",
		"elatostema",
		3797517
	],
	[
		"s3797518",
		"Elatostema tomentosum",
		"elatostema",
		3797518
	],
	[
		"s3797519",
		"Elatostema tricaule",
		"elatostema",
		3797519
	],
	[
		"s3797520",
		"Elatostema trichanthum",
		"elatostema",
		3797520
	],
	[
		"s3086770",
		"Elatostema trichocarpum",
		"elatostema",
		3086770
	],
	[
		"s3797521",
		"Elatostema trichomanes",
		"elatostema",
		3797521
	],
	[
		"s3797522",
		"Elatostema trichosanthum",
		"elatostema",
		3797522
	],
	[
		"s3797523",
		"Elatostema trichotomum",
		"elatostema",
		3797523
	],
	[
		"s3797524",
		"Elatostema tricostatum",
		"elatostema",
		3797524
	],
	[
		"s3797525",
		"Elatostema tricuspe",
		"elatostema",
		3797525
	],
	[
		"s3797526",
		"Elatostema tridens",
		"elatostema",
		3797526
	],
	[
		"s1661599",
		"Elatostema trilobulatum",
		"elatostema",
		1661599
	],
	[
		"s3797527",
		"Elatostema tritepalum",
		"elatostema",
		3797527
	],
	[
		"s3797528",
		"Elatostema truncicola",
		"elatostema",
		3797528
	],
	[
		"s3797529",
		"Elatostema tungyanshanense",
		"elatostema",
		3797529
	],
	[
		"s3797530",
		"Elatostema tutuilense",
		"elatostema",
		3797530
	],
	[
		"s3797531",
		"Elatostema ulmifolium",
		"elatostema",
		3797531
	],
	[
		"s1661600",
		"Elatostema umbellatum",
		"elatostema",
		1661600
	],
	[
		"s3797532",
		"Elatostema umbrinum",
		"elatostema",
		3797532
	],
	[
		"s3797533",
		"Elatostema undulatum",
		"elatostema",
		3797533
	],
	[
		"s3797534",
		"Elatostema uniflorum",
		"elatostema",
		3797534
	],
	[
		"s3797535",
		"Elatostema urvilleanum",
		"elatostema",
		3797535
	],
	[
		"s3797536",
		"Elatostema utakwaense",
		"elatostema",
		3797536
	],
	[
		"s3797537",
		"Elatostema variabile",
		"elatostema",
		3797537
	],
	[
		"s3797538",
		"Elatostema variegatum",
		"elatostema",
		3797538
	],
	[
		"s1785674",
		"Elatostema variolaminosum",
		"elatostema",
		1785674
	],
	[
		"s647288",
		"Elatostema velutinicaule",
		"elatostema",
		647288
	],
	[
		"s3797539",
		"Elatostema velutinum",
		"elatostema",
		3797539
	],
	[
		"s3797540",
		"Elatostema veronicoides",
		"elatostema",
		3797540
	],
	[
		"s3797541",
		"Elatostema vicinum",
		"elatostema",
		3797541
	],
	[
		"s3797542",
		"Elatostema vietnamense",
		"elatostema",
		3797542
	],
	[
		"s1661602",
		"Elatostema villosum",
		"elatostema",
		1661602
	],
	[
		"s3086771",
		"Elatostema viridescens",
		"elatostema",
		3086771
	],
	[
		"s3797543",
		"Elatostema viridibracteolatum",
		"elatostema",
		3797543
	],
	[
		"s3797544",
		"Elatostema viridicarinatum",
		"elatostema",
		3797544
	],
	[
		"s3797545",
		"Elatostema viridicostatum",
		"elatostema",
		3797545
	],
	[
		"s3797546",
		"Elatostema viridinerve",
		"elatostema",
		3797546
	],
	[
		"s1785676",
		"Elatostema vitiense",
		"elatostema",
		1785676
	],
	[
		"s3797547",
		"Elatostema volubile",
		"elatostema",
		3797547
	],
	[
		"s3797548",
		"Elatostema walkerae",
		"elatostema",
		3797548
	],
	[
		"s3086772",
		"Elatostema wangii",
		"elatostema",
		3086772
	],
	[
		"s3797549",
		"Elatostema warburgii",
		"elatostema",
		3797549
	],
	[
		"s3797550",
		"Elatostema weii",
		"elatostema",
		3797550
	],
	[
		"s3086773",
		"Elatostema weinlandii",
		"elatostema",
		3086773
	],
	[
		"s1785678",
		"Elatostema welwitschii",
		"elatostema",
		1785678
	],
	[
		"s3797551",
		"Elatostema wenshanense",
		"elatostema",
		3797551
	],
	[
		"s3797552",
		"Elatostema wenxienense",
		"elatostema",
		3797552
	],
	[
		"s3797553",
		"Elatostema whartonense",
		"elatostema",
		3797553
	],
	[
		"s3797554",
		"Elatostema whitfordii",
		"elatostema",
		3797554
	],
	[
		"s3797555",
		"Elatostema wightii",
		"elatostema",
		3797555
	],
	[
		"s3086774",
		"Elatostema winkleri-hubertii",
		"elatostema",
		3086774
	],
	[
		"s3797556",
		"Elatostema wufengchiwaterfallense",
		"elatostema",
		3797556
	],
	[
		"s3797557",
		"Elatostema wugangense",
		"elatostema",
		3797557
	],
	[
		"s1785679",
		"Elatostema xanthophyllum",
		"elatostema",
		1785679
	],
	[
		"s3797558",
		"Elatostema xanthotrichum",
		"elatostema",
		3797558
	],
	[
		"s3797559",
		"Elatostema xichouense",
		"elatostema",
		3797559
	],
	[
		"s3797560",
		"Elatostema xingyiense",
		"elatostema",
		3797560
	],
	[
		"s1785680",
		"Elatostema yachense",
		"elatostema",
		1785680
	],
	[
		"s1661603",
		"Elatostema yakushimense",
		"elatostema",
		1661603
	],
	[
		"s3797561",
		"Elatostema yangbiense",
		"elatostema",
		3797561
	],
	[
		"s1785681",
		"Elatostema yaoshanense",
		"elatostema",
		1785681
	],
	[
		"s3797562",
		"Elatostema yenii",
		"elatostema",
		3797562
	],
	[
		"s2811218",
		"Elatostema yonakuniense",
		"elatostema",
		2811218
	],
	[
		"s3797563",
		"Elatostema yongtianianum",
		"elatostema",
		3797563
	],
	[
		"s3797564",
		"Elatostema youyangense",
		"elatostema",
		3797564
	],
	[
		"s3797565",
		"Elatostema zamboangense",
		"elatostema",
		3797565
	],
	[
		"s3797566",
		"Elatostema zhengyuanum",
		"elatostema",
		3797566
	],
	[
		"s3797567",
		"Elatostema zhenyuanense",
		"elatostema",
		3797567
	],
	[
		"s3797568",
		"Elatostematoides buderi",
		"elatostematoides",
		3797568
	],
	[
		"s3797569",
		"Elatostematoides caudata",
		"elatostematoides",
		3797569
	],
	[
		"s3797570",
		"Elatostematoides falcata",
		"elatostematoides",
		3797570
	],
	[
		"s3797571",
		"Elatostematoides falcifolia",
		"elatostematoides",
		3797571
	],
	[
		"s3381618",
		"Elatostematoides filicoides",
		"elatostematoides",
		3381618
	],
	[
		"s3381619",
		"Elatostematoides fruticulosa",
		"elatostematoides",
		3381619
	],
	[
		"s3797572",
		"Elatostematoides lingua",
		"elatostematoides",
		3797572
	],
	[
		"s3797573",
		"Elatostematoides machaerophylla",
		"elatostematoides",
		3797573
	],
	[
		"s3797574",
		"Elatostematoides mindanaensis",
		"elatostematoides",
		3797574
	],
	[
		"s3797575",
		"Elatostematoides picta",
		"elatostematoides",
		3797575
	],
	[
		"s3797576",
		"Elatostematoides rigida",
		"elatostematoides",
		3797576
	],
	[
		"s3797577",
		"Elatostematoides robusta",
		"elatostematoides",
		3797577
	],
	[
		"s3797578",
		"Elatostematoides samarensis",
		"elatostematoides",
		3797578
	],
	[
		"s3797579",
		"Elatostematoides scandens",
		"elatostematoides",
		3797579
	],
	[
		"s3797580",
		"Elatostematoides sublaxa",
		"elatostematoides",
		3797580
	],
	[
		"s2806815",
		"Elatostematoides vittata",
		"elatostematoides",
		2806815
	],
	[
		"s3797581",
		"Elatostematoides wenzelii",
		"elatostematoides",
		3797581
	],
	[
		"s106675",
		"Emmenosperma alphitonioides",
		"emmenosperma",
		106675
	],
	[
		"s1619437",
		"Emmenosperma cunninghamii",
		"emmenosperma",
		1619437
	],
	[
		"s2358447",
		"Emmenosperma micropetalum",
		"emmenosperma",
		2358447
	],
	[
		"s1502682",
		"Emmenosperma pancherianum",
		"emmenosperma",
		1502682
	],
	[
		"s3798087",
		"Emmenosperma papuanum",
		"emmenosperma",
		3798087
	],
	[
		"s2905422",
		"Eriobotrya angustissima",
		"eriobotrya",
		2905422
	],
	[
		"s3803473",
		"Eriobotrya balgooyi",
		"eriobotrya",
		3803473
	],
	[
		"s589997",
		"Eriobotrya bengalensis",
		"eriobotrya",
		589997
	],
	[
		"s3803474",
		"Eriobotrya capitata",
		"eriobotrya",
		3803474
	],
	[
		"s691223",
		"Eriobotrya cavaleriei",
		"eriobotrya",
		691223
	],
	[
		"s2086276",
		"Eriobotrya condaoensis",
		"eriobotrya",
		2086276
	],
	[
		"s3447176",
		"Eriobotrya crassifolia",
		"eriobotrya",
		3447176
	],
	[
		"s1143234",
		"Eriobotrya deflexa",
		"eriobotrya",
		1143234
	],
	[
		"s2905717",
		"Eriobotrya dubia",
		"eriobotrya",
		2905717
	],
	[
		"s2024530",
		"Eriobotrya elliptica",
		"eriobotrya",
		2024530
	],
	[
		"s691224",
		"Eriobotrya fragrans",
		"eriobotrya",
		691224
	],
	[
		"s2024531",
		"Eriobotrya fulvicoma",
		"eriobotrya",
		2024531
	],
	[
		"s2024532",
		"Eriobotrya fusca",
		"eriobotrya",
		2024532
	],
	[
		"s2905423",
		"Eriobotrya glabrescens",
		"eriobotrya",
		2905423
	],
	[
		"s1581416",
		"Eriobotrya henryi",
		"eriobotrya",
		1581416
	],
	[
		"s3803475",
		"Eriobotrya hongiaoensis",
		"eriobotrya",
		3803475
	],
	[
		"s2024533",
		"Eriobotrya hookeriana",
		"eriobotrya",
		2024533
	],
	[
		"s32224",
		"Eriobotrya japonica",
		"eriobotrya",
		32224
	],
	[
		"s2741545",
		"Eriobotrya laoshanica",
		"eriobotrya",
		2741545
	],
	[
		"s3803476",
		"Eriobotrya latifolia",
		"eriobotrya",
		3803476
	],
	[
		"s3803477",
		"Eriobotrya longifolia",
		"eriobotrya",
		3803477
	],
	[
		"s3803478",
		"Eriobotrya macrocarpa",
		"eriobotrya",
		3803478
	],
	[
		"s589999",
		"Eriobotrya malipoensis",
		"eriobotrya",
		589999
	],
	[
		"s3803479",
		"Eriobotrya merguiensis",
		"eriobotrya",
		3803479
	],
	[
		"s1581417",
		"Eriobotrya obovata",
		"eriobotrya",
		1581417
	],
	[
		"s2024534",
		"Eriobotrya petiolata",
		"eriobotrya",
		2024534
	],
	[
		"s3803480",
		"Eriobotrya platyphylla",
		"eriobotrya",
		3803480
	],
	[
		"s3803481",
		"Eriobotrya poilanei",
		"eriobotrya",
		3803481
	],
	[
		"s269115",
		"Eriobotrya prinoides",
		"eriobotrya",
		269115
	],
	[
		"s2024535",
		"Eriobotrya salwinensis",
		"eriobotrya",
		2024535
	],
	[
		"s590000",
		"Eriobotrya seguinii",
		"eriobotrya",
		59e4
	],
	[
		"s1679318",
		"Eriobotrya serrata",
		"eriobotrya",
		1679318
	],
	[
		"s2762726",
		"Eriobotrya shanensis",
		"eriobotrya",
		2762726
	],
	[
		"s2905424",
		"Eriobotrya stipularis",
		"eriobotrya",
		2905424
	],
	[
		"s690339",
		"Eriobotrya tengyuehensis",
		"eriobotrya",
		690339
	],
	[
		"s3447178",
		"Eriobotrya tsiangii",
		"eriobotrya",
		3447178
	],
	[
		"s106552",
		"Eriolobus florentinus",
		"eriolobus",
		106552
	],
	[
		"s32225",
		"Exochorda giraldii",
		"exochorda",
		32225
	],
	[
		"s133206",
		"Exochorda racemosa",
		"exochorda",
		133206
	],
	[
		"s329225",
		"Exochorda serratifolia",
		"exochorda",
		329225
	],
	[
		"s35969",
		"Fallugia paradoxa",
		"fallugia",
		35969
	],
	[
		"s210861",
		"Farinopsis salesoviana",
		"farinopsis",
		210861
	],
	[
		"s2605017",
		"Fatoua madagascariensis",
		"fatoua",
		2605017
	],
	[
		"s241879",
		"Fatoua pilosa",
		"fatoua",
		241879
	],
	[
		"s66391",
		"Fatoua villosa",
		"fatoua",
		66391
	],
	[
		"s2682926",
		"Fenghwaia gardeniicarpa",
		"fenghwaia",
		2682926
	],
	[
		"s1045340",
		"Ficus abelii",
		"ficus",
		1045340
	],
	[
		"s3086818",
		"Ficus abscondita",
		"ficus",
		3086818
	],
	[
		"s309297",
		"Ficus abutilifolia",
		"ficus",
		309297
	],
	[
		"s665969",
		"Ficus acamptophylla",
		"ficus",
		665969
	],
	[
		"s3086819",
		"Ficus acreana",
		"ficus",
		3086819
	],
	[
		"s3086820",
		"Ficus aculeata",
		"ficus",
		3086820
	],
	[
		"s370339",
		"Ficus adelpha",
		"ficus",
		370339
	],
	[
		"s100537",
		"Ficus adenosperma",
		"ficus",
		100537
	],
	[
		"s463831",
		"Ficus adhatodifolia",
		"ficus",
		463831
	],
	[
		"s3086821",
		"Ficus adolphi-friderici",
		"ficus",
		3086821
	],
	[
		"s3807741",
		"Ficus aequatorialis",
		"ficus",
		3807741
	],
	[
		"s2984794",
		"Ficus aff. amadiensis QZ-2022",
		"ficus",
		2984794
	],
	[
		"s3048696",
		"Ficus aff. bukitrayaensis EG-2023",
		"ficus",
		3048696
	],
	[
		"s3048697",
		"Ficus aff. conocephalifolia EG-2023",
		"ficus",
		3048697
	],
	[
		"s3048698",
		"Ficus aff. crocata EG-2023",
		"ficus",
		3048698
	],
	[
		"s3048699",
		"Ficus aff. megaleia EG-2023",
		"ficus",
		3048699
	],
	[
		"s3048700",
		"Ficus aff. rubiginosa EG-2023",
		"ficus",
		3048700
	],
	[
		"s2984795",
		"Ficus aff. sansibarica QZ-2022",
		"ficus",
		2984795
	],
	[
		"s3048701",
		"Ficus aff. uncinata EG-2023",
		"ficus",
		3048701
	],
	[
		"s309275",
		"Ficus albert-smithii",
		"ficus",
		309275
	],
	[
		"s100539",
		"Ficus albipila",
		"ficus",
		100539
	],
	[
		"s3048712",
		"Ficus albomaculata",
		"ficus",
		3048712
	],
	[
		"s3086822",
		"Ficus allutacea",
		"ficus",
		3086822
	],
	[
		"s1506671",
		"Ficus alongensis",
		"ficus",
		1506671
	],
	[
		"s309270",
		"Ficus altissima",
		"ficus",
		309270
	],
	[
		"s378010",
		"Ficus amadiensis",
		"ficus",
		378010
	],
	[
		"s929588",
		"Ficus amazonica",
		"ficus",
		929588
	],
	[
		"s309276",
		"Ficus americana",
		"ficus",
		309276
	],
	[
		"s3048713",
		"Ficus ampana",
		"ficus",
		3048713
	],
	[
		"s66382",
		"Ficus ampelas",
		"ficus",
		66382
	],
	[
		"s479792",
		"Ficus amplissima",
		"ficus",
		479792
	],
	[
		"s1854048",
		"Ficus amplocarpa",
		"ficus",
		1854048
	],
	[
		"s3807742",
		"Ficus ampulliformis",
		"ficus",
		3807742
	],
	[
		"s1854049",
		"Ficus anamalayana",
		"ficus",
		1854049
	],
	[
		"s3086823",
		"Ficus anastomosans",
		"ficus",
		3086823
	],
	[
		"s3085924",
		"Ficus andamanica",
		"ficus",
		3085924
	],
	[
		"s309277",
		"Ficus andicola",
		"ficus",
		309277
	],
	[
		"s3048714",
		"Ficus androchaete",
		"ficus",
		3048714
	],
	[
		"s463832",
		"Ficus annulata",
		"ficus",
		463832
	],
	[
		"s2699261",
		"Ficus anserina",
		"ficus",
		2699261
	],
	[
		"s3048715",
		"Ficus antandronarum",
		"ficus",
		3048715
	],
	[
		"s463833",
		"Ficus apiocarpa",
		"ficus",
		463833
	],
	[
		"s3048716",
		"Ficus apollinaris",
		"ficus",
		3048716
	],
	[
		"s3086824",
		"Ficus araneosa",
		"ficus",
		3086824
	],
	[
		"s3807743",
		"Ficus arawaensis",
		"ficus",
		3807743
	],
	[
		"s478940",
		"Ficus arbuscula",
		"ficus",
		478940
	],
	[
		"s463834",
		"Ficus archboldiana",
		"ficus",
		463834
	],
	[
		"s3807744",
		"Ficus archeri",
		"ficus",
		3807744
	],
	[
		"s378011",
		"Ficus ardisioides",
		"ficus",
		378011
	],
	[
		"s370340",
		"Ficus arfakensis",
		"ficus",
		370340
	],
	[
		"s3086825",
		"Ficus aripuanensis",
		"ficus",
		3086825
	],
	[
		"s1506672",
		"Ficus arnottiana",
		"ficus",
		1506672
	],
	[
		"s2080476",
		"Ficus arpazusa",
		"ficus",
		2080476
	],
	[
		"s463835",
		"Ficus aspera",
		"ficus",
		463835
	],
	[
		"s182103",
		"Ficus asperifolia",
		"ficus",
		182103
	],
	[
		"s3807745",
		"Ficus asperiuscula",
		"ficus",
		3807745
	],
	[
		"s2789876",
		"Ficus asperrima",
		"ficus",
		2789876
	],
	[
		"s241880",
		"Ficus asperula",
		"ficus",
		241880
	],
	[
		"s3807746",
		"Ficus assamica",
		"ficus",
		3807746
	],
	[
		"s3048717",
		"Ficus assimilis",
		"ficus",
		3048717
	],
	[
		"s425832",
		"Ficus atricha",
		"ficus",
		425832
	],
	[
		"s460879",
		"Ficus augusta",
		"ficus",
		460879
	],
	[
		"s665971",
		"Ficus aurantiaca",
		"ficus",
		665971
	],
	[
		"s370344",
		"Ficus aurantiacafolia",
		"ficus",
		370344
	],
	[
		"s3807747",
		"Ficus aurantiacifolia",
		"ficus",
		3807747
	],
	[
		"s182104",
		"Ficus aurata",
		"ficus",
		182104
	],
	[
		"s463836",
		"Ficus aurea",
		"ficus",
		463836
	],
	[
		"s3807748",
		"Ficus aureocordata",
		"ficus",
		3807748
	],
	[
		"s3807749",
		"Ficus auricoma",
		"ficus",
		3807749
	],
	[
		"s100541",
		"Ficus auriculata",
		"ficus",
		100541
	],
	[
		"s3807750",
		"Ficus auriculigera",
		"ficus",
		3807750
	],
	[
		"s3048718",
		"Ficus aurita",
		"ficus",
		3048718
	],
	[
		"s3048719",
		"Ficus austrina",
		"ficus",
		3048719
	],
	[
		"s665972",
		"Ficus austrocaledonica",
		"ficus",
		665972
	],
	[
		"s3807751",
		"Ficus baccaureoides",
		"ficus",
		3807751
	],
	[
		"s463837",
		"Ficus badiopurpurea",
		"ficus",
		463837
	],
	[
		"s100542",
		"Ficus baeuerlenii",
		"ficus",
		100542
	],
	[
		"s2080477",
		"Ficus bahiensis",
		"ficus",
		2080477
	],
	[
		"s3086826",
		"Ficus bakeri",
		"ficus",
		3086826
	],
	[
		"s479336",
		"Ficus balete",
		"ficus",
		479336
	],
	[
		"s3807752",
		"Ficus balica",
		"ficus",
		3807752
	],
	[
		"s3086827",
		"Ficus bambusifolia",
		"ficus",
		3086827
	],
	[
		"s3807753",
		"Ficus banahaensis",
		"ficus",
		3807753
	],
	[
		"s3807754",
		"Ficus banosensis",
		"ficus",
		3807754
	],
	[
		"s929589",
		"Ficus baola",
		"ficus",
		929589
	],
	[
		"s2699264",
		"Ficus barba-jovis",
		"ficus",
		2699264
	],
	[
		"s3086050",
		"Ficus barclayana",
		"ficus",
		3086050
	],
	[
		"s3807755",
		"Ficus barraui",
		"ficus",
		3807755
	],
	[
		"s1191361",
		"Ficus barteri",
		"ficus",
		1191361
	],
	[
		"s3807756",
		"Ficus bataanensis",
		"ficus",
		3807756
	],
	[
		"s479793",
		"Ficus beccarii",
		"ficus",
		479793
	],
	[
		"s665973",
		"Ficus beddomei",
		"ficus",
		665973
	],
	[
		"s479794",
		"Ficus beipeiensis",
		"ficus",
		479794
	],
	[
		"s309271",
		"Ficus benghalensis",
		"ficus",
		309271
	],
	[
		"s546739",
		"Ficus benguetensis",
		"ficus",
		546739
	],
	[
		"s182105",
		"Ficus benjamina",
		"ficus",
		182105
	],
	[
		"s100543",
		"Ficus bernaysii",
		"ficus",
		100543
	],
	[
		"s3807757",
		"Ficus bhotanica",
		"ficus",
		3807757
	],
	[
		"s3807758",
		"Ficus biakensis",
		"ficus",
		3807758
	],
	[
		"s665974",
		"Ficus bibracteata",
		"ficus",
		665974
	],
	[
		"s182106",
		"Ficus binnendijkii",
		"ficus",
		182106
	],
	[
		"s3807759",
		"Ficus bistipulata",
		"ficus",
		3807759
	],
	[
		"s3086828",
		"Ficus bivalvata",
		"ficus",
		3086828
	],
	[
		"s378013",
		"Ficus bizanae",
		"ficus",
		378013
	],
	[
		"s3807760",
		"Ficus boanensis",
		"ficus",
		3807760
	],
	[
		"s3086829",
		"Ficus bojeri",
		"ficus",
		3086829
	],
	[
		"s3048720",
		"Ficus boliviana",
		"ficus",
		3048720
	],
	[
		"s1256986",
		"Ficus bonijesulapensis",
		"ficus",
		1256986
	],
	[
		"s546741",
		"Ficus boninsimae",
		"ficus",
		546741
	],
	[
		"s3086830",
		"Ficus borneensis",
		"ficus",
		3086830
	],
	[
		"s100544",
		"Ficus botryocarpa",
		"ficus",
		100544
	],
	[
		"s100545",
		"Ficus botryoides",
		"ficus",
		100545
	],
	[
		"s3086831",
		"Ficus bougainvillei",
		"ficus",
		3086831
	],
	[
		"s3048721",
		"Ficus brachyclada",
		"ficus",
		3048721
	],
	[
		"s459058",
		"Ficus brachypoda",
		"ficus",
		459058
	],
	[
		"s3048722",
		"Ficus bracteata",
		"ficus",
		3048722
	],
	[
		"s3086832",
		"Ficus brandegeei",
		"ficus",
		3086832
	],
	[
		"s3807761",
		"Ficus brenesii",
		"ficus",
		3807761
	],
	[
		"s3086833",
		"Ficus brevibracteata",
		"ficus",
		3086833
	],
	[
		"s3807762",
		"Ficus brittonii",
		"ficus",
		3807762
	],
	[
		"s309278",
		"Ficus broadwayi",
		"ficus",
		309278
	],
	[
		"s3048723",
		"Ficus bruneiensis",
		"ficus",
		3048723
	],
	[
		"s665975",
		"Ficus brunneoaurata",
		"ficus",
		665975
	],
	[
		"s3807763",
		"Ficus brusii",
		"ficus",
		3807763
	],
	[
		"s378014",
		"Ficus bubu",
		"ficus",
		378014
	],
	[
		"s1191350",
		"Ficus bukitrayaensis",
		"ficus",
		1191350
	],
	[
		"s323844",
		"Ficus bullenei",
		"ficus",
		323844
	],
	[
		"s3807764",
		"Ficus buntaensis",
		"ficus",
		3807764
	],
	[
		"s3086834",
		"Ficus burretiana",
		"ficus",
		3086834
	],
	[
		"s378015",
		"Ficus burtt-davyi",
		"ficus",
		378015
	],
	[
		"s1240868",
		"Ficus bussei",
		"ficus",
		1240868
	],
	[
		"s309303",
		"Ficus buxifolia",
		"ficus",
		309303
	],
	[
		"s2080478",
		"Ficus caatingae",
		"ficus",
		2080478
	],
	[
		"s309279",
		"Ficus caballina",
		"ficus",
		309279
	],
	[
		"s1136834",
		"Ficus cahuitensis",
		"ficus",
		1136834
	],
	[
		"s3086835",
		"Ficus calcarata",
		"ficus",
		3086835
	],
	[
		"s463839",
		"Ficus calcicola",
		"ficus",
		463839
	],
	[
		"s309280",
		"Ficus calimana",
		"ficus",
		309280
	],
	[
		"s479796",
		"Ficus callophylla",
		"ficus",
		479796
	],
	[
		"s182107",
		"Ficus callosa",
		"ficus",
		182107
	],
	[
		"s463840",
		"Ficus calopilina",
		"ficus",
		463840
	],
	[
		"s3086836",
		"Ficus calyculata",
		"ficus",
		3086836
	],
	[
		"s378016",
		"Ficus calyptrata",
		"ficus",
		378016
	],
	[
		"s2080479",
		"Ficus calyptroceras",
		"ficus",
		2080479
	],
	[
		"s3807765",
		"Ficus cambodica",
		"ficus",
		3807765
	],
	[
		"s3086837",
		"Ficus camptandra",
		"ficus",
		3086837
	],
	[
		"s3086838",
		"Ficus capillipes",
		"ficus",
		3086838
	],
	[
		"s1237584",
		"Ficus capreifolia",
		"ficus",
		1237584
	],
	[
		"s2080480",
		"Ficus carautana",
		"ficus",
		2080480
	],
	[
		"s1634501",
		"Ficus carchiana",
		"ficus",
		1634501
	],
	[
		"s1179227",
		"Ficus cardiophylla",
		"ficus",
		1179227
	],
	[
		"s3494",
		"Ficus carica",
		"ficus",
		3494
	],
	[
		"s2601404",
		"Ficus carica x Ficus erecta",
		"ficus",
		2601404
	],
	[
		"s3068434",
		"Ficus carica x Ficus palmata",
		"ficus",
		3068434
	],
	[
		"s3807766",
		"Ficus carinata",
		"ficus",
		3807766
	],
	[
		"s3807767",
		"Ficus carpentariensis",
		"ficus",
		3807767
	],
	[
		"s3807768",
		"Ficus carpenteriana",
		"ficus",
		3807768
	],
	[
		"s2699265",
		"Ficus carrii",
		"ficus",
		2699265
	],
	[
		"s3807769",
		"Ficus cartagenensis",
		"ficus",
		3807769
	],
	[
		"s3807770",
		"Ficus carvajalii",
		"ficus",
		3807770
	],
	[
		"s349050",
		"Ficus casapiensis",
		"ficus",
		349050
	],
	[
		"s479795",
		"Ficus casearioides",
		"ficus",
		479795
	],
	[
		"s3086839",
		"Ficus cassidyana",
		"ficus",
		3086839
	],
	[
		"s2080481",
		"Ficus castellviana",
		"ficus",
		2080481
	],
	[
		"s669030",
		"Ficus catappifolia",
		"ficus",
		669030
	],
	[
		"s1164946",
		"Ficus cataractorum",
		"ficus",
		1164946
	],
	[
		"s3807771",
		"Ficus cataupi",
		"ficus",
		3807771
	],
	[
		"s463841",
		"Ficus caulocarpa",
		"ficus",
		463841
	],
	[
		"s3807772",
		"Ficus cauta",
		"ficus",
		3807772
	],
	[
		"s2699266",
		"Ficus cavernicola",
		"ficus",
		2699266
	],
	[
		"s3086840",
		"Ficus celebensis",
		"ficus",
		3086840
	],
	[
		"s3086841",
		"Ficus cerasicarpa",
		"ficus",
		3086841
	],
	[
		"s3048724",
		"Ficus cereicarpa",
		"ficus",
		3048724
	],
	[
		"s309281",
		"Ficus cervantesiana",
		"ficus",
		309281
	],
	[
		"s309282",
		"Ficus cestrifolia",
		"ficus",
		309282
	],
	[
		"s3048702",
		"Ficus cf. archboldiana EG-2023",
		"ficus",
		3048702
	],
	[
		"s2518130",
		"Ficus cf. auriculata AYW-2019",
		"ficus",
		2518130
	],
	[
		"s3048704",
		"Ficus cf. crescentioides EG-2023",
		"ficus",
		3048704
	],
	[
		"s1927896",
		"Ficus cf. eximia CR-2016",
		"ficus",
		1927896
	],
	[
		"s1472336",
		"Ficus cf. eximia PEIC036",
		"ficus",
		1472336
	],
	[
		"s2072206",
		"Ficus cf. eximia PEIC140",
		"ficus",
		2072206
	],
	[
		"s3048703",
		"Ficus cf. fulva EG-2023",
		"ficus",
		3048703
	],
	[
		"s1924390",
		"Ficus cf. fulva sensu Zhou & Gilbert",
		"ficus",
		1924390
	],
	[
		"s3048705",
		"Ficus cf. grandiflora EG-2023",
		"ficus",
		3048705
	],
	[
		"s3413642",
		"Ficus cf. hispida",
		"ficus",
		3413642
	],
	[
		"s1170802",
		"Ficus cf. koutumensis LX-2012",
		"ficus",
		1170802
	],
	[
		"s1170803",
		"Ficus cf. oligodon LX-2012",
		"ficus",
		1170803
	],
	[
		"s1170804",
		"Ficus cf. pubigera LX-2012",
		"ficus",
		1170804
	],
	[
		"s3048706",
		"Ficus cf. recurva EG-2023",
		"ficus",
		3048706
	],
	[
		"s2213076",
		"Ficus cf. ruginervia AC-2018",
		"ficus",
		2213076
	],
	[
		"s3128288",
		"Ficus cf. sakalavarum",
		"ficus",
		3128288
	],
	[
		"s1341786",
		"Ficus cf. sarmentosa MR-2013",
		"ficus",
		1341786
	],
	[
		"s3048707",
		"Ficus cf. segoviae EG-2023",
		"ficus",
		3048707
	],
	[
		"s460877",
		"Ficus cf. sterrocarpa GW1126",
		"ficus",
		460877
	],
	[
		"s460878",
		"Ficus cf. sterrocarpa GW1881",
		"ficus",
		460878
	],
	[
		"s3048708",
		"Ficus cf. treubii EG-2023",
		"ficus",
		3048708
	],
	[
		"s3048709",
		"Ficus cf. trichocarpa EG-2023",
		"ficus",
		3048709
	],
	[
		"s2501712",
		"Ficus cf. trichocerasa SEM-2019",
		"ficus",
		2501712
	],
	[
		"s323841",
		"Ficus cf. trigonata CAM-2005",
		"ficus",
		323841
	],
	[
		"s2593300",
		"Ficus cf. trigonata JS-2019",
		"ficus",
		2593300
	],
	[
		"s1170805",
		"Ficus cf. tsiangii LX-2012",
		"ficus",
		1170805
	],
	[
		"s1170806",
		"Ficus cf. vasculosa LX-2012",
		"ficus",
		1170806
	],
	[
		"s3807773",
		"Ficus chaetostyla",
		"ficus",
		3807773
	],
	[
		"s1202530",
		"Ficus changii",
		"ficus",
		1202530
	],
	[
		"s665976",
		"Ficus chapaensis",
		"ficus",
		665976
	],
	[
		"s3807774",
		"Ficus chaparensis",
		"ficus",
		3807774
	],
	[
		"s3807775",
		"Ficus chaponensis",
		"ficus",
		3807775
	],
	[
		"s309428",
		"Ficus chartacea",
		"ficus",
		309428
	],
	[
		"s463842",
		"Ficus chiapensis",
		"ficus",
		463842
	],
	[
		"s1191351",
		"Ficus chirindensis",
		"ficus",
		1191351
	],
	[
		"s1191352",
		"Ficus chlamydocarpa",
		"ficus",
		1191352
	],
	[
		"s3086842",
		"Ficus christianii",
		"ficus",
		3086842
	],
	[
		"s3086843",
		"Ficus chrysochaete",
		"ficus",
		3086843
	],
	[
		"s463843",
		"Ficus chrysolepis",
		"ficus",
		463843
	],
	[
		"s3086844",
		"Ficus cinnamomea",
		"ficus",
		3086844
	],
	[
		"s309283",
		"Ficus citrifolia",
		"ficus",
		309283
	],
	[
		"s463844",
		"Ficus clusiifolia",
		"ficus",
		463844
	],
	[
		"s463845",
		"Ficus coerulescens",
		"ficus",
		463845
	],
	[
		"s3807776",
		"Ficus colobocarpa",
		"ficus",
		3807776
	],
	[
		"s323842",
		"Ficus colubrinae",
		"ficus",
		323842
	],
	[
		"s665977",
		"Ficus comitis",
		"ficus",
		665977
	],
	[
		"s3807777",
		"Ficus complexa",
		"ficus",
		3807777
	],
	[
		"s309265",
		"Ficus concinna",
		"ficus",
		309265
	],
	[
		"s182108",
		"Ficus condensa",
		"ficus",
		182108
	],
	[
		"s459059",
		"Ficus congensis",
		"ficus",
		459059
	],
	[
		"s309340",
		"Ficus congesta",
		"ficus",
		309340
	],
	[
		"s3239003",
		"Ficus conglobata",
		"ficus",
		3239003
	],
	[
		"s100546",
		"Ficus conocephalifolia",
		"ficus",
		100546
	],
	[
		"s378017",
		"Ficus conraui",
		"ficus",
		378017
	],
	[
		"s182109",
		"Ficus consociata",
		"ficus",
		182109
	],
	[
		"s100547",
		"Ficus copiosa",
		"ficus",
		100547
	],
	[
		"s309266",
		"Ficus cordata",
		"ficus",
		309266
	],
	[
		"s463846",
		"Ficus cordatula",
		"ficus",
		463846
	],
	[
		"s2516217",
		"Ficus cornelisiana",
		"ficus",
		2516217
	],
	[
		"s3807778",
		"Ficus corneri",
		"ficus",
		3807778
	],
	[
		"s3807779",
		"Ficus corneriana",
		"ficus",
		3807779
	],
	[
		"s309335",
		"Ficus coronata",
		"ficus",
		309335
	],
	[
		"s2563726",
		"Ficus coronulata",
		"ficus",
		2563726
	],
	[
		"s323845",
		"Ficus costaricana",
		"ficus",
		323845
	],
	[
		"s3035710",
		"Ficus costata",
		"ficus",
		3035710
	],
	[
		"s1475405",
		"Ficus cotinifolia",
		"ficus",
		1475405
	],
	[
		"s3086845",
		"Ficus cotopaxiensis",
		"ficus",
		3086845
	],
	[
		"s3807780",
		"Ficus crassicosta",
		"ficus",
		3807780
	],
	[
		"s883782",
		"Ficus crassinervia",
		"ficus",
		883782
	],
	[
		"s309321",
		"Ficus crassipes",
		"ficus",
		309321
	],
	[
		"s463847",
		"Ficus crassiramea",
		"ficus",
		463847
	],
	[
		"s3048727",
		"Ficus crassiuscula",
		"ficus",
		3048727
	],
	[
		"s665978",
		"Ficus crassivenosa",
		"ficus",
		665978
	],
	[
		"s3807781",
		"Ficus crateriformis",
		"ficus",
		3807781
	],
	[
		"s309304",
		"Ficus craterostoma",
		"ficus",
		309304
	],
	[
		"s3086846",
		"Ficus cremersii",
		"ficus",
		3086846
	],
	[
		"s378018",
		"Ficus crocata",
		"ficus",
		378018
	],
	[
		"s3807782",
		"Ficus cryptosyce",
		"ficus",
		3807782
	],
	[
		"s463848",
		"Ficus cucurbitina",
		"ficus",
		463848
	],
	[
		"s463849",
		"Ficus cumingii",
		"ficus",
		463849
	],
	[
		"s3086847",
		"Ficus cundinamarcensis",
		"ficus",
		3086847
	],
	[
		"s3807783",
		"Ficus cupulata",
		"ficus",
		3807783
	],
	[
		"s665979",
		"Ficus curtipes",
		"ficus",
		665979
	],
	[
		"s3086848",
		"Ficus cuspidata",
		"ficus",
		3086848
	],
	[
		"s378019",
		"Ficus cyathistipula",
		"ficus",
		378019
	],
	[
		"s182110",
		"Ficus cyathistipuloides",
		"ficus",
		182110
	],
	[
		"s2080482",
		"Ficus cyclophylla",
		"ficus",
		2080482
	],
	[
		"s3086849",
		"Ficus cynaroides",
		"ficus",
		3086849
	],
	[
		"s463850",
		"Ficus cyrtophylla",
		"ficus",
		463850
	],
	[
		"s1179228",
		"Ficus daimingshanensis",
		"ficus",
		1179228
	],
	[
		"s3807784",
		"Ficus dalbertisii",
		"ficus",
		3807784
	],
	[
		"s1854050",
		"Ficus dalhousiae",
		"ficus",
		1854050
	],
	[
		"s100548",
		"Ficus dammaropsis",
		"ficus",
		100548
	],
	[
		"s1191354",
		"Ficus davidsoniae",
		"ficus",
		1191354
	],
	[
		"s3807785",
		"Ficus decipiens",
		"ficus",
		3807785
	],
	[
		"s2516501",
		"Ficus delosyce",
		"ficus",
		2516501
	],
	[
		"s182111",
		"Ficus deltoidea",
		"ficus",
		182111
	],
	[
		"s3086850",
		"Ficus dendrocida",
		"ficus",
		3086850
	],
	[
		"s463851",
		"Ficus densifolia",
		"ficus",
		463851
	],
	[
		"s378020",
		"Ficus densistipulata",
		"ficus",
		378020
	],
	[
		"s3048728",
		"Ficus depressa",
		"ficus",
		3048728
	],
	[
		"s3807786",
		"Ficus desertorum",
		"ficus",
		3807786
	],
	[
		"s100549",
		"Ficus destruens",
		"ficus",
		100549
	],
	[
		"s3086851",
		"Ficus detonsa",
		"ficus",
		3086851
	],
	[
		"s3807787",
		"Ficus devestiens",
		"ficus",
		3807787
	],
	[
		"s1634502",
		"Ficus dewolfii",
		"ficus",
		1634502
	],
	[
		"s3807788",
		"Ficus diamantina",
		"ficus",
		3807788
	],
	[
		"s3807789",
		"Ficus diamantiphylla",
		"ficus",
		3807789
	],
	[
		"s3086852",
		"Ficus diandra",
		"ficus",
		3086852
	],
	[
		"s425833",
		"Ficus dicranostyla",
		"ficus",
		425833
	],
	[
		"s3807790",
		"Ficus dimorpha",
		"ficus",
		3807790
	],
	[
		"s2699267",
		"Ficus dinganensis",
		"ficus",
		2699267
	],
	[
		"s929590",
		"Ficus dissipata",
		"ficus",
		929590
	],
	[
		"s463852",
		"Ficus disticha",
		"ficus",
		463852
	],
	[
		"s3807791",
		"Ficus distichoidea",
		"ficus",
		3807791
	],
	[
		"s309332",
		"Ficus diversiformis",
		"ficus",
		309332
	],
	[
		"s3807792",
		"Ficus dodsonii",
		"ficus",
		3807792
	],
	[
		"s3086853",
		"Ficus donnell-smithii",
		"ficus",
		3086853
	],
	[
		"s309272",
		"Ficus drupacea",
		"ficus",
		309272
	],
	[
		"s378021",
		"Ficus dryepondtiana",
		"ficus",
		378021
	],
	[
		"s3086854",
		"Ficus duartei",
		"ficus",
		3086854
	],
	[
		"s3086855",
		"Ficus duckeana",
		"ficus",
		3086855
	],
	[
		"s323847",
		"Ficus dugandii",
		"ficus",
		323847
	],
	[
		"s2650249",
		"Ficus dulciaria",
		"ficus",
		2650249
	],
	[
		"s1118423",
		"Ficus dzumacensis",
		"ficus",
		1118423
	],
	[
		"s3086856",
		"Ficus ecuadorensis",
		"ficus",
		3086856
	],
	[
		"s3807793",
		"Ficus edanoi",
		"ficus",
		3807793
	],
	[
		"s100550",
		"Ficus edelfeltii",
		"ficus",
		100550
	],
	[
		"s182112",
		"Ficus elastica",
		"ficus",
		182112
	],
	[
		"s309311",
		"Ficus elasticoides",
		"ficus",
		309311
	],
	[
		"s3086857",
		"Ficus eliadis",
		"ficus",
		3086857
	],
	[
		"s2213071",
		"Ficus elmeri",
		"ficus",
		2213071
	],
	[
		"s3807794",
		"Ficus endochaete",
		"ficus",
		3807794
	],
	[
		"s479798",
		"Ficus endospermifolia",
		"ficus",
		479798
	],
	[
		"s2080483",
		"Ficus enormis",
		"ficus",
		2080483
	],
	[
		"s66383",
		"Ficus erecta",
		"ficus",
		66383
	],
	[
		"s3086858",
		"Ficus erinobotrya",
		"ficus",
		3086858
	],
	[
		"s380154",
		"Ficus erythrosperma",
		"ficus",
		380154
	],
	[
		"s665980",
		"Ficus esquiroliana",
		"ficus",
		665980
	],
	[
		"s309284",
		"Ficus eugeniifolia",
		"ficus",
		309284
	],
	[
		"s463853",
		"Ficus eumorpha",
		"ficus",
		463853
	],
	[
		"s3807795",
		"Ficus eustephana",
		"ficus",
		3807795
	],
	[
		"s459060",
		"Ficus exasperata",
		"ficus",
		459060
	],
	[
		"s2699268",
		"Ficus excavata",
		"ficus",
		2699268
	],
	[
		"s309285",
		"Ficus eximia",
		"ficus",
		309285
	],
	[
		"s378022",
		"Ficus faulkneriana",
		"ficus",
		378022
	],
	[
		"s3807796",
		"Ficus fengkaiensis",
		"ficus",
		3807796
	],
	[
		"s3036240",
		"Ficus fergusonii",
		"ficus",
		3036240
	],
	[
		"s2024439",
		"Ficus filicauda",
		"ficus",
		2024439
	],
	[
		"s378023",
		"Ficus fischeri",
		"ficus",
		378023
	],
	[
		"s463854",
		"Ficus fiskei",
		"ficus",
		463854
	],
	[
		"s309341",
		"Ficus fistulosa",
		"ficus",
		309341
	],
	[
		"s3807797",
		"Ficus flagellaris",
		"ficus",
		3807797
	],
	[
		"s3807798",
		"Ficus flavistipulata",
		"ficus",
		3807798
	],
	[
		"s3807799",
		"Ficus floccifera",
		"ficus",
		3807799
	],
	[
		"s3807800",
		"Ficus floresana",
		"ficus",
		3807800
	],
	[
		"s1127366",
		"Ficus formosana",
		"ficus",
		1127366
	],
	[
		"s479799",
		"Ficus forstenii",
		"ficus",
		479799
	],
	[
		"s3048729",
		"Ficus francisci",
		"ficus",
		3048729
	],
	[
		"s3086859",
		"Ficus francoae",
		"ficus",
		3086859
	],
	[
		"s665981",
		"Ficus fraseri",
		"ficus",
		665981
	],
	[
		"s247355",
		"Ficus fulva",
		"ficus",
		247355
	],
	[
		"s3086860",
		"Ficus fulvopilosa",
		"ficus",
		3086860
	],
	[
		"s3807801",
		"Ficus funiculicaulis",
		"ficus",
		3807801
	],
	[
		"s3086861",
		"Ficus funiculosa",
		"ficus",
		3086861
	],
	[
		"s3807802",
		"Ficus fuscata",
		"ficus",
		3807802
	],
	[
		"s3807803",
		"Ficus fusuiensis",
		"ficus",
		3807803
	],
	[
		"s3807804",
		"Ficus gamostyla",
		"ficus",
		3807804
	],
	[
		"s3807805",
		"Ficus garcia-barrigae",
		"ficus",
		3807805
	],
	[
		"s1045341",
		"Ficus gasparriniana",
		"ficus",
		1045341
	],
	[
		"s1506673",
		"Ficus geniculata",
		"ficus",
		1506673
	],
	[
		"s2990819",
		"Ficus geocharis",
		"ficus",
		2990819
	],
	[
		"s3807806",
		"Ficus gibbsiae",
		"ficus",
		3807806
	],
	[
		"s2213072",
		"Ficus gigantifolia",
		"ficus",
		2213072
	],
	[
		"s1634503",
		"Ficus gigantosyce",
		"ficus",
		1634503
	],
	[
		"s3807807",
		"Ficus gilapong",
		"ficus",
		3807807
	],
	[
		"s1191455",
		"Ficus glabella",
		"ficus",
		1191455
	],
	[
		"s479800",
		"Ficus glaberrima",
		"ficus",
		479800
	],
	[
		"s2994427",
		"Ficus glabrata x Ficus maxima",
		"ficus",
		2994427
	],
	[
		"s3807808",
		"Ficus glabristipulata",
		"ficus",
		3807808
	],
	[
		"s309322",
		"Ficus glandifera",
		"ficus",
		309322
	],
	[
		"s463855",
		"Ficus glandulifera",
		"ficus",
		463855
	],
	[
		"s3086862",
		"Ficus glareosa",
		"ficus",
		3086862
	],
	[
		"s479801",
		"Ficus globosa",
		"ficus",
		479801
	],
	[
		"s182114",
		"Ficus glumosa",
		"ficus",
		182114
	],
	[
		"s3086863",
		"Ficus godeffroyi",
		"ficus",
		3086863
	],
	[
		"s2080484",
		"Ficus goiana",
		"ficus",
		2080484
	],
	[
		"s309286",
		"Ficus goldmanii",
		"ficus",
		309286
	],
	[
		"s309287",
		"Ficus gomelleira",
		"ficus",
		309287
	],
	[
		"s3807809",
		"Ficus goniophylla",
		"ficus",
		3807809
	],
	[
		"s3807810",
		"Ficus gorontaloensis",
		"ficus",
		3807810
	],
	[
		"s3807811",
		"Ficus gracillima",
		"ficus",
		3807811
	],
	[
		"s1118424",
		"Ficus granatum",
		"ficus",
		1118424
	],
	[
		"s3048726",
		"Ficus grandiflora",
		"ficus",
		3048726
	],
	[
		"s3807812",
		"Ficus gratiosa",
		"ficus",
		3807812
	],
	[
		"s3086864",
		"Ficus greenwoodii",
		"ficus",
		3086864
	],
	[
		"s3086865",
		"Ficus grevei",
		"ficus",
		3086865
	],
	[
		"s665982",
		"Ficus grewiifolia",
		"ficus",
		665982
	],
	[
		"s3807813",
		"Ficus griffithii",
		"ficus",
		3807813
	],
	[
		"s100551",
		"Ficus grossularioides",
		"ficus",
		100551
	],
	[
		"s3807814",
		"Ficus gryllus",
		"ficus",
		3807814
	],
	[
		"s3086866",
		"Ficus guajavoides",
		"ficus",
		3086866
	],
	[
		"s3807815",
		"Ficus guangxiensis",
		"ficus",
		3807815
	],
	[
		"s1924186",
		"Ficus guaranitica",
		"ficus",
		1924186
	],
	[
		"s3086867",
		"Ficus guatiquiae",
		"ficus",
		3086867
	],
	[
		"s3807816",
		"Ficus guayaquilensis",
		"ficus",
		3807816
	],
	[
		"s2699269",
		"Ficus guizhouensis",
		"ficus",
		2699269
	],
	[
		"s309336",
		"Ficus gul",
		"ficus",
		309336
	],
	[
		"s1854051",
		"Ficus guttata",
		"ficus",
		1854051
	],
	[
		"s3086868",
		"Ficus gymnorygma",
		"ficus",
		3086868
	],
	[
		"s241881",
		"Ficus habrophylla",
		"ficus",
		241881
	],
	[
		"s479802",
		"Ficus hadroneura",
		"ficus",
		479802
	],
	[
		"s1769805",
		"Ficus hahliana",
		"ficus",
		1769805
	],
	[
		"s3807817",
		"Ficus halmaherae",
		"ficus",
		3807817
	],
	[
		"s1926628",
		"Ficus hartwegii",
		"ficus",
		1926628
	],
	[
		"s3807818",
		"Ficus hatschbachii",
		"ficus",
		3807818
	],
	[
		"s3086869",
		"Ficus hebetifolia",
		"ficus",
		3086869
	],
	[
		"s1179229",
		"Ficus hederacea",
		"ficus",
		1179229
	],
	[
		"s665983",
		"Ficus hemsleyana",
		"ficus",
		665983
	],
	[
		"s1506677",
		"Ficus henneana",
		"ficus",
		1506677
	],
	[
		"s463856",
		"Ficus henryi",
		"ficus",
		463856
	],
	[
		"s100552",
		"Ficus hesperidiiformis",
		"ficus",
		100552
	],
	[
		"s460882",
		"Ficus heteromeka",
		"ficus",
		460882
	],
	[
		"s1045344",
		"Ficus heteromorpha",
		"ficus",
		1045344
	],
	[
		"s194259",
		"Ficus heterophylla",
		"ficus",
		194259
	],
	[
		"s309337",
		"Ficus heteropleura",
		"ficus",
		309337
	],
	[
		"s665984",
		"Ficus heteropoda",
		"ficus",
		665984
	],
	[
		"s3807819",
		"Ficus heteroselis",
		"ficus",
		3807819
	],
	[
		"s1191356",
		"Ficus heterostyla",
		"ficus",
		1191356
	],
	[
		"s1924187",
		"Ficus hirsuta",
		"ficus",
		1924187
	],
	[
		"s309429",
		"Ficus hirta",
		"ficus",
		309429
	],
	[
		"s462830",
		"Ficus hispida",
		"ficus",
		462830
	],
	[
		"s100553",
		"Ficus hispidioides",
		"ficus",
		100553
	],
	[
		"s2080485",
		"Ficus holosericea",
		"ficus",
		2080485
	],
	[
		"s100554",
		"Ficus hombroniana",
		"ficus",
		100554
	],
	[
		"s1136835",
		"Ficus hondurensis",
		"ficus",
		1136835
	],
	[
		"s665985",
		"Ficus hookeriana",
		"ficus",
		665985
	],
	[
		"s2930498",
		"Ficus howii",
		"ficus",
		2930498
	],
	[
		"s3048730",
		"Ficus humbertii",
		"ficus",
		3048730
	],
	[
		"s3807820",
		"Ficus hurlimannii",
		"ficus",
		3807820
	],
	[
		"s3807821",
		"Ficus hypobrunnea",
		"ficus",
		3807821
	],
	[
		"s3086870",
		"Ficus hypophaea",
		"ficus",
		3086870
	],
	[
		"s3807822",
		"Ficus hystricicarpa",
		"ficus",
		3807822
	],
	[
		"s3086871",
		"Ficus ihuensis",
		"ficus",
		3086871
	],
	[
		"s1127369",
		"Ficus iidana",
		"ficus",
		1127369
	],
	[
		"s3807823",
		"Ficus ilias-paiei",
		"ficus",
		3807823
	],
	[
		"s672070",
		"Ficus ilicina",
		"ficus",
		672070
	],
	[
		"s3807824",
		"Ficus illiberalis",
		"ficus",
		3807824
	],
	[
		"s3086872",
		"Ficus imbricata",
		"ficus",
		3086872
	],
	[
		"s3807825",
		"Ficus immanis",
		"ficus",
		3807825
	],
	[
		"s3807826",
		"Ficus inaequifolia",
		"ficus",
		3807826
	],
	[
		"s3048731",
		"Ficus inaequipetiolata",
		"ficus",
		3048731
	],
	[
		"s3086873",
		"Ficus indigofera",
		"ficus",
		3086873
	],
	[
		"s309268",
		"Ficus ingens",
		"ficus",
		309268
	],
	[
		"s3086874",
		"Ficus insculpta",
		"ficus",
		3086874
	],
	[
		"s100555",
		"Ficus insipida",
		"ficus",
		100555
	],
	[
		"s3807827",
		"Ficus intramarginalis",
		"ficus",
		3807827
	],
	[
		"s3086875",
		"Ficus involucrata",
		"ficus",
		3086875
	],
	[
		"s479803",
		"Ficus iodotricha",
		"ficus",
		479803
	],
	[
		"s546738",
		"Ficus irisana",
		"ficus",
		546738
	],
	[
		"s309329",
		"Ficus ischnopoda",
		"ficus",
		309329
	],
	[
		"s1191357",
		"Ficus isophlebia",
		"ficus",
		1191357
	],
	[
		"s100556",
		"Ficus itoana",
		"ficus",
		100556
	],
	[
		"s3086876",
		"Ficus ixoroides",
		"ficus",
		3086876
	],
	[
		"s3086877",
		"Ficus jacobii",
		"ficus",
		3086877
	],
	[
		"s3807828",
		"Ficus jacobsii",
		"ficus",
		3807828
	],
	[
		"s3807829",
		"Ficus jaheriana",
		"ficus",
		3807829
	],
	[
		"s3807830",
		"Ficus jambiensis",
		"ficus",
		3807830
	],
	[
		"s669031",
		"Ficus jansii",
		"ficus",
		669031
	],
	[
		"s3807831",
		"Ficus jaramilloi",
		"ficus",
		3807831
	],
	[
		"s3807832",
		"Ficus jarawae",
		"ficus",
		3807832
	],
	[
		"s665986",
		"Ficus jimenezii",
		"ficus",
		665986
	],
	[
		"s348855",
		"Ficus jimiensis",
		"ficus",
		348855
	],
	[
		"s309330",
		"Ficus johannis",
		"ficus",
		309330
	],
	[
		"s3807833",
		"Ficus juglandiformis",
		"ficus",
		3807833
	],
	[
		"s3807834",
		"Ficus kalimantana",
		"ficus",
		3807834
	],
	[
		"s2708838",
		"Ficus kamerunensis",
		"ficus",
		2708838
	],
	[
		"s3807835",
		"Ficus karthalensis",
		"ficus",
		3807835
	],
	[
		"s3807836",
		"Ficus katendei",
		"ficus",
		3807836
	],
	[
		"s3048732",
		"Ficus kerkhovenii",
		"ficus",
		3048732
	],
	[
		"s309305",
		"Ficus kiloneura",
		"ficus",
		309305
	],
	[
		"s3807837",
		"Ficus kjellbergii",
		"ficus",
		3807837
	],
	[
		"s463857",
		"Ficus kochummeniana",
		"ficus",
		463857
	],
	[
		"s3807838",
		"Ficus kofmaniae",
		"ficus",
		3807838
	],
	[
		"s479804",
		"Ficus koutumensis",
		"ficus",
		479804
	],
	[
		"s1634504",
		"Ficus krugiana",
		"ficus",
		1634504
	],
	[
		"s463858",
		"Ficus krukovii",
		"ficus",
		463858
	],
	[
		"s3807839",
		"Ficus kuchinensis",
		"ficus",
		3807839
	],
	[
		"s3086878",
		"Ficus kurzii",
		"ficus",
		3086878
	],
	[
		"s66384",
		"Ficus lacor",
		"ficus",
		66384
	],
	[
		"s3086879",
		"Ficus lacunata",
		"ficus",
		3086879
	],
	[
		"s3807840",
		"Ficus laevicarpa",
		"ficus",
		3807840
	],
	[
		"s472860",
		"Ficus laevigata",
		"ficus",
		472860
	],
	[
		"s1179230",
		"Ficus laevis",
		"ficus",
		1179230
	],
	[
		"s2080486",
		"Ficus lagoensis",
		"ficus",
		2080486
	],
	[
		"s3048733",
		"Ficus lamponga",
		"ficus",
		3048733
	],
	[
		"s1192758",
		"Ficus lanata",
		"ficus",
		1192758
	],
	[
		"s3807841",
		"Ficus lancibracteata",
		"ficus",
		3807841
	],
	[
		"s744260",
		"Ficus langkokensis",
		"ficus",
		744260
	],
	[
		"s463859",
		"Ficus lapathifolia",
		"ficus",
		463859
	],
	[
		"s3086880",
		"Ficus lasiocarpa",
		"ficus",
		3086880
	],
	[
		"s3807842",
		"Ficus lasiosyce",
		"ficus",
		3807842
	],
	[
		"s182115",
		"Ficus lateriflora",
		"ficus",
		182115
	],
	[
		"s3807843",
		"Ficus latimarginata",
		"ficus",
		3807843
	],
	[
		"s3807844",
		"Ficus latipedunculata",
		"ficus",
		3807844
	],
	[
		"s2080487",
		"Ficus laureola",
		"ficus",
		2080487
	],
	[
		"s3086881",
		"Ficus lauretana",
		"ficus",
		3086881
	],
	[
		"s2213074",
		"Ficus laurifolia",
		"ficus",
		2213074
	],
	[
		"s1191358",
		"Ficus lawesii",
		"ficus",
		1191358
	],
	[
		"s3807845",
		"Ficus lawrancei",
		"ficus",
		3807845
	],
	[
		"s1506678",
		"Ficus lecardii",
		"ficus",
		1506678
	],
	[
		"s3807846",
		"Ficus lehmannii",
		"ficus",
		3807846
	],
	[
		"s3086051",
		"Ficus leiocarpa",
		"ficus",
		3086051
	],
	[
		"s3086882",
		"Ficus leiophylla",
		"ficus",
		3086882
	],
	[
		"s3086883",
		"Ficus leonensis",
		"ficus",
		3086883
	],
	[
		"s309430",
		"Ficus lepicarpa",
		"ficus",
		309430
	],
	[
		"s3086884",
		"Ficus leptocalama",
		"ficus",
		3086884
	],
	[
		"s1312811",
		"Ficus leptoclada",
		"ficus",
		1312811
	],
	[
		"s3807847",
		"Ficus leptodictya",
		"ficus",
		3807847
	],
	[
		"s3807848",
		"Ficus leptogramma",
		"ficus",
		3807848
	],
	[
		"s309323",
		"Ficus leucotricha",
		"ficus",
		309323
	],
	[
		"s3807849",
		"Ficus lidaoprostrata",
		"ficus",
		3807849
	],
	[
		"s1118426",
		"Ficus lifouensis",
		"ficus",
		1118426
	],
	[
		"s460883",
		"Ficus lilliputiana",
		"ficus",
		460883
	],
	[
		"s3807850",
		"Ficus limosa",
		"ficus",
		3807850
	],
	[
		"s3807851",
		"Ficus lindsayana",
		"ficus",
		3807851
	],
	[
		"s3086885",
		"Ficus linearifolia",
		"ficus",
		3086885
	],
	[
		"s309306",
		"Ficus lingua",
		"ficus",
		309306
	],
	[
		"s3086886",
		"Ficus litseifolia",
		"ficus",
		3086886
	],
	[
		"s3807852",
		"Ficus longecuspidata",
		"ficus",
		3807852
	],
	[
		"s3086887",
		"Ficus longibracteata",
		"ficus",
		3086887
	],
	[
		"s479805",
		"Ficus longifolia",
		"ficus",
		479805
	],
	[
		"s3807853",
		"Ficus longistipulata",
		"ficus",
		3807853
	],
	[
		"s1191359",
		"Ficus louisii",
		"ficus",
		1191359
	],
	[
		"s3048734",
		"Ficus lowii",
		"ficus",
		3048734
	],
	[
		"s3086888",
		"Ficus loxensis",
		"ficus",
		3086888
	],
	[
		"s3807854",
		"Ficus lumutana",
		"ficus",
		3807854
	],
	[
		"s309288",
		"Ficus luschnathiana",
		"ficus",
		309288
	],
	[
		"s182116",
		"Ficus lutea",
		"ficus",
		182116
	],
	[
		"s309312",
		"Ficus lyrata",
		"ficus",
		309312
	],
	[
		"s1568996",
		"Ficus macbridei",
		"ficus",
		1568996
	],
	[
		"s3807855",
		"Ficus machetana",
		"ficus",
		3807855
	],
	[
		"s3807856",
		"Ficus machupicchuensis",
		"ficus",
		3807856
	],
	[
		"s3048735",
		"Ficus macilenta",
		"ficus",
		3048735
	],
	[
		"s463860",
		"Ficus maclellandii",
		"ficus",
		463860
	],
	[
		"s182117",
		"Ficus macrophylla",
		"ficus",
		182117
	],
	[
		"s3807857",
		"Ficus macropodocarpa",
		"ficus",
		3807857
	],
	[
		"s479806",
		"Ficus macrorrhyncha",
		"ficus",
		479806
	],
	[
		"s3048736",
		"Ficus macrostyla",
		"ficus",
		3048736
	],
	[
		"s1634505",
		"Ficus macrosyce",
		"ficus",
		1634505
	],
	[
		"s3807858",
		"Ficus macrothyrsa",
		"ficus",
		3807858
	],
	[
		"s1506679",
		"Ficus madagascariensis",
		"ficus",
		1506679
	],
	[
		"s463861",
		"Ficus magnoliifolia",
		"ficus",
		463861
	],
	[
		"s3807859",
		"Ficus magwana",
		"ficus",
		3807859
	],
	[
		"s3086889",
		"Ficus maialis",
		"ficus",
		3086889
	],
	[
		"s3086890",
		"Ficus maitin",
		"ficus",
		3086890
	],
	[
		"s2022612",
		"Ficus malayana",
		"ficus",
		2022612
	],
	[
		"s3807860",
		"Ficus manuselensis",
		"ficus",
		3807860
	],
	[
		"s2080488",
		"Ficus mariae",
		"ficus",
		2080488
	],
	[
		"s3048737",
		"Ficus marmorata",
		"ficus",
		3048737
	],
	[
		"s3086891",
		"Ficus maroma",
		"ficus",
		3086891
	],
	[
		"s665987",
		"Ficus maroniensis",
		"ficus",
		665987
	],
	[
		"s3086892",
		"Ficus masonii",
		"ficus",
		3086892
	],
	[
		"s1164947",
		"Ficus matanoensis",
		"ficus",
		1164947
	],
	[
		"s2080489",
		"Ficus mathewsii",
		"ficus",
		2080489
	],
	[
		"s3086893",
		"Ficus matiziana",
		"ficus",
		3086893
	],
	[
		"s182118",
		"Ficus mauritiana",
		"ficus",
		182118
	],
	[
		"s100557",
		"Ficus maxima",
		"ficus",
		100557
	],
	[
		"s2994428",
		"Ficus maxima x Ficus yoponensis",
		"ficus",
		2994428
	],
	[
		"s3086894",
		"Ficus maximoides",
		"ficus",
		3086894
	],
	[
		"s479807",
		"Ficus megaleia",
		"ficus",
		479807
	],
	[
		"s3807861",
		"Ficus megalophylla",
		"ficus",
		3807861
	],
	[
		"s479808",
		"Ficus melinocarpa",
		"ficus",
		479808
	],
	[
		"s3086895",
		"Ficus membranacea",
		"ficus",
		3086895
	],
	[
		"s309273",
		"Ficus menabeensis",
		"ficus",
		309273
	],
	[
		"s3086896",
		"Ficus merrittii",
		"ficus",
		3086896
	],
	[
		"s2080490",
		"Ficus mexiae",
		"ficus",
		2080490
	],
	[
		"s1634506",
		"Ficus mexicana",
		"ficus",
		1634506
	],
	[
		"s66385",
		"Ficus microcarpa",
		"ficus",
		66385
	],
	[
		"s100558",
		"Ficus microdictya",
		"ficus",
		100558
	],
	[
		"s3086897",
		"Ficus microsphaera",
		"ficus",
		3086897
	],
	[
		"s3807862",
		"Ficus microsyce",
		"ficus",
		3807862
	],
	[
		"s3807863",
		"Ficus microtophora",
		"ficus",
		3807863
	],
	[
		"s1506680",
		"Ficus middletonii",
		"ficus",
		1506680
	],
	[
		"s2306770",
		"Ficus midotis",
		"ficus",
		2306770
	],
	[
		"s478941",
		"Ficus minahassae",
		"ficus",
		478941
	],
	[
		"s3807864",
		"Ficus miqueliana",
		"ficus",
		3807864
	],
	[
		"s3086898",
		"Ficus mollicula",
		"ficus",
		3086898
	],
	[
		"s182119",
		"Ficus mollior",
		"ficus",
		182119
	],
	[
		"s2767351",
		"Ficus mollis",
		"ficus",
		2767351
	],
	[
		"s3807865",
		"Ficus mollissima",
		"ficus",
		3807865
	],
	[
		"s300183",
		"Ficus montana",
		"ficus",
		300183
	],
	[
		"s665988",
		"Ficus morazaniana",
		"ficus",
		665988
	],
	[
		"s370341",
		"Ficus morobensis",
		"ficus",
		370341
	],
	[
		"s2952874",
		"Ficus motuoensis",
		"ficus",
		2952874
	],
	[
		"s309328",
		"Ficus mucuso",
		"ficus",
		309328
	],
	[
		"s3807866",
		"Ficus muelleriana",
		"ficus",
		3807866
	],
	[
		"s3807867",
		"Ficus multistipularis",
		"ficus",
		3807867
	],
	[
		"s2930494",
		"Ficus muricata",
		"ficus",
		2930494
	],
	[
		"s3807868",
		"Ficus mutabilis",
		"ficus",
		3807868
	],
	[
		"s1634507",
		"Ficus mutisii",
		"ficus",
		1634507
	],
	[
		"s3807869",
		"Ficus myiopotamica",
		"ficus",
		3807869
	],
	[
		"s3807870",
		"Ficus nana",
		"ficus",
		3807870
	],
	[
		"s2699270",
		"Ficus napoensis",
		"ficus",
		2699270
	],
	[
		"s309333",
		"Ficus nasuta",
		"ficus",
		309333
	],
	[
		"s309307",
		"Ficus natalensis",
		"ficus",
		309307
	],
	[
		"s666378",
		"Ficus neriifolia",
		"ficus",
		666378
	],
	[
		"s463862",
		"Ficus nervosa",
		"ficus",
		463862
	],
	[
		"s2080491",
		"Ficus nevesiae",
		"ficus",
		2080491
	],
	[
		"s3807871",
		"Ficus nhatrangensis",
		"ficus",
		3807871
	],
	[
		"s378024",
		"Ficus nigropunctata",
		"ficus",
		378024
	],
	[
		"s546742",
		"Ficus nishimurae",
		"ficus",
		546742
	],
	[
		"s665989",
		"Ficus nitidifolia",
		"ficus",
		665989
	],
	[
		"s100559",
		"Ficus nodosa",
		"ficus",
		100559
	],
	[
		"s479337",
		"Ficus nota",
		"ficus",
		479337
	],
	[
		"s3086899",
		"Ficus novae-georgiae",
		"ficus",
		3086899
	],
	[
		"s3807872",
		"Ficus novahibernica",
		"ficus",
		3807872
	],
	[
		"s182120",
		"Ficus nymphaeifolia",
		"ficus",
		182120
	],
	[
		"s460884",
		"Ficus obliqua",
		"ficus",
		460884
	],
	[
		"s479809",
		"Ficus obpyramidata",
		"ficus",
		479809
	],
	[
		"s479810",
		"Ficus obscura",
		"ficus",
		479810
	],
	[
		"s309290",
		"Ficus obtusifolia",
		"ficus",
		309290
	],
	[
		"s665990",
		"Ficus obtusiuscula",
		"ficus",
		665990
	],
	[
		"s100560",
		"Ficus ochrochlora",
		"ficus",
		100560
	],
	[
		"s3086900",
		"Ficus ocoana",
		"ficus",
		3086900
	],
	[
		"s100561",
		"Ficus odoardi",
		"ficus",
		100561
	],
	[
		"s3807873",
		"Ficus odorata",
		"ficus",
		3807873
	],
	[
		"s309426",
		"Ficus oleifolia",
		"ficus",
		309426
	],
	[
		"s3086901",
		"Ficus oleracea",
		"ficus",
		3086901
	],
	[
		"s665991",
		"Ficus oligodon",
		"ficus",
		665991
	],
	[
		"s466930",
		"Ficus opposita",
		"ficus",
		466930
	],
	[
		"s378025",
		"Ficus oreodryadum",
		"ficus",
		378025
	],
	[
		"s3086902",
		"Ficus oreophila",
		"ficus",
		3086902
	],
	[
		"s3807874",
		"Ficus oresbia",
		"ficus",
		3807874
	],
	[
		"s1924188",
		"Ficus organensis",
		"ficus",
		1924188
	],
	[
		"s3807875",
		"Ficus orocuensis",
		"ficus",
		3807875
	],
	[
		"s463863",
		"Ficus orthoneura",
		"ficus",
		463863
	],
	[
		"s3086903",
		"Ficus osensis",
		"ficus",
		3086903
	],
	[
		"s1164948",
		"Ficus otophora",
		"ficus",
		1164948
	],
	[
		"s3086904",
		"Ficus otophoroides",
		"ficus",
		3086904
	],
	[
		"s309317",
		"Ficus ottoniifolia",
		"ficus",
		309317
	],
	[
		"s1136836",
		"Ficus ovalis",
		"ficus",
		1136836
	],
	[
		"s378026",
		"Ficus ovata",
		"ficus",
		378026
	],
	[
		"s3086905",
		"Ficus oxymitroides",
		"ficus",
		3086905
	],
	[
		"s1867292",
		"Ficus pachyclada",
		"ficus",
		1867292
	],
	[
		"s3807876",
		"Ficus pachyneura",
		"ficus",
		3807876
	],
	[
		"s370342",
		"Ficus pachyrrhachis",
		"ficus",
		370342
	],
	[
		"s309427",
		"Ficus pachystemon",
		"ficus",
		309427
	],
	[
		"s3807877",
		"Ficus pachysycia",
		"ficus",
		3807877
	],
	[
		"s100562",
		"Ficus padana",
		"ficus",
		100562
	],
	[
		"s2100052",
		"Ficus pakkensis",
		"ficus",
		2100052
	],
	[
		"s3807878",
		"Ficus pallescens",
		"ficus",
		3807878
	],
	[
		"s3086906",
		"Ficus pallida",
		"ficus",
		3086906
	],
	[
		"s3807879",
		"Ficus palmarensis",
		"ficus",
		3807879
	],
	[
		"s309331",
		"Ficus palmata",
		"ficus",
		309331
	],
	[
		"s309291",
		"Ficus palmeri",
		"ficus",
		309291
	],
	[
		"s669034",
		"Ficus paludica",
		"ficus",
		669034
	],
	[
		"s1164949",
		"Ficus pancheriana",
		"ficus",
		1164949
	],
	[
		"s1009471",
		"Ficus pandurata",
		"ficus",
		1009471
	],
	[
		"s479811",
		"Ficus pantoniana",
		"ficus",
		479811
	],
	[
		"s3086907",
		"Ficus panurensis",
		"ficus",
		3086907
	],
	[
		"s3807880",
		"Ficus paoana",
		"ficus",
		3807880
	],
	[
		"s3086908",
		"Ficus papuana",
		"ficus",
		3086908
	],
	[
		"s463864",
		"Ficus paracamptophylla",
		"ficus",
		463864
	],
	[
		"s309292",
		"Ficus paraensis",
		"ficus",
		309292
	],
	[
		"s182121",
		"Ficus parietalis",
		"ficus",
		182121
	],
	[
		"s3807881",
		"Ficus parvibracteata",
		"ficus",
		3807881
	],
	[
		"s3807882",
		"Ficus pastasana",
		"ficus",
		3807882
	],
	[
		"s3807883",
		"Ficus patellata",
		"ficus",
		3807883
	],
	[
		"s1127370",
		"Ficus pedunculosa",
		"ficus",
		1127370
	],
	[
		"s100563",
		"Ficus pellucidopunctata",
		"ficus",
		100563
	],
	[
		"s2699271",
		"Ficus pendens",
		"ficus",
		2699271
	],
	[
		"s3807884",
		"Ficus perfulva",
		"ficus",
		3807884
	],
	[
		"s2024441",
		"Ficus periptera",
		"ficus",
		2024441
	],
	[
		"s100564",
		"Ficus pertusa",
		"ficus",
		100564
	],
	[
		"s309309",
		"Ficus petersii",
		"ficus",
		309309
	],
	[
		"s309294",
		"Ficus petiolaris",
		"ficus",
		309294
	],
	[
		"s3807885",
		"Ficus phaeobullata",
		"ficus",
		3807885
	],
	[
		"s100565",
		"Ficus phaeosyce",
		"ficus",
		100565
	],
	[
		"s3807886",
		"Ficus phanrangensis",
		"ficus",
		3807886
	],
	[
		"s3807887",
		"Ficus phatnophylla",
		"ficus",
		3807887
	],
	[
		"s3086909",
		"Ficus pilulifera",
		"ficus",
		3086909
	],
	[
		"s2775497",
		"Ficus pingtangensis",
		"ficus",
		2775497
	],
	[
		"s479812",
		"Ficus piresiana",
		"ficus",
		479812
	],
	[
		"s3048754",
		"Ficus pisifera",
		"ficus",
		3048754
	],
	[
		"s666379",
		"Ficus pisocarpa",
		"ficus",
		666379
	],
	[
		"s309299",
		"Ficus platyphylla",
		"ficus",
		309299
	],
	[
		"s309325",
		"Ficus platypoda",
		"ficus",
		309325
	],
	[
		"s3807888",
		"Ficus plectonervata",
		"ficus",
		3807888
	],
	[
		"s463865",
		"Ficus pleiadenia",
		"ficus",
		463865
	],
	[
		"s182122",
		"Ficus pleurocarpa",
		"ficus",
		182122
	],
	[
		"s3807889",
		"Ficus pleyteana",
		"ficus",
		3807889
	],
	[
		"s3086910",
		"Ficus podocarpifolia",
		"ficus",
		3086910
	],
	[
		"s378027",
		"Ficus polita",
		"ficus",
		378027
	],
	[
		"s479813",
		"Ficus politoria",
		"ficus",
		479813
	],
	[
		"s479814",
		"Ficus polyantha",
		"ficus",
		479814
	],
	[
		"s2699272",
		"Ficus polynervis",
		"ficus",
		2699272
	],
	[
		"s3425882",
		"Ficus polyphlebia",
		"ficus",
		3425882
	],
	[
		"s3807890",
		"Ficus pongumphaii",
		"ficus",
		3807890
	],
	[
		"s3807891",
		"Ficus popayanensis",
		"ficus",
		3807891
	],
	[
		"s323843",
		"Ficus popenoei",
		"ficus",
		323843
	],
	[
		"s309300",
		"Ficus populifolia",
		"ficus",
		309300
	],
	[
		"s479815",
		"Ficus porphyrochaete",
		"ficus",
		479815
	],
	[
		"s3807892",
		"Ficus porrecta",
		"ficus",
		3807892
	],
	[
		"s2024438",
		"Ficus potingensis",
		"ficus",
		2024438
	],
	[
		"s3807893",
		"Ficus praestans",
		"ficus",
		3807893
	],
	[
		"s3086911",
		"Ficus praetermissa",
		"ficus",
		3086911
	],
	[
		"s100566",
		"Ficus prasinicarpa",
		"ficus",
		100566
	],
	[
		"s309313",
		"Ficus preussii",
		"ficus",
		309313
	],
	[
		"s463866",
		"Ficus primaria",
		"ficus",
		463866
	],
	[
		"s2863845",
		"Ficus pringlei",
		"ficus",
		2863845
	],
	[
		"s2781245",
		"Ficus pritchardii",
		"ficus",
		2781245
	],
	[
		"s3086912",
		"Ficus profusa",
		"ficus",
		3086912
	],
	[
		"s182123",
		"Ficus prolixa",
		"ficus",
		182123
	],
	[
		"s479816",
		"Ficus prostrata",
		"ficus",
		479816
	],
	[
		"s1507503",
		"Ficus pseudocaulocarpa",
		"ficus",
		1507503
	],
	[
		"s1506681",
		"Ficus pseudoconcinna",
		"ficus",
		1506681
	],
	[
		"s425834",
		"Ficus pseudojaca",
		"ficus",
		425834
	],
	[
		"s669035",
		"Ficus pseudomangifera",
		"ficus",
		669035
	],
	[
		"s463867",
		"Ficus pseudopalma",
		"ficus",
		463867
	],
	[
		"s3086913",
		"Ficus pseudowassa",
		"ficus",
		3086913
	],
	[
		"s1164950",
		"Ficus pteroporum",
		"ficus",
		1164950
	],
	[
		"s463868",
		"Ficus pubigera",
		"ficus",
		463868
	],
	[
		"s479817",
		"Ficus pubilimba",
		"ficus",
		479817
	],
	[
		"s1507502",
		"Ficus pubipetiola",
		"ficus",
		1507502
	],
	[
		"s1924189",
		"Ficus pulchella",
		"ficus",
		1924189
	],
	[
		"s66386",
		"Ficus pumila",
		"ficus",
		66386
	],
	[
		"s100567",
		"Ficus punctata",
		"ficus",
		100567
	],
	[
		"s100568",
		"Ficus pungens",
		"ficus",
		100568
	],
	[
		"s3086914",
		"Ficus pustulata",
		"ficus",
		3086914
	],
	[
		"s309338",
		"Ficus pygmaea",
		"ficus",
		309338
	],
	[
		"s665992",
		"Ficus pyriformis",
		"ficus",
		665992
	],
	[
		"s3086915",
		"Ficus quercetorum",
		"ficus",
		3086915
	],
	[
		"s3807894",
		"Ficus quichauensis",
		"ficus",
		3807894
	],
	[
		"s3807895",
		"Ficus quistocochensis",
		"ficus",
		3807895
	],
	[
		"s182124",
		"Ficus racemigera",
		"ficus",
		182124
	],
	[
		"s100569",
		"Ficus racemosa",
		"ficus",
		100569
	],
	[
		"s665993",
		"Ficus recurva",
		"ficus",
		665993
	],
	[
		"s3086916",
		"Ficus recurvata",
		"ficus",
		3086916
	],
	[
		"s378030",
		"Ficus reflexa",
		"ficus",
		378030
	],
	[
		"s66387",
		"Ficus religiosa",
		"ficus",
		66387
	],
	[
		"s3807896",
		"Ficus remifolia",
		"ficus",
		3807896
	],
	[
		"s3086917",
		"Ficus repens",
		"ficus",
		3086917
	],
	[
		"s752802",
		"Ficus retusa",
		"ficus",
		752802
	],
	[
		"s3807897",
		"Ficus rheedei",
		"ficus",
		3807897
	],
	[
		"s3086918",
		"Ficus rhizophoriphylla",
		"ficus",
		3086918
	],
	[
		"s463869",
		"Ficus ribes",
		"ficus",
		463869
	],
	[
		"s3086919",
		"Ficus richteri",
		"ficus",
		3086919
	],
	[
		"s3807898",
		"Ficus ridleyana",
		"ficus",
		3807898
	],
	[
		"s1634508",
		"Ficus rieberiana",
		"ficus",
		1634508
	],
	[
		"s3807899",
		"Ficus riedelii",
		"ficus",
		3807899
	],
	[
		"s3086920",
		"Ficus rigo",
		"ficus",
		3086920
	],
	[
		"s3807900",
		"Ficus rimacana",
		"ficus",
		3807900
	],
	[
		"s479818",
		"Ficus rivularis",
		"ficus",
		479818
	],
	[
		"s100570",
		"Ficus robusta",
		"ficus",
		100570
	],
	[
		"s1237587",
		"Ficus rokko",
		"ficus",
		1237587
	],
	[
		"s3086921",
		"Ficus romeroi",
		"ficus",
		3086921
	],
	[
		"s2080492",
		"Ficus roraimensis",
		"ficus",
		2080492
	],
	[
		"s3048740",
		"Ficus rosulata",
		"ficus",
		3048740
	],
	[
		"s182125",
		"Ficus rubiginosa",
		"ficus",
		182125
	],
	[
		"s1908402",
		"Ficus rubra",
		"ficus",
		1908402
	],
	[
		"s743820",
		"Ficus rubrijuvenis",
		"ficus",
		743820
	],
	[
		"s380155",
		"Ficus rubrivestimenta",
		"ficus",
		380155
	],
	[
		"s3048741",
		"Ficus rubrocuspidata",
		"ficus",
		3048741
	],
	[
		"s3086922",
		"Ficus rubromidotis",
		"ficus",
		3086922
	],
	[
		"s3807901",
		"Ficus rubrosyce",
		"ficus",
		3807901
	],
	[
		"s479338",
		"Ficus ruficaulis",
		"ficus",
		479338
	],
	[
		"s2213075",
		"Ficus ruginervia",
		"ficus",
		2213075
	],
	[
		"s309269",
		"Ficus rumphii",
		"ficus",
		309269
	],
	[
		"s3807902",
		"Ficus ruspolii",
		"ficus",
		3807902
	],
	[
		"s2024442",
		"Ficus ruyuanensis",
		"ficus",
		2024442
	],
	[
		"s3807903",
		"Ficus sabahana",
		"ficus",
		3807903
	],
	[
		"s3086923",
		"Ficus saccata",
		"ficus",
		3086923
	],
	[
		"s3807904",
		"Ficus sageretina",
		"ficus",
		3807904
	],
	[
		"s463870",
		"Ficus sagittata",
		"ficus",
		463870
	],
	[
		"s309314",
		"Ficus sagittifolia",
		"ficus",
		309314
	],
	[
		"s929591",
		"Ficus sakalavarum",
		"ficus",
		929591
	],
	[
		"s3807905",
		"Ficus salicaria",
		"ficus",
		3807905
	],
	[
		"s3086924",
		"Ficus salomonensis",
		"ficus",
		3086924
	],
	[
		"s3807906",
		"Ficus samarana",
		"ficus",
		3807906
	],
	[
		"s3086925",
		"Ficus samoensis",
		"ficus",
		3086925
	],
	[
		"s3807907",
		"Ficus sandanakana",
		"ficus",
		3807907
	],
	[
		"s856836",
		"Ficus sangumae",
		"ficus",
		856836
	],
	[
		"s309319",
		"Ficus sansibarica",
		"ficus",
		309319
	],
	[
		"s1634509",
		"Ficus santanderana",
		"ficus",
		1634509
	],
	[
		"s479797",
		"Ficus sarawakensis",
		"ficus",
		479797
	],
	[
		"s326068",
		"Ficus sarmentosa",
		"ficus",
		326068
	],
	[
		"s3807908",
		"Ficus saruensis",
		"ficus",
		3807908
	],
	[
		"s463871",
		"Ficus satterthwaitei",
		"ficus",
		463871
	],
	[
		"s463872",
		"Ficus saurauioides",
		"ficus",
		463872
	],
	[
		"s309296",
		"Ficus saussureana",
		"ficus",
		309296
	],
	[
		"s2781246",
		"Ficus saxophila",
		"ficus",
		2781246
	],
	[
		"s3048742",
		"Ficus scaberrima",
		"ficus",
		3048742
	],
	[
		"s3086926",
		"Ficus scabra",
		"ficus",
		3086926
	],
	[
		"s3807909",
		"Ficus scaposa",
		"ficus",
		3807909
	],
	[
		"s309315",
		"Ficus scassellatii",
		"ficus",
		309315
	],
	[
		"s3807910",
		"Ficus schefferiana",
		"ficus",
		3807910
	],
	[
		"s309295",
		"Ficus schippii",
		"ficus",
		309295
	],
	[
		"s182127",
		"Ficus schumacheri",
		"ficus",
		182127
	],
	[
		"s3807911",
		"Ficus schumanniana",
		"ficus",
		3807911
	],
	[
		"s479819",
		"Ficus schwarzii",
		"ficus",
		479819
	],
	[
		"s3807912",
		"Ficus sciaphila",
		"ficus",
		3807912
	],
	[
		"s3807913",
		"Ficus sclerosycia",
		"ficus",
		3807913
	],
	[
		"s3086927",
		"Ficus scobina",
		"ficus",
		3086927
	],
	[
		"s3807914",
		"Ficus scopulifera",
		"ficus",
		3807914
	],
	[
		"s309342",
		"Ficus scortechinii",
		"ficus",
		309342
	],
	[
		"s378032",
		"Ficus scott-elliotii",
		"ficus",
		378032
	],
	[
		"s479339",
		"Ficus scratchleyana",
		"ficus",
		479339
	],
	[
		"s1634510",
		"Ficus segoviae",
		"ficus",
		1634510
	],
	[
		"s463873",
		"Ficus semicordata",
		"ficus",
		463873
	],
	[
		"s100572",
		"Ficus semivestita",
		"ficus",
		100572
	],
	[
		"s100573",
		"Ficus septica",
		"ficus",
		100573
	],
	[
		"s3807915",
		"Ficus serraria",
		"ficus",
		3807915
	],
	[
		"s479820",
		"Ficus setiflorus",
		"ficus",
		479820
	],
	[
		"s3807916",
		"Ficus setulosa",
		"ficus",
		3807916
	],
	[
		"s1822162",
		"Ficus simplicissima",
		"ficus",
		1822162
	],
	[
		"s2213077",
		"Ficus singalana",
		"ficus",
		2213077
	],
	[
		"s3807917",
		"Ficus sinociliata",
		"ficus",
		3807917
	],
	[
		"s883783",
		"Ficus sintenisii",
		"ficus",
		883783
	],
	[
		"s309339",
		"Ficus sinuata",
		"ficus",
		309339
	],
	[
		"s3807918",
		"Ficus sirensis",
		"ficus",
		3807918
	],
	[
		"s3086929",
		"Ficus smithii",
		"ficus",
		3086929
	],
	[
		"s3807919",
		"Ficus sodiroi",
		"ficus",
		3807919
	],
	[
		"s1191362",
		"Ficus soepadmoi",
		"ficus",
		1191362
	],
	[
		"s3807920",
		"Ficus sohotonensis",
		"ficus",
		3807920
	],
	[
		"s3807921",
		"Ficus solomonensis",
		"ficus",
		3807921
	],
	[
		"s463874",
		"Ficus spathulifolia",
		"ficus",
		463874
	],
	[
		"s479821",
		"Ficus sphenophylla",
		"ficus",
		479821
	],
	[
		"s3048743",
		"Ficus spiralis",
		"ficus",
		3048743
	],
	[
		"s2789877",
		"Ficus spragueana",
		"ficus",
		2789877
	],
	[
		"s479822",
		"Ficus squamosa",
		"ficus",
		479822
	],
	[
		"s3086930",
		"Ficus stellaris",
		"ficus",
		3086930
	],
	[
		"s463875",
		"Ficus stenophylla",
		"ficus",
		463875
	],
	[
		"s460880",
		"Ficus sterrocarpa",
		"ficus",
		460880
	],
	[
		"s3807922",
		"Ficus stipata",
		"ficus",
		3807922
	],
	[
		"s459061",
		"Ficus stipulifera",
		"ficus",
		459061
	],
	[
		"s479823",
		"Ficus stolonifera",
		"ficus",
		479823
	],
	[
		"s3086931",
		"Ficus storckii",
		"ficus",
		3086931
	],
	[
		"s463876",
		"Ficus stricta",
		"ficus",
		463876
	],
	[
		"s309301",
		"Ficus stuhlmannii",
		"ficus",
		309301
	],
	[
		"s665995",
		"Ficus stupenda",
		"ficus",
		665995
	],
	[
		"s378033",
		"Ficus subandina",
		"ficus",
		378033
	],
	[
		"s3807923",
		"Ficus subcaudata",
		"ficus",
		3807923
	],
	[
		"s3807924",
		"Ficus subcongesta",
		"ficus",
		3807924
	],
	[
		"s463877",
		"Ficus subcordata",
		"ficus",
		463877
	],
	[
		"s3807925",
		"Ficus subcostata",
		"ficus",
		3807925
	],
	[
		"s326052",
		"Ficus subcuneata",
		"ficus",
		326052
	],
	[
		"s3086932",
		"Ficus subfulva",
		"ficus",
		3086932
	],
	[
		"s182128",
		"Ficus subgelderi",
		"ficus",
		182128
	],
	[
		"s3807926",
		"Ficus subglabritepala",
		"ficus",
		3807926
	],
	[
		"s1179236",
		"Ficus subincisa",
		"ficus",
		1179236
	],
	[
		"s3807927",
		"Ficus sublimbata",
		"ficus",
		3807927
	],
	[
		"s3807928",
		"Ficus submontana",
		"ficus",
		3807928
	],
	[
		"s3086933",
		"Ficus subnervosa",
		"ficus",
		3086933
	],
	[
		"s1118427",
		"Ficus subpisocarpa",
		"ficus",
		1118427
	],
	[
		"s460885",
		"Ficus subpuberula",
		"ficus",
		460885
	],
	[
		"s3086934",
		"Ficus subsagittifolia",
		"ficus",
		3086934
	],
	[
		"s3807929",
		"Ficus subsidens",
		"ficus",
		3807929
	],
	[
		"s3086935",
		"Ficus subterranea",
		"ficus",
		3086935
	],
	[
		"s247053",
		"Ficus subtrinervia",
		"ficus",
		247053
	],
	[
		"s463878",
		"Ficus subulata",
		"ficus",
		463878
	],
	[
		"s3807930",
		"Ficus suffruticosa",
		"ficus",
		3807930
	],
	[
		"s3807931",
		"Ficus sulawesiana",
		"ficus",
		3807931
	],
	[
		"s3807932",
		"Ficus sulcata",
		"ficus",
		3807932
	],
	[
		"s3807933",
		"Ficus sumacoana",
		"ficus",
		3807933
	],
	[
		"s479824",
		"Ficus sumatrana",
		"ficus",
		479824
	],
	[
		"s309274",
		"Ficus sundaica",
		"ficus",
		309274
	],
	[
		"s100574",
		"Ficus superba",
		"ficus",
		100574
	],
	[
		"s3086936",
		"Ficus supfiana",
		"ficus",
		3086936
	],
	[
		"s3086937",
		"Ficus supperforata",
		"ficus",
		3086937
	],
	[
		"s100575",
		"Ficus sur",
		"ficus",
		100575
	],
	[
		"s182129",
		"Ficus sycomorus",
		"ficus",
		182129
	],
	[
		"s2516218",
		"Ficus talbotii",
		"ficus",
		2516218
	],
	[
		"s3086938",
		"Ficus tamayoana",
		"ficus",
		3086938
	],
	[
		"s1127373",
		"Ficus tannoensis",
		"ficus",
		1127373
	],
	[
		"s3807934",
		"Ficus tanypoda",
		"ficus",
		3807934
	],
	[
		"s3048744",
		"Ficus tarennifolia",
		"ficus",
		3048744
	],
	[
		"s3807935",
		"Ficus temburongensis",
		"ficus",
		3807935
	],
	[
		"s3807936",
		"Ficus tenuicuspidata",
		"ficus",
		3807936
	],
	[
		"s463879",
		"Ficus tequendamae",
		"ficus",
		463879
	],
	[
		"s370343",
		"Ficus ternatana",
		"ficus",
		370343
	],
	[
		"s378034",
		"Ficus tesselata",
		"ficus",
		378034
	],
	[
		"s378035",
		"Ficus tettensis",
		"ficus",
		378035
	],
	[
		"s3807937",
		"Ficus thailandica",
		"ficus",
		3807937
	],
	[
		"s100576",
		"Ficus theophrastoides",
		"ficus",
		100576
	],
	[
		"s309310",
		"Ficus thonningii",
		"ficus",
		309310
	],
	[
		"s463880",
		"Ficus tikoua",
		"ficus",
		463880
	],
	[
		"s463881",
		"Ficus tiliifolia",
		"ficus",
		463881
	],
	[
		"s100577",
		"Ficus tinctoria",
		"ficus",
		100577
	],
	[
		"s309343",
		"Ficus tonduzii",
		"ficus",
		309343
	],
	[
		"s3086939",
		"Ficus tonsa",
		"ficus",
		3086939
	],
	[
		"s3048745",
		"Ficus torrentium",
		"ficus",
		3048745
	],
	[
		"s1634511",
		"Ficus torresiana",
		"ficus",
		1634511
	],
	[
		"s929592",
		"Ficus trachelosyce",
		"ficus",
		929592
	],
	[
		"s3807938",
		"Ficus trachycoma",
		"ficus",
		3807938
	],
	[
		"s100578",
		"Ficus trachypison",
		"ficus",
		100578
	],
	[
		"s3035711",
		"Ficus travancorica",
		"ficus",
		3035711
	],
	[
		"s309320",
		"Ficus tremula",
		"ficus",
		309320
	],
	[
		"s463882",
		"Ficus treubii",
		"ficus",
		463882
	],
	[
		"s3086940",
		"Ficus trianae",
		"ficus",
		3086940
	],
	[
		"s463883",
		"Ficus trichocarpa",
		"ficus",
		463883
	],
	[
		"s2137834",
		"Ficus trichocerasa",
		"ficus",
		2137834
	],
	[
		"s929593",
		"Ficus trichoclada",
		"ficus",
		929593
	],
	[
		"s378036",
		"Ficus trichopoda",
		"ficus",
		378036
	],
	[
		"s3807939",
		"Ficus tricolor",
		"ficus",
		3807939
	],
	[
		"s378037",
		"Ficus trigona",
		"ficus",
		378037
	],
	[
		"s323846",
		"Ficus trigonata",
		"ficus",
		323846
	],
	[
		"s3079905",
		"Ficus triloba",
		"ficus",
		3079905
	],
	[
		"s3807940",
		"Ficus trimenii",
		"ficus",
		3807940
	],
	[
		"s309326",
		"Ficus triradiata",
		"ficus",
		309326
	],
	[
		"s3086941",
		"Ficus tristaniifolia",
		"ficus",
		3086941
	],
	[
		"s1179238",
		"Ficus trivia",
		"ficus",
		1179238
	],
	[
		"s463884",
		"Ficus tsiangii",
		"ficus",
		463884
	],
	[
		"s1118428",
		"Ficus tsjakela",
		"ficus",
		1118428
	],
	[
		"s463885",
		"Ficus tuerckheimii",
		"ficus",
		463885
	],
	[
		"s3807941",
		"Ficus tulipifera",
		"ficus",
		3807941
	],
	[
		"s3807942",
		"Ficus tunicata",
		"ficus",
		3807942
	],
	[
		"s1179239",
		"Ficus tuphapensis",
		"ficus",
		1179239
	],
	[
		"s478653",
		"Ficus turbinata",
		"ficus",
		478653
	],
	[
		"s3086942",
		"Ficus turrialbana",
		"ficus",
		3086942
	],
	[
		"s3807943",
		"Ficus ulei",
		"ficus",
		3807943
	],
	[
		"s1986358",
		"Ficus ulmifolia",
		"ficus",
		1986358
	],
	[
		"s378038",
		"Ficus umbellata",
		"ficus",
		378038
	],
	[
		"s3807944",
		"Ficus umbonata",
		"ficus",
		3807944
	],
	[
		"s2969975",
		"Ficus umbrae",
		"ficus",
		2969975
	],
	[
		"s1191363",
		"Ficus uncinata",
		"ficus",
		1191363
	],
	[
		"s182130",
		"Ficus uncinulata",
		"ficus",
		182130
	],
	[
		"s3086943",
		"Ficus uniauriculata",
		"ficus",
		3086943
	],
	[
		"s3048746",
		"Ficus uniglandulosa",
		"ficus",
		3048746
	],
	[
		"s459062",
		"Ficus urceolaris",
		"ficus",
		459062
	],
	[
		"s3048747",
		"Ficus urnigera",
		"ficus",
		3048747
	],
	[
		"s3086944",
		"Ficus ursina",
		"ficus",
		3086944
	],
	[
		"s378039",
		"Ficus usambarensis",
		"ficus",
		378039
	],
	[
		"s1127375",
		"Ficus vaccinioides",
		"ficus",
		1127375
	],
	[
		"s3086945",
		"Ficus valaria",
		"ficus",
		3086945
	],
	[
		"s3807945",
		"Ficus vallis-caucae",
		"ficus",
		3807945
	],
	[
		"s182131",
		"Ficus vallis-choudae",
		"ficus",
		182131
	],
	[
		"s100579",
		"Ficus variegata (in: eudicots)",
		"ficus",
		100579
	],
	[
		"s425835",
		"Ficus variifolia",
		"ficus",
		425835
	],
	[
		"s1009473",
		"Ficus variolosa",
		"ficus",
		1009473
	],
	[
		"s463886",
		"Ficus vasculosa",
		"ficus",
		463886
	],
	[
		"s669037",
		"Ficus vasta",
		"ficus",
		669037
	],
	[
		"s1568997",
		"Ficus velutina",
		"ficus",
		1568997
	],
	[
		"s3807946",
		"Ficus venezuelensis",
		"ficus",
		3807946
	],
	[
		"s1634512",
		"Ficus vermifuga",
		"ficus",
		1634512
	],
	[
		"s463887",
		"Ficus verruculosa",
		"ficus",
		463887
	],
	[
		"s1164951",
		"Ficus versicolor",
		"ficus",
		1164951
	],
	[
		"s3807947",
		"Ficus verticillaris",
		"ficus",
		3807947
	],
	[
		"s3086946",
		"Ficus vieillardiana",
		"ficus",
		3086946
	],
	[
		"s309334",
		"Ficus villosa",
		"ficus",
		309334
	],
	[
		"s100580",
		"Ficus virens",
		"ficus",
		100580
	],
	[
		"s3807948",
		"Ficus virescens",
		"ficus",
		3807948
	],
	[
		"s100581",
		"Ficus virgata",
		"ficus",
		100581
	],
	[
		"s3807949",
		"Ficus vitiensis",
		"ficus",
		3807949
	],
	[
		"s3086947",
		"Ficus vittata",
		"ficus",
		3086947
	],
	[
		"s463888",
		"Ficus vogeliana",
		"ficus",
		463888
	],
	[
		"s3807950",
		"Ficus vrieseana",
		"ficus",
		3807950
	],
	[
		"s1191364",
		"Ficus wakefieldii",
		"ficus",
		1191364
	],
	[
		"s856837",
		"Ficus wamanguana",
		"ficus",
		856837
	],
	[
		"s3086948",
		"Ficus warburgii",
		"ficus",
		3086948
	],
	[
		"s100582",
		"Ficus wassa",
		"ficus",
		100582
	],
	[
		"s309327",
		"Ficus watkinsiana",
		"ficus",
		309327
	],
	[
		"s3048748",
		"Ficus webbiana",
		"ficus",
		3048748
	],
	[
		"s762866",
		"Ficus wightiana",
		"ficus",
		762866
	],
	[
		"s309316",
		"Ficus wildemaniana",
		"ficus",
		309316
	],
	[
		"s182132",
		"Ficus xylophylla",
		"ficus",
		182132
	],
	[
		"s100583",
		"Ficus xylosycia",
		"ficus",
		100583
	],
	[
		"s182133",
		"Ficus yoponensis",
		"ficus",
		182133
	],
	[
		"s3023338",
		"Ficus yunnanensis",
		"ficus",
		3023338
	],
	[
		"s3086949",
		"Ficus zarzalensis",
		"ficus",
		3086949
	],
	[
		"s1769919",
		"Filipendula angustiloba",
		"filipendula",
		1769919
	],
	[
		"s3015786",
		"Filipendula auriculata",
		"filipendula",
		3015786
	],
	[
		"s1769920",
		"Filipendula camtschatica",
		"filipendula",
		1769920
	],
	[
		"s3015787",
		"Filipendula digitata",
		"filipendula",
		3015787
	],
	[
		"s1769921",
		"Filipendula formosa",
		"filipendula",
		1769921
	],
	[
		"s1769922",
		"Filipendula glaberrima",
		"filipendula",
		1769922
	],
	[
		"s2259405",
		"Filipendula intermedia",
		"filipendula",
		2259405
	],
	[
		"s1769923",
		"Filipendula kiraishiensis",
		"filipendula",
		1769923
	],
	[
		"s2259406",
		"Filipendula koreana",
		"filipendula",
		2259406
	],
	[
		"s176127",
		"Filipendula multijuga",
		"filipendula",
		176127
	],
	[
		"s3031466",
		"Filipendula nuda",
		"filipendula",
		3031466
	],
	[
		"s1769925",
		"Filipendula occidentalis",
		"filipendula",
		1769925
	],
	[
		"s1769926",
		"Filipendula palmata",
		"filipendula",
		1769926
	],
	[
		"s2071894",
		"Filipendula rubra",
		"filipendula",
		2071894
	],
	[
		"s1769927",
		"Filipendula tsuguwoi",
		"filipendula",
		1769927
	],
	[
		"s57917",
		"Filipendula ulmaria",
		"filipendula",
		57917
	],
	[
		"s1769928",
		"Filipendula vestita",
		"filipendula",
		1769928
	],
	[
		"s32228",
		"Filipendula vulgaris",
		"filipendula",
		32228
	],
	[
		"s32227",
		"Filipendula x purpurea",
		"filipendula",
		32227
	],
	[
		"s1769929",
		"Filipendula yezoensis",
		"filipendula",
		1769929
	],
	[
		"s1399689",
		"Forsskaolea angustifolia",
		"forsskaolea",
		1399689
	],
	[
		"s1586305",
		"Forsskaolea candida",
		"forsskaolea",
		1586305
	],
	[
		"s3808469",
		"Forsskaolea griersonii",
		"forsskaolea",
		3808469
	],
	[
		"s3086952",
		"Forsskaolea hereroensis",
		"forsskaolea",
		3086952
	],
	[
		"s3086953",
		"Forsskaolea procridifolia",
		"forsskaolea",
		3086953
	],
	[
		"s344767",
		"Forsskaolea tenacissima",
		"forsskaolea",
		344767
	],
	[
		"s3086954",
		"Forsskaolea viridis",
		"forsskaolea",
		3086954
	],
	[
		"s538573",
		"Fragaria bucharica",
		"fragaria",
		538573
	],
	[
		"s1810749",
		"Fragaria cascadensis",
		"fragaria",
		1810749
	],
	[
		"s101007",
		"Fragaria chiloensis",
		"fragaria",
		101007
	],
	[
		"s674467",
		"Fragaria chinensis",
		"fragaria",
		674467
	],
	[
		"s538576",
		"Fragaria corymbosa",
		"fragaria",
		538576
	],
	[
		"s101010",
		"Fragaria daltoniana",
		"fragaria",
		101010
	],
	[
		"s2872684",
		"Fragaria emeiensis",
		"fragaria",
		2872684
	],
	[
		"s101011",
		"Fragaria gracilis",
		"fragaria",
		101011
	],
	[
		"s203802",
		"Fragaria grandiflora",
		"fragaria",
		203802
	],
	[
		"s2487926",
		"Fragaria hayatae",
		"fragaria",
		2487926
	],
	[
		"s2497996",
		"Fragaria hybrid cultivar",
		"fragaria",
		2497996
	],
	[
		"s64939",
		"Fragaria iinumae",
		"fragaria",
		64939
	],
	[
		"s538579",
		"Fragaria iturupensis",
		"fragaria",
		538579
	],
	[
		"s538574",
		"Fragaria mandshurica",
		"fragaria",
		538574
	],
	[
		"s64940",
		"Fragaria moschata",
		"fragaria",
		64940
	],
	[
		"s538577",
		"Fragaria moupinensis",
		"fragaria",
		538577
	],
	[
		"s64941",
		"Fragaria nilgerrensis",
		"fragaria",
		64941
	],
	[
		"s101012",
		"Fragaria nipponica",
		"fragaria",
		101012
	],
	[
		"s60188",
		"Fragaria nubicola",
		"fragaria",
		60188
	],
	[
		"s101013",
		"Fragaria orientalis",
		"fragaria",
		101013
	],
	[
		"s101014",
		"Fragaria pentaphylla",
		"fragaria",
		101014
	],
	[
		"s3808520",
		"Fragaria tayulinensis",
		"fragaria",
		3808520
	],
	[
		"s538578",
		"Fragaria tibetica",
		"fragaria",
		538578
	],
	[
		"s57918",
		"Fragaria vesca",
		"fragaria",
		57918
	],
	[
		"s599650",
		"Fragaria vesca x Fragaria nubicola",
		"fragaria",
		599650
	],
	[
		"s101015",
		"Fragaria virginiana",
		"fragaria",
		101015
	],
	[
		"s64942",
		"Fragaria viridis",
		"fragaria",
		64942
	],
	[
		"s3747",
		"Fragaria x ananassa",
		"fragaria",
		3747
	],
	[
		"s3025576",
		"Fragaria x ananassa x Fragaria nilgerrensis",
		"fragaria",
		3025576
	],
	[
		"s674468",
		"Fragaria x bifera",
		"fragaria",
		674468
	],
	[
		"s3808533",
		"Frangula acuminata",
		"frangula",
		3808533
	],
	[
		"s106677",
		"Frangula alnus",
		"frangula",
		106677
	],
	[
		"s3808534",
		"Frangula austrosinensis",
		"frangula",
		3808534
	],
	[
		"s1053348",
		"Frangula azorica",
		"frangula",
		1053348
	],
	[
		"s280012",
		"Frangula betulifolia",
		"frangula",
		280012
	],
	[
		"s1814964",
		"Frangula borneensis",
		"frangula",
		1814964
	],
	[
		"s3808535",
		"Frangula breedlovei",
		"frangula",
		3808535
	],
	[
		"s143678",
		"Frangula californica",
		"frangula",
		143678
	],
	[
		"s1813206",
		"Frangula capreifolia",
		"frangula",
		1813206
	],
	[
		"s280013",
		"Frangula caroliniana",
		"frangula",
		280013
	],
	[
		"s3808536",
		"Frangula chimalapensis",
		"frangula",
		3808536
	],
	[
		"s3808537",
		"Frangula chrysophylla",
		"frangula",
		3808537
	],
	[
		"s3808538",
		"Frangula circumscissa",
		"frangula",
		3808538
	],
	[
		"s3808539",
		"Frangula darienensis",
		"frangula",
		3808539
	],
	[
		"s3808540",
		"Frangula dianthes",
		"frangula",
		3808540
	],
	[
		"s1813034",
		"Frangula discolor",
		"frangula",
		1813034
	],
	[
		"s3086053",
		"Frangula goudotiana",
		"frangula",
		3086053
	],
	[
		"s3808541",
		"Frangula grandiflora",
		"frangula",
		3808541
	],
	[
		"s3086054",
		"Frangula grandifolia",
		"frangula",
		3086054
	],
	[
		"s3086055",
		"Frangula granulosa",
		"frangula",
		3086055
	],
	[
		"s3808542",
		"Frangula grisea",
		"frangula",
		3808542
	],
	[
		"s1813035",
		"Frangula henryi",
		"frangula",
		1813035
	],
	[
		"s1813036",
		"Frangula hintonii",
		"frangula",
		1813036
	],
	[
		"s3808543",
		"Frangula inconspicua",
		"frangula",
		3808543
	],
	[
		"s3808544",
		"Frangula longipedicellata",
		"frangula",
		3808544
	],
	[
		"s1813037",
		"Frangula longipes",
		"frangula",
		1813037
	],
	[
		"s1813038",
		"Frangula longistyla",
		"frangula",
		1813038
	],
	[
		"s1813076",
		"Frangula macrocarpa",
		"frangula",
		1813076
	],
	[
		"s3808545",
		"Frangula marahuacensis",
		"frangula",
		3808545
	],
	[
		"s1813039",
		"Frangula mcvaughii",
		"frangula",
		1813039
	],
	[
		"s1813040",
		"Frangula microphylla",
		"frangula",
		1813040
	],
	[
		"s1813041",
		"Frangula mucronata",
		"frangula",
		1813041
	],
	[
		"s3808546",
		"Frangula neblinensis",
		"frangula",
		3808546
	],
	[
		"s3086056",
		"Frangula obovata",
		"frangula",
		3086056
	],
	[
		"s1813042",
		"Frangula oreodendron",
		"frangula",
		1813042
	],
	[
		"s1813043",
		"Frangula palmeri",
		"frangula",
		1813043
	],
	[
		"s3808547",
		"Frangula pedunculata",
		"frangula",
		3808547
	],
	[
		"s3808548",
		"Frangula pendula",
		"frangula",
		3808548
	],
	[
		"s1813044",
		"Frangula pinetorum",
		"frangula",
		1813044
	],
	[
		"s280015",
		"Frangula polymorpha",
		"frangula",
		280015
	],
	[
		"s1813045",
		"Frangula pringlei",
		"frangula",
		1813045
	],
	[
		"s3808549",
		"Frangula pubescens",
		"frangula",
		3808549
	],
	[
		"s55262",
		"Frangula purshiana",
		"frangula",
		55262
	],
	[
		"s3085925",
		"Frangula revoluta",
		"frangula",
		3085925
	],
	[
		"s3808550",
		"Frangula rhododendriphylla",
		"frangula",
		3808550
	],
	[
		"s3808551",
		"Frangula riojae",
		"frangula",
		3808551
	],
	[
		"s1813046",
		"Frangula rubra",
		"frangula",
		1813046
	],
	[
		"s1532833",
		"Frangula rupestris",
		"frangula",
		1532833
	],
	[
		"s3091429",
		"Frangula scopulorum",
		"frangula",
		3091429
	],
	[
		"s3808552",
		"Frangula surotatensis",
		"frangula",
		3808552
	],
	[
		"s3086057",
		"Frangula ulei",
		"frangula",
		3086057
	],
	[
		"s344769",
		"Gesnouinia arborea",
		"gesnouinia",
		344769
	],
	[
		"s2590070",
		"Gesnouinia filamentosa",
		"gesnouinia",
		2590070
	],
	[
		"s3812028",
		"Geum aequilobatum",
		"geum",
		3812028
	],
	[
		"s714473",
		"Geum aleppicum",
		"geum",
		714473
	],
	[
		"s148891",
		"Geum andicola",
		"geum",
		148891
	],
	[
		"s2759162",
		"Geum atlanticum",
		"geum",
		2759162
	],
	[
		"s3089817",
		"Geum boliviense",
		"geum",
		3089817
	],
	[
		"s3763",
		"Geum borisii",
		"geum",
		3763
	],
	[
		"s3812029",
		"Geum brevicarpellatum",
		"geum",
		3812029
	],
	[
		"s148892",
		"Geum bulgaricum",
		"geum",
		148892
	],
	[
		"s61283",
		"Geum calthifolium",
		"geum",
		61283
	],
	[
		"s350588",
		"Geum canadense",
		"geum",
		350588
	],
	[
		"s3812030",
		"Geum capense",
		"geum",
		3812030
	],
	[
		"s3762",
		"Geum chiloense",
		"geum",
		3762
	],
	[
		"s3089818",
		"Geum coccineum",
		"geum",
		3089818
	],
	[
		"s2726007",
		"Geum donianum",
		"geum",
		2726007
	],
	[
		"s148883",
		"Geum elatum",
		"geum",
		148883
	],
	[
		"s32251",
		"Geum fragarioides",
		"geum",
		32251
	],
	[
		"s148893",
		"Geum geniculatum",
		"geum",
		148893
	],
	[
		"s148902",
		"Geum glaciale",
		"geum",
		148902
	],
	[
		"s1898687",
		"Geum henryi",
		"geum",
		1898687
	],
	[
		"s148894",
		"Geum heterocarpum",
		"geum",
		148894
	],
	[
		"s2759163",
		"Geum hispidum",
		"geum",
		2759163
	],
	[
		"s2056236",
		"Geum iranicum",
		"geum",
		2056236
	],
	[
		"s321607",
		"Geum japonicum",
		"geum",
		321607
	],
	[
		"s2056235",
		"Geum kokanikum",
		"geum",
		2056235
	],
	[
		"s2071472",
		"Geum laciniatum",
		"geum",
		2071472
	],
	[
		"s3812031",
		"Geum latilobum",
		"geum",
		3812031
	],
	[
		"s2726004",
		"Geum lobatum",
		"geum",
		2726004
	],
	[
		"s32229",
		"Geum macrophyllum",
		"geum",
		32229
	],
	[
		"s3812032",
		"Geum macrosepalum",
		"geum",
		3812032
	],
	[
		"s3089820",
		"Geum magellanicum",
		"geum",
		3089820
	],
	[
		"s3812033",
		"Geum mexicanum",
		"geum",
		3812033
	],
	[
		"s148895",
		"Geum montanum",
		"geum",
		148895
	],
	[
		"s2071473",
		"Geum peckii",
		"geum",
		2071473
	],
	[
		"s3812034",
		"Geum peruvianum",
		"geum",
		3812034
	],
	[
		"s1799579",
		"Geum quellyon",
		"geum",
		1799579
	],
	[
		"s3065846",
		"Geum radiatum",
		"geum",
		3065846
	],
	[
		"s148896",
		"Geum reptans",
		"geum",
		148896
	],
	[
		"s3089821",
		"Geum rhodopeum",
		"geum",
		3089821
	],
	[
		"s3812035",
		"Geum riojense",
		"geum",
		3812035
	],
	[
		"s148897",
		"Geum rivale",
		"geum",
		148897
	],
	[
		"s148884",
		"Geum rossii",
		"geum",
		148884
	],
	[
		"s3812036",
		"Geum rubrum",
		"geum",
		3812036
	],
	[
		"s148898",
		"Geum schofieldii",
		"geum",
		148898
	],
	[
		"s148885",
		"Geum sikkimense",
		"geum",
		148885
	],
	[
		"s148899",
		"Geum speciosum",
		"geum",
		148899
	],
	[
		"s2744879",
		"Geum sunhangii",
		"geum",
		2744879
	],
	[
		"s1533085",
		"Geum sylvaticum",
		"geum",
		1533085
	],
	[
		"s2726008",
		"Geum tanzybeicum",
		"geum",
		2726008
	],
	[
		"s1640877",
		"Geum ternatum",
		"geum",
		1640877
	],
	[
		"s148890",
		"Geum triflorum",
		"geum",
		148890
	],
	[
		"s57919",
		"Geum urbanum",
		"geum",
		57919
	],
	[
		"s148900",
		"Geum vernum",
		"geum",
		148900
	],
	[
		"s2071474",
		"Geum virginianum",
		"geum",
		2071474
	],
	[
		"s148911",
		"Geum waldsteiniae",
		"geum",
		148911
	],
	[
		"s3089819",
		"Geum x intermedium",
		"geum",
		3089819
	],
	[
		"s3090528",
		"Geum x pulchrum",
		"geum",
		3090528
	],
	[
		"s3812047",
		"Gibbsia carstenszensis",
		"gibbsia",
		3812047
	],
	[
		"s2306681",
		"Gibbsia insignis",
		"gibbsia",
		2306681
	],
	[
		"s141002",
		"Gillenia stipulata",
		"gillenia",
		141002
	],
	[
		"s141003",
		"Gillenia trifoliata",
		"gillenia",
		141003
	],
	[
		"s2952662",
		"Girardinia bullosa",
		"girardinia",
		2952662
	],
	[
		"s2952663",
		"Girardinia chingiana",
		"girardinia",
		2952663
	],
	[
		"s471946",
		"Girardinia diversifolia",
		"girardinia",
		471946
	],
	[
		"s2952661",
		"Girardinia formosana",
		"girardinia",
		2952661
	],
	[
		"s2928709",
		"Girardinia suborbiculata",
		"girardinia",
		2928709
	],
	[
		"s1184756",
		"Gironniera celtidifolia",
		"gironniera",
		1184756
	],
	[
		"s2606474",
		"Gironniera hirta",
		"gironniera",
		2606474
	],
	[
		"s1827312",
		"Gironniera nervosa",
		"gironniera",
		1827312
	],
	[
		"s3089822",
		"Gironniera parvifolia",
		"gironniera",
		3089822
	],
	[
		"s3089823",
		"Gironniera rhamnifolia",
		"gironniera",
		3089823
	],
	[
		"s63060",
		"Gironniera subaequalis",
		"gironniera",
		63060
	],
	[
		"s3813415",
		"Gonostegia bennettiana",
		"gonostegia",
		3813415
	],
	[
		"s3813416",
		"Gonostegia caudata",
		"gonostegia",
		3813416
	],
	[
		"s3813417",
		"Gonostegia gardneri",
		"gonostegia",
		3813417
	],
	[
		"s3813418",
		"Gonostegia gracilis",
		"gonostegia",
		3813418
	],
	[
		"s3813419",
		"Gonostegia meeboldii",
		"gonostegia",
		3813419
	],
	[
		"s1399690",
		"Gonostegia parvifolia",
		"gonostegia",
		1399690
	],
	[
		"s647272",
		"Gonostegia pentandra",
		"gonostegia",
		647272
	],
	[
		"s3813420",
		"Gonostegia wightii",
		"gonostegia",
		3813420
	],
	[
		"s3089836",
		"Gouania acalyphoides",
		"gouania",
		3089836
	],
	[
		"s3089837",
		"Gouania acreana",
		"gouania",
		3089837
	],
	[
		"s3089838",
		"Gouania alnifolia",
		"gouania",
		3089838
	],
	[
		"s3089630",
		"Gouania ambrensis",
		"gouania",
		3089630
	],
	[
		"s3813565",
		"Gouania andamanica",
		"gouania",
		3813565
	],
	[
		"s3813566",
		"Gouania aphrodes",
		"gouania",
		3813566
	],
	[
		"s3089839",
		"Gouania aptera",
		"gouania",
		3089839
	],
	[
		"s1382146",
		"Gouania australiana",
		"gouania",
		1382146
	],
	[
		"s3089840",
		"Gouania blanchetiana",
		"gouania",
		3089840
	],
	[
		"s3089631",
		"Gouania callmanderi",
		"gouania",
		3089631
	],
	[
		"s3813567",
		"Gouania canescens",
		"gouania",
		3813567
	],
	[
		"s2945804",
		"Gouania cf. lupuloides HUEFS246957",
		"gouania",
		2945804
	],
	[
		"s2945805",
		"Gouania cf. lupuloides HUEFS247075",
		"gouania",
		2945805
	],
	[
		"s3128294",
		"Gouania cf. tiliifolia",
		"gouania",
		3128294
	],
	[
		"s3089841",
		"Gouania chrysophylla",
		"gouania",
		3089841
	],
	[
		"s1504175",
		"Gouania colombiana",
		"gouania",
		1504175
	],
	[
		"s3089842",
		"Gouania conzattii",
		"gouania",
		3089842
	],
	[
		"s3089843",
		"Gouania cornifolia",
		"gouania",
		3089843
	],
	[
		"s3089844",
		"Gouania corylifolia",
		"gouania",
		3089844
	],
	[
		"s3813568",
		"Gouania croatii",
		"gouania",
		3813568
	],
	[
		"s3813569",
		"Gouania cupreifolia",
		"gouania",
		3813569
	],
	[
		"s3089632",
		"Gouania cupuliflora",
		"gouania",
		3089632
	],
	[
		"s3089845",
		"Gouania discolor",
		"gouania",
		3089845
	],
	[
		"s3089846",
		"Gouania efatensis",
		"gouania",
		3089846
	],
	[
		"s3813570",
		"Gouania ekmanii",
		"gouania",
		3813570
	],
	[
		"s3089847",
		"Gouania eurycarpa",
		"gouania",
		3089847
	],
	[
		"s3813571",
		"Gouania exilis",
		"gouania",
		3813571
	],
	[
		"s3813572",
		"Gouania ferruginea",
		"gouania",
		3813572
	],
	[
		"s3813573",
		"Gouania fimbriata",
		"gouania",
		3813573
	],
	[
		"s3089848",
		"Gouania frangulifolia",
		"gouania",
		3089848
	],
	[
		"s3089849",
		"Gouania gagnei",
		"gouania",
		3089849
	],
	[
		"s3813574",
		"Gouania gautieri",
		"gouania",
		3813574
	],
	[
		"s3089850",
		"Gouania glandulosa",
		"gouania",
		3089850
	],
	[
		"s3813575",
		"Gouania guiengolensis",
		"gouania",
		3813575
	],
	[
		"s3089851",
		"Gouania hillebrandii",
		"gouania",
		3089851
	],
	[
		"s3089852",
		"Gouania humbertii",
		"gouania",
		3089852
	],
	[
		"s3089853",
		"Gouania hypoglauca",
		"gouania",
		3089853
	],
	[
		"s3089854",
		"Gouania inornata",
		"gouania",
		3089854
	],
	[
		"s1813006",
		"Gouania javanica",
		"gouania",
		1813006
	],
	[
		"s1813007",
		"Gouania latifolia",
		"gouania",
		1813007
	],
	[
		"s3089855",
		"Gouania laxiflora",
		"gouania",
		3089855
	],
	[
		"s1813008",
		"Gouania leptostachya",
		"gouania",
		1813008
	],
	[
		"s3089856",
		"Gouania leratii",
		"gouania",
		3089856
	],
	[
		"s3089857",
		"Gouania lineata",
		"gouania",
		3089857
	],
	[
		"s3813576",
		"Gouania longipedunculata",
		"gouania",
		3813576
	],
	[
		"s3089858",
		"Gouania longipetala",
		"gouania",
		3089858
	],
	[
		"s1813009",
		"Gouania longispicata",
		"gouania",
		1813009
	],
	[
		"s1136837",
		"Gouania lupuloides",
		"gouania",
		1136837
	],
	[
		"s3089859",
		"Gouania mangarevica",
		"gouania",
		3089859
	],
	[
		"s106679",
		"Gouania mauritiana",
		"gouania",
		106679
	],
	[
		"s3089860",
		"Gouania meyenii",
		"gouania",
		3089860
	],
	[
		"s2501689",
		"Gouania microcarpa",
		"gouania",
		2501689
	],
	[
		"s3089861",
		"Gouania mollis",
		"gouania",
		3089861
	],
	[
		"s3089862",
		"Gouania myriocarpa",
		"gouania",
		3089862
	],
	[
		"s3089863",
		"Gouania napalensis",
		"gouania",
		3089863
	],
	[
		"s3813577",
		"Gouania nematostachya",
		"gouania",
		3813577
	],
	[
		"s3089633",
		"Gouania obamana",
		"gouania",
		3089633
	],
	[
		"s3089864",
		"Gouania pannigera",
		"gouania",
		3089864
	],
	[
		"s3813578",
		"Gouania perrieri",
		"gouania",
		3813578
	],
	[
		"s3089865",
		"Gouania petiolaris",
		"gouania",
		3089865
	],
	[
		"s3089634",
		"Gouania phillipsonii",
		"gouania",
		3089634
	],
	[
		"s1136838",
		"Gouania polygama",
		"gouania",
		1136838
	],
	[
		"s3813579",
		"Gouania pubidisca",
		"gouania",
		3813579
	],
	[
		"s3089866",
		"Gouania pyrifolia",
		"gouania",
		3089866
	],
	[
		"s3089867",
		"Gouania riparia",
		"gouania",
		3089867
	],
	[
		"s3089868",
		"Gouania rosei",
		"gouania",
		3089868
	],
	[
		"s3089869",
		"Gouania rumicina",
		"gouania",
		3089869
	],
	[
		"s3089870",
		"Gouania stipularis",
		"gouania",
		3089870
	],
	[
		"s3813580",
		"Gouania striata",
		"gouania",
		3813580
	],
	[
		"s3089635",
		"Gouania taolagnarensis",
		"gouania",
		3089635
	],
	[
		"s1908403",
		"Gouania tiliifolia",
		"gouania",
		1908403
	],
	[
		"s3089871",
		"Gouania trichodonta",
		"gouania",
		3089871
	],
	[
		"s3089872",
		"Gouania ulmifolia",
		"gouania",
		3089872
	],
	[
		"s3089873",
		"Gouania ulugurica",
		"gouania",
		3089873
	],
	[
		"s3089874",
		"Gouania urticifolia",
		"gouania",
		3089874
	],
	[
		"s3089875",
		"Gouania velutina",
		"gouania",
		3089875
	],
	[
		"s3089876",
		"Gouania virgata",
		"gouania",
		3089876
	],
	[
		"s3813581",
		"Gouania viridis",
		"gouania",
		3813581
	],
	[
		"s3089877",
		"Gouania wurdackii",
		"gouania",
		3089877
	],
	[
		"s3089636",
		"Gouania zebrifolia",
		"gouania",
		3089636
	],
	[
		"s155902",
		"Granitites intangendus",
		"granitites",
		155902
	],
	[
		"s3393892",
		"Griffitharia atrosanguinea",
		"griffitharia",
		3393892
	],
	[
		"s3394265",
		"Griffitharia guanii",
		"griffitharia",
		3394265
	],
	[
		"s691235",
		"Griffitharia hemsleyi",
		"griffitharia",
		691235
	],
	[
		"s3109545",
		"Griffitharia heseltinei",
		"griffitharia",
		3109545
	],
	[
		"s3095446",
		"Griffitharia hudsonii",
		"griffitharia",
		3095446
	],
	[
		"s3095447",
		"Griffitharia lanata",
		"griffitharia",
		3095447
	],
	[
		"s3095445",
		"Griffitharia needhamii",
		"griffitharia",
		3095445
	],
	[
		"s1770161",
		"Griffitharia pallescens",
		"griffitharia",
		1770161
	],
	[
		"s3109546",
		"Griffitharia schwerinii",
		"griffitharia",
		3109546
	],
	[
		"s1770163",
		"Griffitharia thibetica",
		"griffitharia",
		1770163
	],
	[
		"s3095448",
		"Griffitharia wardii",
		"griffitharia",
		3095448
	],
	[
		"s1399692",
		"Gyrotaenia crassifolia",
		"gyrotaenia",
		1399692
	],
	[
		"s1399693",
		"Gyrotaenia microcarpa",
		"gyrotaenia",
		1399693
	],
	[
		"s1586306",
		"Gyrotaenia myriocarpa",
		"gyrotaenia",
		1586306
	],
	[
		"s1399694",
		"Gyrotaenia spicata",
		"gyrotaenia",
		1399694
	],
	[
		"s3089883",
		"Gyrotaenia trujilloana",
		"gyrotaenia",
		3089883
	],
	[
		"s57921",
		"Hagenia abyssinica",
		"hagenia",
		57921
	],
	[
		"s2807231",
		"Haroldiella rapaensis",
		"haroldiella",
		2807231
	],
	[
		"s3816481",
		"Hedlundia abscondita",
		"hedlundia",
		3816481
	],
	[
		"s746469",
		"Hedlundia anglica",
		"hedlundia",
		746469
	],
	[
		"s3091534",
		"Hedlundia armeniaca",
		"hedlundia",
		3091534
	],
	[
		"s1572684",
		"Hedlundia arranensis",
		"hedlundia",
		1572684
	],
	[
		"s1775738",
		"Hedlundia austriaca",
		"hedlundia",
		1775738
	],
	[
		"s1851445",
		"Hedlundia borbasii",
		"hedlundia",
		1851445
	],
	[
		"s1775739",
		"Hedlundia bosniaca",
		"hedlundia",
		1775739
	],
	[
		"s3816482",
		"Hedlundia buekkensis",
		"hedlundia",
		3816482
	],
	[
		"s1155368",
		"Hedlundia cuneifolia",
		"hedlundia",
		1155368
	],
	[
		"s2604389",
		"Hedlundia gauckleri",
		"hedlundia",
		2604389
	],
	[
		"s2604391",
		"Hedlundia harziana",
		"hedlundia",
		2604391
	],
	[
		"s3816483",
		"Hedlundia hazslinszkyana",
		"hedlundia",
		3816483
	],
	[
		"s2604392",
		"Hedlundia hohenesteri",
		"hedlundia",
		2604392
	],
	[
		"s3816484",
		"Hedlundia hornadensis",
		"hedlundia",
		3816484
	],
	[
		"s1775740",
		"Hedlundia hybrida",
		"hedlundia",
		1775740
	],
	[
		"s3816485",
		"Hedlundia kuznetzovii",
		"hedlundia",
		3816485
	],
	[
		"s2666042",
		"Hedlundia lancifolia",
		"hedlundia",
		2666042
	],
	[
		"s1534659",
		"Hedlundia legrei",
		"hedlundia",
		1534659
	],
	[
		"s1155373",
		"Hedlundia leyana",
		"hedlundia",
		1155373
	],
	[
		"s3816486",
		"Hedlundia lippertiana",
		"hedlundia",
		3816486
	],
	[
		"s3816487",
		"Hedlundia lonetalensis",
		"hedlundia",
		3816487
	],
	[
		"s3091540",
		"Hedlundia luristanica",
		"hedlundia",
		3091540
	],
	[
		"s2005213",
		"Hedlundia meinichii",
		"hedlundia",
		2005213
	],
	[
		"s1155374",
		"Hedlundia minima",
		"hedlundia",
		1155374
	],
	[
		"s3816488",
		"Hedlundia motleyi",
		"hedlundia",
		3816488
	],
	[
		"s1000428",
		"Hedlundia mougeotii",
		"hedlundia",
		1000428
	],
	[
		"s3816489",
		"Hedlundia neglecta",
		"hedlundia",
		3816489
	],
	[
		"s3816490",
		"Hedlundia neopinnatifida",
		"hedlundia",
		3816490
	],
	[
		"s3040229",
		"Hedlundia pauca",
		"hedlundia",
		3040229
	],
	[
		"s3040230",
		"Hedlundia pekarovae",
		"hedlundia",
		3040230
	],
	[
		"s3091543",
		"Hedlundia persica",
		"hedlundia",
		3091543
	],
	[
		"s1572687",
		"Hedlundia pseudofennica",
		"hedlundia",
		1572687
	],
	[
		"s1844645",
		"Hedlundia pseudomeinichii",
		"hedlundia",
		1844645
	],
	[
		"s2604397",
		"Hedlundia pseudothuringiaca",
		"hedlundia",
		2604397
	],
	[
		"s2604399",
		"Hedlundia pulchra",
		"hedlundia",
		2604399
	],
	[
		"s3091544",
		"Hedlundia roopiana",
		"hedlundia",
		3091544
	],
	[
		"s3816491",
		"Hedlundia scannelliana",
		"hedlundia",
		3816491
	],
	[
		"s3816492",
		"Hedlundia scepusiensis",
		"hedlundia",
		3816492
	],
	[
		"s2604402",
		"Hedlundia schwarziana",
		"hedlundia",
		2604402
	],
	[
		"s3816493",
		"Hedlundia semipinnata",
		"hedlundia",
		3816493
	],
	[
		"s3816494",
		"Hedlundia sognensis",
		"hedlundia",
		3816494
	],
	[
		"s2666043",
		"Hedlundia subarranensis",
		"hedlundia",
		2666043
	],
	[
		"s2666044",
		"Hedlundia subpinnata",
		"hedlundia",
		2666044
	],
	[
		"s2005313",
		"Hedlundia subsimilis",
		"hedlundia",
		2005313
	],
	[
		"s3091548",
		"Hedlundia takhtajanii",
		"hedlundia",
		3091548
	],
	[
		"s1943558",
		"Hedlundia tamamschjanae",
		"hedlundia",
		1943558
	],
	[
		"s3816495",
		"Hedlundia teodori",
		"hedlundia",
		3816495
	],
	[
		"s3816496",
		"Hedlundia velebitica",
		"hedlundia",
		3816496
	],
	[
		"s746468",
		"Hedlundia x thuringiaca",
		"hedlundia",
		746468
	],
	[
		"s1904798",
		"Helicostylis elegans",
		"helicostylis",
		1904798
	],
	[
		"s2771396",
		"Helicostylis heterotricha",
		"helicostylis",
		2771396
	],
	[
		"s241885",
		"Helicostylis pedunculata",
		"helicostylis",
		241885
	],
	[
		"s3816674",
		"Helicostylis salicifolia",
		"helicostylis",
		3816674
	],
	[
		"s3089650",
		"Helicostylis scabra",
		"helicostylis",
		3089650
	],
	[
		"s241886",
		"Helicostylis tomentosa",
		"helicostylis",
		241886
	],
	[
		"s1635308",
		"Helicostylis tovarensis",
		"helicostylis",
		1635308
	],
	[
		"s2771397",
		"Helicostylis turbinata",
		"helicostylis",
		2771397
	],
	[
		"s3089892",
		"Helinus brevipes",
		"helinus",
		3089892
	],
	[
		"s2984746",
		"Helinus cf. integrifolius QZ-2022",
		"helinus",
		2984746
	],
	[
		"s106681",
		"Helinus integrifolius",
		"helinus",
		106681
	],
	[
		"s1630243",
		"Helinus lanceolatus",
		"helinus",
		1630243
	],
	[
		"s2511961",
		"Helinus mystacinus",
		"helinus",
		2511961
	],
	[
		"s3089893",
		"Helinus ovatus",
		"helinus",
		3089893
	],
	[
		"s3089651",
		"Helinus spartioides",
		"helinus",
		3089651
	],
	[
		"s63068",
		"Hemiptelea davidii",
		"hemiptelea",
		63068
	],
	[
		"s3089895",
		"Hemistylus boehmerioides",
		"hemistylus",
		3089895
	],
	[
		"s1399696",
		"Hemistylus macrostachya",
		"hemistylus",
		1399696
	],
	[
		"s2699476",
		"Hemistylus odontophylla",
		"hemistylus",
		2699476
	],
	[
		"s3817073",
		"Hemistylus velutina",
		"hemistylus",
		3817073
	],
	[
		"s1586307",
		"Hesperocnide sandwicensis",
		"hesperocnide",
		1586307
	],
	[
		"s194267",
		"Hesperocnide tenella",
		"hesperocnide",
		194267
	],
	[
		"s2675837",
		"Hesperomeles cuneata",
		"hesperomeles",
		2675837
	],
	[
		"s3089653",
		"Hesperomeles escalloniifolia",
		"hesperomeles",
		3089653
	],
	[
		"s2675838",
		"Hesperomeles ferruginea",
		"hesperomeles",
		2675838
	],
	[
		"s3089654",
		"Hesperomeles gayana",
		"hesperomeles",
		3089654
	],
	[
		"s2654664",
		"Hesperomeles glabrata",
		"hesperomeles",
		2654664
	],
	[
		"s2675839",
		"Hesperomeles goudotiana",
		"hesperomeles",
		2675839
	],
	[
		"s3809367",
		"Hesperomeles incerta",
		"hesperomeles",
		3809367
	],
	[
		"s691225",
		"Hesperomeles latifolia",
		"hesperomeles",
		691225
	],
	[
		"s3809368",
		"Hesperomeles nitida",
		"hesperomeles",
		3809368
	],
	[
		"s2654665",
		"Hesperomeles obovata",
		"hesperomeles",
		2654665
	],
	[
		"s2650225",
		"Hesperomeles obtusifolia",
		"hesperomeles",
		2650225
	],
	[
		"s3809369",
		"Hesperomeles pachyphylla",
		"hesperomeles",
		3809369
	],
	[
		"s690341",
		"Hesperomeles palcensis",
		"hesperomeles",
		690341
	],
	[
		"s2675840",
		"Hesperomeles pernettyoides",
		"hesperomeles",
		2675840
	],
	[
		"s3809370",
		"Hesperomeles resinosopunctata",
		"hesperomeles",
		3809370
	],
	[
		"s3089896",
		"Hesperomeles weberbaueri",
		"hesperomeles",
		3089896
	],
	[
		"s36612",
		"Heteromeles arbutifolia",
		"heteromeles",
		36612
	],
	[
		"s984794",
		"Hijmania alta",
		"hijmania",
		984794
	],
	[
		"s2604972",
		"Hijmania angusticornis",
		"hijmania",
		2604972
	],
	[
		"s2605005",
		"Hijmania scaphigera",
		"hijmania",
		2605005
	],
	[
		"s3453197",
		"Hijmania turbinata",
		"hijmania",
		3453197
	],
	[
		"s193520",
		"Hippophae goniocarpa",
		"hippophae",
		193520
	],
	[
		"s193515",
		"Hippophae gyantsensis",
		"hippophae",
		193515
	],
	[
		"s2909272",
		"Hippophae gyantsensis x Hippophae neurocarpa",
		"hippophae",
		2909272
	],
	[
		"s1500042",
		"Hippophae gyantsensis x Hippophae neurocarpa subsp. stellatopilosa",
		"hippophae",
		1500042
	],
	[
		"s193522",
		"Hippophae litangensis",
		"hippophae",
		193522
	],
	[
		"s193523",
		"Hippophae neurocarpa",
		"hippophae",
		193523
	],
	[
		"s672069",
		"Hippophae neurocarpa x Hippophae tibetana",
		"hippophae",
		672069
	],
	[
		"s193516",
		"Hippophae rhamnoides",
		"hippophae",
		193516
	],
	[
		"s48234",
		"Hippophae salicifolia",
		"hippophae",
		48234
	],
	[
		"s193531",
		"Hippophae sinensis",
		"hippophae",
		193531
	],
	[
		"s193519",
		"Hippophae tibetana",
		"hippophae",
		193519
	],
	[
		"s1961195",
		"Holodiscus argenteus",
		"holodiscus",
		1961195
	],
	[
		"s3753319",
		"Holodiscus australis",
		"holodiscus",
		3753319
	],
	[
		"s32230",
		"Holodiscus discolor",
		"holodiscus",
		32230
	],
	[
		"s3753320",
		"Holodiscus fissus",
		"holodiscus",
		3753320
	],
	[
		"s3753321",
		"Holodiscus orizabae",
		"holodiscus",
		3753321
	],
	[
		"s3753322",
		"Holodiscus pachydiscus",
		"holodiscus",
		3753322
	],
	[
		"s3753323",
		"Holodiscus velutinus",
		"holodiscus",
		3753323
	],
	[
		"s2708851",
		"Holoptelea grandis",
		"holoptelea",
		2708851
	],
	[
		"s63066",
		"Holoptelea integrifolia",
		"holoptelea",
		63066
	],
	[
		"s667219",
		"Horkelia tridentata",
		"horkelia",
		667219
	],
	[
		"s210357",
		"Hovenia acerba",
		"hovenia",
		210357
	],
	[
		"s99292",
		"Hovenia dulcis",
		"hovenia",
		99292
	],
	[
		"s3770545",
		"Hovenia pubescens",
		"hovenia",
		3770545
	],
	[
		"s3770546",
		"Hovenia tomentella",
		"hovenia",
		3770546
	],
	[
		"s345800",
		"Hovenia trichocarpa",
		"hovenia",
		345800
	],
	[
		"s709068",
		"Hullettia dumosa",
		"hullettia",
		709068
	],
	[
		"s1867293",
		"Hullettia griffithiana",
		"hullettia",
		1867293
	],
	[
		"s3485",
		"Humulus japonicus",
		"humulus",
		3485
	],
	[
		"s3486",
		"Humulus lupulus",
		"humulus",
		3486
	],
	[
		"s436087",
		"Humulus neomexicanus",
		"humulus",
		436087
	],
	[
		"s3825569",
		"Humulus pubescens",
		"humulus",
		3825569
	],
	[
		"s228586",
		"Humulus scandens",
		"humulus",
		228586
	],
	[
		"s1184757",
		"Humulus yunnanensis",
		"humulus",
		1184757
	],
	[
		"s667221",
		"Ivesia arizonica",
		"ivesia",
		667221
	],
	[
		"s1502676",
		"Jaffrea erubescens",
		"jaffrea",
		1502676
	],
	[
		"s1502680",
		"Jaffrea xerocarpa",
		"jaffrea",
		1502680
	],
	[
		"s3710749",
		"Johnstonalia axilliflora",
		"johnstonalia",
		3710749
	],
	[
		"s32231",
		"Kageneckia angustifolia",
		"kageneckia",
		32231
	],
	[
		"s1961196",
		"Kageneckia crataegifolia",
		"kageneckia",
		1961196
	],
	[
		"s1898940",
		"Kageneckia lanceolata",
		"kageneckia",
		1898940
	],
	[
		"s133198",
		"Kageneckia oblonga",
		"kageneckia",
		133198
	],
	[
		"s3870880",
		"Aria edulis x Torminalis glaberrima",
		"karpatiosorbus",
		3870880
	],
	[
		"s2606499",
		"Karpatiosorbus adeana",
		"karpatiosorbus",
		2606499
	],
	[
		"s2695390",
		"Karpatiosorbus admonitor",
		"karpatiosorbus",
		2695390
	],
	[
		"s2604383",
		"Karpatiosorbus badensis",
		"karpatiosorbus",
		2604383
	],
	[
		"s3108480",
		"Karpatiosorbus bakonyensis",
		"karpatiosorbus",
		3108480
	],
	[
		"s746470",
		"Karpatiosorbus bristoliensis",
		"karpatiosorbus",
		746470
	],
	[
		"s2604384",
		"Karpatiosorbus cordigastensis",
		"karpatiosorbus",
		2604384
	],
	[
		"s746471",
		"Karpatiosorbus croceocarpa",
		"karpatiosorbus",
		746471
	],
	[
		"s1572685",
		"Karpatiosorbus devoniensis",
		"karpatiosorbus",
		1572685
	],
	[
		"s2604386",
		"Karpatiosorbus eystettensis",
		"karpatiosorbus",
		2604386
	],
	[
		"s2604387",
		"Karpatiosorbus fischeri",
		"karpatiosorbus",
		2604387
	],
	[
		"s2604388",
		"Karpatiosorbus franconica",
		"karpatiosorbus",
		2604388
	],
	[
		"s2604390",
		"Karpatiosorbus haesitans",
		"karpatiosorbus",
		2604390
	],
	[
		"s2591761",
		"Karpatiosorbus herbipolitana",
		"karpatiosorbus",
		2591761
	],
	[
		"s1902519",
		"Karpatiosorbus hoppeana",
		"karpatiosorbus",
		1902519
	],
	[
		"s3091537",
		"Karpatiosorbus hybrida",
		"karpatiosorbus",
		3091537
	],
	[
		"s746473",
		"Karpatiosorbus latifolia",
		"karpatiosorbus",
		746473
	],
	[
		"s2604393",
		"Karpatiosorbus meierottii",
		"karpatiosorbus",
		2604393
	],
	[
		"s1902520",
		"Karpatiosorbus mergenthaleriana",
		"karpatiosorbus",
		1902520
	],
	[
		"s2604394",
		"Karpatiosorbus meyeri",
		"karpatiosorbus",
		2604394
	],
	[
		"s2604396",
		"Karpatiosorbus perlonga",
		"karpatiosorbus",
		2604396
	],
	[
		"s2604398",
		"Karpatiosorbus puellarum",
		"karpatiosorbus",
		2604398
	],
	[
		"s1902521",
		"Karpatiosorbus ratisbonensis",
		"karpatiosorbus",
		1902521
	],
	[
		"s2604400",
		"Karpatiosorbus schnizleiniana",
		"karpatiosorbus",
		2604400
	],
	[
		"s2604401",
		"Karpatiosorbus schuwerkiorum",
		"karpatiosorbus",
		2604401
	],
	[
		"s3091545",
		"Karpatiosorbus semi-incisa",
		"karpatiosorbus",
		3091545
	],
	[
		"s3091546",
		"Karpatiosorbus slovenica",
		"karpatiosorbus",
		3091546
	],
	[
		"s1572688",
		"Karpatiosorbus subcuneata",
		"karpatiosorbus",
		1572688
	],
	[
		"s3091549",
		"Karpatiosorbus tauricola",
		"karpatiosorbus",
		3091549
	],
	[
		"s3832312",
		"Karwinskia angustata",
		"karwinskia",
		3832312
	],
	[
		"s3832313",
		"Karwinskia bicolor",
		"karwinskia",
		3832313
	],
	[
		"s1127048",
		"Karwinskia calderonii",
		"karwinskia",
		1127048
	],
	[
		"s3832314",
		"Karwinskia caloneura",
		"karwinskia",
		3832314
	],
	[
		"s3832315",
		"Karwinskia colombiana",
		"karwinskia",
		3832315
	],
	[
		"s106683",
		"Karwinskia humboldtiana",
		"karwinskia",
		106683
	],
	[
		"s3090033",
		"Karwinskia latifolia",
		"karwinskia",
		3090033
	],
	[
		"s3090034",
		"Karwinskia mollis",
		"karwinskia",
		3090034
	],
	[
		"s3832316",
		"Karwinskia orbiculata",
		"karwinskia",
		3832316
	],
	[
		"s3089637",
		"Karwinskia pluvialis",
		"karwinskia",
		3089637
	],
	[
		"s3089677",
		"Karwinskia potrerilloana",
		"karwinskia",
		3089677
	],
	[
		"s3832317",
		"Karwinskia rocana",
		"karwinskia",
		3832317
	],
	[
		"s3090035",
		"Karwinskia rzedowskii",
		"karwinskia",
		3090035
	],
	[
		"s3090036",
		"Karwinskia subcordata",
		"karwinskia",
		3090036
	],
	[
		"s3090037",
		"Karwinskia tehuacana",
		"karwinskia",
		3090037
	],
	[
		"s3089678",
		"Karwinskia umbellata",
		"karwinskia",
		3089678
	],
	[
		"s3090038",
		"Karwinskia venturae",
		"karwinskia",
		3090038
	],
	[
		"s401071",
		"Kelseya uniflora",
		"kelseya",
		401071
	],
	[
		"s262939",
		"Kentrothamnus weddellianus",
		"kentrothamnus",
		262939
	],
	[
		"s120385",
		"Kerria japonica",
		"kerria",
		120385
	],
	[
		"s106685",
		"Krugiodendron ferreum",
		"krugiodendron",
		106685
	],
	[
		"s2052770",
		"Lachemilla adscendens",
		"lachemilla",
		2052770
	],
	[
		"s478359",
		"Lachemilla angustata",
		"lachemilla",
		478359
	],
	[
		"s2052771",
		"Lachemilla barbata",
		"lachemilla",
		2052771
	],
	[
		"s2052772",
		"Lachemilla bipinnatifida",
		"lachemilla",
		2052772
	],
	[
		"s2052773",
		"Lachemilla equisetiformis",
		"lachemilla",
		2052773
	],
	[
		"s2052774",
		"Lachemilla erodiifolia",
		"lachemilla",
		2052774
	],
	[
		"s2052775",
		"Lachemilla frigida",
		"lachemilla",
		2052775
	],
	[
		"s907209",
		"Lachemilla holmgrenii",
		"lachemilla",
		907209
	],
	[
		"s2052776",
		"Lachemilla jaramilloi",
		"lachemilla",
		2052776
	],
	[
		"s2495401",
		"Lachemilla lechleriana",
		"lachemilla",
		2495401
	],
	[
		"s907222",
		"Lachemilla llanganatensis",
		"lachemilla",
		907222
	],
	[
		"s2052777",
		"Lachemilla mexiquense",
		"lachemilla",
		2052777
	],
	[
		"s2052778",
		"Lachemilla moritziana",
		"lachemilla",
		2052778
	],
	[
		"s2052779",
		"Lachemilla perryana",
		"lachemilla",
		2052779
	],
	[
		"s2052780",
		"Lachemilla pringlei",
		"lachemilla",
		2052780
	],
	[
		"s2052781",
		"Lachemilla pseudovenusta",
		"lachemilla",
		2052781
	],
	[
		"s2052782",
		"Lachemilla purdiei",
		"lachemilla",
		2052782
	],
	[
		"s2762381",
		"Lachemilla ramosissima",
		"lachemilla",
		2762381
	],
	[
		"s2052783",
		"Lachemilla ranunculoides",
		"lachemilla",
		2052783
	],
	[
		"s2495402",
		"Lachemilla repens",
		"lachemilla",
		2495402
	],
	[
		"s2052784",
		"Lachemilla sarmentosa",
		"lachemilla",
		2052784
	],
	[
		"s2052785",
		"Lachemilla sibbaldiifolia",
		"lachemilla",
		2052785
	],
	[
		"s2495403",
		"Lachemilla standleyi",
		"lachemilla",
		2495403
	],
	[
		"s2052788",
		"Lachemilla steinbachii",
		"lachemilla",
		2052788
	],
	[
		"s2052789",
		"Lachemilla talamanquensis",
		"lachemilla",
		2052789
	],
	[
		"s2052790",
		"Lachemilla velutina",
		"lachemilla",
		2052790
	],
	[
		"s2052791",
		"Lachemilla venusta",
		"lachemilla",
		2052791
	],
	[
		"s2495404",
		"Lachemilla williamsii",
		"lachemilla",
		2495404
	],
	[
		"s1475415",
		"Laportea aestuans",
		"laportea",
		1475415
	],
	[
		"s1586308",
		"Laportea alatipes",
		"laportea",
		1586308
	],
	[
		"s3833626",
		"Laportea amberana",
		"laportea",
		3833626
	],
	[
		"s1303700",
		"Laportea bulbifera",
		"laportea",
		1303700
	],
	[
		"s194269",
		"Laportea canadensis",
		"laportea",
		194269
	],
	[
		"s2306654",
		"Laportea cf. cuspidata WuZY2012230",
		"laportea",
		2306654
	],
	[
		"s3089689",
		"Laportea cuneata",
		"laportea",
		3089689
	],
	[
		"s471947",
		"Laportea cuspidata",
		"laportea",
		471947
	],
	[
		"s2952666",
		"Laportea decumana",
		"laportea",
		2952666
	],
	[
		"s3833627",
		"Laportea disepala",
		"laportea",
		3833627
	],
	[
		"s2806830",
		"Laportea floribunda",
		"laportea",
		2806830
	],
	[
		"s3833628",
		"Laportea fujianensis",
		"laportea",
		3833628
	],
	[
		"s2952667",
		"Laportea grossa",
		"laportea",
		2952667
	],
	[
		"s2806831",
		"Laportea humblotii",
		"laportea",
		2806831
	],
	[
		"s3833629",
		"Laportea humilis",
		"laportea",
		3833629
	],
	[
		"s1303697",
		"Laportea interrupta",
		"laportea",
		1303697
	],
	[
		"s3833630",
		"Laportea jinganensis",
		"laportea",
		3833630
	],
	[
		"s3833631",
		"Laportea lageensis",
		"laportea",
		3833631
	],
	[
		"s1586309",
		"Laportea lanceolata",
		"laportea",
		1586309
	],
	[
		"s3833632",
		"Laportea laxiflora",
		"laportea",
		3833632
	],
	[
		"s540249",
		"Laportea macrostachya",
		"laportea",
		540249
	],
	[
		"s2952668",
		"Laportea medogensis",
		"laportea",
		2952668
	],
	[
		"s2306682",
		"Laportea mooreana",
		"laportea",
		2306682
	],
	[
		"s3089690",
		"Laportea oligoloba",
		"laportea",
		3089690
	],
	[
		"s2306683",
		"Laportea ovalifolia",
		"laportea",
		2306683
	],
	[
		"s1435566",
		"Laportea peduncularis",
		"laportea",
		1435566
	],
	[
		"s3833633",
		"Laportea pedunculata",
		"laportea",
		3833633
	],
	[
		"s3090046",
		"Laportea perrieri",
		"laportea",
		3090046
	],
	[
		"s1586310",
		"Laportea ruderalis",
		"laportea",
		1586310
	],
	[
		"s3833634",
		"Laportea septentrionalis",
		"laportea",
		3833634
	],
	[
		"s3833635",
		"Laportea stolonifera",
		"laportea",
		3833635
	],
	[
		"s3833636",
		"Laportea sumatrana",
		"laportea",
		3833636
	],
	[
		"s3833637",
		"Laportea taiwanensis",
		"laportea",
		3833637
	],
	[
		"s3833638",
		"Laportea ventricosa",
		"laportea",
		3833638
	],
	[
		"s3050862",
		"Laportea violacea",
		"laportea",
		3050862
	],
	[
		"s3833639",
		"Laportea weddellii",
		"laportea",
		3833639
	],
	[
		"s3090047",
		"Lasiodiscus chevalieri",
		"lasiodiscus",
		3090047
	],
	[
		"s2708872",
		"Lasiodiscus fasciculiflorus",
		"lasiodiscus",
		2708872
	],
	[
		"s3090048",
		"Lasiodiscus holtzii",
		"lasiodiscus",
		3090048
	],
	[
		"s3776857",
		"Lasiodiscus lebrunii",
		"lasiodiscus",
		3776857
	],
	[
		"s2708873",
		"Lasiodiscus mannii",
		"lasiodiscus",
		2708873
	],
	[
		"s3090049",
		"Lasiodiscus marmoratus",
		"lasiodiscus",
		3090049
	],
	[
		"s106687",
		"Lasiodiscus mildbraedii",
		"lasiodiscus",
		106687
	],
	[
		"s3090050",
		"Lasiodiscus palustris",
		"lasiodiscus",
		3090050
	],
	[
		"s1237608",
		"Lasiodiscus pervillei",
		"lasiodiscus",
		1237608
	],
	[
		"s3776858",
		"Lasiodiscus rozeirae",
		"lasiodiscus",
		3776858
	],
	[
		"s3776859",
		"Lasiodiscus usambarensis",
		"lasiodiscus",
		3776859
	],
	[
		"s3835225",
		"Lecanthus obtusus",
		"lecanthus",
		3835225
	],
	[
		"s344771",
		"Lecanthus peduncularis",
		"lecanthus",
		344771
	],
	[
		"s1399697",
		"Lecanthus petelotii",
		"lecanthus",
		1399697
	],
	[
		"s3835226",
		"Lecanthus pileoides",
		"lecanthus",
		3835226
	],
	[
		"s137445",
		"Leucosidea sericea",
		"leucosidea",
		137445
	],
	[
		"s3840024",
		"Leucosyke arcuatovenosa",
		"leucosyke",
		3840024
	],
	[
		"s3840025",
		"Leucosyke aspera",
		"leucosyke",
		3840025
	],
	[
		"s1085456",
		"Leucosyke australis",
		"leucosyke",
		1085456
	],
	[
		"s3840026",
		"Leucosyke benguetensis",
		"leucosyke",
		3840026
	],
	[
		"s3840027",
		"Leucosyke bornensis",
		"leucosyke",
		3840027
	],
	[
		"s3840028",
		"Leucosyke brunnescens",
		"leucosyke",
		3840028
	],
	[
		"s3840029",
		"Leucosyke buderi",
		"leucosyke",
		3840029
	],
	[
		"s647274",
		"Leucosyke capitellata",
		"leucosyke",
		647274
	],
	[
		"s3840030",
		"Leucosyke caudata",
		"leucosyke",
		3840030
	],
	[
		"s3840031",
		"Leucosyke celebica",
		"leucosyke",
		3840031
	],
	[
		"s3840032",
		"Leucosyke clemensii",
		"leucosyke",
		3840032
	],
	[
		"s3840033",
		"Leucosyke elmeri",
		"leucosyke",
		3840033
	],
	[
		"s3840034",
		"Leucosyke forbesii",
		"leucosyke",
		3840034
	],
	[
		"s3840035",
		"Leucosyke hispidissima",
		"leucosyke",
		3840035
	],
	[
		"s3840036",
		"Leucosyke javanica",
		"leucosyke",
		3840036
	],
	[
		"s3840037",
		"Leucosyke kjellbergii",
		"leucosyke",
		3840037
	],
	[
		"s3840038",
		"Leucosyke media",
		"leucosyke",
		3840038
	],
	[
		"s3840039",
		"Leucosyke mindorensis",
		"leucosyke",
		3840039
	],
	[
		"s3840040",
		"Leucosyke montana",
		"leucosyke",
		3840040
	],
	[
		"s3840041",
		"Leucosyke negrosensis",
		"leucosyke",
		3840041
	],
	[
		"s3840042",
		"Leucosyke nivea",
		"leucosyke",
		3840042
	],
	[
		"s3840043",
		"Leucosyke ochroneura",
		"leucosyke",
		3840043
	],
	[
		"s3840044",
		"Leucosyke ovalifolia",
		"leucosyke",
		3840044
	],
	[
		"s3840045",
		"Leucosyke pulchra",
		"leucosyke",
		3840045
	],
	[
		"s2807117",
		"Leucosyke puya",
		"leucosyke",
		2807117
	],
	[
		"s1399699",
		"Leucosyke quadrinervia",
		"leucosyke",
		1399699
	],
	[
		"s3840046",
		"Leucosyke rizalensis",
		"leucosyke",
		3840046
	],
	[
		"s3840047",
		"Leucosyke rubiginosa",
		"leucosyke",
		3840047
	],
	[
		"s3840048",
		"Leucosyke salomonensis",
		"leucosyke",
		3840048
	],
	[
		"s3840049",
		"Leucosyke sumatrana",
		"leucosyke",
		3840049
	],
	[
		"s3840050",
		"Leucosyke superfluens",
		"leucosyke",
		3840050
	],
	[
		"s3840051",
		"Leucosyke weddellii",
		"leucosyke",
		3840051
	],
	[
		"s3840052",
		"Leucosyke winkleri-huberti",
		"leucosyke",
		3840052
	],
	[
		"s32232",
		"Lindleya mespiloides",
		"lindleya",
		32232
	],
	[
		"s2201423",
		"Lindleyella schiedeana",
		"lindleyella",
		2201423
	],
	[
		"s194264",
		"Lozanella enantiophylla",
		"lozanella",
		194264
	],
	[
		"s1184758",
		"Lozanella permollis",
		"lozanella",
		1184758
	],
	[
		"s1184759",
		"Lozanella trematoides",
		"lozanella",
		1184759
	],
	[
		"s357459",
		"Luetkea pectinata",
		"luetkea",
		357459
	],
	[
		"s32233",
		"Lyonothamnus floribundus",
		"lyonothamnus",
		32233
	],
	[
		"s992723",
		"Maclura africana",
		"maclura",
		992723
	],
	[
		"s418449",
		"Maclura amboinensis",
		"maclura",
		418449
	],
	[
		"s1867294",
		"Maclura andamanica",
		"maclura",
		1867294
	],
	[
		"s1867295",
		"Maclura brasiliensis",
		"maclura",
		1867295
	],
	[
		"s194324",
		"Maclura cochinchinensis",
		"maclura",
		194324
	],
	[
		"s1341718",
		"Maclura fruticosa",
		"maclura",
		1341718
	],
	[
		"s3843157",
		"Maclura mollis",
		"maclura",
		3843157
	],
	[
		"s3496",
		"Maclura pomifera",
		"maclura",
		3496
	],
	[
		"s1603712",
		"Maclura pubescens",
		"maclura",
		1603712
	],
	[
		"s1867296",
		"Maclura spinosa",
		"maclura",
		1867296
	],
	[
		"s1867297",
		"Maclura thorelii",
		"maclura",
		1867297
	],
	[
		"s681456",
		"Maclura tinctoria",
		"maclura",
		681456
	],
	[
		"s210328",
		"Maclura tricuspidata",
		"maclura",
		210328
	],
	[
		"s3843424",
		"Macromeles formosana",
		"macromeles",
		3843424
	],
	[
		"s106571",
		"Macromeles tschonoskii",
		"macromeles",
		106571
	],
	[
		"s3089711",
		"Maesopsis berchemioides",
		"maesopsis",
		3089711
	],
	[
		"s106689",
		"Maesopsis eminii",
		"maesopsis",
		106689
	],
	[
		"s2807254",
		"Maillardia borbonica",
		"maillardia",
		2807254
	],
	[
		"s2604382",
		"Majovskya algoviensis",
		"majovskya",
		2604382
	],
	[
		"s3843784",
		"Majovskya ambigua",
		"majovskya",
		3843784
	],
	[
		"s3843785",
		"Majovskya haljamovae",
		"majovskya",
		3843785
	],
	[
		"s3843786",
		"Majovskya sudetica",
		"majovskya",
		3843786
	],
	[
		"s3843787",
		"Majovskya zuzanae",
		"majovskya",
		3843787
	],
	[
		"s36614",
		"Malacomeles denticulata",
		"malacomeles",
		36614
	],
	[
		"s3083803",
		"Malacomeles nervosa",
		"malacomeles",
		3083803
	],
	[
		"s2778666",
		"Malacomeles paniculata",
		"malacomeles",
		2778666
	],
	[
		"s3843792",
		"Malacomeles pringlei",
		"malacomeles",
		3843792
	],
	[
		"s3843793",
		"Malacomeles psilantha",
		"malacomeles",
		3843793
	],
	[
		"s241935",
		"Malaisia scandens",
		"malaisia",
		241935
	],
	[
		"s106547",
		"Malus angustifolia",
		"malus",
		106547
	],
	[
		"s3410965",
		"Malus armeniacaefolia (nom. nud.)",
		"malus",
		3410965
	],
	[
		"s106548",
		"Malus asiatica",
		"malus",
		106548
	],
	[
		"s106549",
		"Malus baccata",
		"malus",
		106549
	],
	[
		"s1143236",
		"Malus brevipes",
		"malus",
		1143236
	],
	[
		"s1143237",
		"Malus carolinensis",
		"malus",
		1143237
	],
	[
		"s1400191",
		"Malus caspiriensis",
		"malus",
		1400191
	],
	[
		"s2653639",
		"Malus cf. sylvestris RM-2019",
		"malus",
		2653639
	],
	[
		"s1843289",
		"Malus cf. x robusta OMH0009",
		"malus",
		1843289
	],
	[
		"s106550",
		"Malus coronaria",
		"malus",
		106550
	],
	[
		"s3844197",
		"Malus crescimannoi",
		"malus",
		3844197
	],
	[
		"s3090198",
		"Malus daochengensis",
		"malus",
		3090198
	],
	[
		"s3095559",
		"Malus delavayi",
		"malus",
		3095559
	],
	[
		"s1400193",
		"Malus denticulata",
		"malus",
		1400193
	],
	[
		"s3750",
		"Malus domestica",
		"malus",
		3750
	],
	[
		"s2662992",
		"Malus domestica x Malus asiatica",
		"malus",
		2662992
	],
	[
		"s3591704",
		"Malus domestica x Malus baccata",
		"malus",
		3591704
	],
	[
		"s1379479",
		"Malus domestica x Malus fusca",
		"malus",
		1379479
	],
	[
		"s1297389",
		"Malus domestica x Malus honanensis",
		"malus",
		1297389
	],
	[
		"s3880206",
		"Malus domestica x Malus micromalus",
		"malus",
		3880206
	],
	[
		"s339852",
		"Malus domestica x Malus sieversii",
		"malus",
		339852
	],
	[
		"s2980405",
		"Malus doumeri",
		"malus",
		2980405
	],
	[
		"s138912",
		"Malus floribunda",
		"malus",
		138912
	],
	[
		"s106553",
		"Malus fusca",
		"malus",
		106553
	],
	[
		"s106554",
		"Malus halliana",
		"malus",
		106554
	],
	[
		"s106555",
		"Malus honanensis",
		"malus",
		106555
	],
	[
		"s106556",
		"Malus hupehensis",
		"malus",
		106556
	],
	[
		"s604297",
		"Malus hybrid cultivar",
		"malus",
		604297
	],
	[
		"s370305",
		"Malus hybrid rootstock",
		"malus",
		370305
	],
	[
		"s3410966",
		"Malus hybrida",
		"malus",
		3410966
	],
	[
		"s3095560",
		"Malus indica",
		"malus",
		3095560
	],
	[
		"s106557",
		"Malus ioensis",
		"malus",
		106557
	],
	[
		"s3844198",
		"Malus jinxianensis",
		"malus",
		3844198
	],
	[
		"s106558",
		"Malus kansuensis",
		"malus",
		106558
	],
	[
		"s2969439",
		"Malus komarovii",
		"malus",
		2969439
	],
	[
		"s3090199",
		"Malus lancifolia",
		"malus",
		3090199
	],
	[
		"s1008924",
		"Malus leiocalyca",
		"malus",
		1008924
	],
	[
		"s2834524",
		"Malus longiunguis",
		"malus",
		2834524
	],
	[
		"s1413704",
		"Malus maerkangensis",
		"malus",
		1413704
	],
	[
		"s106559",
		"Malus mandshurica",
		"malus",
		106559
	],
	[
		"s1603816",
		"Malus melliana",
		"malus",
		1603816
	],
	[
		"s147045",
		"Malus micromalus",
		"malus",
		147045
	],
	[
		"s3090200",
		"Malus muliensis",
		"malus",
		3090200
	],
	[
		"s106560",
		"Malus niedzwetzkyana",
		"malus",
		106560
	],
	[
		"s2760075",
		"Malus ombrophila",
		"malus",
		2760075
	],
	[
		"s106562",
		"Malus orientalis",
		"malus",
		106562
	],
	[
		"s2760073",
		"Malus orthocarpa",
		"malus",
		2760073
	],
	[
		"s1400194",
		"Malus pallasiana",
		"malus",
		1400194
	],
	[
		"s106563",
		"Malus prattii",
		"malus",
		106563
	],
	[
		"s106564",
		"Malus prunifolia",
		"malus",
		106564
	],
	[
		"s1781214",
		"Malus prunifolia x Malus pumila",
		"malus",
		1781214
	],
	[
		"s283210",
		"Malus pumila",
		"malus",
		283210
	],
	[
		"s1400197",
		"Malus ringo",
		"malus",
		1400197
	],
	[
		"s470517",
		"Malus rockii",
		"malus",
		470517
	],
	[
		"s3844199",
		"Malus roseotakanabensis",
		"malus",
		3844199
	],
	[
		"s1479478",
		"Malus sargenti x Malus niedzwetzkyana",
		"malus",
		1479478
	],
	[
		"s106565",
		"Malus sargentii",
		"malus",
		106565
	],
	[
		"s1413705",
		"Malus setok",
		"malus",
		1413705
	],
	[
		"s106566",
		"Malus sieboldii",
		"malus",
		106566
	],
	[
		"s1479477",
		"Malus sieboldii x Malus spectabilis",
		"malus",
		1479477
	],
	[
		"s106567",
		"Malus sieversii",
		"malus",
		106567
	],
	[
		"s1143241",
		"Malus sikkimensis",
		"malus",
		1143241
	],
	[
		"s709982",
		"Malus spectabilis",
		"malus",
		709982
	],
	[
		"s2826894",
		"Malus spontanea",
		"malus",
		2826894
	],
	[
		"s3752",
		"Malus sylvestris",
		"malus",
		3752
	],
	[
		"s106568",
		"Malus toringoides",
		"malus",
		106568
	],
	[
		"s106569",
		"Malus transitoria",
		"malus",
		106569
	],
	[
		"s106570",
		"Malus trilobata",
		"malus",
		106570
	],
	[
		"s1479479",
		"Malus x adstringens",
		"malus",
		1479479
	],
	[
		"s1400188",
		"Malus x arnoldiana",
		"malus",
		1400188
	],
	[
		"s2654653",
		"Malus x atrosanguinea",
		"malus",
		2654653
	],
	[
		"s3090533",
		"Malus x dawsoniana",
		"malus",
		3090533
	],
	[
		"s3682900",
		"Malus x eleyi",
		"malus",
		3682900
	],
	[
		"s2759891",
		"Malus x hartwigii",
		"malus",
		2759891
	],
	[
		"s3108479",
		"Malus x magdeburgensis",
		"malus",
		3108479
	],
	[
		"s1479480",
		"Malus x moerlandsii",
		"malus",
		1479480
	],
	[
		"s343465",
		"Malus x platycarpa",
		"malus",
		343465
	],
	[
		"s1217205",
		"Malus x purpurea",
		"malus",
		1217205
	],
	[
		"s1184610",
		"Malus x robusta",
		"malus",
		1184610
	],
	[
		"s1400189",
		"Malus x scheideckeri",
		"malus",
		1400189
	],
	[
		"s1400190",
		"Malus x soulardii",
		"malus",
		1400190
	],
	[
		"s3682901",
		"Malus x sublobata",
		"malus",
		3682901
	],
	[
		"s106572",
		"Malus yunnanensis",
		"malus",
		106572
	],
	[
		"s1143243",
		"Malus zhaojiaoensis",
		"malus",
		1143243
	],
	[
		"s544964",
		"Malus zumi",
		"malus",
		544964
	],
	[
		"s2587782",
		"Malus domestica x (Pyrus pyrifolia x Pyrus communis)",
		"malus-x-pyrus",
		2587782
	],
	[
		"s28521",
		"Malus domestica x Pyrus communis",
		"malus-x-pyrus",
		28521
	],
	[
		"s3113633",
		"Malus domestica x Pyrus x bretschneideri",
		"malus-x-pyrus",
		3113633
	],
	[
		"s3780166",
		"Maoutia ambigua",
		"maoutia",
		3780166
	],
	[
		"s3090204",
		"Maoutia australis",
		"maoutia",
		3090204
	],
	[
		"s3780167",
		"Maoutia diversifolia",
		"maoutia",
		3780167
	],
	[
		"s3780168",
		"Maoutia gracilis",
		"maoutia",
		3780168
	],
	[
		"s3780169",
		"Maoutia lanceolata",
		"maoutia",
		3780169
	],
	[
		"s3780170",
		"Maoutia odontophylla",
		"maoutia",
		3780170
	],
	[
		"s3780171",
		"Maoutia salomonensis",
		"maoutia",
		3780171
	],
	[
		"s1399700",
		"Maoutia setosa",
		"maoutia",
		1399700
	],
	[
		"s3780172",
		"Maoutia warburgii",
		"maoutia",
		3780172
	],
	[
		"s241889",
		"Maquira calophylla",
		"maquira",
		241889
	],
	[
		"s2771398",
		"Maquira coriacea",
		"maquira",
		2771398
	],
	[
		"s681459",
		"Maquira guianensis",
		"maquira",
		681459
	],
	[
		"s2771399",
		"Maquira sclerophylla",
		"maquira",
		2771399
	],
	[
		"s137451",
		"Marcetella maderensis",
		"marcetella",
		137451
	],
	[
		"s137452",
		"Marcetella moquiniana",
		"marcetella",
		137452
	],
	[
		"s3845447",
		"Margyricarpus digynus",
		"margyricarpus",
		3845447
	],
	[
		"s3845448",
		"Margyricarpus lanatus",
		"margyricarpus",
		3845448
	],
	[
		"s3845449",
		"Margyricarpus microcarpus",
		"margyricarpus",
		3845449
	],
	[
		"s281856",
		"Margyricarpus pinnatus",
		"margyricarpus",
		281856
	],
	[
		"s281886",
		"Margyricarpus setosus",
		"margyricarpus",
		281886
	],
	[
		"s241892",
		"Mesogyne insignis",
		"mesogyne",
		241892
	],
	[
		"s356594",
		"Mespilus canescens",
		"mespilus",
		356594
	],
	[
		"s36616",
		"Mespilus germanica",
		"mespilus",
		36616
	],
	[
		"s3711210",
		"Metapilea jingxiensis",
		"metapilea",
		3711210
	],
	[
		"s2807265",
		"Metatrophis margaretae",
		"metatrophis",
		2807265
	],
	[
		"s3850593",
		"Micromeles ambrozyana",
		"micromeles",
		3850593
	],
	[
		"s3850598",
		"Micromeles burtonsmithiorum",
		"micromeles",
		3850598
	],
	[
		"s1770152",
		"Micromeles calcicola",
		"micromeles",
		1770152
	],
	[
		"s2495370",
		"Micromeles calocarpa",
		"micromeles",
		2495370
	],
	[
		"s661363",
		"Micromeles coronata",
		"micromeles",
		661363
	],
	[
		"s3850599",
		"Micromeles granulosa",
		"micromeles",
		3850599
	],
	[
		"s3850600",
		"Micromeles griffithii",
		"micromeles",
		3850600
	],
	[
		"s3850601",
		"Micromeles hedlundii",
		"micromeles",
		3850601
	],
	[
		"s1770156",
		"Micromeles japonica",
		"micromeles",
		1770156
	],
	[
		"s3850602",
		"Micromeles karchungii",
		"micromeles",
		3850602
	],
	[
		"s3850603",
		"Micromeles khasiana",
		"micromeles",
		3850603
	],
	[
		"s3850604",
		"Micromeles ligustrifolia",
		"micromeles",
		3850604
	],
	[
		"s3850605",
		"Micromeles malayensis",
		"micromeles",
		3850605
	],
	[
		"s3850606",
		"Micromeles paucinervia",
		"micromeles",
		3850606
	],
	[
		"s3850607",
		"Micromeles prunifolia",
		"micromeles",
		3850607
	],
	[
		"s1770162",
		"Micromeles rhamnoides",
		"micromeles",
		1770162
	],
	[
		"s3850608",
		"Micromeles sharmae",
		"micromeles",
		3850608
	],
	[
		"s3850609",
		"Micromeles spongbergii",
		"micromeles",
		3850609
	],
	[
		"s3850610",
		"Micromeles subochracea",
		"micromeles",
		3850610
	],
	[
		"s3850611",
		"Micromeles vestita",
		"micromeles",
		3850611
	],
	[
		"s3850612",
		"Micromeles yongdeensis",
		"micromeles",
		3850612
	],
	[
		"s1770165",
		"Micromeles zahlbruckneri",
		"micromeles",
		1770165
	],
	[
		"s140503",
		"Milicia cf. excelsa GD-AB1",
		"milicia",
		140503
	],
	[
		"s140502",
		"Milicia cf. regia GM-AM5",
		"milicia",
		140502
	],
	[
		"s140504",
		"Milicia cf. regia GW-BO12",
		"milicia",
		140504
	],
	[
		"s58664",
		"Milicia excelsa",
		"milicia",
		58664
	],
	[
		"s140313",
		"Milicia regia",
		"milicia",
		140313
	],
	[
		"s2057814",
		"Milicia regia x Milicia excelsa",
		"milicia",
		2057814
	],
	[
		"s3498",
		"Morus alba",
		"morus",
		3498
	],
	[
		"s873450",
		"Morus alba x Morus rubra",
		"morus",
		873450
	],
	[
		"s66392",
		"Morus australis",
		"morus",
		66392
	],
	[
		"s66393",
		"Morus bombycis",
		"morus",
		66393
	],
	[
		"s213035",
		"Morus boninensis",
		"morus",
		213035
	],
	[
		"s226895",
		"Morus cathayana",
		"morus",
		226895
	],
	[
		"s873451",
		"Morus celtidifolia",
		"morus",
		873451
	],
	[
		"s2582704",
		"Morus cf. nigra KP-2019",
		"morus",
		2582704
	],
	[
		"s2582705",
		"Morus cf. wittiorum KP-2019",
		"morus",
		2582705
	],
	[
		"s2582707",
		"Morus hybrid cultivar",
		"morus",
		2582707
	],
	[
		"s248361",
		"Morus indica",
		"morus",
		248361
	],
	[
		"s1453430",
		"Morus kagayamae",
		"morus",
		1453430
	],
	[
		"s3852570",
		"Morus koordersiana",
		"morus",
		3852570
	],
	[
		"s226896",
		"Morus lhou",
		"morus",
		226896
	],
	[
		"s3043289",
		"Morus liboensis",
		"morus",
		3043289
	],
	[
		"s191188",
		"Morus macroura",
		"morus",
		191188
	],
	[
		"s2653506",
		"Morus macroura x Morus indica",
		"morus",
		2653506
	],
	[
		"s3852571",
		"Morus miyabeana",
		"morus",
		3852571
	],
	[
		"s229049",
		"Morus mongolica",
		"morus",
		229049
	],
	[
		"s643835",
		"Morus murrayana",
		"morus",
		643835
	],
	[
		"s85232",
		"Morus nigra",
		"morus",
		85232
	],
	[
		"s981085",
		"Morus notabilis",
		"morus",
		981085
	],
	[
		"s226897",
		"Morus rotundiloba",
		"morus",
		226897
	],
	[
		"s32202",
		"Morus rubra",
		"morus",
		32202
	],
	[
		"s1434888",
		"Morus rubra x Morus alba",
		"morus",
		1434888
	],
	[
		"s249543",
		"Morus serrata",
		"morus",
		249543
	],
	[
		"s3852572",
		"Morus trilobata",
		"morus",
		3852572
	],
	[
		"s229048",
		"Morus wittiorum",
		"morus",
		229048
	],
	[
		"s229047",
		"Morus x mizuho",
		"morus",
		229047
	],
	[
		"s1458532",
		"Morus yunnanensis",
		"morus",
		1458532
	],
	[
		"s1317686",
		"Musanga cecropioides",
		"musanga",
		1317686
	],
	[
		"s1980308",
		"Musanga leo-errerae",
		"musanga",
		1980308
	],
	[
		"s1781621",
		"Myrianthus arboreus",
		"myrianthus",
		1781621
	],
	[
		"s3090291",
		"Myrianthus cuneifolius",
		"myrianthus",
		3090291
	],
	[
		"s3853963",
		"Myrianthus fosi",
		"myrianthus",
		3853963
	],
	[
		"s1220084",
		"Myrianthus holstii",
		"myrianthus",
		1220084
	],
	[
		"s2708904",
		"Myrianthus libericus",
		"myrianthus",
		2708904
	],
	[
		"s1399701",
		"Myrianthus preussii",
		"myrianthus",
		1399701
	],
	[
		"s3853964",
		"Myrianthus scandens",
		"myrianthus",
		3853964
	],
	[
		"s1781622",
		"Myrianthus serratus",
		"myrianthus",
		1781622
	],
	[
		"s3090295",
		"Myriocarpa bifurca",
		"myriocarpa",
		3090295
	],
	[
		"s3853986",
		"Myriocarpa brachystachys",
		"myriocarpa",
		3853986
	],
	[
		"s1413209",
		"Myriocarpa cordifolia",
		"myriocarpa",
		1413209
	],
	[
		"s3090296",
		"Myriocarpa cubilgueitzensis",
		"myriocarpa",
		3090296
	],
	[
		"s3853987",
		"Myriocarpa filiformis",
		"myriocarpa",
		3853987
	],
	[
		"s3090297",
		"Myriocarpa heterospicata",
		"myriocarpa",
		3090297
	],
	[
		"s3090298",
		"Myriocarpa laevigata",
		"myriocarpa",
		3090298
	],
	[
		"s226095",
		"Myriocarpa longipes",
		"myriocarpa",
		226095
	],
	[
		"s1399702",
		"Myriocarpa obovata",
		"myriocarpa",
		1399702
	],
	[
		"s3853988",
		"Myriocarpa obscura",
		"myriocarpa",
		3853988
	],
	[
		"s3853989",
		"Myriocarpa purpurascens",
		"myriocarpa",
		3853989
	],
	[
		"s1569014",
		"Myriocarpa stipitata",
		"myriocarpa",
		1569014
	],
	[
		"s3853990",
		"Myriocarpa tatei",
		"myriocarpa",
		3853990
	],
	[
		"s3090299",
		"Myriocarpa trifurca",
		"myriocarpa",
		3090299
	],
	[
		"s1399704",
		"Nanocnide japonica",
		"nanocnide",
		1399704
	],
	[
		"s1399705",
		"Nanocnide lobata",
		"nanocnide",
		1399705
	],
	[
		"s2663344",
		"Nanocnide pilosa",
		"nanocnide",
		2663344
	],
	[
		"s3097645",
		"Nanocnide simingshanensis",
		"nanocnide",
		3097645
	],
	[
		"s3854291",
		"Nanocnide zhejiangensis",
		"nanocnide",
		3854291
	],
	[
		"s241895",
		"Naucleopsis caloneura",
		"naucleopsis",
		241895
	],
	[
		"s1127094",
		"Naucleopsis capirensis",
		"naucleopsis",
		1127094
	],
	[
		"s3854448",
		"Naucleopsis chiguila",
		"naucleopsis",
		3854448
	],
	[
		"s3089755",
		"Naucleopsis concinna",
		"naucleopsis",
		3089755
	],
	[
		"s3048750",
		"Naucleopsis francisci",
		"naucleopsis",
		3048750
	],
	[
		"s1835401",
		"Naucleopsis glabra",
		"naucleopsis",
		1835401
	],
	[
		"s241896",
		"Naucleopsis guianensis",
		"naucleopsis",
		241896
	],
	[
		"s3854449",
		"Naucleopsis herrerensis",
		"naucleopsis",
		3854449
	],
	[
		"s3854450",
		"Naucleopsis humilis",
		"naucleopsis",
		3854450
	],
	[
		"s2771400",
		"Naucleopsis imitans",
		"naucleopsis",
		2771400
	],
	[
		"s3089756",
		"Naucleopsis inaequalis",
		"naucleopsis",
		3089756
	],
	[
		"s3854451",
		"Naucleopsis insculptula",
		"naucleopsis",
		3854451
	],
	[
		"s3090300",
		"Naucleopsis jamariensis",
		"naucleopsis",
		3090300
	],
	[
		"s241897",
		"Naucleopsis krukovii",
		"naucleopsis",
		241897
	],
	[
		"s2807278",
		"Naucleopsis macrophylla",
		"naucleopsis",
		2807278
	],
	[
		"s241898",
		"Naucleopsis naga",
		"naucleopsis",
		241898
	],
	[
		"s3089757",
		"Naucleopsis oblongifolia",
		"naucleopsis",
		3089757
	],
	[
		"s3048751",
		"Naucleopsis pseudonaga",
		"naucleopsis",
		3048751
	],
	[
		"s3854452",
		"Naucleopsis riparia",
		"naucleopsis",
		3854452
	],
	[
		"s3854453",
		"Naucleopsis stipularis",
		"naucleopsis",
		3854453
	],
	[
		"s3090301",
		"Naucleopsis straminea",
		"naucleopsis",
		3090301
	],
	[
		"s241899",
		"Naucleopsis ternstroemiiflora",
		"naucleopsis",
		241899
	],
	[
		"s3854454",
		"Naucleopsis tubulata",
		"naucleopsis",
		3854454
	],
	[
		"s241900",
		"Naucleopsis ulei",
		"naucleopsis",
		241900
	],
	[
		"s3090302",
		"Naucleopsis velutina",
		"naucleopsis",
		3090302
	],
	[
		"s190004",
		"Neillia affinis",
		"neillia",
		190004
	],
	[
		"s3090303",
		"Neillia breviracemosa",
		"neillia",
		3090303
	],
	[
		"s3090304",
		"Neillia densiflora",
		"neillia",
		3090304
	],
	[
		"s190005",
		"Neillia gracilis",
		"neillia",
		190005
	],
	[
		"s3090305",
		"Neillia grandiflora",
		"neillia",
		3090305
	],
	[
		"s141009",
		"Neillia hanceana",
		"neillia",
		141009
	],
	[
		"s190009",
		"Neillia incisa",
		"neillia",
		190009
	],
	[
		"s3854728",
		"Neillia jianggangshanensis",
		"neillia",
		3854728
	],
	[
		"s3854729",
		"Neillia pendryi",
		"neillia",
		3854729
	],
	[
		"s3050869",
		"Neillia ribesioides",
		"neillia",
		3050869
	],
	[
		"s3090306",
		"Neillia rubiflora",
		"neillia",
		3090306
	],
	[
		"s1043504",
		"Neillia serratisepala",
		"neillia",
		1043504
	],
	[
		"s32234",
		"Neillia sinensis",
		"neillia",
		32234
	],
	[
		"s266787",
		"Neillia sparsiflora",
		"neillia",
		266787
	],
	[
		"s190010",
		"Neillia tanakae",
		"neillia",
		190010
	],
	[
		"s190006",
		"Neillia thibetica",
		"neillia",
		190006
	],
	[
		"s140998",
		"Neillia thyrsiflora",
		"neillia",
		140998
	],
	[
		"s190007",
		"Neillia uekii",
		"neillia",
		190007
	],
	[
		"s1399707",
		"Neodistemon indicus",
		"neodistemon",
		1399707
	],
	[
		"s2306684",
		"Neraudia angulata",
		"neraudia",
		2306684
	],
	[
		"s1399709",
		"Neraudia kauaiensis",
		"neraudia",
		1399709
	],
	[
		"s1399710",
		"Neraudia melastomifolia",
		"neraudia",
		1399710
	],
	[
		"s3090307",
		"Neraudia ovata",
		"neraudia",
		3090307
	],
	[
		"s3090308",
		"Neraudia sericea",
		"neraudia",
		3090308
	],
	[
		"s72162",
		"Nesiota elliptica",
		"nesiota",
		72162
	],
	[
		"s32235",
		"Neviusia alabamensis",
		"neviusia",
		32235
	],
	[
		"s1961200",
		"Neviusia cliftonii",
		"neviusia",
		1961200
	],
	[
		"s106691",
		"Noltea africana",
		"noltea",
		106691
	],
	[
		"s3855803",
		"Normeyera atrimontis",
		"normeyera",
		3855803
	],
	[
		"s3855804",
		"Normeyera caeruleomontana",
		"normeyera",
		3855804
	],
	[
		"s3855805",
		"Normeyera diversicolor",
		"normeyera",
		3855805
	],
	[
		"s2604385",
		"Normeyera doerriana",
		"normeyera",
		2604385
	],
	[
		"s3855806",
		"Normeyera hostii",
		"normeyera",
		3855806
	],
	[
		"s3855807",
		"Normeyera margittaiana",
		"normeyera",
		3855807
	],
	[
		"s3855808",
		"Normeyera montisalpae",
		"normeyera",
		3855808
	],
	[
		"s3855809",
		"Normeyera salatini",
		"normeyera",
		3855809
	],
	[
		"s3855810",
		"Normeyera schinzii",
		"normeyera",
		3855810
	],
	[
		"s2592393",
		"Normeyera x schinzii",
		"normeyera",
		2592393
	],
	[
		"s3089759",
		"Nothocnide discolor",
		"nothocnide",
		3089759
	],
	[
		"s2501722",
		"Nothocnide melastomatifolia",
		"nothocnide",
		2501722
	],
	[
		"s1399711",
		"Nothocnide mollissima",
		"nothocnide",
		1399711
	],
	[
		"s647278",
		"Nothocnide repanda",
		"nothocnide",
		647278
	],
	[
		"s1586311",
		"Obetia aldabrensis",
		"obetia",
		1586311
	],
	[
		"s1470435",
		"Obetia carruthersiana",
		"obetia",
		1470435
	],
	[
		"s3090312",
		"Obetia ficifolia",
		"obetia",
		3090312
	],
	[
		"s3089760",
		"Obetia madagascariensis",
		"obetia",
		3089760
	],
	[
		"s1586312",
		"Obetia pinnatifida",
		"obetia",
		1586312
	],
	[
		"s1586313",
		"Obetia radula",
		"obetia",
		1586313
	],
	[
		"s992759",
		"Obetia tenax",
		"obetia",
		992759
	],
	[
		"s262933",
		"Ochetophila nana",
		"ochetophila",
		262933
	],
	[
		"s262936",
		"Ochetophila trinervis",
		"ochetophila",
		262936
	],
	[
		"s32237",
		"Oemleria cerasiformis",
		"oemleria",
		32237
	],
	[
		"s3857886",
		"Oncostylus albiflorus",
		"oncostylus",
		3857886
	],
	[
		"s148904",
		"Oncostylus cockaynei",
		"oncostylus",
		148904
	],
	[
		"s3857887",
		"Oncostylus divergens",
		"oncostylus",
		3857887
	],
	[
		"s3857888",
		"Oncostylus involucratus",
		"oncostylus",
		3857888
	],
	[
		"s3857889",
		"Oncostylus lechlerianus",
		"oncostylus",
		3857889
	],
	[
		"s148905",
		"Oncostylus leiospermus",
		"oncostylus",
		148905
	],
	[
		"s3857890",
		"Oncostylus pusillus",
		"oncostylus",
		3857890
	],
	[
		"s3857891",
		"Oncostylus renifolius",
		"oncostylus",
		3857891
	],
	[
		"s3857892",
		"Oncostylus uniflorus",
		"oncostylus",
		3857892
	],
	[
		"s2306685",
		"Oreocnide boniana",
		"oreocnide",
		2306685
	],
	[
		"s1399712",
		"Oreocnide frutescens",
		"oreocnide",
		1399712
	],
	[
		"s1679334",
		"Oreocnide integrifolia",
		"oreocnide",
		1679334
	],
	[
		"s2928711",
		"Oreocnide kwangsiensis",
		"oreocnide",
		2928711
	],
	[
		"s3858456",
		"Oreocnide laotica",
		"oreocnide",
		3858456
	],
	[
		"s3858457",
		"Oreocnide murina",
		"oreocnide",
		3858457
	],
	[
		"s3858458",
		"Oreocnide nivea",
		"oreocnide",
		3858458
	],
	[
		"s2928712",
		"Oreocnide obovata",
		"oreocnide",
		2928712
	],
	[
		"s1463642",
		"Oreocnide pedunculata",
		"oreocnide",
		1463642
	],
	[
		"s3858459",
		"Oreocnide rhodopleura",
		"oreocnide",
		3858459
	],
	[
		"s1679352",
		"Oreocnide rubescens",
		"oreocnide",
		1679352
	],
	[
		"s1085473",
		"Oreocnide rufescens",
		"oreocnide",
		1085473
	],
	[
		"s3858460",
		"Oreocnide semicrenata",
		"oreocnide",
		3858460
	],
	[
		"s2928714",
		"Oreocnide serrulata",
		"oreocnide",
		2928714
	],
	[
		"s3858461",
		"Oreocnide sylvatica",
		"oreocnide",
		3858461
	],
	[
		"s2306686",
		"Oreocnide tonkinensis",
		"oreocnide",
		2306686
	],
	[
		"s2306688",
		"Oreocnide trinervis",
		"oreocnide",
		2306688
	],
	[
		"s1441791",
		"Oreoherzogia fallax",
		"oreoherzogia",
		1441791
	],
	[
		"s1813055",
		"Oreoherzogia glaucophylla",
		"oreoherzogia",
		1813055
	],
	[
		"s1813057",
		"Oreoherzogia imeretina",
		"oreoherzogia",
		1813057
	],
	[
		"s280023",
		"Oreoherzogia pumila",
		"oreoherzogia",
		280023
	],
	[
		"s1813094",
		"Oreoherzogia sibthorpiana",
		"oreoherzogia",
		1813094
	],
	[
		"s133201",
		"Osteomeles anthyllidifolia",
		"osteomeles",
		133201
	],
	[
		"s1322134",
		"Osteomeles boninensis",
		"osteomeles",
		1322134
	],
	[
		"s1322135",
		"Osteomeles lanata",
		"osteomeles",
		1322135
	],
	[
		"s36618",
		"Osteomeles schwerinae",
		"osteomeles",
		36618
	],
	[
		"s3859057",
		"Osteomeles schweriniae",
		"osteomeles",
		3859057
	],
	[
		"s1881092",
		"Osteomeles subrotunda",
		"osteomeles",
		1881092
	],
	[
		"s210383",
		"Paliurus hemsleyanus",
		"paliurus",
		210383
	],
	[
		"s2021930",
		"Paliurus hirsutus",
		"paliurus",
		2021930
	],
	[
		"s2021929",
		"Paliurus orientalis",
		"paliurus",
		2021929
	],
	[
		"s345801",
		"Paliurus ramosissimus",
		"paliurus",
		345801
	],
	[
		"s106693",
		"Paliurus spina-christi",
		"paliurus",
		106693
	],
	[
		"s323941",
		"Papistylus grandiflorus",
		"papistylus",
		323941
	],
	[
		"s3859871",
		"Papistylus intropubens",
		"papistylus",
		3859871
	],
	[
		"s709069",
		"Parartocarpus bracteatus",
		"parartocarpus",
		709069
	],
	[
		"s241902",
		"Parartocarpus venenosus",
		"parartocarpus",
		241902
	],
	[
		"s3477",
		"Parasponia rigida",
		"parasponia",
		3477
	],
	[
		"s1603294",
		"Parasponia rugosa",
		"parasponia",
		1603294
	],
	[
		"s2005749",
		"Parasponia andersonii x Trema tomentosa",
		"parasponia-x-trema",
		2005749
	],
	[
		"s3089776",
		"Paratrophis anthropophagorum",
		"paratrophis",
		3089776
	],
	[
		"s1085501",
		"Paratrophis ascendens",
		"paratrophis",
		1085501
	],
	[
		"s1382183",
		"Paratrophis australiana",
		"paratrophis",
		1382183
	],
	[
		"s450848",
		"Paratrophis banksii",
		"paratrophis",
		450848
	],
	[
		"s241928",
		"Paratrophis glabra",
		"paratrophis",
		241928
	],
	[
		"s3054372",
		"Paratrophis insignis",
		"paratrophis",
		3054372
	],
	[
		"s194261",
		"Paratrophis pendulina",
		"paratrophis",
		194261
	],
	[
		"s2502978",
		"Paratrophis philippinensis",
		"paratrophis",
		2502978
	],
	[
		"s3860121",
		"Paratrophis sclerophylla",
		"paratrophis",
		3860121
	],
	[
		"s241929",
		"Paratrophis smithii",
		"paratrophis",
		241929
	],
	[
		"s3860122",
		"Paratrophis solomonensis",
		"paratrophis",
		3860122
	],
	[
		"s1465655",
		"Parietaria alsinifolia",
		"parietaria",
		1465655
	],
	[
		"s2590086",
		"Parietaria australis",
		"parietaria",
		2590086
	],
	[
		"s2590071",
		"Parietaria cardiostegia",
		"parietaria",
		2590071
	],
	[
		"s2608279",
		"Parietaria cf. judaica CS-2019",
		"parietaria",
		2608279
	],
	[
		"s2590072",
		"Parietaria cretica",
		"parietaria",
		2590072
	],
	[
		"s647281",
		"Parietaria debilis",
		"parietaria",
		647281
	],
	[
		"s3015731",
		"Parietaria decoris",
		"parietaria",
		3015731
	],
	[
		"s2590087",
		"Parietaria elliptica",
		"parietaria",
		2590087
	],
	[
		"s3860150",
		"Parietaria erronea",
		"parietaria",
		3860150
	],
	[
		"s3860151",
		"Parietaria feliciana",
		"parietaria",
		3860151
	],
	[
		"s1620155",
		"Parietaria floridana",
		"parietaria",
		1620155
	],
	[
		"s2042442",
		"Parietaria hespera",
		"parietaria",
		2042442
	],
	[
		"s33127",
		"Parietaria judaica",
		"parietaria",
		33127
	],
	[
		"s2590073",
		"Parietaria laxiflora",
		"parietaria",
		2590073
	],
	[
		"s2590074",
		"Parietaria littoralis",
		"parietaria",
		2590074
	],
	[
		"s1533267",
		"Parietaria lusitanica",
		"parietaria",
		1533267
	],
	[
		"s3090339",
		"Parietaria macrophylla",
		"parietaria",
		3090339
	],
	[
		"s2590075",
		"Parietaria mauritanica",
		"parietaria",
		2590075
	],
	[
		"s1399715",
		"Parietaria micrantha",
		"parietaria",
		1399715
	],
	[
		"s13187",
		"Parietaria officinalis",
		"parietaria",
		13187
	],
	[
		"s194270",
		"Parietaria pensylvanica",
		"parietaria",
		194270
	],
	[
		"s2590076",
		"Parietaria praetermissa",
		"parietaria",
		2590076
	],
	[
		"s3860152",
		"Parietaria rechingeri",
		"parietaria",
		3860152
	],
	[
		"s3860153",
		"Parietaria rhodopaea",
		"parietaria",
		3860153
	],
	[
		"s3860154",
		"Parietaria roschanica",
		"parietaria",
		3860154
	],
	[
		"s3860155",
		"Parietaria semispeluncaria",
		"parietaria",
		3860155
	],
	[
		"s3860156",
		"Parietaria serbica",
		"parietaria",
		3860156
	],
	[
		"s3860157",
		"Parietaria taiwaniana",
		"parietaria",
		3860157
	],
	[
		"s3860158",
		"Parietaria umbricola",
		"parietaria",
		3860158
	],
	[
		"s3711211",
		"Parsana malekiana",
		"parsana",
		3711211
	],
	[
		"s3773512",
		"Pellionia annamica",
		"pellionia",
		3773512
	],
	[
		"s3773513",
		"Pellionia brachyceras",
		"pellionia",
		3773513
	],
	[
		"s3132614",
		"Pellionia brevifolia",
		"pellionia",
		3132614
	],
	[
		"s3773514",
		"Pellionia calcifera",
		"pellionia",
		3773514
	],
	[
		"s3773515",
		"Pellionia cephaloidea",
		"pellionia",
		3773515
	],
	[
		"s194272",
		"Pellionia daveauana",
		"pellionia",
		194272
	],
	[
		"s3773516",
		"Pellionia donglanensis",
		"pellionia",
		3773516
	],
	[
		"s3773517",
		"Pellionia elatostemoides",
		"pellionia",
		3773517
	],
	[
		"s3773518",
		"Pellionia fruticosa",
		"pellionia",
		3773518
	],
	[
		"s3773519",
		"Pellionia funingensis",
		"pellionia",
		3773519
	],
	[
		"s2747978",
		"Pellionia jinyunensis",
		"pellionia",
		2747978
	],
	[
		"s3773520",
		"Pellionia laibinensis",
		"pellionia",
		3773520
	],
	[
		"s2572699",
		"Pellionia longipetiolata",
		"pellionia",
		2572699
	],
	[
		"s3773521",
		"Pellionia longzhouensis",
		"pellionia",
		3773521
	],
	[
		"s1399716",
		"Pellionia macrophylla",
		"pellionia",
		1399716
	],
	[
		"s1661604",
		"Pellionia minima",
		"pellionia",
		1661604
	],
	[
		"s3773522",
		"Pellionia mollissima",
		"pellionia",
		3773522
	],
	[
		"s3773523",
		"Pellionia pauciflora",
		"pellionia",
		3773523
	],
	[
		"s3143404",
		"Pellionia pellucida",
		"pellionia",
		3143404
	],
	[
		"s2004481",
		"Pellionia pulchra",
		"pellionia",
		2004481
	],
	[
		"s1785683",
		"Pellionia retrohispida",
		"pellionia",
		1785683
	],
	[
		"s3773524",
		"Pellionia ronganensis",
		"pellionia",
		3773524
	],
	[
		"s1002525",
		"Pellionia scabra",
		"pellionia",
		1002525
	],
	[
		"s3773525",
		"Pellionia simianschanica",
		"pellionia",
		3773525
	],
	[
		"s3773526",
		"Pellionia sumatrana",
		"pellionia",
		3773526
	],
	[
		"s3773527",
		"Pellionia thorelii",
		"pellionia",
		3773527
	],
	[
		"s3773528",
		"Pellionia tonkinensis",
		"pellionia",
		3773528
	],
	[
		"s3773529",
		"Pellionia tritepala",
		"pellionia",
		3773529
	],
	[
		"s1399719",
		"Pellionia tsoongii",
		"pellionia",
		1399719
	],
	[
		"s1785684",
		"Pellionia viridis",
		"pellionia",
		1785684
	],
	[
		"s2306689",
		"Pellionia yunnanensis",
		"pellionia",
		2306689
	],
	[
		"s519533",
		"Pentactina rupicola",
		"pentactina",
		519533
	],
	[
		"s3115579",
		"Pentactina schlothauerae",
		"pentactina",
		3115579
	],
	[
		"s36620",
		"Peraphyllum ramosissimum",
		"peraphyllum",
		36620
	],
	[
		"s241904",
		"Perebea angustifolia",
		"perebea",
		241904
	],
	[
		"s241905",
		"Perebea guianensis",
		"perebea",
		241905
	],
	[
		"s3863509",
		"Perebea hispidula",
		"perebea",
		3863509
	],
	[
		"s241906",
		"Perebea humilis",
		"perebea",
		241906
	],
	[
		"s382340",
		"Perebea longepedunculata",
		"perebea",
		382340
	],
	[
		"s3141197",
		"Perebea longipedunculata",
		"perebea",
		3141197
	],
	[
		"s3863510",
		"Perebea mennegae",
		"perebea",
		3863510
	],
	[
		"s241907",
		"Perebea mollis",
		"perebea",
		241907
	],
	[
		"s382337",
		"Perebea rubra",
		"perebea",
		382337
	],
	[
		"s2771401",
		"Perebea tessmannii",
		"perebea",
		2771401
	],
	[
		"s241908",
		"Perebea xanthochyma",
		"perebea",
		241908
	],
	[
		"s3089781",
		"Petelotiella tonkinensis",
		"petelotiella",
		3089781
	],
	[
		"s457879",
		"Petrophytum caespitosum",
		"petrophytum",
		457879
	],
	[
		"s3089782",
		"Petrophytum cinerascens",
		"petrophytum",
		3089782
	],
	[
		"s409503",
		"Petrophytum hendersonii",
		"petrophytum",
		409503
	],
	[
		"s3089787",
		"Phenax angustifolius",
		"phenax",
		3089787
	],
	[
		"s3864074",
		"Phenax asper",
		"phenax",
		3864074
	],
	[
		"s3090352",
		"Phenax bullatus",
		"phenax",
		3090352
	],
	[
		"s3864075",
		"Phenax ekmanii",
		"phenax",
		3864075
	],
	[
		"s3864076",
		"Phenax erectus",
		"phenax",
		3864076
	],
	[
		"s3864077",
		"Phenax flavifolius",
		"phenax",
		3864077
	],
	[
		"s3864078",
		"Phenax granulatus",
		"phenax",
		3864078
	],
	[
		"s3864079",
		"Phenax haitensis",
		"phenax",
		3864079
	],
	[
		"s2282287",
		"Phenax hirtus",
		"phenax",
		2282287
	],
	[
		"s3090353",
		"Phenax integrifolius",
		"phenax",
		3090353
	],
	[
		"s1079187",
		"Phenax laevigatus",
		"phenax",
		1079187
	],
	[
		"s3864080",
		"Phenax laevis",
		"phenax",
		3864080
	],
	[
		"s3090354",
		"Phenax laxiflorus",
		"phenax",
		3090354
	],
	[
		"s3090355",
		"Phenax madagascariensis",
		"phenax",
		3090355
	],
	[
		"s858904",
		"Phenax mexicanus",
		"phenax",
		858904
	],
	[
		"s3864081",
		"Phenax microcarpus",
		"phenax",
		3864081
	],
	[
		"s3864082",
		"Phenax microphyllus",
		"phenax",
		3864082
	],
	[
		"s3864083",
		"Phenax pauciflorus",
		"phenax",
		3864083
	],
	[
		"s3864084",
		"Phenax pauciserratus",
		"phenax",
		3864084
	],
	[
		"s3090356",
		"Phenax perrieri",
		"phenax",
		3090356
	],
	[
		"s3864085",
		"Phenax poiretii",
		"phenax",
		3864085
	],
	[
		"s1569021",
		"Phenax rugosus",
		"phenax",
		1569021
	],
	[
		"s3864086",
		"Phenax sessilifolius",
		"phenax",
		3864086
	],
	[
		"s2306690",
		"Phenax sonneratii",
		"phenax",
		2306690
	],
	[
		"s3864087",
		"Phenax uliginosus",
		"phenax",
		3864087
	],
	[
		"s3864088",
		"Phenax weddellianus",
		"phenax",
		3864088
	],
	[
		"s2305211",
		"Phippsiomeles guerreris",
		"phippsiomeles",
		2305211
	],
	[
		"s2305213",
		"Phippsiomeles matudae",
		"phippsiomeles",
		2305213
	],
	[
		"s661346",
		"Phippsiomeles mexicana",
		"phippsiomeles",
		661346
	],
	[
		"s661347",
		"Phippsiomeles microcarpa",
		"phippsiomeles",
		661347
	],
	[
		"s661348",
		"Phippsiomeles oblongifolia",
		"phippsiomeles",
		661348
	],
	[
		"s3050871",
		"Photinia anlungensis",
		"photinia",
		3050871
	],
	[
		"s455096",
		"Photinia beauverdiana",
		"photinia",
		455096
	],
	[
		"s2675832",
		"Photinia beckii",
		"photinia",
		2675832
	],
	[
		"s661354",
		"Photinia benthamiana",
		"photinia",
		661354
	],
	[
		"s661320",
		"Photinia berberidifolia",
		"photinia",
		661320
	],
	[
		"s661340",
		"Photinia chihsiniana",
		"photinia",
		661340
	],
	[
		"s3864542",
		"Photinia chingiana",
		"photinia",
		3864542
	],
	[
		"s3864543",
		"Photinia chingshuiensis",
		"photinia",
		3864543
	],
	[
		"s3864544",
		"Photinia chiuana",
		"photinia",
		3864544
	],
	[
		"s2873988",
		"Photinia crassifolia",
		"photinia",
		2873988
	],
	[
		"s3864545",
		"Photinia cucphuongensis",
		"photinia",
		3864545
	],
	[
		"s661341",
		"Photinia davidsoniae",
		"photinia",
		661341
	],
	[
		"s661358",
		"Photinia fokienensis",
		"photinia",
		661358
	],
	[
		"s294377",
		"Photinia glabra",
		"photinia",
		294377
	],
	[
		"s661342",
		"Photinia glomerata",
		"photinia",
		661342
	],
	[
		"s3864546",
		"Photinia griffithii",
		"photinia",
		3864546
	],
	[
		"s661359",
		"Photinia hirsuta",
		"photinia",
		661359
	],
	[
		"s661360",
		"Photinia impressivena",
		"photinia",
		661360
	],
	[
		"s661343",
		"Photinia integrifolia",
		"photinia",
		661343
	],
	[
		"s661361",
		"Photinia komarovii",
		"photinia",
		661361
	],
	[
		"s2305212",
		"Photinia kwangsiensis",
		"photinia",
		2305212
	],
	[
		"s2675833",
		"Photinia lanuginosa",
		"photinia",
		2675833
	],
	[
		"s2291143",
		"Photinia lasiogyna",
		"photinia",
		2291143
	],
	[
		"s3864547",
		"Photinia lindleyana",
		"photinia",
		3864547
	],
	[
		"s661344",
		"Photinia lochengensis",
		"photinia",
		661344
	],
	[
		"s661345",
		"Photinia loriformis",
		"photinia",
		661345
	],
	[
		"s455099",
		"Photinia lucida",
		"photinia",
		455099
	],
	[
		"s3090357",
		"Photinia megaphylla",
		"photinia",
		3090357
	],
	[
		"s455100",
		"Photinia niitakayamensis",
		"photinia",
		455100
	],
	[
		"s455101",
		"Photinia parvifolia",
		"photinia",
		455101
	],
	[
		"s3090358",
		"Photinia podocarpifolia",
		"photinia",
		3090358
	],
	[
		"s661349",
		"Photinia prionophylla",
		"photinia",
		661349
	],
	[
		"s661350",
		"Photinia prunifolia",
		"photinia",
		661350
	],
	[
		"s661351",
		"Photinia raupingensis",
		"photinia",
		661351
	],
	[
		"s661362",
		"Photinia schneideriana",
		"photinia",
		661362
	],
	[
		"s140999",
		"Photinia serratifolia",
		"photinia",
		140999
	],
	[
		"s664754",
		"Photinia sorbifolia",
		"photinia",
		664754
	],
	[
		"s665325",
		"Photinia stenophylla",
		"photinia",
		665325
	],
	[
		"s2654666",
		"Photinia taishunensis",
		"photinia",
		2654666
	],
	[
		"s661353",
		"Photinia tsaii",
		"photinia",
		661353
	],
	[
		"s661352",
		"Photinia tushanensis",
		"photinia",
		661352
	],
	[
		"s3093685",
		"Photinia undulata",
		"photinia",
		3093685
	],
	[
		"s1322150",
		"Photinia wrightiana",
		"photinia",
		1322150
	],
	[
		"s23200",
		"Photinia x fraseri",
		"photinia",
		23200
	],
	[
		"s1324432",
		"Phylica abietina",
		"phylica",
		1324432
	],
	[
		"s1604780",
		"Phylica acmaephylla",
		"phylica",
		1604780
	],
	[
		"s1604781",
		"Phylica aemula",
		"phylica",
		1604781
	],
	[
		"s1324433",
		"Phylica affinis",
		"phylica",
		1324433
	],
	[
		"s3090359",
		"Phylica agathosmoides",
		"phylica",
		3090359
	],
	[
		"s1324434",
		"Phylica alba",
		"phylica",
		1324434
	],
	[
		"s3835002",
		"Phylica alpina",
		"phylica",
		3835002
	],
	[
		"s3835003",
		"Phylica alticola",
		"phylica",
		3835003
	],
	[
		"s1604782",
		"Phylica altigena",
		"phylica",
		1604782
	],
	[
		"s1324435",
		"Phylica ambigua",
		"phylica",
		1324435
	],
	[
		"s3835004",
		"Phylica amoena",
		"phylica",
		3835004
	],
	[
		"s3835005",
		"Phylica ampliata",
		"phylica",
		3835005
	],
	[
		"s3835006",
		"Phylica anomala",
		"phylica",
		3835006
	],
	[
		"s1604783",
		"Phylica apiculata",
		"phylica",
		1604783
	],
	[
		"s172222",
		"Phylica arborea",
		"phylica",
		172222
	],
	[
		"s1604784",
		"Phylica atrata",
		"phylica",
		1604784
	],
	[
		"s1324436",
		"Phylica axillaris",
		"phylica",
		1324436
	],
	[
		"s3835007",
		"Phylica barbata",
		"phylica",
		3835007
	],
	[
		"s3835008",
		"Phylica barnardii",
		"phylica",
		3835008
	],
	[
		"s3835009",
		"Phylica bathiei",
		"phylica",
		3835009
	],
	[
		"s3090360",
		"Phylica bolusii",
		"phylica",
		3090360
	],
	[
		"s3835010",
		"Phylica brachycephala",
		"phylica",
		3835010
	],
	[
		"s3090361",
		"Phylica brevifolia",
		"phylica",
		3090361
	],
	[
		"s3835011",
		"Phylica burchellii",
		"phylica",
		3835011
	],
	[
		"s172223",
		"Phylica buxifolia",
		"phylica",
		172223
	],
	[
		"s3835012",
		"Phylica calcarata",
		"phylica",
		3835012
	],
	[
		"s1604785",
		"Phylica callosa",
		"phylica",
		1604785
	],
	[
		"s1324437",
		"Phylica cephalantha",
		"phylica",
		1324437
	],
	[
		"s3835013",
		"Phylica chionocephala",
		"phylica",
		3835013
	],
	[
		"s3835014",
		"Phylica chionophila",
		"phylica",
		3835014
	],
	[
		"s3090362",
		"Phylica comosa",
		"phylica",
		3090362
	],
	[
		"s3090363",
		"Phylica comptonii",
		"phylica",
		3090363
	],
	[
		"s1604786",
		"Phylica confusa",
		"phylica",
		1604786
	],
	[
		"s1604787",
		"Phylica constricta",
		"phylica",
		1604787
	],
	[
		"s3835015",
		"Phylica costata",
		"phylica",
		3835015
	],
	[
		"s172224",
		"Phylica cryptandroides",
		"phylica",
		172224
	],
	[
		"s1604788",
		"Phylica curvifolia",
		"phylica",
		1604788
	],
	[
		"s1604789",
		"Phylica cuspidata",
		"phylica",
		1604789
	],
	[
		"s1324438",
		"Phylica cylindrica",
		"phylica",
		1324438
	],
	[
		"s1604790",
		"Phylica debilis",
		"phylica",
		1604790
	],
	[
		"s3090364",
		"Phylica diffusa",
		"phylica",
		3090364
	],
	[
		"s1604793",
		"Phylica dioica",
		"phylica",
		1604793
	],
	[
		"s1604794",
		"Phylica diosmoides",
		"phylica",
		1604794
	],
	[
		"s1324439",
		"Phylica disticha",
		"phylica",
		1324439
	],
	[
		"s1604795",
		"Phylica dodii",
		"phylica",
		1604795
	],
	[
		"s3835016",
		"Phylica elimensis",
		"phylica",
		3835016
	],
	[
		"s178505",
		"Phylica emirnensis",
		"phylica",
		178505
	],
	[
		"s1604796",
		"Phylica empetroides",
		"phylica",
		1604796
	],
	[
		"s172225",
		"Phylica ericoides",
		"phylica",
		172225
	],
	[
		"s1324440",
		"Phylica excelsa",
		"phylica",
		1324440
	],
	[
		"s3835017",
		"Phylica floccosa",
		"phylica",
		3835017
	],
	[
		"s1604797",
		"Phylica floribunda",
		"phylica",
		1604797
	],
	[
		"s1324441",
		"Phylica fourcadei",
		"phylica",
		1324441
	],
	[
		"s172226",
		"Phylica fruticosa",
		"phylica",
		172226
	],
	[
		"s3835018",
		"Phylica galpinii",
		"phylica",
		3835018
	],
	[
		"s3835019",
		"Phylica glabrata",
		"phylica",
		3835019
	],
	[
		"s1604798",
		"Phylica gnidioides",
		"phylica",
		1604798
	],
	[
		"s1604799",
		"Phylica gracilis",
		"phylica",
		1604799
	],
	[
		"s3835020",
		"Phylica greyi",
		"phylica",
		3835020
	],
	[
		"s3835021",
		"Phylica guthriei",
		"phylica",
		3835021
	],
	[
		"s1324442",
		"Phylica harveyi",
		"phylica",
		1324442
	],
	[
		"s3835022",
		"Phylica hirta",
		"phylica",
		3835022
	],
	[
		"s1324443",
		"Phylica humilis",
		"phylica",
		1324443
	],
	[
		"s1324444",
		"Phylica imberbis",
		"phylica",
		1324444
	],
	[
		"s1604800",
		"Phylica incurvata",
		"phylica",
		1604800
	],
	[
		"s3835023",
		"Phylica insignis",
		"phylica",
		3835023
	],
	[
		"s1604801",
		"Phylica intrusa",
		"phylica",
		1604801
	],
	[
		"s1604802",
		"Phylica karroica",
		"phylica",
		1604802
	],
	[
		"s1604803",
		"Phylica keetii",
		"phylica",
		1604803
	],
	[
		"s1324445",
		"Phylica lachneaeoides",
		"phylica",
		1324445
	],
	[
		"s3835024",
		"Phylica laevifolia",
		"phylica",
		3835024
	],
	[
		"s1324446",
		"Phylica laevigata",
		"phylica",
		1324446
	],
	[
		"s1324447",
		"Phylica laevis",
		"phylica",
		1324447
	],
	[
		"s1324448",
		"Phylica lanata",
		"phylica",
		1324448
	],
	[
		"s1604805",
		"Phylica lasiantha",
		"phylica",
		1604805
	],
	[
		"s1324449",
		"Phylica lasiocarpa",
		"phylica",
		1324449
	],
	[
		"s1324450",
		"Phylica leipoldtii",
		"phylica",
		1324450
	],
	[
		"s1604806",
		"Phylica levynsiae",
		"phylica",
		1604806
	],
	[
		"s3835025",
		"Phylica linifolia",
		"phylica",
		3835025
	],
	[
		"s1604807",
		"Phylica litoralis",
		"phylica",
		1604807
	],
	[
		"s3835026",
		"Phylica longimontana",
		"phylica",
		3835026
	],
	[
		"s1604808",
		"Phylica lucens",
		"phylica",
		1604808
	],
	[
		"s3090365",
		"Phylica lucida",
		"phylica",
		3090365
	],
	[
		"s3090366",
		"Phylica mairei",
		"phylica",
		3090366
	],
	[
		"s3835027",
		"Phylica marlothii",
		"phylica",
		3835027
	],
	[
		"s3835028",
		"Phylica maximiliani",
		"phylica",
		3835028
	],
	[
		"s1604809",
		"Phylica meyeri",
		"phylica",
		1604809
	],
	[
		"s1604810",
		"Phylica minutiflora",
		"phylica",
		1604810
	],
	[
		"s172227",
		"Phylica montana",
		"phylica",
		172227
	],
	[
		"s3835029",
		"Phylica mundii",
		"phylica",
		3835029
	],
	[
		"s178506",
		"Phylica natalensis",
		"phylica",
		178506
	],
	[
		"s3090367",
		"Phylica nervosa",
		"phylica",
		3090367
	],
	[
		"s1324451",
		"Phylica nigrita",
		"phylica",
		1324451
	],
	[
		"s3090368",
		"Phylica nigromontana",
		"phylica",
		3090368
	],
	[
		"s106694",
		"Phylica nitida",
		"phylica",
		106694
	],
	[
		"s3835030",
		"Phylica nodosa",
		"phylica",
		3835030
	],
	[
		"s1324452",
		"Phylica obtusifolia",
		"phylica",
		1324452
	],
	[
		"s1324453",
		"Phylica odorata",
		"phylica",
		1324453
	],
	[
		"s172228",
		"Phylica oleifolia",
		"phylica",
		172228
	],
	[
		"s172229",
		"Phylica paniculata",
		"phylica",
		172229
	],
	[
		"s1324454",
		"Phylica parviflora",
		"phylica",
		1324454
	],
	[
		"s1604811",
		"Phylica parvula",
		"phylica",
		1604811
	],
	[
		"s1604812",
		"Phylica pauciflora",
		"phylica",
		1604812
	],
	[
		"s1604813",
		"Phylica pearsonii",
		"phylica",
		1604813
	],
	[
		"s1324455",
		"Phylica pinea",
		"phylica",
		1324455
	],
	[
		"s3835031",
		"Phylica piquetbergensis",
		"phylica",
		3835031
	],
	[
		"s172230",
		"Phylica plumigera",
		"phylica",
		172230
	],
	[
		"s1324456",
		"Phylica plumosa",
		"phylica",
		1324456
	],
	[
		"s72164",
		"Phylica polifolia",
		"phylica",
		72164
	],
	[
		"s1604814",
		"Phylica propinqua",
		"phylica",
		1604814
	],
	[
		"s74494",
		"Phylica pubescens",
		"phylica",
		74494
	],
	[
		"s1604815",
		"Phylica pulchella",
		"phylica",
		1604815
	],
	[
		"s1324457",
		"Phylica purpurea",
		"phylica",
		1324457
	],
	[
		"s1324458",
		"Phylica pustulata",
		"phylica",
		1324458
	],
	[
		"s1324459",
		"Phylica recurvifolia",
		"phylica",
		1324459
	],
	[
		"s3835032",
		"Phylica retorta",
		"phylica",
		3835032
	],
	[
		"s3835033",
		"Phylica reversa",
		"phylica",
		3835033
	],
	[
		"s1604818",
		"Phylica rigida",
		"phylica",
		1604818
	],
	[
		"s3090369",
		"Phylica rigidifolia",
		"phylica",
		3090369
	],
	[
		"s1604819",
		"Phylica rogersii",
		"phylica",
		1604819
	],
	[
		"s1604820",
		"Phylica rubra",
		"phylica",
		1604820
	],
	[
		"s3835034",
		"Phylica salteri",
		"phylica",
		3835034
	],
	[
		"s3835035",
		"Phylica schlechteri",
		"phylica",
		3835035
	],
	[
		"s1604821",
		"Phylica selaginoides",
		"phylica",
		1604821
	],
	[
		"s1604822",
		"Phylica sericea",
		"phylica",
		1604822
	],
	[
		"s3835036",
		"Phylica simii",
		"phylica",
		3835036
	],
	[
		"s172231",
		"Phylica spicata",
		"phylica",
		172231
	],
	[
		"s1604824",
		"Phylica stenantha",
		"phylica",
		1604824
	],
	[
		"s3090370",
		"Phylica stenopetala",
		"phylica",
		3090370
	],
	[
		"s3090371",
		"Phylica stokoei",
		"phylica",
		3090371
	],
	[
		"s1604825",
		"Phylica strigosa",
		"phylica",
		1604825
	],
	[
		"s3090372",
		"Phylica strigulosa",
		"phylica",
		3090372
	],
	[
		"s3835037",
		"Phylica subulifolia",
		"phylica",
		3835037
	],
	[
		"s172233",
		"Phylica thodei",
		"phylica",
		172233
	],
	[
		"s1604826",
		"Phylica thunbergiana",
		"phylica",
		1604826
	],
	[
		"s1604827",
		"Phylica trachyphylla",
		"phylica",
		1604827
	],
	[
		"s178507",
		"Phylica tropica",
		"phylica",
		178507
	],
	[
		"s3835038",
		"Phylica tuberculata",
		"phylica",
		3835038
	],
	[
		"s3835039",
		"Phylica tubulosa",
		"phylica",
		3835039
	],
	[
		"s3835040",
		"Phylica tysonii",
		"phylica",
		3835040
	],
	[
		"s3835041",
		"Phylica variabilis",
		"phylica",
		3835041
	],
	[
		"s3835042",
		"Phylica velutina",
		"phylica",
		3835042
	],
	[
		"s1237775",
		"Phylica villosa",
		"phylica",
		1237775
	],
	[
		"s1604828",
		"Phylica virgata",
		"phylica",
		1604828
	],
	[
		"s1604829",
		"Phylica vulgaris",
		"phylica",
		1604829
	],
	[
		"s1324460",
		"Phylica willdenowiana",
		"phylica",
		1324460
	],
	[
		"s1604832",
		"Phylica wittebergensis",
		"phylica",
		1604832
	],
	[
		"s3103836",
		"Phyllogeiton discolor",
		"phyllogeiton",
		3103836
	],
	[
		"s3865196",
		"Phyllogeiton trachybasis",
		"phyllogeiton",
		3865196
	],
	[
		"s3103837",
		"Phyllogeiton zeyheri",
		"phyllogeiton",
		3103837
	],
	[
		"s3865282",
		"Phyllostylon brasiliense",
		"phyllostylon",
		3865282
	],
	[
		"s1428766",
		"Phyllostylon rhamnoides",
		"phyllostylon",
		1428766
	],
	[
		"s266785",
		"Physocarpus alternans",
		"physocarpus",
		266785
	],
	[
		"s190008",
		"Physocarpus amurensis",
		"physocarpus",
		190008
	],
	[
		"s141000",
		"Physocarpus capitatus",
		"physocarpus",
		141e3
	],
	[
		"s3879931",
		"Physocarpus intermedius",
		"physocarpus",
		3879931
	],
	[
		"s32238",
		"Physocarpus malvaceus",
		"physocarpus",
		32238
	],
	[
		"s266786",
		"Physocarpus monogynus",
		"physocarpus",
		266786
	],
	[
		"s133202",
		"Physocarpus opulifolius",
		"physocarpus",
		133202
	],
	[
		"s3865339",
		"Pilea abbreviata",
		"pilea",
		3865339
	],
	[
		"s3865340",
		"Pilea acanthoides",
		"pilea",
		3865340
	],
	[
		"s3865341",
		"Pilea acanthospermoides",
		"pilea",
		3865341
	],
	[
		"s1807084",
		"Pilea acuminata",
		"pilea",
		1807084
	],
	[
		"s3865342",
		"Pilea acunae",
		"pilea",
		3865342
	],
	[
		"s3865343",
		"Pilea adamsiana",
		"pilea",
		3865343
	],
	[
		"s3865344",
		"Pilea affinis",
		"pilea",
		3865344
	],
	[
		"s3090376",
		"Pilea alaotrae",
		"pilea",
		3090376
	],
	[
		"s3865345",
		"Pilea alfaroana",
		"pilea",
		3865345
	],
	[
		"s3865346",
		"Pilea alongensis",
		"pilea",
		3865346
	],
	[
		"s344772",
		"Pilea alpestris",
		"pilea",
		344772
	],
	[
		"s344773",
		"Pilea alpina",
		"pilea",
		344773
	],
	[
		"s344774",
		"Pilea alsinifolia",
		"pilea",
		344774
	],
	[
		"s3865347",
		"Pilea alta",
		"pilea",
		3865347
	],
	[
		"s3865348",
		"Pilea alternifolia",
		"pilea",
		3865348
	],
	[
		"s3865349",
		"Pilea ambecarpa",
		"pilea",
		3865349
	],
	[
		"s2739277",
		"Pilea amplistipulata",
		"pilea",
		2739277
	],
	[
		"s3865350",
		"Pilea andersonii",
		"pilea",
		3865350
	],
	[
		"s3865351",
		"Pilea andringitrensis",
		"pilea",
		3865351
	],
	[
		"s3089791",
		"Pilea angolensis",
		"pilea",
		3089791
	],
	[
		"s1399720",
		"Pilea angulata",
		"pilea",
		1399720
	],
	[
		"s3090377",
		"Pilea angustata",
		"pilea",
		3090377
	],
	[
		"s344775",
		"Pilea angustifolia",
		"pilea",
		344775
	],
	[
		"s344776",
		"Pilea anisophylla",
		"pilea",
		344776
	],
	[
		"s3865352",
		"Pilea ansincola",
		"pilea",
		3865352
	],
	[
		"s3865353",
		"Pilea anthotricha",
		"pilea",
		3865353
	],
	[
		"s3090378",
		"Pilea antioquensis",
		"pilea",
		3090378
	],
	[
		"s3865354",
		"Pilea aparadensis",
		"pilea",
		3865354
	],
	[
		"s344777",
		"Pilea aphrophila (nom. nud.)",
		"pilea",
		344777
	],
	[
		"s3865355",
		"Pilea apiculata",
		"pilea",
		3865355
	],
	[
		"s3865356",
		"Pilea apoensis",
		"pilea",
		3865356
	],
	[
		"s3865357",
		"Pilea appendicilata",
		"pilea",
		3865357
	],
	[
		"s3865358",
		"Pilea approximata",
		"pilea",
		3865358
	],
	[
		"s2739278",
		"Pilea aquarum",
		"pilea",
		2739278
	],
	[
		"s3865359",
		"Pilea arbuscula",
		"pilea",
		3865359
	],
	[
		"s3865360",
		"Pilea argentea",
		"pilea",
		3865360
	],
	[
		"s3089792",
		"Pilea arguta",
		"pilea",
		3089792
	],
	[
		"s3865361",
		"Pilea articulata",
		"pilea",
		3865361
	],
	[
		"s3865362",
		"Pilea astrogramma",
		"pilea",
		3865362
	],
	[
		"s3865363",
		"Pilea atroviridis",
		"pilea",
		3865363
	],
	[
		"s3090379",
		"Pilea attenuata",
		"pilea",
		3090379
	],
	[
		"s2294063",
		"Pilea auricularis",
		"pilea",
		2294063
	],
	[
		"s3090380",
		"Pilea auriculata",
		"pilea",
		3090380
	],
	[
		"s3865364",
		"Pilea australis",
		"pilea",
		3865364
	],
	[
		"s3865365",
		"Pilea bakeriana",
		"pilea",
		3865365
	],
	[
		"s2739280",
		"Pilea balansae",
		"pilea",
		2739280
	],
	[
		"s3865366",
		"Pilea balfourii",
		"pilea",
		3865366
	],
	[
		"s3865367",
		"Pilea baltenweckii",
		"pilea",
		3865367
	],
	[
		"s3090381",
		"Pilea bambuseti",
		"pilea",
		3090381
	],
	[
		"s3090382",
		"Pilea bambusifolia",
		"pilea",
		3090382
	],
	[
		"s3865368",
		"Pilea barahonensis",
		"pilea",
		3865368
	],
	[
		"s3865369",
		"Pilea barbiflora",
		"pilea",
		3865369
	],
	[
		"s344778",
		"Pilea basicordata",
		"pilea",
		344778
	],
	[
		"s345212",
		"Pilea bassleriana",
		"pilea",
		345212
	],
	[
		"s544623",
		"Pilea baurii",
		"pilea",
		544623
	],
	[
		"s3865370",
		"Pilea beguinotii",
		"pilea",
		3865370
	],
	[
		"s2306691",
		"Pilea bemarivensis",
		"pilea",
		2306691
	],
	[
		"s344779",
		"Pilea benguetensis",
		"pilea",
		344779
	],
	[
		"s3865371",
		"Pilea betulifolia",
		"pilea",
		3865371
	],
	[
		"s3865372",
		"Pilea bicolor",
		"pilea",
		3865372
	],
	[
		"s3865373",
		"Pilea bisepala",
		"pilea",
		3865373
	],
	[
		"s3865374",
		"Pilea bissei",
		"pilea",
		3865374
	],
	[
		"s3865375",
		"Pilea boehmerioides",
		"pilea",
		3865375
	],
	[
		"s3090383",
		"Pilea boiviniana",
		"pilea",
		3090383
	],
	[
		"s3865376",
		"Pilea borbonica",
		"pilea",
		3865376
	],
	[
		"s3865377",
		"Pilea botterii",
		"pilea",
		3865377
	],
	[
		"s3865378",
		"Pilea brachypila",
		"pilea",
		3865378
	],
	[
		"s2306692",
		"Pilea bracteosa",
		"pilea",
		2306692
	],
	[
		"s3865379",
		"Pilea bradei",
		"pilea",
		3865379
	],
	[
		"s3865380",
		"Pilea brasiliensis",
		"pilea",
		3865380
	],
	[
		"s3865381",
		"Pilea brassii",
		"pilea",
		3865381
	],
	[
		"s3865382",
		"Pilea brevipetiolata",
		"pilea",
		3865382
	],
	[
		"s3865383",
		"Pilea brevistipula",
		"pilea",
		3865383
	],
	[
		"s3865384",
		"Pilea brittoniae",
		"pilea",
		3865384
	],
	[
		"s3865385",
		"Pilea buchenavii",
		"pilea",
		3865385
	],
	[
		"s3090384",
		"Pilea buchtienii",
		"pilea",
		3090384
	],
	[
		"s3865386",
		"Pilea bullata",
		"pilea",
		3865386
	],
	[
		"s3865387",
		"Pilea butaudiana",
		"pilea",
		3865387
	],
	[
		"s3865388",
		"Pilea cacuminum",
		"pilea",
		3865388
	],
	[
		"s3865389",
		"Pilea cadetii",
		"pilea",
		3865389
	],
	[
		"s45185",
		"Pilea cadierei",
		"pilea",
		45185
	],
	[
		"s3865390",
		"Pilea calcicola",
		"pilea",
		3865390
	],
	[
		"s3090385",
		"Pilea callicometes",
		"pilea",
		3090385
	],
	[
		"s3865391",
		"Pilea cangyuanensis",
		"pilea",
		3865391
	],
	[
		"s3865392",
		"Pilea capitata",
		"pilea",
		3865392
	],
	[
		"s3865393",
		"Pilea capitellata",
		"pilea",
		3865393
	],
	[
		"s3865394",
		"Pilea carautae",
		"pilea",
		3865394
	],
	[
		"s3865395",
		"Pilea cardiophylla",
		"pilea",
		3865395
	],
	[
		"s344780",
		"Pilea caribaea",
		"pilea",
		344780
	],
	[
		"s3865396",
		"Pilea carnosa",
		"pilea",
		3865396
	],
	[
		"s344781",
		"Pilea carnulosa",
		"pilea",
		344781
	],
	[
		"s3865397",
		"Pilea castronis",
		"pilea",
		3865397
	],
	[
		"s3865398",
		"Pilea cataractae",
		"pilea",
		3865398
	],
	[
		"s3865399",
		"Pilea caulescens",
		"pilea",
		3865399
	],
	[
		"s1399722",
		"Pilea cavaleriei",
		"pilea",
		1399722
	],
	[
		"s2998964",
		"Pilea cavernicola",
		"pilea",
		2998964
	],
	[
		"s3865400",
		"Pilea celebica",
		"pilea",
		3865400
	],
	[
		"s3865401",
		"Pilea cellulosa",
		"pilea",
		3865401
	],
	[
		"s345207",
		"Pilea centradenioides",
		"pilea",
		345207
	],
	[
		"s3865402",
		"Pilea cephalantha",
		"pilea",
		3865402
	],
	[
		"s3865403",
		"Pilea cephalophora",
		"pilea",
		3865403
	],
	[
		"s3090386",
		"Pilea ceratocalyx",
		"pilea",
		3090386
	],
	[
		"s3865404",
		"Pilea chamaesyce",
		"pilea",
		3865404
	],
	[
		"s2306693",
		"Pilea chartacea",
		"pilea",
		2306693
	],
	[
		"s3090387",
		"Pilea chiapensis",
		"pilea",
		3090387
	],
	[
		"s3865405",
		"Pilea chotardiana",
		"pilea",
		3865405
	],
	[
		"s3865406",
		"Pilea christii",
		"pilea",
		3865406
	],
	[
		"s344782",
		"Pilea ciliata",
		"pilea",
		344782
	],
	[
		"s3865407",
		"Pilea citriodora",
		"pilea",
		3865407
	],
	[
		"s3865408",
		"Pilea clandestina",
		"pilea",
		3865408
	],
	[
		"s3865409",
		"Pilea clarana",
		"pilea",
		3865409
	],
	[
		"s3865410",
		"Pilea clarkei",
		"pilea",
		3865410
	],
	[
		"s344783",
		"Pilea clementis",
		"pilea",
		344783
	],
	[
		"s3865411",
		"Pilea cocottei",
		"pilea",
		3865411
	],
	[
		"s3865412",
		"Pilea confusa",
		"pilea",
		3865412
	],
	[
		"s3090388",
		"Pilea conjugalis",
		"pilea",
		3090388
	],
	[
		"s344784",
		"Pilea consanguinea",
		"pilea",
		344784
	],
	[
		"s3090389",
		"Pilea cordifolia",
		"pilea",
		3090389
	],
	[
		"s2739282",
		"Pilea cordistipulata",
		"pilea",
		2739282
	],
	[
		"s345210",
		"Pilea cornutocucullata",
		"pilea",
		345210
	],
	[
		"s3090390",
		"Pilea corona",
		"pilea",
		3090390
	],
	[
		"s3865414",
		"Pilea coronopifolia",
		"pilea",
		3865414
	],
	[
		"s3865415",
		"Pilea corymbosa",
		"pilea",
		3865415
	],
	[
		"s345206",
		"Pilea costaricensis",
		"pilea",
		345206
	],
	[
		"s344829",
		"Pilea costata",
		"pilea",
		344829
	],
	[
		"s3865416",
		"Pilea cowellii",
		"pilea",
		3865416
	],
	[
		"s297233",
		"Pilea craspedodroma",
		"pilea",
		297233
	],
	[
		"s3865417",
		"Pilea crenata",
		"pilea",
		3865417
	],
	[
		"s3865418",
		"Pilea crenulata",
		"pilea",
		3865418
	],
	[
		"s3090391",
		"Pilea cruegeriana",
		"pilea",
		3090391
	],
	[
		"s3865419",
		"Pilea cubensis",
		"pilea",
		3865419
	],
	[
		"s3865420",
		"Pilea cuneata",
		"pilea",
		3865420
	],
	[
		"s3865421",
		"Pilea cuneiformis",
		"pilea",
		3865421
	],
	[
		"s3865422",
		"Pilea cuprea",
		"pilea",
		3865422
	],
	[
		"s3865423",
		"Pilea cushiensis",
		"pilea",
		3865423
	],
	[
		"s3865424",
		"Pilea cyclophylla",
		"pilea",
		3865424
	],
	[
		"s3090392",
		"Pilea cymbifolia",
		"pilea",
		3090392
	],
	[
		"s344785",
		"Pilea daguensis",
		"pilea",
		344785
	],
	[
		"s2945687",
		"Pilea danxiaensis",
		"pilea",
		2945687
	],
	[
		"s3865425",
		"Pilea dataensis",
		"pilea",
		3865425
	],
	[
		"s344786",
		"Pilea dauciodora",
		"pilea",
		344786
	],
	[
		"s3865426",
		"Pilea delicatula",
		"pilea",
		3865426
	],
	[
		"s3865427",
		"Pilea densiflora",
		"pilea",
		3865427
	],
	[
		"s194273",
		"Pilea depressa",
		"pilea",
		194273
	],
	[
		"s3865428",
		"Pilea diandra",
		"pilea",
		3865428
	],
	[
		"s3865429",
		"Pilea dictyocarpa",
		"pilea",
		3865429
	],
	[
		"s344787",
		"Pilea digitata",
		"pilea",
		344787
	],
	[
		"s3865430",
		"Pilea discolor",
		"pilea",
		3865430
	],
	[
		"s3865431",
		"Pilea dispar",
		"pilea",
		3865431
	],
	[
		"s3865432",
		"Pilea distantifolia",
		"pilea",
		3865432
	],
	[
		"s3090393",
		"Pilea diversifolia",
		"pilea",
		3090393
	],
	[
		"s345215",
		"Pilea dolichocarpa",
		"pilea",
		345215
	],
	[
		"s3090394",
		"Pilea dombeyana",
		"pilea",
		3090394
	],
	[
		"s344788",
		"Pilea dominguensis",
		"pilea",
		344788
	],
	[
		"s3090395",
		"Pilea donnell-smithiana",
		"pilea",
		3090395
	],
	[
		"s344789",
		"Pilea ecboliophylla",
		"pilea",
		344789
	],
	[
		"s3865433",
		"Pilea effusa",
		"pilea",
		3865433
	],
	[
		"s3865434",
		"Pilea ekmanii",
		"pilea",
		3865434
	],
	[
		"s344790",
		"Pilea elegantissima",
		"pilea",
		344790
	],
	[
		"s3865435",
		"Pilea elizabethae",
		"pilea",
		3865435
	],
	[
		"s3865436",
		"Pilea elliptica",
		"pilea",
		3865436
	],
	[
		"s2739283",
		"Pilea elliptilimba",
		"pilea",
		2739283
	],
	[
		"s3865437",
		"Pilea entradana",
		"pilea",
		3865437
	],
	[
		"s3865438",
		"Pilea ermitensis",
		"pilea",
		3865438
	],
	[
		"s3865439",
		"Pilea erosa",
		"pilea",
		3865439
	],
	[
		"s3865440",
		"Pilea fairchildiana",
		"pilea",
		3865440
	],
	[
		"s3090396",
		"Pilea falcata",
		"pilea",
		3090396
	],
	[
		"s3090397",
		"Pilea fallax",
		"pilea",
		3090397
	],
	[
		"s3090398",
		"Pilea fasciata",
		"pilea",
		3090398
	],
	[
		"s3090399",
		"Pilea fendleri",
		"pilea",
		3090399
	],
	[
		"s3865441",
		"Pilea filicina",
		"pilea",
		3865441
	],
	[
		"s3090400",
		"Pilea filipes",
		"pilea",
		3090400
	],
	[
		"s3865442",
		"Pilea flammula",
		"pilea",
		3865442
	],
	[
		"s3865443",
		"Pilea flavicaulis",
		"pilea",
		3865443
	],
	[
		"s3865444",
		"Pilea flexuosa",
		"pilea",
		3865444
	],
	[
		"s3865445",
		"Pilea floridana",
		"pilea",
		3865445
	],
	[
		"s3865446",
		"Pilea foetida",
		"pilea",
		3865446
	],
	[
		"s344791",
		"Pilea foliosa",
		"pilea",
		344791
	],
	[
		"s99289",
		"Pilea fontana",
		"pilea",
		99289
	],
	[
		"s3865447",
		"Pilea foreroi",
		"pilea",
		3865447
	],
	[
		"s344792",
		"Pilea forgetii",
		"pilea",
		344792
	],
	[
		"s3865448",
		"Pilea formonensis",
		"pilea",
		3865448
	],
	[
		"s3865449",
		"Pilea formosa",
		"pilea",
		3865449
	],
	[
		"s344793",
		"Pilea forsythiana",
		"pilea",
		344793
	],
	[
		"s3865450",
		"Pilea frutescens",
		"pilea",
		3865450
	],
	[
		"s344794",
		"Pilea fruticosa",
		"pilea",
		344794
	],
	[
		"s3865451",
		"Pilea fruticulosa",
		"pilea",
		3865451
	],
	[
		"s3090401",
		"Pilea funkikensis",
		"pilea",
		3090401
	],
	[
		"s3865452",
		"Pilea gallowayana",
		"pilea",
		3865452
	],
	[
		"s3090402",
		"Pilea gamboana",
		"pilea",
		3090402
	],
	[
		"s2876031",
		"Pilea gansuensis",
		"pilea",
		2876031
	],
	[
		"s3865453",
		"Pilea geminata",
		"pilea",
		3865453
	],
	[
		"s3865454",
		"Pilea gesnerioides",
		"pilea",
		3865454
	],
	[
		"s344795",
		"Pilea glaberrima",
		"pilea",
		344795
	],
	[
		"s344796",
		"Pilea glabra",
		"pilea",
		344796
	],
	[
		"s2789716",
		"Pilea glauca (nom. nud.)",
		"pilea",
		2789716
	],
	[
		"s3865455",
		"Pilea glomerata",
		"pilea",
		3865455
	],
	[
		"s3865456",
		"Pilea gnidioides",
		"pilea",
		3865456
	],
	[
		"s3865457",
		"Pilea godetiana",
		"pilea",
		3865457
	],
	[
		"s3090403",
		"Pilea goetzei",
		"pilea",
		3090403
	],
	[
		"s544624",
		"Pilea gomeziana",
		"pilea",
		544624
	],
	[
		"s3865458",
		"Pilea gongjueensis",
		"pilea",
		3865458
	],
	[
		"s3865459",
		"Pilea goudotiana",
		"pilea",
		3865459
	],
	[
		"s3865460",
		"Pilea gracilior",
		"pilea",
		3865460
	],
	[
		"s2739284",
		"Pilea gracilis",
		"pilea",
		2739284
	],
	[
		"s344797",
		"Pilea grandifolia",
		"pilea",
		344797
	],
	[
		"s3865461",
		"Pilea granmae",
		"pilea",
		3865461
	],
	[
		"s3865462",
		"Pilea granulata",
		"pilea",
		3865462
	],
	[
		"s3865463",
		"Pilea griffithii",
		"pilea",
		3865463
	],
	[
		"s3865464",
		"Pilea guanwuensis",
		"pilea",
		3865464
	],
	[
		"s3865465",
		"Pilea guirana",
		"pilea",
		3865465
	],
	[
		"s2739265",
		"Pilea guizhouensis",
		"pilea",
		2739265
	],
	[
		"s3865466",
		"Pilea gyrophylla",
		"pilea",
		3865466
	],
	[
		"s3865467",
		"Pilea haenkei",
		"pilea",
		3865467
	],
	[
		"s344798",
		"Pilea harrisii",
		"pilea",
		344798
	],
	[
		"s3865468",
		"Pilea hedemarkii",
		"pilea",
		3865468
	],
	[
		"s3865469",
		"Pilea helwigii",
		"pilea",
		3865469
	],
	[
		"s3865470",
		"Pilea helxinoides",
		"pilea",
		3865470
	],
	[
		"s3865471",
		"Pilea hemisphaerica",
		"pilea",
		3865471
	],
	[
		"s3865472",
		"Pilea hepatica",
		"pilea",
		3865472
	],
	[
		"s344799",
		"Pilea herniarioides",
		"pilea",
		344799
	],
	[
		"s2306694",
		"Pilea hexagona",
		"pilea",
		2306694
	],
	[
		"s3090404",
		"Pilea hilariana",
		"pilea",
		3090404
	],
	[
		"s2739285",
		"Pilea hilliana",
		"pilea",
		2739285
	],
	[
		"s3090405",
		"Pilea hirsuta",
		"pilea",
		3090405
	],
	[
		"s3865473",
		"Pilea hirtella",
		"pilea",
		3865473
	],
	[
		"s3865474",
		"Pilea hispaniolana",
		"pilea",
		3865474
	],
	[
		"s3090406",
		"Pilea hitchcockii",
		"pilea",
		3090406
	],
	[
		"s344800",
		"Pilea holstii",
		"pilea",
		344800
	],
	[
		"s3865475",
		"Pilea hookeriana",
		"pilea",
		3865475
	],
	[
		"s3865476",
		"Pilea howardiana",
		"pilea",
		3865476
	],
	[
		"s2306695",
		"Pilea howelliana",
		"pilea",
		2306695
	],
	[
		"s3090407",
		"Pilea humbertii",
		"pilea",
		3090407
	],
	[
		"s3865477",
		"Pilea humilis",
		"pilea",
		3865477
	],
	[
		"s344801",
		"Pilea hyalina",
		"pilea",
		344801
	],
	[
		"s3865478",
		"Pilea hydra",
		"pilea",
		3865478
	],
	[
		"s3090408",
		"Pilea hydrocotyliflora",
		"pilea",
		3090408
	],
	[
		"s3865479",
		"Pilea hygrophila",
		"pilea",
		3865479
	],
	[
		"s3865480",
		"Pilea imitans",
		"pilea",
		3865480
	],
	[
		"s344802",
		"Pilea imparifolia",
		"pilea",
		344802
	],
	[
		"s3865481",
		"Pilea impressa",
		"pilea",
		3865481
	],
	[
		"s344803",
		"Pilea inaequalis",
		"pilea",
		344803
	],
	[
		"s1399724",
		"Pilea insolens",
		"pilea",
		1399724
	],
	[
		"s3865482",
		"Pilea intermedia",
		"pilea",
		3865482
	],
	[
		"s3865483",
		"Pilea intumescens",
		"pilea",
		3865483
	],
	[
		"s544625",
		"Pilea involucrata",
		"pilea",
		544625
	],
	[
		"s344804",
		"Pilea irrorata",
		"pilea",
		344804
	],
	[
		"s3865484",
		"Pilea iteophylla",
		"pilea",
		3865484
	],
	[
		"s3865485",
		"Pilea ivohibeensis",
		"pilea",
		3865485
	],
	[
		"s3090409",
		"Pilea jamesoniana",
		"pilea",
		3090409
	],
	[
		"s297232",
		"Pilea jayaensis",
		"pilea",
		297232
	],
	[
		"s3865486",
		"Pilea jeremiensis",
		"pilea",
		3865486
	],
	[
		"s344805",
		"Pilea johniana",
		"pilea",
		344805
	],
	[
		"s297234",
		"Pilea johnsii",
		"pilea",
		297234
	],
	[
		"s344806",
		"Pilea johnstonii",
		"pilea",
		344806
	],
	[
		"s3865487",
		"Pilea jujuyensis",
		"pilea",
		3865487
	],
	[
		"s3865488",
		"Pilea kakurang",
		"pilea",
		3865488
	],
	[
		"s3865489",
		"Pilea kanaii",
		"pilea",
		3865489
	],
	[
		"s3090410",
		"Pilea killipiana",
		"pilea",
		3090410
	],
	[
		"s3865490",
		"Pilea kingii",
		"pilea",
		3865490
	],
	[
		"s3865491",
		"Pilea kiotensis",
		"pilea",
		3865491
	],
	[
		"s3865492",
		"Pilea klossii",
		"pilea",
		3865492
	],
	[
		"s344807",
		"Pilea krugii",
		"pilea",
		344807
	],
	[
		"s3865493",
		"Pilea laciniata",
		"pilea",
		3865493
	],
	[
		"s344808",
		"Pilea lacorum",
		"pilea",
		344808
	],
	[
		"s3865494",
		"Pilea lageensis",
		"pilea",
		3865494
	],
	[
		"s3865495",
		"Pilea lamii",
		"pilea",
		3865495
	],
	[
		"s3090411",
		"Pilea lamioides",
		"pilea",
		3090411
	],
	[
		"s3865496",
		"Pilea lanceolata",
		"pilea",
		3865496
	],
	[
		"s3865497",
		"Pilea lancifolia",
		"pilea",
		3865497
	],
	[
		"s344809",
		"Pilea lapestris",
		"pilea",
		344809
	],
	[
		"s345213",
		"Pilea latifolia",
		"pilea",
		345213
	],
	[
		"s3865498",
		"Pilea laurea",
		"pilea",
		3865498
	],
	[
		"s3865499",
		"Pilea laxa",
		"pilea",
		3865499
	],
	[
		"s3865500",
		"Pilea ledermannii",
		"pilea",
		3865500
	],
	[
		"s3865501",
		"Pilea leptocardia",
		"pilea",
		3865501
	],
	[
		"s3865502",
		"Pilea leptogramma",
		"pilea",
		3865502
	],
	[
		"s3865503",
		"Pilea leucophaea",
		"pilea",
		3865503
	],
	[
		"s3865504",
		"Pilea libanensis",
		"pilea",
		3865504
	],
	[
		"s3865505",
		"Pilea lidaoensis",
		"pilea",
		3865505
	],
	[
		"s344810",
		"Pilea lindeniana",
		"pilea",
		344810
	],
	[
		"s3865506",
		"Pilea linearifolia",
		"pilea",
		3865506
	],
	[
		"s345218",
		"Pilea lippioides",
		"pilea",
		345218
	],
	[
		"s3865507",
		"Pilea lobulata",
		"pilea",
		3865507
	],
	[
		"s3865508",
		"Pilea loeseneri",
		"pilea",
		3865508
	],
	[
		"s3865509",
		"Pilea loheri",
		"pilea",
		3865509
	],
	[
		"s3090412",
		"Pilea lokohensis",
		"pilea",
		3090412
	],
	[
		"s3090413",
		"Pilea lomatogramma",
		"pilea",
		3090413
	],
	[
		"s3865510",
		"Pilea longibracteolata",
		"pilea",
		3865510
	],
	[
		"s344811",
		"Pilea longicaulis",
		"pilea",
		344811
	],
	[
		"s344812",
		"Pilea longifolia",
		"pilea",
		344812
	],
	[
		"s1399725",
		"Pilea longipedunculata",
		"pilea",
		1399725
	],
	[
		"s3865511",
		"Pilea longruiensis",
		"pilea",
		3865511
	],
	[
		"s3865512",
		"Pilea longzhouensis",
		"pilea",
		3865512
	],
	[
		"s3865513",
		"Pilea losensis",
		"pilea",
		3865513
	],
	[
		"s3865514",
		"Pilea loshanensis",
		"pilea",
		3865514
	],
	[
		"s3089793",
		"Pilea lucens",
		"pilea",
		3089793
	],
	[
		"s344813",
		"Pilea lucida",
		"pilea",
		344813
	],
	[
		"s3865515",
		"Pilea luisiana",
		"pilea",
		3865515
	],
	[
		"s3865516",
		"Pilea luochengensis",
		"pilea",
		3865516
	],
	[
		"s3865517",
		"Pilea lurida",
		"pilea",
		3865517
	],
	[
		"s3865518",
		"Pilea lushuiensis",
		"pilea",
		3865518
	],
	[
		"s3865519",
		"Pilea luzonensis",
		"pilea",
		3865519
	],
	[
		"s3865520",
		"Pilea macbridei",
		"pilea",
		3865520
	],
	[
		"s3865521",
		"Pilea macrantha",
		"pilea",
		3865521
	],
	[
		"s3695195",
		"Pilea macrocarpa",
		"pilea",
		3695195
	],
	[
		"s3090414",
		"Pilea macrocystolithica",
		"pilea",
		3090414
	],
	[
		"s3865522",
		"Pilea maculata",
		"pilea",
		3865522
	],
	[
		"s344814",
		"Pilea magnicarpa",
		"pilea",
		344814
	],
	[
		"s344815",
		"Pilea manniana",
		"pilea",
		344815
	],
	[
		"s3090415",
		"Pilea margarettae",
		"pilea",
		3090415
	],
	[
		"s3090416",
		"Pilea marginata",
		"pilea",
		3090416
	],
	[
		"s1399726",
		"Pilea martinii",
		"pilea",
		1399726
	],
	[
		"s3090417",
		"Pilea matama",
		"pilea",
		3090417
	],
	[
		"s3865523",
		"Pilea matheuxiana",
		"pilea",
		3865523
	],
	[
		"s3090418",
		"Pilea matsudai",
		"pilea",
		3090418
	],
	[
		"s3865524",
		"Pilea matthewii",
		"pilea",
		3865524
	],
	[
		"s3865525",
		"Pilea maxonii",
		"pilea",
		3865525
	],
	[
		"s3865526",
		"Pilea mayarensis",
		"pilea",
		3865526
	],
	[
		"s3090419",
		"Pilea media",
		"pilea",
		3090419
	],
	[
		"s3865527",
		"Pilea mediophylla",
		"pilea",
		3865527
	],
	[
		"s3865528",
		"Pilea medongensis",
		"pilea",
		3865528
	],
	[
		"s344816",
		"Pilea melastomoides",
		"pilea",
		344816
	],
	[
		"s3133952",
		"Pilea menghaiensis",
		"pilea",
		3133952
	],
	[
		"s344817",
		"Pilea mexicana",
		"pilea",
		344817
	],
	[
		"s3865529",
		"Pilea michaelensis",
		"pilea",
		3865529
	],
	[
		"s3090420",
		"Pilea microcardia",
		"pilea",
		3090420
	],
	[
		"s226284",
		"Pilea microphylla",
		"pilea",
		226284
	],
	[
		"s3865530",
		"Pilea microrhombea",
		"pilea",
		3865530
	],
	[
		"s3865531",
		"Pilea miguelii",
		"pilea",
		3865531
	],
	[
		"s3865532",
		"Pilea mimema",
		"pilea",
		3865532
	],
	[
		"s3865533",
		"Pilea minguetii",
		"pilea",
		3865533
	],
	[
		"s3865534",
		"Pilea minima",
		"pilea",
		3865534
	],
	[
		"s3865535",
		"Pilea minuta",
		"pilea",
		3865535
	],
	[
		"s3865536",
		"Pilea minutissima",
		"pilea",
		3865536
	],
	[
		"s2786967",
		"Pilea mollis",
		"pilea",
		2786967
	],
	[
		"s870202",
		"Pilea mongolica",
		"pilea",
		870202
	],
	[
		"s2583426",
		"Pilea monilifera",
		"pilea",
		2583426
	],
	[
		"s3865537",
		"Pilea monticola",
		"pilea",
		3865537
	],
	[
		"s3865538",
		"Pilea montis-wilhelmi",
		"pilea",
		3865538
	],
	[
		"s3865539",
		"Pilea moragana",
		"pilea",
		3865539
	],
	[
		"s3865540",
		"Pilea moroniana",
		"pilea",
		3865540
	],
	[
		"s3865541",
		"Pilea multicaulis",
		"pilea",
		3865541
	],
	[
		"s2739288",
		"Pilea multicellularis",
		"pilea",
		2739288
	],
	[
		"s1835405",
		"Pilea multiflora",
		"pilea",
		1835405
	],
	[
		"s3865542",
		"Pilea mutisiana",
		"pilea",
		3865542
	],
	[
		"s344831",
		"Pilea myriantha",
		"pilea",
		344831
	],
	[
		"s3090421",
		"Pilea myriophylla",
		"pilea",
		3090421
	],
	[
		"s3865543",
		"Pilea nana",
		"pilea",
		3865543
	],
	[
		"s3090422",
		"Pilea napoana",
		"pilea",
		3090422
	],
	[
		"s3865544",
		"Pilea neglecta",
		"pilea",
		3865544
	],
	[
		"s344818",
		"Pilea nepalensis",
		"pilea",
		344818
	],
	[
		"s3865545",
		"Pilea nerteroides",
		"pilea",
		3865545
	],
	[
		"s3865546",
		"Pilea nguruensis",
		"pilea",
		3865546
	],
	[
		"s3865547",
		"Pilea nicholasii",
		"pilea",
		3865547
	],
	[
		"s3865548",
		"Pilea nidiae",
		"pilea",
		3865548
	],
	[
		"s344819",
		"Pilea nigrescens",
		"pilea",
		344819
	],
	[
		"s3865549",
		"Pilea nipensis",
		"pilea",
		3865549
	],
	[
		"s3090423",
		"Pilea nitida",
		"pilea",
		3090423
	],
	[
		"s2027359",
		"Pilea nonggangensis",
		"pilea",
		2027359
	],
	[
		"s345217",
		"Pilea notata",
		"pilea",
		345217
	],
	[
		"s3865550",
		"Pilea nudicaulis",
		"pilea",
		3865550
	],
	[
		"s226285",
		"Pilea nummulariifolia",
		"pilea",
		226285
	],
	[
		"s3090424",
		"Pilea nutans",
		"pilea",
		3090424
	],
	[
		"s3090425",
		"Pilea obetiifolia",
		"pilea",
		3090425
	],
	[
		"s3865551",
		"Pilea oblanceolata",
		"pilea",
		3865551
	],
	[
		"s3865552",
		"Pilea obscura",
		"pilea",
		3865552
	],
	[
		"s3865553",
		"Pilea obtusangula",
		"pilea",
		3865553
	],
	[
		"s3865554",
		"Pilea occulta",
		"pilea",
		3865554
	],
	[
		"s3090426",
		"Pilea ophioderma",
		"pilea",
		3090426
	],
	[
		"s3865555",
		"Pilea ophiticola",
		"pilea",
		3865555
	],
	[
		"s3865556",
		"Pilea ordinata",
		"pilea",
		3865556
	],
	[
		"s3865557",
		"Pilea orientalis",
		"pilea",
		3865557
	],
	[
		"s3865558",
		"Pilea ornatifolia",
		"pilea",
		3865558
	],
	[
		"s3865559",
		"Pilea ovalifolia",
		"pilea",
		3865559
	],
	[
		"s3865560",
		"Pilea ovalis",
		"pilea",
		3865560
	],
	[
		"s1399727",
		"Pilea oxyodon",
		"pilea",
		1399727
	],
	[
		"s3865561",
		"Pilea pachycarpa",
		"pilea",
		3865561
	],
	[
		"s3865562",
		"Pilea pachycephala",
		"pilea",
		3865562
	],
	[
		"s3090427",
		"Pilea pallida",
		"pilea",
		3090427
	],
	[
		"s3865563",
		"Pilea palustris",
		"pilea",
		3865563
	],
	[
		"s3865564",
		"Pilea pandurata",
		"pilea",
		3865564
	],
	[
		"s2306697",
		"Pilea paniculigera",
		"pilea",
		2306697
	],
	[
		"s344820",
		"Pilea pansamalana",
		"pilea",
		344820
	],
	[
		"s3865565",
		"Pilea panzhihuaensis",
		"pilea",
		3865565
	],
	[
		"s3865566",
		"Pilea papuana",
		"pilea",
		3865566
	],
	[
		"s3865567",
		"Pilea parciflora",
		"pilea",
		3865567
	],
	[
		"s344821",
		"Pilea parietaria",
		"pilea",
		344821
	],
	[
		"s3865568",
		"Pilea pauciflora",
		"pilea",
		3865568
	],
	[
		"s3090428",
		"Pilea pauciserrata",
		"pilea",
		3090428
	],
	[
		"s3865569",
		"Pilea pavonii",
		"pilea",
		3865569
	],
	[
		"s3865570",
		"Pilea pedroi",
		"pilea",
		3865570
	],
	[
		"s3865571",
		"Pilea peladerosi",
		"pilea",
		3865571
	],
	[
		"s2739289",
		"Pilea pellionioides",
		"pilea",
		2739289
	],
	[
		"s344822",
		"Pilea pelonae (nom. nud.)",
		"pilea",
		344822
	],
	[
		"s344823",
		"Pilea peltata",
		"pilea",
		344823
	],
	[
		"s3865572",
		"Pilea pennellii",
		"pilea",
		3865572
	],
	[
		"s2739290",
		"Pilea penninervis",
		"pilea",
		2739290
	],
	[
		"s344824",
		"Pilea peperomiifolia",
		"pilea",
		344824
	],
	[
		"s344825",
		"Pilea peperomioides",
		"pilea",
		344825
	],
	[
		"s344826",
		"Pilea peploides",
		"pilea",
		344826
	],
	[
		"s3865573",
		"Pilea perfragilis",
		"pilea",
		3865573
	],
	[
		"s3090429",
		"Pilea perrieri",
		"pilea",
		3090429
	],
	[
		"s3865574",
		"Pilea phaeocarpa",
		"pilea",
		3865574
	],
	[
		"s3865575",
		"Pilea pichisana",
		"pilea",
		3865575
	],
	[
		"s3090430",
		"Pilea picta",
		"pilea",
		3090430
	],
	[
		"s3865576",
		"Pilea pitresia",
		"pilea",
		3865576
	],
	[
		"s344828",
		"Pilea pittieri",
		"pilea",
		344828
	],
	[
		"s344832",
		"Pilea plataniflora",
		"pilea",
		344832
	],
	[
		"s344833",
		"Pilea pleuroneura",
		"pilea",
		344833
	],
	[
		"s3865577",
		"Pilea plicatidentata",
		"pilea",
		3865577
	],
	[
		"s3865578",
		"Pilea plumieri",
		"pilea",
		3865578
	],
	[
		"s344834",
		"Pilea plumulosa",
		"pilea",
		344834
	],
	[
		"s3865579",
		"Pilea poeppigiana",
		"pilea",
		3865579
	],
	[
		"s3865580",
		"Pilea pollicaris",
		"pilea",
		3865580
	],
	[
		"s3865581",
		"Pilea polyclada",
		"pilea",
		3865581
	],
	[
		"s3865582",
		"Pilea portlandiana",
		"pilea",
		3865582
	],
	[
		"s3865583",
		"Pilea proctorii",
		"pilea",
		3865583
	],
	[
		"s3865584",
		"Pilea propinqua",
		"pilea",
		3865584
	],
	[
		"s344835",
		"Pilea pseudonotata",
		"pilea",
		344835
	],
	[
		"s3865585",
		"Pilea psilogyne",
		"pilea",
		3865585
	],
	[
		"s3090431",
		"Pilea ptericlada",
		"pilea",
		3090431
	],
	[
		"s345204",
		"Pilea pteridophylla",
		"pilea",
		345204
	],
	[
		"s3090432",
		"Pilea pteropodon",
		"pilea",
		3090432
	],
	[
		"s344836",
		"Pilea pubescens",
		"pilea",
		344836
	],
	[
		"s3865586",
		"Pilea pulchra",
		"pilea",
		3865586
	],
	[
		"s3089794",
		"Pilea pulegifolia",
		"pilea",
		3089794
	],
	[
		"s24776",
		"Pilea pumila",
		"pilea",
		24776
	],
	[
		"s3865587",
		"Pilea pumileoides",
		"pilea",
		3865587
	],
	[
		"s3089795",
		"Pilea punctata",
		"pilea",
		3089795
	],
	[
		"s3865588",
		"Pilea puracensis",
		"pilea",
		3865588
	],
	[
		"s3865589",
		"Pilea purpurea",
		"pilea",
		3865589
	],
	[
		"s344837",
		"Pilea purulensis",
		"pilea",
		344837
	],
	[
		"s3865590",
		"Pilea pusilla",
		"pilea",
		3865590
	],
	[
		"s3865591",
		"Pilea putridicola",
		"pilea",
		3865591
	],
	[
		"s3865592",
		"Pilea pyrrhotricha",
		"pilea",
		3865592
	],
	[
		"s344838",
		"Pilea quadrata",
		"pilea",
		344838
	],
	[
		"s344839",
		"Pilea quercifolia",
		"pilea",
		344839
	],
	[
		"s2739291",
		"Pilea racemiformis",
		"pilea",
		2739291
	],
	[
		"s344840",
		"Pilea racemosa",
		"pilea",
		344840
	],
	[
		"s3865593",
		"Pilea radiculosa",
		"pilea",
		3865593
	],
	[
		"s3090433",
		"Pilea ramosissima",
		"pilea",
		3090433
	],
	[
		"s344841",
		"Pilea receptacularis",
		"pilea",
		344841
	],
	[
		"s3865594",
		"Pilea refracta",
		"pilea",
		3865594
	],
	[
		"s3865595",
		"Pilea repanda",
		"pilea",
		3865595
	],
	[
		"s3865596",
		"Pilea reticulata",
		"pilea",
		3865596
	],
	[
		"s3865597",
		"Pilea rhexioides",
		"pilea",
		3865597
	],
	[
		"s344842",
		"Pilea rhizobola",
		"pilea",
		344842
	],
	[
		"s344843",
		"Pilea rhombea",
		"pilea",
		344843
	],
	[
		"s344830",
		"Pilea rhombifolia",
		"pilea",
		344830
	],
	[
		"s3865598",
		"Pilea richardii",
		"pilea",
		3865598
	],
	[
		"s3865599",
		"Pilea riedlei",
		"pilea",
		3865599
	],
	[
		"s3865600",
		"Pilea rigida",
		"pilea",
		3865600
	],
	[
		"s3865601",
		"Pilea rigidiuscula",
		"pilea",
		3865601
	],
	[
		"s3090434",
		"Pilea riopalenquensis",
		"pilea",
		3090434
	],
	[
		"s3865602",
		"Pilea riparia",
		"pilea",
		3865602
	],
	[
		"s3865603",
		"Pilea rivoriae",
		"pilea",
		3865603
	],
	[
		"s344844",
		"Pilea rivularis",
		"pilea",
		344844
	],
	[
		"s3865604",
		"Pilea robinsonii",
		"pilea",
		3865604
	],
	[
		"s3865605",
		"Pilea robusta",
		"pilea",
		3865605
	],
	[
		"s3865606",
		"Pilea roemeri",
		"pilea",
		3865606
	],
	[
		"s3865607",
		"Pilea rojasiana",
		"pilea",
		3865607
	],
	[
		"s3865608",
		"Pilea rostellata",
		"pilea",
		3865608
	],
	[
		"s3090435",
		"Pilea rostulata",
		"pilea",
		3090435
	],
	[
		"s3090436",
		"Pilea rotundata",
		"pilea",
		3090436
	],
	[
		"s344845",
		"Pilea rotundinucula",
		"pilea",
		344845
	],
	[
		"s3865609",
		"Pilea royenii",
		"pilea",
		3865609
	],
	[
		"s3865610",
		"Pilea rubiacea",
		"pilea",
		3865610
	],
	[
		"s345216",
		"Pilea rubriflora",
		"pilea",
		345216
	],
	[
		"s344846",
		"Pilea rufa",
		"pilea",
		344846
	],
	[
		"s3865611",
		"Pilea rufescens",
		"pilea",
		3865611
	],
	[
		"s345211",
		"Pilea rugosa",
		"pilea",
		345211
	],
	[
		"s3090437",
		"Pilea rugosissima",
		"pilea",
		3090437
	],
	[
		"s3089796",
		"Pilea rusbyi",
		"pilea",
		3089796
	],
	[
		"s3865612",
		"Pilea salentana",
		"pilea",
		3865612
	],
	[
		"s3865613",
		"Pilea salwinensis",
		"pilea",
		3865613
	],
	[
		"s3865614",
		"Pilea samanensis",
		"pilea",
		3865614
	],
	[
		"s3090438",
		"Pilea sanctae-crucis",
		"pilea",
		3090438
	],
	[
		"s3865615",
		"Pilea sancti-johannis",
		"pilea",
		3865615
	],
	[
		"s3865616",
		"Pilea saxicola",
		"pilea",
		3865616
	],
	[
		"s3865617",
		"Pilea scandens",
		"pilea",
		3865617
	],
	[
		"s3865618",
		"Pilea schimpffii",
		"pilea",
		3865618
	],
	[
		"s3865619",
		"Pilea schlechteri",
		"pilea",
		3865619
	],
	[
		"s3089797",
		"Pilea scripta",
		"pilea",
		3089797
	],
	[
		"s3865620",
		"Pilea selbyanorum",
		"pilea",
		3865620
	],
	[
		"s3865621",
		"Pilea selleana",
		"pilea",
		3865621
	],
	[
		"s344847",
		"Pilea semidentata",
		"pilea",
		344847
	],
	[
		"s2739292",
		"Pilea semisessilis",
		"pilea",
		2739292
	],
	[
		"s3090439",
		"Pilea senarifolia",
		"pilea",
		3090439
	],
	[
		"s3089798",
		"Pilea serpyllifolia",
		"pilea",
		3089798
	],
	[
		"s3865622",
		"Pilea serratifolia",
		"pilea",
		3865622
	],
	[
		"s3865623",
		"Pilea serrulata",
		"pilea",
		3865623
	],
	[
		"s3865624",
		"Pilea sessiliflora",
		"pilea",
		3865624
	],
	[
		"s3865625",
		"Pilea sessilifolia",
		"pilea",
		3865625
	],
	[
		"s345205",
		"Pilea setigera",
		"pilea",
		345205
	],
	[
		"s3865626",
		"Pilea sevillensis",
		"pilea",
		3865626
	],
	[
		"s3865627",
		"Pilea shaferi",
		"pilea",
		3865627
	],
	[
		"s3865628",
		"Pilea shizongensis",
		"pilea",
		3865628
	],
	[
		"s3865629",
		"Pilea siguaneana",
		"pilea",
		3865629
	],
	[
		"s3865630",
		"Pilea silvicola",
		"pilea",
		3865630
	],
	[
		"s3865631",
		"Pilea simplex",
		"pilea",
		3865631
	],
	[
		"s2945672",
		"Pilea sinocrassifolia",
		"pilea",
		2945672
	],
	[
		"s344848",
		"Pilea sinofasciata",
		"pilea",
		344848
	],
	[
		"s3865632",
		"Pilea skutchii",
		"pilea",
		3865632
	],
	[
		"s3865633",
		"Pilea solandri",
		"pilea",
		3865633
	],
	[
		"s3865634",
		"Pilea spathulata",
		"pilea",
		3865634
	],
	[
		"s344849",
		"Pilea spathulifolia",
		"pilea",
		344849
	],
	[
		"s3865635",
		"Pilea sphenophylla",
		"pilea",
		3865635
	],
	[
		"s2739293",
		"Pilea spicata",
		"pilea",
		2739293
	],
	[
		"s3865636",
		"Pilea spinulosa",
		"pilea",
		3865636
	],
	[
		"s3090440",
		"Pilea spruceana",
		"pilea",
		3090440
	],
	[
		"s3090441",
		"Pilea squamosa",
		"pilea",
		3090441
	],
	[
		"s3865637",
		"Pilea squamulata",
		"pilea",
		3865637
	],
	[
		"s3865638",
		"Pilea stapfiana",
		"pilea",
		3865638
	],
	[
		"s3865639",
		"Pilea stellarioides",
		"pilea",
		3865639
	],
	[
		"s3865640",
		"Pilea stenoneura",
		"pilea",
		3865640
	],
	[
		"s3865641",
		"Pilea stenophylla",
		"pilea",
		3865641
	],
	[
		"s647282",
		"Pilea stipulosa",
		"pilea",
		647282
	],
	[
		"s3865642",
		"Pilea stolonifera",
		"pilea",
		3865642
	],
	[
		"s3865643",
		"Pilea striata",
		"pilea",
		3865643
	],
	[
		"s3865644",
		"Pilea strigillosa",
		"pilea",
		3865644
	],
	[
		"s3090442",
		"Pilea strigosa",
		"pilea",
		3090442
	],
	[
		"s3865645",
		"Pilea subamplexicaulis",
		"pilea",
		3865645
	],
	[
		"s2739294",
		"Pilea subcoriacea",
		"pilea",
		2739294
	],
	[
		"s3865646",
		"Pilea subedentata",
		"pilea",
		3865646
	],
	[
		"s3865647",
		"Pilea subintegerrima",
		"pilea",
		3865647
	],
	[
		"s3865648",
		"Pilea sublobata",
		"pilea",
		3865648
	],
	[
		"s3865649",
		"Pilea sublucens",
		"pilea",
		3865649
	],
	[
		"s3865650",
		"Pilea submissa",
		"pilea",
		3865650
	],
	[
		"s344850",
		"Pilea succulenta",
		"pilea",
		344850
	],
	[
		"s3865651",
		"Pilea suffruticosa",
		"pilea",
		3865651
	],
	[
		"s3865652",
		"Pilea sumideroensis",
		"pilea",
		3865652
	],
	[
		"s3865653",
		"Pilea supersedens",
		"pilea",
		3865653
	],
	[
		"s3865654",
		"Pilea suta",
		"pilea",
		3865654
	],
	[
		"s345209",
		"Pilea swinglei",
		"pilea",
		345209
	],
	[
		"s3865655",
		"Pilea sykesii",
		"pilea",
		3865655
	],
	[
		"s3865656",
		"Pilea sylvatica",
		"pilea",
		3865656
	],
	[
		"s3865657",
		"Pilea tabularis",
		"pilea",
		3865657
	],
	[
		"s3865658",
		"Pilea taiwanensis",
		"pilea",
		3865658
	],
	[
		"s3090443",
		"Pilea tatamensis",
		"pilea",
		3090443
	],
	[
		"s3090444",
		"Pilea tatei",
		"pilea",
		3090444
	],
	[
		"s3865659",
		"Pilea tenebrosa",
		"pilea",
		3865659
	],
	[
		"s3865660",
		"Pilea tenerrima",
		"pilea",
		3865660
	],
	[
		"s344851",
		"Pilea ternifolia",
		"pilea",
		344851
	],
	[
		"s344852",
		"Pilea tetraphylla",
		"pilea",
		344852
	],
	[
		"s3865661",
		"Pilea tetrapoda",
		"pilea",
		3865661
	],
	[
		"s3865662",
		"Pilea thouarsiana",
		"pilea",
		3865662
	],
	[
		"s344853",
		"Pilea thymifolia",
		"pilea",
		344853
	],
	[
		"s3865663",
		"Pilea thymoidea",
		"pilea",
		3865663
	],
	[
		"s3090445",
		"Pilea tilarana",
		"pilea",
		3090445
	],
	[
		"s3865664",
		"Pilea tippenhaueri",
		"pilea",
		3865664
	],
	[
		"s3865665",
		"Pilea tobagensis",
		"pilea",
		3865665
	],
	[
		"s3865666",
		"Pilea topensis",
		"pilea",
		3865666
	],
	[
		"s3865667",
		"Pilea torbeciana",
		"pilea",
		3865667
	],
	[
		"s3089799",
		"Pilea trianthemoides",
		"pilea",
		3089799
	],
	[
		"s3865668",
		"Pilea trichomanophylla",
		"pilea",
		3865668
	],
	[
		"s3090446",
		"Pilea trichosanthes",
		"pilea",
		3090446
	],
	[
		"s3865669",
		"Pilea trichotoma",
		"pilea",
		3865669
	],
	[
		"s344854",
		"Pilea tridentata",
		"pilea",
		344854
	],
	[
		"s3865670",
		"Pilea trilobata",
		"pilea",
		3865670
	],
	[
		"s344855",
		"Pilea tripartita",
		"pilea",
		344855
	],
	[
		"s3865671",
		"Pilea triradiata",
		"pilea",
		3865671
	],
	[
		"s3865672",
		"Pilea troyensis",
		"pilea",
		3865672
	],
	[
		"s3865673",
		"Pilea truncata",
		"pilea",
		3865673
	],
	[
		"s3090447",
		"Pilea tsaratananensis",
		"pilea",
		3090447
	],
	[
		"s2739295",
		"Pilea tsiangiana",
		"pilea",
		2739295
	],
	[
		"s3865674",
		"Pilea tungurahuae",
		"pilea",
		3865674
	],
	[
		"s3090448",
		"Pilea tutensis",
		"pilea",
		3090448
	],
	[
		"s3865675",
		"Pilea ulei",
		"pilea",
		3865675
	],
	[
		"s3865676",
		"Pilea umbellata",
		"pilea",
		3865676
	],
	[
		"s3090449",
		"Pilea umbriana",
		"pilea",
		3090449
	],
	[
		"s345214",
		"Pilea umbrosa",
		"pilea",
		345214
	],
	[
		"s2739296",
		"Pilea unciformis",
		"pilea",
		2739296
	],
	[
		"s3865677",
		"Pilea uninervis",
		"pilea",
		3865677
	],
	[
		"s3865678",
		"Pilea urticella",
		"pilea",
		3865678
	],
	[
		"s3865679",
		"Pilea urticifolia",
		"pilea",
		3865679
	],
	[
		"s2984587",
		"Pilea usambarensis",
		"pilea",
		2984587
	],
	[
		"s3865680",
		"Pilea valenzuelae",
		"pilea",
		3865680
	],
	[
		"s3090450",
		"Pilea vegasana",
		"pilea",
		3090450
	],
	[
		"s3865681",
		"Pilea venulosa",
		"pilea",
		3865681
	],
	[
		"s344856",
		"Pilea verbascifolia",
		"pilea",
		344856
	],
	[
		"s3865682",
		"Pilea vermicularis",
		"pilea",
		3865682
	],
	[
		"s1399730",
		"Pilea verrucosa",
		"pilea",
		1399730
	],
	[
		"s3865683",
		"Pilea versteegii",
		"pilea",
		3865683
	],
	[
		"s2283691",
		"Pilea victoriae",
		"pilea",
		2283691
	],
	[
		"s3865684",
		"Pilea victoriensis",
		"pilea",
		3865684
	],
	[
		"s2739297",
		"Pilea villicaulis",
		"pilea",
		2739297
	],
	[
		"s344857",
		"Pilea virgata",
		"pilea",
		344857
	],
	[
		"s344858",
		"Pilea vulcanica",
		"pilea",
		344858
	],
	[
		"s3865685",
		"Pilea weberbaueri",
		"pilea",
		3865685
	],
	[
		"s344859",
		"Pilea weddellii",
		"pilea",
		344859
	],
	[
		"s2739266",
		"Pilea weimingii",
		"pilea",
		2739266
	],
	[
		"s3090451",
		"Pilea wightii",
		"pilea",
		3090451
	],
	[
		"s3865686",
		"Pilea wilsonii",
		"pilea",
		3865686
	],
	[
		"s3865687",
		"Pilea wollastonii",
		"pilea",
		3865687
	],
	[
		"s3865688",
		"Pilea wrightiana",
		"pilea",
		3865688
	],
	[
		"s3865689",
		"Pilea wullschlaegelii",
		"pilea",
		3865689
	],
	[
		"s3865690",
		"Pilea yarensis",
		"pilea",
		3865690
	],
	[
		"s3865691",
		"Pilea yingshaoyaoana",
		"pilea",
		3865691
	],
	[
		"s3865692",
		"Pilea yuanbaoshanica",
		"pilea",
		3865692
	],
	[
		"s3865693",
		"Pilea yunckeri",
		"pilea",
		3865693
	],
	[
		"s3089800",
		"Pilea yunquensis",
		"pilea",
		3089800
	],
	[
		"s3865694",
		"Pilea zaranensis",
		"pilea",
		3865694
	],
	[
		"s309432",
		"Pipturus albidus",
		"pipturus",
		309432
	],
	[
		"s3866245",
		"Pipturus angustifolius",
		"pipturus",
		3866245
	],
	[
		"s1399732",
		"Pipturus arborescens",
		"pipturus",
		1399732
	],
	[
		"s875747",
		"Pipturus argenteus",
		"pipturus",
		875747
	],
	[
		"s3866246",
		"Pipturus asper",
		"pipturus",
		3866246
	],
	[
		"s3866247",
		"Pipturus australium",
		"pipturus",
		3866247
	],
	[
		"s3090452",
		"Pipturus brighamii",
		"pipturus",
		3090452
	],
	[
		"s3866248",
		"Pipturus ceramicus",
		"pipturus",
		3866248
	],
	[
		"s3866249",
		"Pipturus cinnamomeus",
		"pipturus",
		3866249
	],
	[
		"s3866250",
		"Pipturus dentatus",
		"pipturus",
		3866250
	],
	[
		"s3090453",
		"Pipturus forbesii",
		"pipturus",
		3090453
	],
	[
		"s3090454",
		"Pipturus gaudichaudianus",
		"pipturus",
		3090454
	],
	[
		"s3866251",
		"Pipturus grandifolius",
		"pipturus",
		3866251
	],
	[
		"s3866252",
		"Pipturus grantii",
		"pipturus",
		3866252
	],
	[
		"s3090455",
		"Pipturus hawaiensis",
		"pipturus",
		3090455
	],
	[
		"s3866253",
		"Pipturus henryanus",
		"pipturus",
		3866253
	],
	[
		"s3866254",
		"Pipturus hubertii",
		"pipturus",
		3866254
	],
	[
		"s1399733",
		"Pipturus kauaiensis",
		"pipturus",
		1399733
	],
	[
		"s3866255",
		"Pipturus ledermannii",
		"pipturus",
		3866255
	],
	[
		"s3866256",
		"Pipturus lithospermum",
		"pipturus",
		3866256
	],
	[
		"s3866257",
		"Pipturus micronesicus",
		"pipturus",
		3866257
	],
	[
		"s2807298",
		"Pipturus montanus",
		"pipturus",
		2807298
	],
	[
		"s3090456",
		"Pipturus oahuensis",
		"pipturus",
		3090456
	],
	[
		"s3866258",
		"Pipturus oreophilus",
		"pipturus",
		3866258
	],
	[
		"s3090457",
		"Pipturus pachyphyllus",
		"pipturus",
		3090457
	],
	[
		"s3866259",
		"Pipturus platyphyllus",
		"pipturus",
		3866259
	],
	[
		"s3866260",
		"Pipturus polynesicus",
		"pipturus",
		3866260
	],
	[
		"s3866261",
		"Pipturus pullei",
		"pipturus",
		3866261
	],
	[
		"s3090458",
		"Pipturus rockii",
		"pipturus",
		3090458
	],
	[
		"s1399734",
		"Pipturus ruber",
		"pipturus",
		1399734
	],
	[
		"s3866262",
		"Pipturus schaeferi",
		"pipturus",
		3866262
	],
	[
		"s3090459",
		"Pipturus skottsbergii",
		"pipturus",
		3090459
	],
	[
		"s3866263",
		"Pipturus subinteger",
		"pipturus",
		3866263
	],
	[
		"s3866264",
		"Pipturus succulentus",
		"pipturus",
		3866264
	],
	[
		"s3866265",
		"Pipturus tooviianus",
		"pipturus",
		3866265
	],
	[
		"s3089801",
		"Pipturus velutinus",
		"pipturus",
		3089801
	],
	[
		"s3866266",
		"Pipturus verticillatus",
		"pipturus",
		3866266
	],
	[
		"s3866267",
		"Pipturus vitiensis",
		"pipturus",
		3866267
	],
	[
		"s1428768",
		"Planera aquatica",
		"planera",
		1428768
	],
	[
		"s1785685",
		"Poikilospermum acuminatum",
		"poikilospermum",
		1785685
	],
	[
		"s3868056",
		"Poikilospermum amboinense",
		"poikilospermum",
		3868056
	],
	[
		"s3868057",
		"Poikilospermum amoenum",
		"poikilospermum",
		3868057
	],
	[
		"s3868058",
		"Poikilospermum annamense",
		"poikilospermum",
		3868058
	],
	[
		"s3868059",
		"Poikilospermum azureum",
		"poikilospermum",
		3868059
	],
	[
		"s3868060",
		"Poikilospermum borneense",
		"poikilospermum",
		3868060
	],
	[
		"s2792736",
		"Poikilospermum cordifolium",
		"poikilospermum",
		2792736
	],
	[
		"s3868061",
		"Poikilospermum dubium",
		"poikilospermum",
		3868061
	],
	[
		"s3868062",
		"Poikilospermum erectum",
		"poikilospermum",
		3868062
	],
	[
		"s3868063",
		"Poikilospermum forbesii",
		"poikilospermum",
		3868063
	],
	[
		"s3868064",
		"Poikilospermum gjellerupii",
		"poikilospermum",
		3868064
	],
	[
		"s3868065",
		"Poikilospermum hirsutum",
		"poikilospermum",
		3868065
	],
	[
		"s3868066",
		"Poikilospermum intermedium",
		"poikilospermum",
		3868066
	],
	[
		"s344860",
		"Poikilospermum lanceolatum",
		"poikilospermum",
		344860
	],
	[
		"s3868067",
		"Poikilospermum longifolium",
		"poikilospermum",
		3868067
	],
	[
		"s3868068",
		"Poikilospermum micranthum",
		"poikilospermum",
		3868068
	],
	[
		"s3868069",
		"Poikilospermum microstachys",
		"poikilospermum",
		3868069
	],
	[
		"s2952669",
		"Poikilospermum naucleiflorum",
		"poikilospermum",
		2952669
	],
	[
		"s2807134",
		"Poikilospermum nobile",
		"poikilospermum",
		2807134
	],
	[
		"s3868070",
		"Poikilospermum oblongifolium",
		"poikilospermum",
		3868070
	],
	[
		"s3868071",
		"Poikilospermum paxianum",
		"poikilospermum",
		3868071
	],
	[
		"s3868072",
		"Poikilospermum peltatum",
		"poikilospermum",
		3868072
	],
	[
		"s2792737",
		"Poikilospermum scabrinervium",
		"poikilospermum",
		2792737
	],
	[
		"s3868073",
		"Poikilospermum scortechinii",
		"poikilospermum",
		3868073
	],
	[
		"s3868074",
		"Poikilospermum singalense",
		"poikilospermum",
		3868074
	],
	[
		"s647284",
		"Poikilospermum suaveolens",
		"poikilospermum",
		647284
	],
	[
		"s3868075",
		"Poikilospermum subtrinervium",
		"poikilospermum",
		3868075
	],
	[
		"s2306698",
		"Poikilospermum tangaum",
		"poikilospermum",
		2306698
	],
	[
		"s2985947",
		"Polianthion biloculare",
		"polianthion",
		2985947
	],
	[
		"s456989",
		"Polianthion collinum",
		"polianthion",
		456989
	],
	[
		"s323937",
		"Polianthion minutiflorum",
		"polianthion",
		323937
	],
	[
		"s323935",
		"Polianthion wichurae",
		"polianthion",
		323935
	],
	[
		"s3836539",
		"Polylepis acomayensis",
		"polylepis",
		3836539
	],
	[
		"s3836540",
		"Polylepis albicans",
		"polylepis",
		3836540
	],
	[
		"s3836541",
		"Polylepis argentea",
		"polylepis",
		3836541
	],
	[
		"s281887",
		"Polylepis australis",
		"polylepis",
		281887
	],
	[
		"s281888",
		"Polylepis besseri",
		"polylepis",
		281888
	],
	[
		"s3836542",
		"Polylepis canoi",
		"polylepis",
		3836542
	],
	[
		"s281892",
		"Polylepis crista-galli",
		"polylepis",
		281892
	],
	[
		"s3836543",
		"Polylepis fjeldsaoi",
		"polylepis",
		3836543
	],
	[
		"s3836544",
		"Polylepis frontinensis",
		"polylepis",
		3836544
	],
	[
		"s211871",
		"Polylepis hieronymi",
		"polylepis",
		211871
	],
	[
		"s3836545",
		"Polylepis humboldtii",
		"polylepis",
		3836545
	],
	[
		"s281893",
		"Polylepis incana",
		"polylepis",
		281893
	],
	[
		"s281908",
		"Polylepis incanoides",
		"polylepis",
		281908
	],
	[
		"s281890",
		"Polylepis incarum",
		"polylepis",
		281890
	],
	[
		"s281901",
		"Polylepis lanata",
		"polylepis",
		281901
	],
	[
		"s281894",
		"Polylepis lanuginosa",
		"polylepis",
		281894
	],
	[
		"s3836546",
		"Polylepis loxensis",
		"polylepis",
		3836546
	],
	[
		"s3440245",
		"Polylepis microphylla",
		"polylepis",
		3440245
	],
	[
		"s281895",
		"Polylepis multijuga",
		"polylepis",
		281895
	],
	[
		"s3836547",
		"Polylepis nana",
		"polylepis",
		3836547
	],
	[
		"s281896",
		"Polylepis neglecta",
		"polylepis",
		281896
	],
	[
		"s3836548",
		"Polylepis occidentalis",
		"polylepis",
		3836548
	],
	[
		"s3836549",
		"Polylepis pacensis",
		"polylepis",
		3836549
	],
	[
		"s3836550",
		"Polylepis pampabella",
		"polylepis",
		3836550
	],
	[
		"s281897",
		"Polylepis pauta",
		"polylepis",
		281897
	],
	[
		"s281898",
		"Polylepis pepei",
		"polylepis",
		281898
	],
	[
		"s3836551",
		"Polylepis pilosissima",
		"polylepis",
		3836551
	],
	[
		"s281899",
		"Polylepis quadrijuga",
		"polylepis",
		281899
	],
	[
		"s281900",
		"Polylepis racemosa",
		"polylepis",
		281900
	],
	[
		"s281903",
		"Polylepis reticulata",
		"polylepis",
		281903
	],
	[
		"s3836552",
		"Polylepis rocio-rojasiae",
		"polylepis",
		3836552
	],
	[
		"s3836553",
		"Polylepis rodolfo-vasquezii",
		"polylepis",
		3836553
	],
	[
		"s281904",
		"Polylepis rugulosa",
		"polylepis",
		281904
	],
	[
		"s3836554",
		"Polylepis sacra",
		"polylepis",
		3836554
	],
	[
		"s137450",
		"Polylepis sericea",
		"polylepis",
		137450
	],
	[
		"s3836555",
		"Polylepis serrata",
		"polylepis",
		3836555
	],
	[
		"s281905",
		"Polylepis subsericans",
		"polylepis",
		281905
	],
	[
		"s281891",
		"Polylepis subtusalbida",
		"polylepis",
		281891
	],
	[
		"s211870",
		"Polylepis tarapacana",
		"polylepis",
		211870
	],
	[
		"s281906",
		"Polylepis tomentella",
		"polylepis",
		281906
	],
	[
		"s281902",
		"Polylepis triacontandra",
		"polylepis",
		281902
	],
	[
		"s281909",
		"Polylepis weberbaueri",
		"polylepis",
		281909
	],
	[
		"s3091618",
		"Pomaderris adnata",
		"pomaderris",
		3091618
	],
	[
		"s3869385",
		"Pomaderris amoena",
		"pomaderris",
		3869385
	],
	[
		"s3091619",
		"Pomaderris andromedifolia",
		"pomaderris",
		3091619
	],
	[
		"s323950",
		"Pomaderris angustifolia",
		"pomaderris",
		323950
	],
	[
		"s3869386",
		"Pomaderris apetala",
		"pomaderris",
		3869386
	],
	[
		"s3049603",
		"Pomaderris argyrophylla",
		"pomaderris",
		3049603
	],
	[
		"s2814419",
		"Pomaderris aspera",
		"pomaderris",
		2814419
	],
	[
		"s3869387",
		"Pomaderris aurea",
		"pomaderris",
		3869387
	],
	[
		"s3869388",
		"Pomaderris bodalla",
		"pomaderris",
		3869388
	],
	[
		"s323946",
		"Pomaderris brevifolia",
		"pomaderris",
		323946
	],
	[
		"s3869389",
		"Pomaderris briagolensis",
		"pomaderris",
		3869389
	],
	[
		"s3869390",
		"Pomaderris brogoensis",
		"pomaderris",
		3869390
	],
	[
		"s3869391",
		"Pomaderris brunnea",
		"pomaderris",
		3869391
	],
	[
		"s3869392",
		"Pomaderris buchanensis",
		"pomaderris",
		3869392
	],
	[
		"s3869393",
		"Pomaderris canescens",
		"pomaderris",
		3869393
	],
	[
		"s3869394",
		"Pomaderris cinerea",
		"pomaderris",
		3869394
	],
	[
		"s1842776",
		"Pomaderris clivicola",
		"pomaderris",
		1842776
	],
	[
		"s3869395",
		"Pomaderris cocoparrana",
		"pomaderris",
		3869395
	],
	[
		"s3869396",
		"Pomaderris coomingalensis",
		"pomaderris",
		3869396
	],
	[
		"s3869397",
		"Pomaderris costata",
		"pomaderris",
		3869397
	],
	[
		"s3869398",
		"Pomaderris cotoneaster",
		"pomaderris",
		3869398
	],
	[
		"s3869399",
		"Pomaderris crassifolia",
		"pomaderris",
		3869399
	],
	[
		"s3869400",
		"Pomaderris delicata",
		"pomaderris",
		3869400
	],
	[
		"s325282",
		"Pomaderris edgerleyi",
		"pomaderris",
		325282
	],
	[
		"s3091620",
		"Pomaderris elachophylla",
		"pomaderris",
		3091620
	],
	[
		"s323952",
		"Pomaderris elliptica",
		"pomaderris",
		323952
	],
	[
		"s3091621",
		"Pomaderris eriocephala",
		"pomaderris",
		3091621
	],
	[
		"s3091622",
		"Pomaderris ferruginea",
		"pomaderris",
		3091622
	],
	[
		"s323954",
		"Pomaderris flabellaris",
		"pomaderris",
		323954
	],
	[
		"s323948",
		"Pomaderris forrestiana",
		"pomaderris",
		323948
	],
	[
		"s3869401",
		"Pomaderris gilmourii",
		"pomaderris",
		3869401
	],
	[
		"s323949",
		"Pomaderris grandis",
		"pomaderris",
		323949
	],
	[
		"s3869402",
		"Pomaderris graniticola",
		"pomaderris",
		3869402
	],
	[
		"s3869403",
		"Pomaderris halmaturina",
		"pomaderris",
		3869403
	],
	[
		"s3091623",
		"Pomaderris hamiltonii",
		"pomaderris",
		3091623
	],
	[
		"s3869404",
		"Pomaderris helianthemifolia",
		"pomaderris",
		3869404
	],
	[
		"s3869405",
		"Pomaderris humilis",
		"pomaderris",
		3869405
	],
	[
		"s3091630",
		"Pomaderris intermedia",
		"pomaderris",
		3091630
	],
	[
		"s3091624",
		"Pomaderris lanigera",
		"pomaderris",
		3091624
	],
	[
		"s3091625",
		"Pomaderris ledifolia",
		"pomaderris",
		3091625
	],
	[
		"s3091626",
		"Pomaderris ligustrina",
		"pomaderris",
		3091626
	],
	[
		"s3869406",
		"Pomaderris mediora",
		"pomaderris",
		3869406
	],
	[
		"s3869407",
		"Pomaderris myrtilloides",
		"pomaderris",
		3869407
	],
	[
		"s1842777",
		"Pomaderris notata",
		"pomaderris",
		1842777
	],
	[
		"s323945",
		"Pomaderris obcordata",
		"pomaderris",
		323945
	],
	[
		"s3869408",
		"Pomaderris oblongifolia",
		"pomaderris",
		3869408
	],
	[
		"s323953",
		"Pomaderris oraria",
		"pomaderris",
		323953
	],
	[
		"s3869409",
		"Pomaderris pallida",
		"pomaderris",
		3869409
	],
	[
		"s3091627",
		"Pomaderris paniculosa",
		"pomaderris",
		3091627
	],
	[
		"s3869410",
		"Pomaderris parrisiae",
		"pomaderris",
		3869410
	],
	[
		"s3869411",
		"Pomaderris pauciflora",
		"pomaderris",
		3869411
	],
	[
		"s323955",
		"Pomaderris phylicifolia",
		"pomaderris",
		323955
	],
	[
		"s3091628",
		"Pomaderris pilifera",
		"pomaderris",
		3091628
	],
	[
		"s3869412",
		"Pomaderris precaria",
		"pomaderris",
		3869412
	],
	[
		"s323956",
		"Pomaderris prunifolia",
		"pomaderris",
		323956
	],
	[
		"s3091629",
		"Pomaderris queenslandica",
		"pomaderris",
		3091629
	],
	[
		"s2985948",
		"Pomaderris racemosa",
		"pomaderris",
		2985948
	],
	[
		"s323947",
		"Pomaderris rotundifolia",
		"pomaderris",
		323947
	],
	[
		"s106698",
		"Pomaderris rugosa",
		"pomaderris",
		106698
	],
	[
		"s3869413",
		"Pomaderris sericea",
		"pomaderris",
		3869413
	],
	[
		"s3869414",
		"Pomaderris subcapitata",
		"pomaderris",
		3869414
	],
	[
		"s3091631",
		"Pomaderris subplicata",
		"pomaderris",
		3091631
	],
	[
		"s323951",
		"Pomaderris tropica",
		"pomaderris",
		323951
	],
	[
		"s2945634",
		"Pomaderris vacciniifolia",
		"pomaderris",
		2945634
	],
	[
		"s3869415",
		"Pomaderris vellea",
		"pomaderris",
		3869415
	],
	[
		"s3091632",
		"Pomaderris velutina",
		"pomaderris",
		3091632
	],
	[
		"s3869416",
		"Pomaderris virgata",
		"pomaderris",
		3869416
	],
	[
		"s3869417",
		"Pomaderris viridis",
		"pomaderris",
		3869417
	],
	[
		"s3869418",
		"Pomaderris walshii",
		"pomaderris",
		3869418
	],
	[
		"s393623",
		"Potaninia mongolica",
		"potaninia",
		393623
	],
	[
		"s1732545",
		"Potentilla acaulis",
		"potentilla",
		1732545
	],
	[
		"s3817325",
		"Potentilla adenotricha",
		"potentilla",
		3817325
	],
	[
		"s3817326",
		"Potentilla adriatica",
		"potentilla",
		3817326
	],
	[
		"s1433391",
		"Potentilla adscharica",
		"potentilla",
		1433391
	],
	[
		"s1016827",
		"Potentilla aff. verna JP-2011",
		"potentilla",
		1016827
	],
	[
		"s667229",
		"Potentilla agrimonioides",
		"potentilla",
		667229
	],
	[
		"s654612",
		"Potentilla alba",
		"potentilla",
		654612
	],
	[
		"s667230",
		"Potentilla albiflora",
		"potentilla",
		667230
	],
	[
		"s3817327",
		"Potentilla alborzensis",
		"potentilla",
		3817327
	],
	[
		"s637896",
		"Potentilla alchemilloides",
		"potentilla",
		637896
	],
	[
		"s3091634",
		"Potentilla alchimilloides",
		"potentilla",
		3091634
	],
	[
		"s1819509",
		"Potentilla algida",
		"potentilla",
		1819509
	],
	[
		"s667231",
		"Potentilla alpicola",
		"potentilla",
		667231
	],
	[
		"s3817328",
		"Potentilla alsatica",
		"potentilla",
		3817328
	],
	[
		"s3817329",
		"Potentilla altaica",
		"potentilla",
		3817329
	],
	[
		"s3817330",
		"Potentilla ambigens",
		"potentilla",
		3817330
	],
	[
		"s3817331",
		"Potentilla amicarum",
		"potentilla",
		3817331
	],
	[
		"s669783",
		"Potentilla anachoretica",
		"potentilla",
		669783
	],
	[
		"s3817332",
		"Potentilla anadryensis",
		"potentilla",
		3817332
	],
	[
		"s1819510",
		"Potentilla anadyrensis",
		"potentilla",
		1819510
	],
	[
		"s1819511",
		"Potentilla anatolica",
		"potentilla",
		1819511
	],
	[
		"s714487",
		"Potentilla ancistrifolia",
		"potentilla",
		714487
	],
	[
		"s538580",
		"Potentilla andicola",
		"potentilla",
		538580
	],
	[
		"s1486131",
		"Potentilla anemonifolia",
		"potentilla",
		1486131
	],
	[
		"s3817333",
		"Potentilla angelliae",
		"potentilla",
		3817333
	],
	[
		"s660070",
		"Potentilla anglica",
		"potentilla",
		660070
	],
	[
		"s3091635",
		"Potentilla angustiloba",
		"potentilla",
		3091635
	],
	[
		"s3141234",
		"Potentilla anjuica",
		"potentilla",
		3141234
	],
	[
		"s667232",
		"Potentilla apennina",
		"potentilla",
		667232
	],
	[
		"s667220",
		"Potentilla aperta",
		"potentilla",
		667220
	],
	[
		"s3082574",
		"Potentilla approximata",
		"potentilla",
		3082574
	],
	[
		"s3817334",
		"Potentilla arcadiensis",
		"potentilla",
		3817334
	],
	[
		"s2775455",
		"Potentilla arctica",
		"potentilla",
		2775455
	],
	[
		"s669784",
		"Potentilla arenosa",
		"potentilla",
		669784
	],
	[
		"s667233",
		"Potentilla argaea",
		"potentilla",
		667233
	],
	[
		"s654633",
		"Potentilla argentea",
		"potentilla",
		654633
	],
	[
		"s667202",
		"Potentilla argentea x Potentilla inclinata",
		"potentilla",
		667202
	],
	[
		"s1042661",
		"Potentilla argyrocoma",
		"potentilla",
		1042661
	],
	[
		"s1819513",
		"Potentilla argyroloma",
		"potentilla",
		1819513
	],
	[
		"s487760",
		"Potentilla argyrophylla",
		"potentilla",
		487760
	],
	[
		"s667234",
		"Potentilla arizonica",
		"potentilla",
		667234
	],
	[
		"s654645",
		"Potentilla articulata",
		"potentilla",
		654645
	],
	[
		"s3817335",
		"Potentilla asiae-mediae",
		"potentilla",
		3817335
	],
	[
		"s3817336",
		"Potentilla asinaria",
		"potentilla",
		3817336
	],
	[
		"s3817337",
		"Potentilla aspegrenii",
		"potentilla",
		3817337
	],
	[
		"s3091636",
		"Potentilla asperrima",
		"potentilla",
		3091636
	],
	[
		"s3817338",
		"Potentilla assalemica",
		"potentilla",
		3817338
	],
	[
		"s3817339",
		"Potentilla asterotricha",
		"potentilla",
		3817339
	],
	[
		"s1819514",
		"Potentilla astracanica",
		"potentilla",
		1819514
	],
	[
		"s1819515",
		"Potentilla astragalifolia",
		"potentilla",
		1819515
	],
	[
		"s3817340",
		"Potentilla asturica",
		"potentilla",
		3817340
	],
	[
		"s487759",
		"Potentilla atrosanguinea",
		"potentilla",
		487759
	],
	[
		"s1819516",
		"Potentilla aucheriana",
		"potentilla",
		1819516
	],
	[
		"s581249",
		"Potentilla aurea",
		"potentilla",
		581249
	],
	[
		"s3817341",
		"Potentilla bactriana",
		"potentilla",
		3817341
	],
	[
		"s3817342",
		"Potentilla baekdusanensis",
		"potentilla",
		3817342
	],
	[
		"s1008374",
		"Potentilla baileyi",
		"potentilla",
		1008374
	],
	[
		"s3817343",
		"Potentilla bannehalensis",
		"potentilla",
		3817343
	],
	[
		"s3141233",
		"Potentilla basaltica",
		"potentilla",
		3141233
	],
	[
		"s3817344",
		"Potentilla beringensis",
		"potentilla",
		3817344
	],
	[
		"s3817345",
		"Potentilla beringii",
		"potentilla",
		3817345
	],
	[
		"s1778367",
		"Potentilla betonicifolia",
		"potentilla",
		1778367
	],
	[
		"s3817346",
		"Potentilla bhutanica",
		"potentilla",
		3817346
	],
	[
		"s457908",
		"Potentilla biennis",
		"potentilla",
		457908
	],
	[
		"s395302",
		"Potentilla biflora",
		"potentilla",
		395302
	],
	[
		"s667235",
		"Potentilla bimundorum",
		"potentilla",
		667235
	],
	[
		"s667236",
		"Potentilla bipinnatifida",
		"potentilla",
		667236
	],
	[
		"s654639",
		"Potentilla bolanderi",
		"potentilla",
		654639
	],
	[
		"s3817347",
		"Potentilla botschantzeviana",
		"potentilla",
		3817347
	],
	[
		"s3091637",
		"Potentilla brachypetala",
		"potentilla",
		3091637
	],
	[
		"s667237",
		"Potentilla brauneana",
		"potentilla",
		667237
	],
	[
		"s667238",
		"Potentilla brevifolia",
		"potentilla",
		667238
	],
	[
		"s3817348",
		"Potentilla brevifoliolata",
		"potentilla",
		3817348
	],
	[
		"s1042670",
		"Potentilla breweri",
		"potentilla",
		1042670
	],
	[
		"s667239",
		"Potentilla bruceae",
		"potentilla",
		667239
	],
	[
		"s3817349",
		"Potentilla buccoana",
		"potentilla",
		3817349
	],
	[
		"s3091638",
		"Potentilla bungei",
		"potentilla",
		3091638
	],
	[
		"s3817350",
		"Potentilla butandae",
		"potentilla",
		3817350
	],
	[
		"s3817351",
		"Potentilla butkovii",
		"potentilla",
		3817351
	],
	[
		"s889475",
		"Potentilla calabra",
		"potentilla",
		889475
	],
	[
		"s654646",
		"Potentilla californica",
		"potentilla",
		654646
	],
	[
		"s1562890",
		"Potentilla caliginosa",
		"potentilla",
		1562890
	],
	[
		"s3817352",
		"Potentilla callida",
		"potentilla",
		3817352
	],
	[
		"s3091639",
		"Potentilla camillae",
		"potentilla",
		3091639
	],
	[
		"s3089676",
		"Potentilla campestris",
		"potentilla",
		3089676
	],
	[
		"s1076577",
		"Potentilla canadensis",
		"potentilla",
		1076577
	],
	[
		"s1819517",
		"Potentilla cappadocica",
		"potentilla",
		1819517
	],
	[
		"s1819519",
		"Potentilla carduchorum",
		"potentilla",
		1819519
	],
	[
		"s1533302",
		"Potentilla carniolica",
		"potentilla",
		1533302
	],
	[
		"s667351",
		"Potentilla caruifolia",
		"potentilla",
		667351
	],
	[
		"s654626",
		"Potentilla caucasica",
		"potentilla",
		654626
	],
	[
		"s637897",
		"Potentilla caulescens",
		"potentilla",
		637897
	],
	[
		"s714646",
		"Potentilla centigrana",
		"potentilla",
		714646
	],
	[
		"s1301411",
		"Potentilla chamissonis",
		"potentilla",
		1301411
	],
	[
		"s210858",
		"Potentilla chinensis",
		"potentilla",
		210858
	],
	[
		"s654631",
		"Potentilla chrysantha",
		"potentilla",
		654631
	],
	[
		"s1533303",
		"Potentilla cinerea",
		"potentilla",
		1533303
	],
	[
		"s1541695",
		"Potentilla clandestina",
		"potentilla",
		1541695
	],
	[
		"s3817353",
		"Potentilla clarkei",
		"potentilla",
		3817353
	],
	[
		"s3121473",
		"Potentilla clevelandii",
		"potentilla",
		3121473
	],
	[
		"s654640",
		"Potentilla clusiana",
		"potentilla",
		654640
	],
	[
		"s3817354",
		"Potentilla coelestis",
		"potentilla",
		3817354
	],
	[
		"s667240",
		"Potentilla collina",
		"potentilla",
		667240
	],
	[
		"s457909",
		"Potentilla concinna",
		"potentilla",
		457909
	],
	[
		"s1732547",
		"Potentilla conferta",
		"potentilla",
		1732547
	],
	[
		"s1042654",
		"Potentilla congdonis",
		"potentilla",
		1042654
	],
	[
		"s3089656",
		"Potentilla congesta",
		"potentilla",
		3089656
	],
	[
		"s3817355",
		"Potentilla coreana",
		"potentilla",
		3817355
	],
	[
		"s1732548",
		"Potentilla coriandrifolia",
		"potentilla",
		1732548
	],
	[
		"s3817356",
		"Potentilla cottamii",
		"potentilla",
		3817356
	],
	[
		"s667241",
		"Potentilla crantzii",
		"potentilla",
		667241
	],
	[
		"s667242",
		"Potentilla crassinervia",
		"potentilla",
		667242
	],
	[
		"s654613",
		"Potentilla crebridens",
		"potentilla",
		654613
	],
	[
		"s3091640",
		"Potentilla crenulata",
		"potentilla",
		3091640
	],
	[
		"s667243",
		"Potentilla crinita",
		"potentilla",
		667243
	],
	[
		"s667244",
		"Potentilla cristae",
		"potentilla",
		667244
	],
	[
		"s1042662",
		"Potentilla cryptocaulis",
		"potentilla",
		1042662
	],
	[
		"s3091641",
		"Potentilla cryptophila",
		"potentilla",
		3091641
	],
	[
		"s1472690",
		"Potentilla cryptotaeniae",
		"potentilla",
		1472690
	],
	[
		"s637898",
		"Potentilla cuneata",
		"potentilla",
		637898
	],
	[
		"s667245",
		"Potentilla curviseta",
		"potentilla",
		667245
	],
	[
		"s3817357",
		"Potentilla czerepninii",
		"potentilla",
		3817357
	],
	[
		"s3817358",
		"Potentilla darvazica",
		"potentilla",
		3817358
	],
	[
		"s667215",
		"Potentilla daucifolia",
		"potentilla",
		667215
	],
	[
		"s3091642",
		"Potentilla delavayi",
		"potentilla",
		3091642
	],
	[
		"s1533304",
		"Potentilla delphinensis",
		"potentilla",
		1533304
	],
	[
		"s3817359",
		"Potentilla demotica",
		"potentilla",
		3817359
	],
	[
		"s3817360",
		"Potentilla dentata",
		"potentilla",
		3817360
	],
	[
		"s1819522",
		"Potentilla deorum",
		"potentilla",
		1819522
	],
	[
		"s667246",
		"Potentilla desertorum",
		"potentilla",
		667246
	],
	[
		"s3091643",
		"Potentilla detommasii",
		"potentilla",
		3091643
	],
	[
		"s3817361",
		"Potentilla discipulorum",
		"potentilla",
		3817361
	],
	[
		"s648872",
		"Potentilla discolor",
		"potentilla",
		648872
	],
	[
		"s3817362",
		"Potentilla divaricata",
		"potentilla",
		3817362
	],
	[
		"s3817363",
		"Potentilla diversidentata",
		"potentilla",
		3817363
	],
	[
		"s457910",
		"Potentilla diversifolia",
		"potentilla",
		457910
	],
	[
		"s1541696",
		"Potentilla divina",
		"potentilla",
		1541696
	],
	[
		"s3817364",
		"Potentilla doddsii",
		"potentilla",
		3817364
	],
	[
		"s3817365",
		"Potentilla doerfleri",
		"potentilla",
		3817365
	],
	[
		"s907221",
		"Potentilla dombeyi",
		"potentilla",
		907221
	],
	[
		"s3141228",
		"Potentilla doubjonneana",
		"potentilla",
		3141228
	],
	[
		"s57923",
		"Potentilla douglasii",
		"potentilla",
		57923
	],
	[
		"s654614",
		"Potentilla drummondii",
		"potentilla",
		654614
	],
	[
		"s2844921",
		"Potentilla dryadanthoides",
		"potentilla",
		2844921
	],
	[
		"s3817366",
		"Potentilla durangensis",
		"potentilla",
		3817366
	],
	[
		"s667247",
		"Potentilla effusa",
		"potentilla",
		667247
	],
	[
		"s669785",
		"Potentilla egedei",
		"potentilla",
		669785
	],
	[
		"s3817367",
		"Potentilla ehrenbergiana",
		"potentilla",
		3817367
	],
	[
		"s3817368",
		"Potentilla ekaterinae",
		"potentilla",
		3817368
	],
	[
		"s667248",
		"Potentilla elatior",
		"potentilla",
		667248
	],
	[
		"s654615",
		"Potentilla elegans",
		"potentilla",
		654615
	],
	[
		"s3817369",
		"Potentilla elegantissima",
		"potentilla",
		3817369
	],
	[
		"s1819525",
		"Potentilla elvendensis",
		"potentilla",
		1819525
	],
	[
		"s2071513",
		"Potentilla emarginata",
		"potentilla",
		2071513
	],
	[
		"s3817370",
		"Potentilla emilii-popii",
		"potentilla",
		3817370
	],
	[
		"s57940",
		"Potentilla erecta",
		"potentilla",
		57940
	],
	[
		"s667249",
		"Potentilla eriocarpa",
		"potentilla",
		667249
	],
	[
		"s2692206",
		"Potentilla eversmanniana",
		"potentilla",
		2692206
	],
	[
		"s1819526",
		"Potentilla evestita",
		"potentilla",
		1819526
	],
	[
		"s3817371",
		"Potentilla exigua",
		"potentilla",
		3817371
	],
	[
		"s3817372",
		"Potentilla exsul",
		"potentilla",
		3817372
	],
	[
		"s3817373",
		"Potentilla exuta",
		"potentilla",
		3817373
	],
	[
		"s1819527",
		"Potentilla fedtschenkoana",
		"potentilla",
		1819527
	],
	[
		"s3817374",
		"Potentilla ferganensis",
		"potentilla",
		3817374
	],
	[
		"s2071514",
		"Potentilla finitima",
		"potentilla",
		2071514
	],
	[
		"s1819529",
		"Potentilla flabellata",
		"potentilla",
		1819529
	],
	[
		"s654635",
		"Potentilla flabellifolia",
		"potentilla",
		654635
	],
	[
		"s3817375",
		"Potentilla flaccida",
		"potentilla",
		3817375
	],
	[
		"s1778369",
		"Potentilla flagellaris",
		"potentilla",
		1778369
	],
	[
		"s57939",
		"Potentilla fragarioides",
		"potentilla",
		57939
	],
	[
		"s654632",
		"Potentilla fragiformis",
		"potentilla",
		654632
	],
	[
		"s667250",
		"Potentilla freyniana",
		"potentilla",
		667250
	],
	[
		"s2998788",
		"Potentilla friesenii",
		"potentilla",
		2998788
	],
	[
		"s667251",
		"Potentilla frigida",
		"potentilla",
		667251
	],
	[
		"s2071515",
		"Potentilla furcata",
		"potentilla",
		2071515
	],
	[
		"s2866273",
		"Potentilla gageodoensis",
		"potentilla",
		2866273
	],
	[
		"s3817376",
		"Potentilla gaubaeana",
		"potentilla",
		3817376
	],
	[
		"s667252",
		"Potentilla gelida",
		"potentilla",
		667252
	],
	[
		"s1819530",
		"Potentilla geranioides",
		"potentilla",
		1819530
	],
	[
		"s3091644",
		"Potentilla glaucescens",
		"potentilla",
		3091644
	],
	[
		"s3127342",
		"Potentilla glaucophylla",
		"potentilla",
		3127342
	],
	[
		"s3464992",
		"Potentilla gobica",
		"potentilla",
		3464992
	],
	[
		"s3817377",
		"Potentilla goldmanii",
		"potentilla",
		3817377
	],
	[
		"s57925",
		"Potentilla gordonii",
		"potentilla",
		57925
	],
	[
		"s654627",
		"Potentilla gorodkovii",
		"potentilla",
		654627
	],
	[
		"s457912",
		"Potentilla gracilis",
		"potentilla",
		457912
	],
	[
		"s655808",
		"Potentilla grammopetala",
		"potentilla",
		655808
	],
	[
		"s654638",
		"Potentilla grandiflora",
		"potentilla",
		654638
	],
	[
		"s3091645",
		"Potentilla granulosa",
		"potentilla",
		3091645
	],
	[
		"s3817378",
		"Potentilla grayi",
		"potentilla",
		3817378
	],
	[
		"s3817379",
		"Potentilla greuteriana",
		"potentilla",
		3817379
	],
	[
		"s667254",
		"Potentilla griffithii",
		"potentilla",
		667254
	],
	[
		"s3091646",
		"Potentilla grisea",
		"potentilla",
		3091646
	],
	[
		"s3817380",
		"Potentilla guilliermondii",
		"potentilla",
		3817380
	],
	[
		"s3817381",
		"Potentilla haematochrus",
		"potentilla",
		3817381
	],
	[
		"s1851388",
		"Potentilla haynaldiana",
		"potentilla",
		1851388
	],
	[
		"s176126",
		"Potentilla hebiichigo",
		"potentilla",
		176126
	],
	[
		"s667216",
		"Potentilla hendersonii",
		"potentilla",
		667216
	],
	[
		"s667255",
		"Potentilla heptaphylla",
		"potentilla",
		667255
	],
	[
		"s3817382",
		"Potentilla heterosepala",
		"potentilla",
		3817382
	],
	[
		"s3817383",
		"Potentilla heynei",
		"potentilla",
		3817383
	],
	[
		"s3817384",
		"Potentilla hickmanii",
		"potentilla",
		3817384
	],
	[
		"s3817492",
		"Potentilla hilbigii",
		"potentilla",
		3817492
	],
	[
		"s457913",
		"Potentilla hippiana",
		"potentilla",
		457913
	],
	[
		"s667256",
		"Potentilla hirta",
		"potentilla",
		667256
	],
	[
		"s1819532",
		"Potentilla hispanica",
		"potentilla",
		1819532
	],
	[
		"s1042655",
		"Potentilla hispidula",
		"potentilla",
		1042655
	],
	[
		"s3817385",
		"Potentilla holmgrenii",
		"potentilla",
		3817385
	],
	[
		"s1819533",
		"Potentilla hololeuca",
		"potentilla",
		1819533
	],
	[
		"s667257",
		"Potentilla hookeriana",
		"potentilla",
		667257
	],
	[
		"s3817386",
		"Potentilla horrida",
		"potentilla",
		3817386
	],
	[
		"s667217",
		"Potentilla howellii",
		"potentilla",
		667217
	],
	[
		"s3817387",
		"Potentilla hubsugulica",
		"potentilla",
		3817387
	],
	[
		"s3817388",
		"Potentilla hudsonii",
		"potentilla",
		3817388
	],
	[
		"s1819534",
		"Potentilla humifusa",
		"potentilla",
		1819534
	],
	[
		"s3817389",
		"Potentilla humillis",
		"potentilla",
		3817389
	],
	[
		"s395303",
		"Potentilla hyparctica",
		"potentilla",
		395303
	],
	[
		"s3091647",
		"Potentilla hypargyrea",
		"potentilla",
		3091647
	],
	[
		"s2992797",
		"Potentilla ikonnikovii",
		"potentilla",
		2992797
	],
	[
		"s3817390",
		"Potentilla imerethica",
		"potentilla",
		3817390
	],
	[
		"s667258",
		"Potentilla incana",
		"potentilla",
		667258
	],
	[
		"s516013",
		"Potentilla inclinata",
		"potentilla",
		516013
	],
	[
		"s13044",
		"Potentilla indica",
		"potentilla",
		13044
	],
	[
		"s3464993",
		"Potentilla inopinata",
		"potentilla",
		3464993
	],
	[
		"s1533305",
		"Potentilla intermedia",
		"potentilla",
		1533305
	],
	[
		"s1433397",
		"Potentilla iranica",
		"potentilla",
		1433397
	],
	[
		"s3817391",
		"Potentilla isaurica",
		"potentilla",
		3817391
	],
	[
		"s1042663",
		"Potentilla jaegeri",
		"potentilla",
		1042663
	],
	[
		"s667259",
		"Potentilla jenissejensis",
		"potentilla",
		667259
	],
	[
		"s667260",
		"Potentilla jepsonii",
		"potentilla",
		667260
	],
	[
		"s3817392",
		"Potentilla jiaozishanensis",
		"potentilla",
		3817392
	],
	[
		"s3091648",
		"Potentilla johanniniana",
		"potentilla",
		3091648
	],
	[
		"s3817393",
		"Potentilla johnstonii",
		"potentilla",
		3817393
	],
	[
		"s2998805",
		"Potentilla junatovii",
		"potentilla",
		2998805
	],
	[
		"s3817394",
		"Potentilla kamelinii",
		"potentilla",
		3817394
	],
	[
		"s3817395",
		"Potentilla karakoramica",
		"potentilla",
		3817395
	],
	[
		"s3817396",
		"Potentilla karatavica",
		"potentilla",
		3817396
	],
	[
		"s3817397",
		"Potentilla kashmirica",
		"potentilla",
		3817397
	],
	[
		"s2998806",
		"Potentilla khanminczunii",
		"potentilla",
		2998806
	],
	[
		"s654625",
		"Potentilla kingii",
		"potentilla",
		654625
	],
	[
		"s3817398",
		"Potentilla kionaea",
		"potentilla",
		3817398
	],
	[
		"s1082504",
		"Potentilla kleiniana",
		"potentilla",
		1082504
	],
	[
		"s3817399",
		"Potentilla komaroviana",
		"potentilla",
		3817399
	],
	[
		"s1819535",
		"Potentilla kotschyana",
		"potentilla",
		1819535
	],
	[
		"s3091649",
		"Potentilla kryloviana",
		"potentilla",
		3091649
	],
	[
		"s3817400",
		"Potentilla kulabensis",
		"potentilla",
		3817400
	],
	[
		"s654637",
		"Potentilla kurdica",
		"potentilla",
		654637
	],
	[
		"s3817401",
		"Potentilla kuznetzowii",
		"potentilla",
		3817401
	],
	[
		"s683804",
		"Potentilla laciniosa",
		"potentilla",
		683804
	],
	[
		"s3464994",
		"Potentilla laevipes",
		"potentilla",
		3464994
	],
	[
		"s3464995",
		"Potentilla laevissima",
		"potentilla",
		3464995
	],
	[
		"s1961204",
		"Potentilla lancinata",
		"potentilla",
		1961204
	],
	[
		"s2692207",
		"Potentilla lapponica",
		"potentilla",
		2692207
	],
	[
		"s2071516",
		"Potentilla lasiodonta",
		"potentilla",
		2071516
	],
	[
		"s3817402",
		"Potentilla lazica",
		"potentilla",
		3817402
	],
	[
		"s3817403",
		"Potentilla leonina",
		"potentilla",
		3817403
	],
	[
		"s3817404",
		"Potentilla leptopetala",
		"potentilla",
		3817404
	],
	[
		"s3817405",
		"Potentilla leschenaultiana",
		"potentilla",
		3817405
	],
	[
		"s667262",
		"Potentilla leucophylla",
		"potentilla",
		667262
	],
	[
		"s3091650",
		"Potentilla leucopolitana",
		"potentilla",
		3091650
	],
	[
		"s3817406",
		"Potentilla libanotica",
		"potentilla",
		3817406
	],
	[
		"s3817407",
		"Potentilla lignipes",
		"potentilla",
		3817407
	],
	[
		"s637899",
		"Potentilla lignosa",
		"potentilla",
		637899
	],
	[
		"s3091651",
		"Potentilla limprichtii",
		"potentilla",
		3091651
	],
	[
		"s3141225",
		"Potentilla lindackeri",
		"potentilla",
		3141225
	],
	[
		"s144560",
		"Potentilla lindleyi",
		"potentilla",
		144560
	],
	[
		"s539895",
		"Potentilla lineata",
		"potentilla",
		539895
	],
	[
		"s3817408",
		"Potentilla lipskyana",
		"potentilla",
		3817408
	],
	[
		"s667263",
		"Potentilla litoralis",
		"potentilla",
		667263
	],
	[
		"s3817409",
		"Potentilla lomakinii",
		"potentilla",
		3817409
	],
	[
		"s1042665",
		"Potentilla longibracteata",
		"potentilla",
		1042665
	],
	[
		"s667264",
		"Potentilla longifolia",
		"potentilla",
		667264
	],
	[
		"s3091652",
		"Potentilla longipes",
		"potentilla",
		3091652
	],
	[
		"s3817410",
		"Potentilla luteosericea",
		"potentilla",
		3817410
	],
	[
		"s457902",
		"Potentilla lycopodioides",
		"potentilla",
		457902
	],
	[
		"s2005308",
		"Potentilla lyngei",
		"potentilla",
		2005308
	],
	[
		"s3817411",
		"Potentilla macdonaldii",
		"potentilla",
		3817411
	],
	[
		"s2071517",
		"Potentilla macounii",
		"potentilla",
		2071517
	],
	[
		"s1819536",
		"Potentilla macrosepala",
		"potentilla",
		1819536
	],
	[
		"s3817412",
		"Potentilla makaluensis",
		"potentilla",
		3817412
	],
	[
		"s3817413",
		"Potentilla mallota",
		"potentilla",
		3817413
	],
	[
		"s3091394",
		"Potentilla mandshurica",
		"potentilla",
		3091394
	],
	[
		"s667218",
		"Potentilla marinensis",
		"potentilla",
		667218
	],
	[
		"s3817414",
		"Potentilla martjanowii",
		"potentilla",
		3817414
	],
	[
		"s3817415",
		"Potentilla maryae",
		"potentilla",
		3817415
	],
	[
		"s335958",
		"Potentilla matsumurae",
		"potentilla",
		335958
	],
	[
		"s667265",
		"Potentilla maura",
		"potentilla",
		667265
	],
	[
		"s538581",
		"Potentilla megalantha",
		"potentilla",
		538581
	],
	[
		"s3817416",
		"Potentilla mexiae",
		"potentilla",
		3817416
	],
	[
		"s1819537",
		"Potentilla meyeri",
		"potentilla",
		1819537
	],
	[
		"s3817417",
		"Potentilla micheneri",
		"potentilla",
		3817417
	],
	[
		"s57941",
		"Potentilla micrantha",
		"potentilla",
		57941
	],
	[
		"s3817418",
		"Potentilla microdons",
		"potentilla",
		3817418
	],
	[
		"s667228",
		"Potentilla micropetala",
		"potentilla",
		667228
	],
	[
		"s654634",
		"Potentilla microphylla",
		"potentilla",
		654634
	],
	[
		"s667266",
		"Potentilla millefolia",
		"potentilla",
		667266
	],
	[
		"s637900",
		"Potentilla miyabei",
		"potentilla",
		637900
	],
	[
		"s667267",
		"Potentilla modesta",
		"potentilla",
		667267
	],
	[
		"s3817419",
		"Potentilla mollissima",
		"potentilla",
		3817419
	],
	[
		"s2992798",
		"Potentilla mongolica",
		"potentilla",
		2992798
	],
	[
		"s3091653",
		"Potentilla montana",
		"potentilla",
		3091653
	],
	[
		"s654616",
		"Potentilla montenegrina",
		"potentilla",
		654616
	],
	[
		"s667268",
		"Potentilla morefieldii",
		"potentilla",
		667268
	],
	[
		"s3817420",
		"Potentilla morrisonensis",
		"potentilla",
		3817420
	],
	[
		"s3121474",
		"Potentilla muirii",
		"potentilla",
		3121474
	],
	[
		"s3817421",
		"Potentilla mujensis",
		"potentilla",
		3817421
	],
	[
		"s667269",
		"Potentilla multicaulis",
		"potentilla",
		667269
	],
	[
		"s3091654",
		"Potentilla multiceps",
		"potentilla",
		3091654
	],
	[
		"s210859",
		"Potentilla multifida",
		"potentilla",
		210859
	],
	[
		"s2713430",
		"Potentilla multifoliolata",
		"potentilla",
		2713430
	],
	[
		"s3091395",
		"Potentilla multisecta",
		"potentilla",
		3091395
	],
	[
		"s2071518",
		"Potentilla nana",
		"potentilla",
		2071518
	],
	[
		"s3817422",
		"Potentilla nanopetala",
		"potentilla",
		3817422
	],
	[
		"s1533306",
		"Potentilla neglecta",
		"potentilla",
		1533306
	],
	[
		"s538582",
		"Potentilla nepalensis",
		"potentilla",
		538582
	],
	[
		"s1819538",
		"Potentilla nervosa",
		"potentilla",
		1819538
	],
	[
		"s654621",
		"Potentilla neumaniana",
		"potentilla",
		654621
	],
	[
		"s667270",
		"Potentilla nevadensis",
		"potentilla",
		667270
	],
	[
		"s667271",
		"Potentilla newberryi",
		"potentilla",
		667271
	],
	[
		"s3817423",
		"Potentilla nicicii",
		"potentilla",
		3817423
	],
	[
		"s667272",
		"Potentilla niponica",
		"potentilla",
		667272
	],
	[
		"s654624",
		"Potentilla nitida",
		"potentilla",
		654624
	],
	[
		"s1533307",
		"Potentilla nivalis",
		"potentilla",
		1533307
	],
	[
		"s57942",
		"Potentilla nivea",
		"potentilla",
		57942
	],
	[
		"s3817424",
		"Potentilla nordmanniana",
		"potentilla",
		3817424
	],
	[
		"s3817425",
		"Potentilla norrelmukana",
		"potentilla",
		3817425
	],
	[
		"s57931",
		"Potentilla norvegica",
		"potentilla",
		57931
	],
	[
		"s1008380",
		"Potentilla nubigena",
		"potentilla",
		1008380
	],
	[
		"s3817426",
		"Potentilla nuda",
		"potentilla",
		3817426
	],
	[
		"s3817427",
		"Potentilla nurensis",
		"potentilla",
		3817427
	],
	[
		"s3817428",
		"Potentilla oaxacana",
		"potentilla",
		3817428
	],
	[
		"s3091655",
		"Potentilla oblanceolata",
		"potentilla",
		3091655
	],
	[
		"s3809259",
		"Potentilla omeiensis",
		"potentilla",
		3809259
	],
	[
		"s3817429",
		"Potentilla osterhoutii",
		"potentilla",
		3817429
	],
	[
		"s667274",
		"Potentilla ovina",
		"potentilla",
		667274
	],
	[
		"s1819539",
		"Potentilla oweriniana",
		"potentilla",
		1819539
	],
	[
		"s3817430",
		"Potentilla ozjorensis",
		"potentilla",
		3817430
	],
	[
		"s2212996",
		"Potentilla pamirica",
		"potentilla",
		2212996
	],
	[
		"s1819540",
		"Potentilla pamiroalaica",
		"potentilla",
		1819540
	],
	[
		"s667223",
		"Potentilla paniculata",
		"potentilla",
		667223
	],
	[
		"s3817431",
		"Potentilla panigrahiana",
		"potentilla",
		3817431
	],
	[
		"s1433392",
		"Potentilla pannosa",
		"potentilla",
		1433392
	],
	[
		"s1819507",
		"Potentilla parryi",
		"potentilla",
		1819507
	],
	[
		"s1045296",
		"Potentilla parvifolia",
		"potentilla",
		1045296
	],
	[
		"s3121475",
		"Potentilla patellifera",
		"potentilla",
		3121475
	],
	[
		"s1819541",
		"Potentilla patula",
		"potentilla",
		1819541
	],
	[
		"s3817432",
		"Potentilla paucidentata",
		"potentilla",
		3817432
	],
	[
		"s3817433",
		"Potentilla paucidenticula",
		"potentilla",
		3817433
	],
	[
		"s3817434",
		"Potentilla paucijuga",
		"potentilla",
		3817434
	],
	[
		"s1819542",
		"Potentilla pectinisecta",
		"potentilla",
		1819542
	],
	[
		"s667275",
		"Potentilla pedata",
		"potentilla",
		667275
	],
	[
		"s654641",
		"Potentilla pedersenii",
		"potentilla",
		654641
	],
	[
		"s3141231",
		"Potentilla pendula",
		"potentilla",
		3141231
	],
	[
		"s3817435",
		"Potentilla penniphylla",
		"potentilla",
		3817435
	],
	[
		"s457914",
		"Potentilla pensylvanica",
		"potentilla",
		457914
	],
	[
		"s1433393",
		"Potentilla persica",
		"potentilla",
		1433393
	],
	[
		"s1433394",
		"Potentilla petraea",
		"potentilla",
		1433394
	],
	[
		"s654630",
		"Potentilla pimpinelloides",
		"potentilla",
		654630
	],
	[
		"s2675279",
		"Potentilla pindicola",
		"potentilla",
		2675279
	],
	[
		"s1819508",
		"Potentilla pityocharis",
		"potentilla",
		1819508
	],
	[
		"s667276",
		"Potentilla plattensis",
		"potentilla",
		667276
	],
	[
		"s3121465",
		"Potentilla plumosa",
		"potentilla",
		3121465
	],
	[
		"s3817436",
		"Potentilla porphyrantha",
		"potentilla",
		3817436
	],
	[
		"s1562891",
		"Potentilla potaninii",
		"potentilla",
		1562891
	],
	[
		"s1851389",
		"Potentilla praecox",
		"potentilla",
		1851389
	],
	[
		"s3091656",
		"Potentilla pseudosericea",
		"potentilla",
		3091656
	],
	[
		"s3141235",
		"Potentilla pseudosimulatrix",
		"potentilla",
		3141235
	],
	[
		"s3817437",
		"Potentilla pteropoda",
		"potentilla",
		3817437
	],
	[
		"s2509693",
		"Potentilla puberula",
		"potentilla",
		2509693
	],
	[
		"s395304",
		"Potentilla pulchella",
		"potentilla",
		395304
	],
	[
		"s667277",
		"Potentilla pulcherrima",
		"potentilla",
		667277
	],
	[
		"s654636",
		"Potentilla pulvinaris",
		"potentilla",
		654636
	],
	[
		"s3817438",
		"Potentilla pulviniformis",
		"potentilla",
		3817438
	],
	[
		"s1961205",
		"Potentilla purpurascens",
		"potentilla",
		1961205
	],
	[
		"s1541697",
		"Potentilla purpurea",
		"potentilla",
		1541697
	],
	[
		"s667278",
		"Potentilla pusilla",
		"potentilla",
		667278
	],
	[
		"s1016824",
		"Potentilla pusilla x Potentilla thuringiaca",
		"potentilla",
		1016824
	],
	[
		"s667279",
		"Potentilla pyrenaica",
		"potentilla",
		667279
	],
	[
		"s3817439",
		"Potentilla queretarensis",
		"potentilla",
		3817439
	],
	[
		"s1042672",
		"Potentilla quinquefolia",
		"potentilla",
		1042672
	],
	[
		"s1433395",
		"Potentilla radiata",
		"potentilla",
		1433395
	],
	[
		"s1819543",
		"Potentilla ranunculoides",
		"potentilla",
		1819543
	],
	[
		"s2820170",
		"Potentilla ranunculus",
		"potentilla",
		2820170
	],
	[
		"s538583",
		"Potentilla recta",
		"potentilla",
		538583
	],
	[
		"s3817440",
		"Potentilla regeliana",
		"potentilla",
		3817440
	],
	[
		"s57933",
		"Potentilla reptans",
		"potentilla",
		57933
	],
	[
		"s2834238",
		"Potentilla reverchonii",
		"potentilla",
		2834238
	],
	[
		"s2597779",
		"Potentilla rhenana",
		"potentilla",
		2597779
	],
	[
		"s667280",
		"Potentilla rhyolitica",
		"potentilla",
		667280
	],
	[
		"s1008377",
		"Potentilla rhypara",
		"potentilla",
		1008377
	],
	[
		"s3817441",
		"Potentilla richardii",
		"potentilla",
		3817441
	],
	[
		"s3817442",
		"Potentilla rigidula",
		"potentilla",
		3817442
	],
	[
		"s3817443",
		"Potentilla rigoana",
		"potentilla",
		3817443
	],
	[
		"s3091396",
		"Potentilla rimicola",
		"potentilla",
		3091396
	],
	[
		"s1819544",
		"Potentilla riparia",
		"potentilla",
		1819544
	],
	[
		"s667281",
		"Potentilla rivalis",
		"potentilla",
		667281
	],
	[
		"s1472698",
		"Potentilla rosulifera",
		"potentilla",
		1472698
	],
	[
		"s669786",
		"Potentilla rubella",
		"potentilla",
		669786
	],
	[
		"s1819545",
		"Potentilla rubra",
		"potentilla",
		1819545
	],
	[
		"s654647",
		"Potentilla rubricaulis",
		"potentilla",
		654647
	],
	[
		"s2998807",
		"Potentilla rudolfii",
		"potentilla",
		2998807
	],
	[
		"s3817444",
		"Potentilla rupifraga",
		"potentilla",
		3817444
	],
	[
		"s3817445",
		"Potentilla rupincola",
		"potentilla",
		3817445
	],
	[
		"s1819546",
		"Potentilla ruprechtii",
		"potentilla",
		1819546
	],
	[
		"s1042656",
		"Potentilla rydbergii",
		"potentilla",
		1042656
	],
	[
		"s3817446",
		"Potentilla saalae",
		"potentilla",
		3817446
	],
	[
		"s1008379",
		"Potentilla sabulosa",
		"potentilla",
		1008379
	],
	[
		"s3817447",
		"Potentilla sajanensis",
		"potentilla",
		3817447
	],
	[
		"s3817448",
		"Potentilla salsa",
		"potentilla",
		3817448
	],
	[
		"s3817449",
		"Potentilla sangedehensis",
		"potentilla",
		3817449
	],
	[
		"s3091657",
		"Potentilla sanguisorba",
		"potentilla",
		3091657
	],
	[
		"s667224",
		"Potentilla santolinoides",
		"potentilla",
		667224
	],
	[
		"s3817450",
		"Potentilla saposhnikovii",
		"potentilla",
		3817450
	],
	[
		"s667282",
		"Potentilla saundersiana",
		"potentilla",
		667282
	],
	[
		"s3817451",
		"Potentilla savvalensis",
		"potentilla",
		3817451
	],
	[
		"s1042674",
		"Potentilla saxifraga",
		"potentilla",
		1042674
	],
	[
		"s3817452",
		"Potentilla saximontana",
		"potentilla",
		3817452
	],
	[
		"s457903",
		"Potentilla saxosa",
		"potentilla",
		457903
	],
	[
		"s3464996",
		"Potentilla schmakovii",
		"potentilla",
		3464996
	],
	[
		"s3817453",
		"Potentilla schrenkiana",
		"potentilla",
		3817453
	],
	[
		"s3817454",
		"Potentilla schultzii",
		"potentilla",
		3817454
	],
	[
		"s3817455",
		"Potentilla scotica",
		"potentilla",
		3817455
	],
	[
		"s3817456",
		"Potentilla sergievskajae",
		"potentilla",
		3817456
	],
	[
		"s3089657",
		"Potentilla sericata",
		"potentilla",
		3089657
	],
	[
		"s1819547",
		"Potentilla sericea",
		"potentilla",
		1819547
	],
	[
		"s1042667",
		"Potentilla sericoleuca",
		"potentilla",
		1042667
	],
	[
		"s3817457",
		"Potentilla serrata",
		"potentilla",
		3817457
	],
	[
		"s1042668",
		"Potentilla setosa",
		"potentilla",
		1042668
	],
	[
		"s1008378",
		"Potentilla shockleyi",
		"potentilla",
		1008378
	],
	[
		"s3817458",
		"Potentilla sierrae-blancae",
		"potentilla",
		3817458
	],
	[
		"s1541698",
		"Potentilla sikkimensis",
		"potentilla",
		1541698
	],
	[
		"s667283",
		"Potentilla simplex",
		"potentilla",
		667283
	],
	[
		"s714647",
		"Potentilla simulatrix",
		"potentilla",
		714647
	],
	[
		"s3121463",
		"Potentilla sinonivea",
		"potentilla",
		3121463
	],
	[
		"s1732551",
		"Potentilla sischanensis",
		"potentilla",
		1732551
	],
	[
		"s3817459",
		"Potentilla smirnovii",
		"potentilla",
		3817459
	],
	[
		"s3817460",
		"Potentilla sommerfeltii",
		"potentilla",
		3817460
	],
	[
		"s2764663",
		"Potentilla soongorica",
		"potentilla",
		2764663
	],
	[
		"s1042675",
		"Potentilla speciosa",
		"potentilla",
		1042675
	],
	[
		"s3817461",
		"Potentilla sphenophylla",
		"potentilla",
		3817461
	],
	[
		"s3817462",
		"Potentilla spodiochlora",
		"potentilla",
		3817462
	],
	[
		"s1472691",
		"Potentilla squamosa",
		"potentilla",
		1472691
	],
	[
		"s3091659",
		"Potentilla staminea",
		"potentilla",
		3091659
	],
	[
		"s3817463",
		"Potentilla stanjukoviczii",
		"potentilla",
		3817463
	],
	[
		"s1042657",
		"Potentilla stenoloba",
		"potentilla",
		1042657
	],
	[
		"s3817464",
		"Potentilla stepposa",
		"potentilla",
		3817464
	],
	[
		"s644184",
		"Potentilla sterilis",
		"potentilla",
		644184
	],
	[
		"s3817465",
		"Potentilla stewartiana",
		"potentilla",
		3817465
	],
	[
		"s667284",
		"Potentilla stipularis",
		"potentilla",
		667284
	],
	[
		"s654617",
		"Potentilla stolonifera",
		"potentilla",
		654617
	],
	[
		"s3091397",
		"Potentilla straussii",
		"potentilla",
		3091397
	],
	[
		"s1778372",
		"Potentilla strigosa",
		"potentilla",
		1778372
	],
	[
		"s1732552",
		"Potentilla suavis",
		"potentilla",
		1732552
	],
	[
		"s3141227",
		"Potentilla subarenaria",
		"potentilla",
		3141227
	],
	[
		"s1301413",
		"Potentilla subgorodkovii",
		"potentilla",
		1301413
	],
	[
		"s667285",
		"Potentilla subjuga",
		"potentilla",
		667285
	],
	[
		"s3817466",
		"Potentilla sublaevis",
		"potentilla",
		3817466
	],
	[
		"s3817467",
		"Potentilla subpalmata",
		"potentilla",
		3817467
	],
	[
		"s654618",
		"Potentilla subvahliana",
		"potentilla",
		654618
	],
	[
		"s667286",
		"Potentilla subviscosa",
		"potentilla",
		667286
	],
	[
		"s3817468",
		"Potentilla sunhangii",
		"potentilla",
		3817468
	],
	[
		"s667287",
		"Potentilla supina",
		"potentilla",
		667287
	],
	[
		"s1433398",
		"Potentilla szovitsii",
		"potentilla",
		1433398
	],
	[
		"s654619",
		"Potentilla tabernaemontani",
		"potentilla",
		654619
	],
	[
		"s654620",
		"Potentilla tanacetifolia",
		"potentilla",
		654620
	],
	[
		"s3817469",
		"Potentilla taronensis",
		"potentilla",
		3817469
	],
	[
		"s3091660",
		"Potentilla taurica",
		"potentilla",
		3091660
	],
	[
		"s1732553",
		"Potentilla tenuis",
		"potentilla",
		1732553
	],
	[
		"s3817470",
		"Potentilla tephroleuca",
		"potentilla",
		3817470
	],
	[
		"s3817471",
		"Potentilla tephroserica",
		"potentilla",
		3817471
	],
	[
		"s2692208",
		"Potentilla tergemina",
		"potentilla",
		2692208
	],
	[
		"s3817472",
		"Potentilla tericholica",
		"potentilla",
		3817472
	],
	[
		"s667297",
		"Potentilla tetrandra",
		"potentilla",
		667297
	],
	[
		"s457915",
		"Potentilla thurberi",
		"potentilla",
		457915
	],
	[
		"s654642",
		"Potentilla thuringiaca",
		"potentilla",
		654642
	],
	[
		"s3141229",
		"Potentilla thyrsiflora",
		"potentilla",
		3141229
	],
	[
		"s3817473",
		"Potentilla tianschanica",
		"potentilla",
		3817473
	],
	[
		"s1961206",
		"Potentilla tilingii",
		"potentilla",
		1961206
	],
	[
		"s654643",
		"Potentilla tollii",
		"potentilla",
		654643
	],
	[
		"s2483602",
		"Potentilla tommasiniana",
		"potentilla",
		2483602
	],
	[
		"s3817474",
		"Potentilla tornezyana",
		"potentilla",
		3817474
	],
	[
		"s667288",
		"Potentilla townsendii",
		"potentilla",
		667288
	],
	[
		"s3091661",
		"Potentilla transcaspia",
		"potentilla",
		3091661
	],
	[
		"s3817475",
		"Potentilla transitoria",
		"potentilla",
		3817475
	],
	[
		"s3817476",
		"Potentilla tridentula",
		"potentilla",
		3817476
	],
	[
		"s1042658",
		"Potentilla truncata",
		"potentilla",
		1042658
	],
	[
		"s3817477",
		"Potentilla tschimganica",
		"potentilla",
		3817477
	],
	[
		"s3817478",
		"Potentilla tuberculifera",
		"potentilla",
		3817478
	],
	[
		"s500580",
		"Potentilla tucumanensis",
		"potentilla",
		500580
	],
	[
		"s3141223",
		"Potentilla tularensis",
		"potentilla",
		3141223
	],
	[
		"s3091662",
		"Potentilla turczaninowiana",
		"potentilla",
		3091662
	],
	[
		"s1571453",
		"Potentilla turfosa",
		"potentilla",
		1571453
	],
	[
		"s3817479",
		"Potentilla turfosoides",
		"potentilla",
		3817479
	],
	[
		"s3817480",
		"Potentilla turgaica",
		"potentilla",
		3817480
	],
	[
		"s3095883",
		"Potentilla tuvinica",
		"potentilla",
		3095883
	],
	[
		"s1042669",
		"Potentilla tweedyi",
		"potentilla",
		1042669
	],
	[
		"s3817481",
		"Potentilla tytthantha",
		"potentilla",
		3817481
	],
	[
		"s3817482",
		"Potentilla uliginosa",
		"potentilla",
		3817482
	],
	[
		"s667289",
		"Potentilla umbrosa",
		"potentilla",
		667289
	],
	[
		"s1008376",
		"Potentilla unguiculata",
		"potentilla",
		1008376
	],
	[
		"s395305",
		"Potentilla uniflora",
		"potentilla",
		395305
	],
	[
		"s2071519",
		"Potentilla uschakovii",
		"potentilla",
		2071519
	],
	[
		"s667225",
		"Potentilla utahensis",
		"potentilla",
		667225
	],
	[
		"s667290",
		"Potentilla vahliana",
		"potentilla",
		667290
	],
	[
		"s1042677",
		"Potentilla valderia",
		"potentilla",
		1042677
	],
	[
		"s3817483",
		"Potentilla varzobica",
		"potentilla",
		3817483
	],
	[
		"s667291",
		"Potentilla velutina",
		"potentilla",
		667291
	],
	[
		"s1016828",
		"Potentilla verna",
		"potentilla",
		1016828
	],
	[
		"s667292",
		"Potentilla versicolor",
		"potentilla",
		667292
	],
	[
		"s1778373",
		"Potentilla verticillaris",
		"potentilla",
		1778373
	],
	[
		"s395306",
		"Potentilla villosa",
		"potentilla",
		395306
	],
	[
		"s667293",
		"Potentilla villosula",
		"potentilla",
		667293
	],
	[
		"s667294",
		"Potentilla virgata",
		"potentilla",
		667294
	],
	[
		"s3091663",
		"Potentilla visianii",
		"potentilla",
		3091663
	],
	[
		"s2692209",
		"Potentilla volgarica",
		"potentilla",
		2692209
	],
	[
		"s3817484",
		"Potentilla vorobievii",
		"potentilla",
		3817484
	],
	[
		"s667295",
		"Potentilla vulcanicola",
		"potentilla",
		667295
	],
	[
		"s3817485",
		"Potentilla vvedenskyi",
		"potentilla",
		3817485
	],
	[
		"s667226",
		"Potentilla webberi",
		"potentilla",
		667226
	],
	[
		"s3817486",
		"Potentilla weddellii",
		"potentilla",
		3817486
	],
	[
		"s667296",
		"Potentilla wheeleri",
		"potentilla",
		667296
	],
	[
		"s1042659",
		"Potentilla wilderae",
		"potentilla",
		1042659
	],
	[
		"s3817487",
		"Potentilla wismariensis",
		"potentilla",
		3817487
	],
	[
		"s3817488",
		"Potentilla wrangelii",
		"potentilla",
		3817488
	],
	[
		"s2998839",
		"Potentilla x chemalensis",
		"potentilla",
		2998839
	],
	[
		"s2998784",
		"Potentilla x habievii",
		"potentilla",
		2998784
	],
	[
		"s2998785",
		"Potentilla x jakovlevii",
		"potentilla",
		2998785
	],
	[
		"s3817491",
		"Potentilla x prostrata",
		"potentilla",
		3817491
	],
	[
		"s3121419",
		"Potentilla x subdigitata",
		"potentilla",
		3121419
	],
	[
		"s2597767",
		"Potentilla x suberecta",
		"potentilla",
		2597767
	],
	[
		"s3141232",
		"Potentilla xizangensis",
		"potentilla",
		3141232
	],
	[
		"s1042660",
		"Potentilla yadonii",
		"potentilla",
		1042660
	],
	[
		"s1486296",
		"Potentilla yokusaiana",
		"potentilla",
		1486296
	],
	[
		"s3817489",
		"Potentilla zhangbeiensis",
		"potentilla",
		3817489
	],
	[
		"s176128",
		"Poteridium annuum",
		"poteridium",
		176128
	],
	[
		"s2071520",
		"Poteridium occidentale",
		"poteridium",
		2071520
	],
	[
		"s241910",
		"Poulsenia armata",
		"poulsenia",
		241910
	],
	[
		"s3091664",
		"Pourouma acuminata",
		"pourouma",
		3091664
	],
	[
		"s2483613",
		"Pourouma amacayacuensis",
		"pourouma",
		2483613
	],
	[
		"s3869974",
		"Pourouma bergii",
		"pourouma",
		3869974
	],
	[
		"s597388",
		"Pourouma bicolor",
		"pourouma",
		597388
	],
	[
		"s3869975",
		"Pourouma bolivarensis",
		"pourouma",
		3869975
	],
	[
		"s1958861",
		"Pourouma cecropiifolia",
		"pourouma",
		1958861
	],
	[
		"s3869976",
		"Pourouma cordata",
		"pourouma",
		3869976
	],
	[
		"s2483615",
		"Pourouma cucura",
		"pourouma",
		2483615
	],
	[
		"s3869977",
		"Pourouma cuspidata",
		"pourouma",
		3869977
	],
	[
		"s3869978",
		"Pourouma elliptica",
		"pourouma",
		3869978
	],
	[
		"s2483616",
		"Pourouma essequiboensis",
		"pourouma",
		2483616
	],
	[
		"s3091665",
		"Pourouma ferruginea",
		"pourouma",
		3091665
	],
	[
		"s3091666",
		"Pourouma floccosa",
		"pourouma",
		3091666
	],
	[
		"s3091667",
		"Pourouma formicarum",
		"pourouma",
		3091667
	],
	[
		"s2072282",
		"Pourouma guianensis",
		"pourouma",
		2072282
	],
	[
		"s2483617",
		"Pourouma herrerensis",
		"pourouma",
		2483617
	],
	[
		"s3869979",
		"Pourouma hirsutipetiolata",
		"pourouma",
		3869979
	],
	[
		"s2483618",
		"Pourouma maroniensis",
		"pourouma",
		2483618
	],
	[
		"s1186179",
		"Pourouma melinonii",
		"pourouma",
		1186179
	],
	[
		"s1129501",
		"Pourouma minor",
		"pourouma",
		1129501
	],
	[
		"s1937610",
		"Pourouma mollis",
		"pourouma",
		1937610
	],
	[
		"s3869980",
		"Pourouma montana",
		"pourouma",
		3869980
	],
	[
		"s1781623",
		"Pourouma myrmecophila",
		"pourouma",
		1781623
	],
	[
		"s3869981",
		"Pourouma napoensis",
		"pourouma",
		3869981
	],
	[
		"s3869982",
		"Pourouma oraria",
		"pourouma",
		3869982
	],
	[
		"s2483619",
		"Pourouma ovata",
		"pourouma",
		2483619
	],
	[
		"s3869983",
		"Pourouma petiolulata",
		"pourouma",
		3869983
	],
	[
		"s3091668",
		"Pourouma phaeotricha",
		"pourouma",
		3091668
	],
	[
		"s3091669",
		"Pourouma saulensis",
		"pourouma",
		3091669
	],
	[
		"s2483620",
		"Pourouma scobina",
		"pourouma",
		2483620
	],
	[
		"s3869984",
		"Pourouma stipulacea",
		"pourouma",
		3869984
	],
	[
		"s597389",
		"Pourouma tomentosa",
		"pourouma",
		597389
	],
	[
		"s2483621",
		"Pourouma triloba",
		"pourouma",
		2483621
	],
	[
		"s1937611",
		"Pourouma velutina",
		"pourouma",
		1937611
	],
	[
		"s688053",
		"Pourouma villosa",
		"pourouma",
		688053
	],
	[
		"s1826815",
		"Pourthiaea amphidoxa",
		"pourthiaea",
		1826815
	],
	[
		"s2109368",
		"Pourthiaea arguta",
		"pourthiaea",
		2109368
	],
	[
		"s661356",
		"Pourthiaea blinii",
		"pourthiaea",
		661356
	],
	[
		"s3869985",
		"Pourthiaea brevifolia",
		"pourthiaea",
		3869985
	],
	[
		"s3869986",
		"Pourthiaea dabeishanensis",
		"pourthiaea",
		3869986
	],
	[
		"s3102695",
		"Pourthiaea magnoliifolia",
		"pourthiaea",
		3102695
	],
	[
		"s2654667",
		"Pourthiaea pilosicalyx",
		"pourthiaea",
		2654667
	],
	[
		"s2865624",
		"Pourthiaea pustulata",
		"pourthiaea",
		2865624
	],
	[
		"s1961208",
		"Pourthiaea salicifolia",
		"pourthiaea",
		1961208
	],
	[
		"s1826816",
		"Pourthiaea tomentosa",
		"pourthiaea",
		1826816
	],
	[
		"s193308",
		"Pourthiaea villosa",
		"pourthiaea",
		193308
	],
	[
		"s2654668",
		"Pourthiaea zhejiangensis",
		"pourthiaea",
		2654668
	],
	[
		"s3870070",
		"Pouzolzia acalyphoides",
		"pouzolzia",
		3870070
	],
	[
		"s3870071",
		"Pouzolzia amambaiensis",
		"pouzolzia",
		3870071
	],
	[
		"s3870072",
		"Pouzolzia arachnoidea",
		"pouzolzia",
		3870072
	],
	[
		"s1399735",
		"Pouzolzia argenteonitida",
		"pouzolzia",
		1399735
	],
	[
		"s3870073",
		"Pouzolzia auriculata",
		"pouzolzia",
		3870073
	],
	[
		"s1793843",
		"Pouzolzia australis",
		"pouzolzia",
		1793843
	],
	[
		"s3870074",
		"Pouzolzia baronii",
		"pouzolzia",
		3870074
	],
	[
		"s3091398",
		"Pouzolzia boiviniana",
		"pouzolzia",
		3091398
	],
	[
		"s3870075",
		"Pouzolzia bracteosa",
		"pouzolzia",
		3870075
	],
	[
		"s3870076",
		"Pouzolzia ceramica",
		"pouzolzia",
		3870076
	],
	[
		"s3870077",
		"Pouzolzia conglobata",
		"pouzolzia",
		3870077
	],
	[
		"s3870078",
		"Pouzolzia cymosa",
		"pouzolzia",
		3870078
	],
	[
		"s3091670",
		"Pouzolzia denudata",
		"pouzolzia",
		3091670
	],
	[
		"s3870079",
		"Pouzolzia diffusa",
		"pouzolzia",
		3870079
	],
	[
		"s2807303",
		"Pouzolzia fadenii",
		"pouzolzia",
		2807303
	],
	[
		"s3870080",
		"Pouzolzia floresiana",
		"pouzolzia",
		3870080
	],
	[
		"s3091399",
		"Pouzolzia formicaria",
		"pouzolzia",
		3091399
	],
	[
		"s3870081",
		"Pouzolzia friisii",
		"pouzolzia",
		3870081
	],
	[
		"s3091671",
		"Pouzolzia gaudichaudii",
		"pouzolzia",
		3091671
	],
	[
		"s3091400",
		"Pouzolzia guatemalana",
		"pouzolzia",
		3091400
	],
	[
		"s1399736",
		"Pouzolzia guineensis",
		"pouzolzia",
		1399736
	],
	[
		"s3870082",
		"Pouzolzia herpetophyton",
		"pouzolzia",
		3870082
	],
	[
		"s648870",
		"Pouzolzia hirta",
		"pouzolzia",
		648870
	],
	[
		"s3091672",
		"Pouzolzia humbertii",
		"pouzolzia",
		3091672
	],
	[
		"s3091401",
		"Pouzolzia laevis",
		"pouzolzia",
		3091401
	],
	[
		"s3870083",
		"Pouzolzia latistipula",
		"pouzolzia",
		3870083
	],
	[
		"s344862",
		"Pouzolzia longipes",
		"pouzolzia",
		344862
	],
	[
		"s3870084",
		"Pouzolzia mandrarensis",
		"pouzolzia",
		3870084
	],
	[
		"s992773",
		"Pouzolzia mixta",
		"pouzolzia",
		992773
	],
	[
		"s3870085",
		"Pouzolzia niveotomentosa",
		"pouzolzia",
		3870085
	],
	[
		"s3870086",
		"Pouzolzia nudiflora",
		"pouzolzia",
		3870086
	],
	[
		"s3091402",
		"Pouzolzia obliqua",
		"pouzolzia",
		3091402
	],
	[
		"s3870087",
		"Pouzolzia occidentalis",
		"pouzolzia",
		3870087
	],
	[
		"s3870088",
		"Pouzolzia papuana",
		"pouzolzia",
		3870088
	],
	[
		"s2806860",
		"Pouzolzia parasitica",
		"pouzolzia",
		2806860
	],
	[
		"s3870089",
		"Pouzolzia peteri",
		"pouzolzia",
		3870089
	],
	[
		"s2306701",
		"Pouzolzia poeppigiana",
		"pouzolzia",
		2306701
	],
	[
		"s3091673",
		"Pouzolzia pringlei",
		"pouzolzia",
		3091673
	],
	[
		"s3091674",
		"Pouzolzia purpusii",
		"pouzolzia",
		3091674
	],
	[
		"s3870090",
		"Pouzolzia revoluta",
		"pouzolzia",
		3870090
	],
	[
		"s2807136",
		"Pouzolzia rubricaulis",
		"pouzolzia",
		2807136
	],
	[
		"s1399664",
		"Pouzolzia rugulosa",
		"pouzolzia",
		1399664
	],
	[
		"s1399737",
		"Pouzolzia sanguinea",
		"pouzolzia",
		1399737
	],
	[
		"s3836693",
		"Pouzolzia saxophila",
		"pouzolzia",
		3836693
	],
	[
		"s3836694",
		"Pouzolzia scaberrima",
		"pouzolzia",
		3836694
	],
	[
		"s3836695",
		"Pouzolzia thailandica",
		"pouzolzia",
		3836695
	],
	[
		"s3836696",
		"Pouzolzia tsaratananensis",
		"pouzolzia",
		3836696
	],
	[
		"s3836697",
		"Pouzolzia variifolia",
		"pouzolzia",
		3836697
	],
	[
		"s3836698",
		"Pouzolzia vesicaria",
		"pouzolzia",
		3836698
	],
	[
		"s3091675",
		"Pouzolzia weddellii",
		"pouzolzia",
		3091675
	],
	[
		"s1225090",
		"Pouzolzia zeylanica",
		"pouzolzia",
		1225090
	],
	[
		"s241912",
		"Prainea limpato",
		"prainea",
		241912
	],
	[
		"s2807304",
		"Prainea scandens",
		"prainea",
		2807304
	],
	[
		"s2558369",
		"Prinsepia scandens",
		"prinsepia",
		2558369
	],
	[
		"s133203",
		"Prinsepia sinensis",
		"prinsepia",
		133203
	],
	[
		"s32240",
		"Prinsepia uniflora",
		"prinsepia",
		32240
	],
	[
		"s1308043",
		"Prinsepia utilis",
		"prinsepia",
		1308043
	],
	[
		"s3870334",
		"Procris acaulis",
		"procris",
		3870334
	],
	[
		"s3870335",
		"Procris anfracta",
		"procris",
		3870335
	],
	[
		"s1785686",
		"Procris archboldiana",
		"procris",
		1785686
	],
	[
		"s1322151",
		"Procris boninensis",
		"procris",
		1322151
	],
	[
		"s3870336",
		"Procris brunnea",
		"procris",
		3870336
	],
	[
		"s1785687",
		"Procris crenata",
		"procris",
		1785687
	],
	[
		"s226273",
		"Procris curtisii",
		"procris",
		226273
	],
	[
		"s3870337",
		"Procris decurrens",
		"procris",
		3870337
	],
	[
		"s3870338",
		"Procris dolichophylla",
		"procris",
		3870338
	],
	[
		"s226093",
		"Procris frutescens",
		"procris",
		226093
	],
	[
		"s2306702",
		"Procris goepeliana",
		"procris",
		2306702
	],
	[
		"s226096",
		"Procris insularis",
		"procris",
		226096
	],
	[
		"s1785688",
		"Procris laevigata",
		"procris",
		1785688
	],
	[
		"s3870339",
		"Procris langbianensis",
		"procris",
		3870339
	],
	[
		"s3870340",
		"Procris mindanaensis",
		"procris",
		3870340
	],
	[
		"s1785689",
		"Procris montana",
		"procris",
		1785689
	],
	[
		"s647285",
		"Procris pedunculata",
		"procris",
		647285
	],
	[
		"s3870341",
		"Procris pilifera",
		"procris",
		3870341
	],
	[
		"s3870342",
		"Procris puberula",
		"procris",
		3870342
	],
	[
		"s2807137",
		"Procris repens",
		"procris",
		2807137
	],
	[
		"s647286",
		"Procris ruhlandii",
		"procris",
		647286
	],
	[
		"s3870343",
		"Procris urdanetensis",
		"procris",
		3870343
	],
	[
		"s3870344",
		"Procris visciformis",
		"procris",
		3870344
	],
	[
		"s1399742",
		"Procris wightiana",
		"procris",
		1399742
	],
	[
		"s2315768",
		"(Prunus cerasifera x Prunus salicina) x (Prunus cerasifera x Prunus persica)",
		"prunus",
		2315768
	],
	[
		"s2315769",
		"(Prunus dulcis x Prunus persica) x (Prunus dulcis x Prunus davidiana)",
		"prunus",
		2315769
	],
	[
		"s2315770",
		"(Prunus dulcis x Prunus persica) x (Prunus dulcis x Prunus persica)",
		"prunus",
		2315770
	],
	[
		"s2315771",
		"(Prunus persica x Prunus davidiana) x (Prunus dulcis x Prunus persica)",
		"prunus",
		2315771
	],
	[
		"s2315772",
		"(Prunus persica x Prunus davidiana) x Prunus persica",
		"prunus",
		2315772
	],
	[
		"s2789311",
		"[Cerasus] fengyangshanica",
		"prunus",
		2789311
	],
	[
		"s3895396",
		"[Cerasus] klokovii",
		"prunus",
		3895396
	],
	[
		"s2748631",
		"[Cerasus] kumanoensis",
		"prunus",
		2748631
	],
	[
		"s3870515",
		"Prunus accumulans",
		"prunus",
		3870515
	],
	[
		"s379279",
		"Prunus africana",
		"prunus",
		379279
	],
	[
		"s3870516",
		"Prunus aitchisonii",
		"prunus",
		3870516
	],
	[
		"s983178",
		"Prunus alabamensis",
		"prunus",
		983178
	],
	[
		"s3870517",
		"Prunus alaica",
		"prunus",
		3870517
	],
	[
		"s3021873",
		"Prunus albicaulis",
		"prunus",
		3021873
	],
	[
		"s3023007",
		"Prunus alidagensis",
		"prunus",
		3023007
	],
	[
		"s151330",
		"Prunus alleghaniensis",
		"prunus",
		151330
	],
	[
		"s122118",
		"Prunus americana",
		"prunus",
		122118
	],
	[
		"s983179",
		"Prunus amplifolia",
		"prunus",
		983179
	],
	[
		"s151425",
		"Prunus andersonii",
		"prunus",
		151425
	],
	[
		"s122119",
		"Prunus angustifolia",
		"prunus",
		122119
	],
	[
		"s1129514",
		"Prunus annularis",
		"prunus",
		1129514
	],
	[
		"s140662",
		"Prunus apetala",
		"prunus",
		140662
	],
	[
		"s1284229",
		"Prunus arabica",
		"prunus",
		1284229
	],
	[
		"s552829",
		"Prunus arborea",
		"prunus",
		552829
	],
	[
		"s151426",
		"Prunus argentea",
		"prunus",
		151426
	],
	[
		"s36596",
		"Prunus armeniaca",
		"prunus",
		36596
	],
	[
		"s2100584",
		"Prunus armeniaca x Prunus dulcis",
		"prunus",
		2100584
	],
	[
		"s1170638",
		"Prunus australis",
		"prunus",
		1170638
	],
	[
		"s3050819",
		"Prunus austrosinensis",
		"prunus",
		3050819
	],
	[
		"s42229",
		"Prunus avium",
		"prunus",
		42229
	],
	[
		"s349168",
		"Prunus avium x P. cerasus x P. canescens",
		"prunus",
		349168
	],
	[
		"s1181296",
		"Prunus avium x Prunus pseudocerasus",
		"prunus",
		1181296
	],
	[
		"s3870518",
		"Prunus axitliana",
		"prunus",
		3870518
	],
	[
		"s664995",
		"Prunus azorica",
		"prunus",
		664995
	],
	[
		"s3870519",
		"Prunus barbata",
		"prunus",
		3870519
	],
	[
		"s3870520",
		"Prunus beccarii",
		"prunus",
		3870520
	],
	[
		"s136446",
		"Prunus besseyi",
		"prunus",
		136446
	],
	[
		"s2315773",
		"Prunus besseyi x Prunus cerasifera",
		"prunus",
		2315773
	],
	[
		"s151427",
		"Prunus bifrons",
		"prunus",
		151427
	],
	[
		"s743732",
		"Prunus bokhariensis",
		"prunus",
		743732
	],
	[
		"s1129515",
		"Prunus brachybotrya",
		"prunus",
		1129515
	],
	[
		"s2939651",
		"Prunus brachypetala",
		"prunus",
		2939651
	],
	[
		"s1170639",
		"Prunus brachypoda",
		"prunus",
		1170639
	],
	[
		"s3091676",
		"Prunus brachystachya",
		"prunus",
		3091676
	],
	[
		"s3870521",
		"Prunus bracteopadus",
		"prunus",
		3870521
	],
	[
		"s2572106",
		"Prunus brahuica",
		"prunus",
		2572106
	],
	[
		"s3091405",
		"Prunus brasiliensis",
		"prunus",
		3091405
	],
	[
		"s3091677",
		"Prunus brassii",
		"prunus",
		3091677
	],
	[
		"s151428",
		"Prunus brigantina",
		"prunus",
		151428
	],
	[
		"s2107764",
		"Prunus brigantina x Prunus cerasifera",
		"prunus",
		2107764
	],
	[
		"s983182",
		"Prunus brittoniana",
		"prunus",
		983182
	],
	[
		"s3870522",
		"Prunus browiczii",
		"prunus",
		3870522
	],
	[
		"s3870523",
		"Prunus brunnescens",
		"prunus",
		3870523
	],
	[
		"s151429",
		"Prunus bucharica",
		"prunus",
		151429
	],
	[
		"s97305",
		"Prunus buergeriana",
		"prunus",
		97305
	],
	[
		"s3870524",
		"Prunus buxifolia",
		"prunus",
		3870524
	],
	[
		"s136465",
		"Prunus campanulata",
		"prunus",
		136465
	],
	[
		"s2773138",
		"Prunus campanulata x Prunus kanzakura",
		"prunus",
		2773138
	],
	[
		"s549207",
		"Prunus canescens",
		"prunus",
		549207
	],
	[
		"s549208",
		"Prunus canescens x Prunus cerasus",
		"prunus",
		549208
	],
	[
		"s749916",
		"Prunus carduchorum",
		"prunus",
		749916
	],
	[
		"s3091678",
		"Prunus carmesina",
		"prunus",
		3091678
	],
	[
		"s140652",
		"Prunus caroliniana",
		"prunus",
		140652
	],
	[
		"s2962494",
		"Prunus cathayana",
		"prunus",
		2962494
	],
	[
		"s1642860",
		"Prunus caudata",
		"prunus",
		1642860
	],
	[
		"s3870525",
		"Prunus cerasia",
		"prunus",
		3870525
	],
	[
		"s36595",
		"Prunus cerasifera",
		"prunus",
		36595
	],
	[
		"s2315774",
		"Prunus cerasifera x (Prunus persica x Prunus dulcis)",
		"prunus",
		2315774
	],
	[
		"s2315775",
		"Prunus cerasifera x Prunus dulcis",
		"prunus",
		2315775
	],
	[
		"s381902",
		"Prunus cerasifera x Prunus munsoniana",
		"prunus",
		381902
	],
	[
		"s2315776",
		"Prunus cerasifera x Prunus persica",
		"prunus",
		2315776
	],
	[
		"s2315777",
		"Prunus cerasifera x Prunus salicina",
		"prunus",
		2315777
	],
	[
		"s378224",
		"Prunus cerasoides",
		"prunus",
		378224
	],
	[
		"s140311",
		"Prunus cerasus",
		"prunus",
		140311
	],
	[
		"s1759535",
		"Prunus cerasus x Prunus canescens",
		"prunus",
		1759535
	],
	[
		"s1182928",
		"Prunus cercocarpifolia",
		"prunus",
		1182928
	],
	[
		"s983183",
		"Prunus ceylanica",
		"prunus",
		983183
	],
	[
		"s2516742",
		"Prunus cf. arborea KR2241",
		"prunus",
		2516742
	],
	[
		"s2516743",
		"Prunus cf. grisea KR0497",
		"prunus",
		2516743
	],
	[
		"s2516745",
		"Prunus cf. grisea KR0541",
		"prunus",
		2516745
	],
	[
		"s2516744",
		"Prunus cf. grisea KR2420",
		"prunus",
		2516744
	],
	[
		"s3091679",
		"Prunus chamissoana",
		"prunus",
		3091679
	],
	[
		"s3870526",
		"Prunus chiapensis",
		"prunus",
		3870526
	],
	[
		"s3870527",
		"Prunus chiliangensis",
		"prunus",
		3870527
	],
	[
		"s106848",
		"Prunus choreiana",
		"prunus",
		106848
	],
	[
		"s3870528",
		"Prunus chorossanica",
		"prunus",
		3870528
	],
	[
		"s1170640",
		"Prunus clarofolia",
		"prunus",
		1170640
	],
	[
		"s3091406",
		"Prunus clementis",
		"prunus",
		3091406
	],
	[
		"s114936",
		"Prunus cocomilia",
		"prunus",
		114936
	],
	[
		"s3870529",
		"Prunus compacta",
		"prunus",
		3870529
	],
	[
		"s1642854",
		"Prunus conadenia",
		"prunus",
		1642854
	],
	[
		"s456515",
		"Prunus conradinae",
		"prunus",
		456515
	],
	[
		"s983184",
		"Prunus consociiflora",
		"prunus",
		983184
	],
	[
		"s743733",
		"Prunus cornuta",
		"prunus",
		743733
	],
	[
		"s3870530",
		"Prunus cortapico",
		"prunus",
		3870530
	],
	[
		"s983185",
		"Prunus costata",
		"prunus",
		983185
	],
	[
		"s3870531",
		"Prunus crassifolia",
		"prunus",
		3870531
	],
	[
		"s1891964",
		"Prunus crataegifolia",
		"prunus",
		1891964
	],
	[
		"s136467",
		"Prunus cyclamina",
		"prunus",
		136467
	],
	[
		"s3870532",
		"Prunus darvasica",
		"prunus",
		3870532
	],
	[
		"s151430",
		"Prunus davidiana",
		"prunus",
		151430
	],
	[
		"s374398",
		"Prunus davidiana x Prunus persica",
		"prunus",
		374398
	],
	[
		"s217729",
		"Prunus debilis",
		"prunus",
		217729
	],
	[
		"s2762727",
		"Prunus dictyoneura",
		"prunus",
		2762727
	],
	[
		"s552830",
		"Prunus dielsiana",
		"prunus",
		552830
	],
	[
		"s2927821",
		"Prunus dinabandhuana",
		"prunus",
		2927821
	],
	[
		"s1642861",
		"Prunus discadenia",
		"prunus",
		1642861
	],
	[
		"s1008929",
		"Prunus discoidea",
		"prunus",
		1008929
	],
	[
		"s3870533",
		"Prunus discolor",
		"prunus",
		3870533
	],
	[
		"s1891965",
		"Prunus dolichadenia",
		"prunus",
		1891965
	],
	[
		"s928659",
		"Prunus dolichobotrys",
		"prunus",
		928659
	],
	[
		"s3870534",
		"Prunus dolichophylla",
		"prunus",
		3870534
	],
	[
		"s3758",
		"Prunus domestica",
		"prunus",
		3758
	],
	[
		"s2736819",
		"Prunus domestica x Prunus domestica subsp. insititia",
		"prunus",
		2736819
	],
	[
		"s3870535",
		"Prunus douglasii",
		"prunus",
		3870535
	],
	[
		"s2740320",
		"Prunus duclouxii",
		"prunus",
		2740320
	],
	[
		"s3755",
		"Prunus dulcis",
		"prunus",
		3755
	],
	[
		"s472390",
		"Prunus dulcis x Prunus persica",
		"prunus",
		472390
	],
	[
		"s1431470",
		"Prunus eburnea",
		"prunus",
		1431470
	],
	[
		"s1284231",
		"Prunus elaeagrifolia",
		"prunus",
		1284231
	],
	[
		"s32241",
		"Prunus emarginata",
		"prunus",
		32241
	],
	[
		"s1182929",
		"Prunus eremophila",
		"prunus",
		1182929
	],
	[
		"s2133962",
		"Prunus erythrocarpa",
		"prunus",
		2133962
	],
	[
		"s3870536",
		"Prunus erythroxylon",
		"prunus",
		3870536
	],
	[
		"s3870537",
		"Prunus espinozana",
		"prunus",
		3870537
	],
	[
		"s3870538",
		"Prunus falcata",
		"prunus",
		3870538
	],
	[
		"s151431",
		"Prunus fasciculata",
		"prunus",
		151431
	],
	[
		"s749917",
		"Prunus fenzliana",
		"prunus",
		749917
	],
	[
		"s166019",
		"Prunus ferganensis",
		"prunus",
		166019
	],
	[
		"s983186",
		"Prunus ferganica",
		"prunus",
		983186
	],
	[
		"s140653",
		"Prunus fordiana",
		"prunus",
		140653
	],
	[
		"s1807086",
		"Prunus fortunensis",
		"prunus",
		1807086
	],
	[
		"s3091407",
		"Prunus fragrans",
		"prunus",
		3091407
	],
	[
		"s151432",
		"Prunus fremontii",
		"prunus",
		151432
	],
	[
		"s151433",
		"Prunus fruticosa",
		"prunus",
		151433
	],
	[
		"s2783863",
		"Prunus fujianensis",
		"prunus",
		2783863
	],
	[
		"s983187",
		"Prunus gazelle-peninsulae",
		"prunus",
		983187
	],
	[
		"s262525",
		"Prunus geniculata",
		"prunus",
		262525
	],
	[
		"s3870539",
		"Prunus gentryi",
		"prunus",
		3870539
	],
	[
		"s3870540",
		"Prunus georgica",
		"prunus",
		3870540
	],
	[
		"s3870541",
		"Prunus ghahremanii",
		"prunus",
		3870541
	],
	[
		"s3870542",
		"Prunus glabrifolia",
		"prunus",
		3870542
	],
	[
		"s105665",
		"Prunus glandulosa",
		"prunus",
		105665
	],
	[
		"s1284228",
		"Prunus glauca",
		"prunus",
		1284228
	],
	[
		"s2783864",
		"Prunus gongshanensis",
		"prunus",
		2783864
	],
	[
		"s262523",
		"Prunus gracilis",
		"prunus",
		262523
	],
	[
		"s140654",
		"Prunus grayana",
		"prunus",
		140654
	],
	[
		"s3870543",
		"Prunus griffithii",
		"prunus",
		3870543
	],
	[
		"s552831",
		"Prunus grisea",
		"prunus",
		552831
	],
	[
		"s3870544",
		"Prunus guanaiensis",
		"prunus",
		3870544
	],
	[
		"s3870545",
		"Prunus guanwuensis",
		"prunus",
		3870545
	],
	[
		"s3870546",
		"Prunus guatemalensis",
		"prunus",
		3870546
	],
	[
		"s3870547",
		"Prunus gyirongensis",
		"prunus",
		3870547
	],
	[
		"s1570059",
		"Prunus hallasanensis",
		"prunus",
		1570059
	],
	[
		"s3870548",
		"Prunus harae",
		"prunus",
		3870548
	],
	[
		"s3870549",
		"Prunus hargraonensis",
		"prunus",
		3870549
	],
	[
		"s749918",
		"Prunus haussknechtii",
		"prunus",
		749918
	],
	[
		"s552832",
		"Prunus havardii",
		"prunus",
		552832
	],
	[
		"s3870550",
		"Prunus hefengensis",
		"prunus",
		3870550
	],
	[
		"s983188",
		"Prunus henryi",
		"prunus",
		983188
	],
	[
		"s2576276",
		"Prunus himalaica",
		"prunus",
		2576276
	],
	[
		"s928657",
		"Prunus himalayana",
		"prunus",
		928657
	],
	[
		"s3021872",
		"Prunus hippophaeoides",
		"prunus",
		3021872
	],
	[
		"s3091680",
		"Prunus hirtipes",
		"prunus",
		3091680
	],
	[
		"s3870551",
		"Prunus hongiaoensis",
		"prunus",
		3870551
	],
	[
		"s151434",
		"Prunus hortulana",
		"prunus",
		151434
	],
	[
		"s3870552",
		"Prunus huadongensis",
		"prunus",
		3870552
	],
	[
		"s2650237",
		"Prunus huantensis",
		"prunus",
		2650237
	],
	[
		"s434060",
		"Prunus humilis",
		"prunus",
		434060
	],
	[
		"s768725",
		"Prunus hybrid cultivar",
		"prunus",
		768725
	],
	[
		"s608844",
		"Prunus hybrid rootstock",
		"prunus",
		608844
	],
	[
		"s140651",
		"Prunus hypoleuca",
		"prunus",
		140651
	],
	[
		"s3091681",
		"Prunus hypotricha",
		"prunus",
		3091681
	],
	[
		"s3870553",
		"Prunus hypotrichodes",
		"prunus",
		3870553
	],
	[
		"s2291138",
		"Prunus hypoxantha",
		"prunus",
		2291138
	],
	[
		"s23206",
		"Prunus ilicifolia",
		"prunus",
		23206
	],
	[
		"s3021866",
		"Prunus incana",
		"prunus",
		3021866
	],
	[
		"s137206",
		"Prunus incisa",
		"prunus",
		137206
	],
	[
		"s2518305",
		"Prunus incisa x Prunus campanulata",
		"prunus",
		2518305
	],
	[
		"s2518604",
		"Prunus incisa x Prunus speciosa",
		"prunus",
		2518604
	],
	[
		"s928658",
		"Prunus incisoserrata",
		"prunus",
		928658
	],
	[
		"s928660",
		"Prunus integrifolia",
		"prunus",
		928660
	],
	[
		"s2986971",
		"Prunus itosakura",
		"prunus",
		2986971
	],
	[
		"s195661",
		"Prunus jacquemontii",
		"prunus",
		195661
	],
	[
		"s3870554",
		"Prunus jajarkotensis",
		"prunus",
		3870554
	],
	[
		"s97325",
		"Prunus jamasakura",
		"prunus",
		97325
	],
	[
		"s97319",
		"Prunus japonica",
		"prunus",
		97319
	],
	[
		"s928661",
		"Prunus javanica",
		"prunus",
		928661
	],
	[
		"s1679435",
		"Prunus jenkinsii",
		"prunus",
		1679435
	],
	[
		"s1813458",
		"Prunus jingningensis",
		"prunus",
		1813458
	],
	[
		"s3870555",
		"Prunus jugata",
		"prunus",
		3870555
	],
	[
		"s3870556",
		"Prunus kaengkrachanensis",
		"prunus",
		3870556
	],
	[
		"s3870557",
		"Prunus kalkmanii",
		"prunus",
		3870557
	],
	[
		"s329890",
		"Prunus kansuensis",
		"prunus",
		329890
	],
	[
		"s1813533",
		"Prunus kanzakura",
		"prunus",
		1813533
	],
	[
		"s3870558",
		"Prunus kinabaluensis",
		"prunus",
		3870558
	],
	[
		"s3870559",
		"Prunus koelzii",
		"prunus",
		3870559
	],
	[
		"s749920",
		"Prunus korshinskyi",
		"prunus",
		749920
	],
	[
		"s1431472",
		"Prunus kotschyi",
		"prunus",
		1431472
	],
	[
		"s151331",
		"Prunus kuramica",
		"prunus",
		151331
	],
	[
		"s1431465",
		"Prunus kurdistanica",
		"prunus",
		1431465
	],
	[
		"s3091408",
		"Prunus lamponga",
		"prunus",
		3091408
	],
	[
		"s928662",
		"Prunus lancilimba",
		"prunus",
		928662
	],
	[
		"s151421",
		"Prunus lannesiana",
		"prunus",
		151421
	],
	[
		"s32242",
		"Prunus laurocerasus",
		"prunus",
		32242
	],
	[
		"s3870560",
		"Prunus laxinervis",
		"prunus",
		3870560
	],
	[
		"s2605356",
		"Prunus ledebouriana",
		"prunus",
		2605356
	],
	[
		"s1431473",
		"Prunus leiocarpa",
		"prunus",
		1431473
	],
	[
		"s3870561",
		"Prunus leucophylla",
		"prunus",
		3870561
	],
	[
		"s105666",
		"Prunus leveilleana",
		"prunus",
		105666
	],
	[
		"s3870562",
		"Prunus lichoana",
		"prunus",
		3870562
	],
	[
		"s3870563",
		"Prunus ligustrina",
		"prunus",
		3870563
	],
	[
		"s3870564",
		"Prunus littlei",
		"prunus",
		3870564
	],
	[
		"s3870565",
		"Prunus longispinosa",
		"prunus",
		3870565
	],
	[
		"s1570060",
		"Prunus longistyla",
		"prunus",
		1570060
	],
	[
		"s3870566",
		"Prunus lundelliana",
		"prunus",
		3870566
	],
	[
		"s194545",
		"Prunus lusitanica",
		"prunus",
		194545
	],
	[
		"s1284230",
		"Prunus lycioides",
		"prunus",
		1284230
	],
	[
		"s140657",
		"Prunus maackii",
		"prunus",
		140657
	],
	[
		"s129217",
		"Prunus mahaleb",
		"prunus",
		129217
	],
	[
		"s2315778",
		"Prunus mahaleb x Prunus avium",
		"prunus",
		2315778
	],
	[
		"s552833",
		"Prunus malayana",
		"prunus",
		552833
	],
	[
		"s122122",
		"Prunus mandshurica",
		"prunus",
		122122
	],
	[
		"s151436",
		"Prunus maritima",
		"prunus",
		151436
	],
	[
		"s3091682",
		"Prunus marsupialis",
		"prunus",
		3091682
	],
	[
		"s3870567",
		"Prunus matudae",
		"prunus",
		3870567
	],
	[
		"s2491139",
		"Prunus matuurae",
		"prunus",
		2491139
	],
	[
		"s97306",
		"Prunus maximowiczii",
		"prunus",
		97306
	],
	[
		"s3870568",
		"Prunus mazandaranica",
		"prunus",
		3870568
	],
	[
		"s3870569",
		"Prunus megacarpa",
		"prunus",
		3870569
	],
	[
		"s3870570",
		"Prunus menghaiensis",
		"prunus",
		3870570
	],
	[
		"s151437",
		"Prunus mexicana",
		"prunus",
		151437
	],
	[
		"s194546",
		"Prunus microcarpa",
		"prunus",
		194546
	],
	[
		"s1182930",
		"Prunus microphylla",
		"prunus",
		1182930
	],
	[
		"s1182931",
		"Prunus minutiflora",
		"prunus",
		1182931
	],
	[
		"s151332",
		"Prunus mira",
		"prunus",
		151332
	],
	[
		"s1501231",
		"Prunus mongolica",
		"prunus",
		1501231
	],
	[
		"s3870571",
		"Prunus moritziana",
		"prunus",
		3870571
	],
	[
		"s1642862",
		"Prunus mugus",
		"prunus",
		1642862
	],
	[
		"s102107",
		"Prunus mume",
		"prunus",
		102107
	],
	[
		"s151438",
		"Prunus munsoniana",
		"prunus",
		151438
	],
	[
		"s3870572",
		"Prunus muris",
		"prunus",
		3870572
	],
	[
		"s476033",
		"Prunus murrayana",
		"prunus",
		476033
	],
	[
		"s983189",
		"Prunus myrtifolia",
		"prunus",
		983189
	],
	[
		"s749915",
		"Prunus nairica",
		"prunus",
		749915
	],
	[
		"s2826883",
		"Prunus nakatakei",
		"prunus",
		2826883
	],
	[
		"s552834",
		"Prunus napaulensis",
		"prunus",
		552834
	],
	[
		"s122120",
		"Prunus nigra",
		"prunus",
		122120
	],
	[
		"s137737",
		"Prunus nipponica",
		"prunus",
		137737
	],
	[
		"s3870573",
		"Prunus nutantiflora",
		"prunus",
		3870573
	],
	[
		"s983190",
		"Prunus oblonga",
		"prunus",
		983190
	],
	[
		"s983191",
		"Prunus obtusata",
		"prunus",
		983191
	],
	[
		"s1170641",
		"Prunus occidentalis",
		"prunus",
		1170641
	],
	[
		"s3870574",
		"Prunus ocellata",
		"prunus",
		3870574
	],
	[
		"s3870575",
		"Prunus ochoterenae",
		"prunus",
		3870575
	],
	[
		"s928663",
		"Prunus oleifolia",
		"prunus",
		928663
	],
	[
		"s983192",
		"Prunus oligantha",
		"prunus",
		983192
	],
	[
		"s3870576",
		"Prunus omissa",
		"prunus",
		3870576
	],
	[
		"s1170649",
		"Prunus oocarpa",
		"prunus",
		1170649
	],
	[
		"s485827",
		"Prunus opaca",
		"prunus",
		485827
	],
	[
		"s1431466",
		"Prunus orazii",
		"prunus",
		1431466
	],
	[
		"s983193",
		"Prunus orthosepala",
		"prunus",
		983193
	],
	[
		"s983194",
		"Prunus ovalis",
		"prunus",
		983194
	],
	[
		"s1431467",
		"Prunus pabotii",
		"prunus",
		1431467
	],
	[
		"s97307",
		"Prunus padus",
		"prunus",
		97307
	],
	[
		"s1263852",
		"Prunus pananensis",
		"prunus",
		1263852
	],
	[
		"s3870577",
		"Prunus paradoxa",
		"prunus",
		3870577
	],
	[
		"s1813531",
		"Prunus patentipila",
		"prunus",
		1813531
	],
	[
		"s3870578",
		"Prunus pearcei",
		"prunus",
		3870578
	],
	[
		"s983195",
		"Prunus pedunculata",
		"prunus",
		983195
	],
	[
		"s262529",
		"Prunus pensylvanica",
		"prunus",
		262529
	],
	[
		"s3760",
		"Prunus persica",
		"prunus",
		3760
	],
	[
		"s2315779",
		"Prunus persica x (Prunus dulcis x Prunus persica)",
		"prunus",
		2315779
	],
	[
		"s2315780",
		"Prunus persica x (Prunus persica x Prunus davidiana)",
		"prunus",
		2315780
	],
	[
		"s1081492",
		"Prunus persica x Prunus dulcis",
		"prunus",
		1081492
	],
	[
		"s1046628",
		"Prunus persica x Prunus ferganensis",
		"prunus",
		1046628
	],
	[
		"s1170642",
		"Prunus perulata",
		"prunus",
		1170642
	],
	[
		"s217727",
		"Prunus petunnikowii",
		"prunus",
		217727
	],
	[
		"s552835",
		"Prunus phaeosticta",
		"prunus",
		552835
	],
	[
		"s983196",
		"Prunus pleiocerasus",
		"prunus",
		983196
	],
	[
		"s3870579",
		"Prunus podperae",
		"prunus",
		3870579
	],
	[
		"s3091683",
		"Prunus pogonostyla",
		"prunus",
		3091683
	],
	[
		"s1642863",
		"Prunus pojarkovii",
		"prunus",
		1642863
	],
	[
		"s983197",
		"Prunus polystachya",
		"prunus",
		983197
	],
	[
		"s1642864",
		"Prunus polytricha",
		"prunus",
		1642864
	],
	[
		"s195662",
		"Prunus prostrata",
		"prunus",
		195662
	],
	[
		"s151439",
		"Prunus pseudocerasus",
		"prunus",
		151439
	],
	[
		"s3091409",
		"Prunus pseudoprostrata",
		"prunus",
		3091409
	],
	[
		"s3091410",
		"Prunus pulgarensis",
		"prunus",
		3091410
	],
	[
		"s983198",
		"Prunus pullei",
		"prunus",
		983198
	],
	[
		"s262528",
		"Prunus pumila",
		"prunus",
		262528
	],
	[
		"s1642865",
		"Prunus pusilliflora",
		"prunus",
		1642865
	],
	[
		"s3870580",
		"Prunus pygeoides",
		"prunus",
		3870580
	],
	[
		"s3870581",
		"Prunus quanzhouensis",
		"prunus",
		3870581
	],
	[
		"s391055",
		"Prunus ramburei",
		"prunus",
		391055
	],
	[
		"s3870582",
		"Prunus ramburii",
		"prunus",
		3870582
	],
	[
		"s3870583",
		"Prunus ramonensis",
		"prunus",
		3870583
	],
	[
		"s3870584",
		"Prunus ravenii",
		"prunus",
		3870584
	],
	[
		"s983200",
		"Prunus reflexa",
		"prunus",
		983200
	],
	[
		"s3091684",
		"Prunus reverchonii",
		"prunus",
		3091684
	],
	[
		"s3067256",
		"Prunus rhamnoides",
		"prunus",
		3067256
	],
	[
		"s3870585",
		"Prunus rigida",
		"prunus",
		3870585
	],
	[
		"s262521",
		"Prunus rivularis",
		"prunus",
		262521
	],
	[
		"s3870586",
		"Prunus rotunda",
		"prunus",
		3870586
	],
	[
		"s3091411",
		"Prunus rubiginosa",
		"prunus",
		3091411
	],
	[
		"s1642855",
		"Prunus rufa",
		"prunus",
		1642855
	],
	[
		"s3870587",
		"Prunus rufoides",
		"prunus",
		3870587
	],
	[
		"s3870588",
		"Prunus ruiziana",
		"prunus",
		3870588
	],
	[
		"s1431468",
		"Prunus runemarkii",
		"prunus",
		1431468
	],
	[
		"s1870834",
		"Prunus sachalinensis",
		"prunus",
		1870834
	],
	[
		"s3870589",
		"Prunus salasii",
		"prunus",
		3870589
	],
	[
		"s88123",
		"Prunus salicina",
		"prunus",
		88123
	],
	[
		"s551137",
		"Prunus salicina x Prunus armeniaca",
		"prunus",
		551137
	],
	[
		"s2315781",
		"Prunus salicina x Prunus persica",
		"prunus",
		2315781
	],
	[
		"s3015745",
		"Prunus samydoides",
		"prunus",
		3015745
	],
	[
		"s97308",
		"Prunus sargentii",
		"prunus",
		97308
	],
	[
		"s1085493",
		"Prunus schlechteri",
		"prunus",
		1085493
	],
	[
		"s497077",
		"Prunus schneideriana",
		"prunus",
		497077
	],
	[
		"s2576277",
		"Prunus sclerophylla",
		"prunus",
		2576277
	],
	[
		"s749922",
		"Prunus scoparia",
		"prunus",
		749922
	],
	[
		"s1431458",
		"Prunus scoparia x Prunus eburnea",
		"prunus",
		1431458
	],
	[
		"s1431457",
		"Prunus scoparia x Prunus elaeagrifolia",
		"prunus",
		1431457
	],
	[
		"s1431459",
		"Prunus scoparia x Prunus haussknechtii",
		"prunus",
		1431459
	],
	[
		"s1813530",
		"Prunus scopulorum",
		"prunus",
		1813530
	],
	[
		"s217728",
		"Prunus sellowii",
		"prunus",
		217728
	],
	[
		"s23207",
		"Prunus serotina",
		"prunus",
		23207
	],
	[
		"s1358727",
		"Prunus serrula",
		"prunus",
		1358727
	],
	[
		"s97321",
		"Prunus serrulata",
		"prunus",
		97321
	],
	[
		"s1642866",
		"Prunus setulosa",
		"prunus",
		1642866
	],
	[
		"s151440",
		"Prunus sibirica",
		"prunus",
		151440
	],
	[
		"s2518335",
		"Prunus sieboldii",
		"prunus",
		2518335
	],
	[
		"s151441",
		"Prunus simonii",
		"prunus",
		151441
	],
	[
		"s3870590",
		"Prunus singalilaensis",
		"prunus",
		3870590
	],
	[
		"s983202",
		"Prunus skutchii",
		"prunus",
		983202
	],
	[
		"s391056",
		"Prunus sogdiana",
		"prunus",
		391056
	],
	[
		"s749923",
		"Prunus spartioides",
		"prunus",
		749923
	],
	[
		"s378228",
		"Prunus speciosa",
		"prunus",
		378228
	],
	[
		"s3091685",
		"Prunus spicata",
		"prunus",
		3091685
	],
	[
		"s114937",
		"Prunus spinosa",
		"prunus",
		114937
	],
	[
		"s983204",
		"Prunus spinosissima",
		"prunus",
		983204
	],
	[
		"s170480",
		"Prunus spinulosa",
		"prunus",
		170480
	],
	[
		"s1926489",
		"Prunus ssiori",
		"prunus",
		1926489
	],
	[
		"s3870591",
		"Prunus stellipila",
		"prunus",
		3870591
	],
	[
		"s2508334",
		"Prunus stepposa",
		"prunus",
		2508334
	],
	[
		"s552837",
		"Prunus stipulacea",
		"prunus",
		552837
	],
	[
		"s3870592",
		"Prunus strobilifera",
		"prunus",
		3870592
	],
	[
		"s151442",
		"Prunus subcordata",
		"prunus",
		151442
	],
	[
		"s3870593",
		"Prunus subcoriacea",
		"prunus",
		3870593
	],
	[
		"s3870594",
		"Prunus subcorymbosa",
		"prunus",
		3870594
	],
	[
		"s3091412",
		"Prunus subglabra",
		"prunus",
		3091412
	],
	[
		"s97320",
		"Prunus subhirtella",
		"prunus",
		97320
	],
	[
		"s2506380",
		"Prunus sunhangii",
		"prunus",
		2506380
	],
	[
		"s3870595",
		"Prunus susakensis",
		"prunus",
		3870595
	],
	[
		"s3091686",
		"Prunus susquehanae",
		"prunus",
		3091686
	],
	[
		"s1642867",
		"Prunus szechuanica",
		"prunus",
		1642867
	],
	[
		"s3870596",
		"Prunus tadzhikistanica",
		"prunus",
		3870596
	],
	[
		"s1642868",
		"Prunus takasagomontana",
		"prunus",
		1642868
	],
	[
		"s97309",
		"Prunus takesimensis",
		"prunus",
		97309
	],
	[
		"s911495",
		"Prunus tangutica",
		"prunus",
		911495
	],
	[
		"s3870597",
		"Prunus taplejungnica",
		"prunus",
		3870597
	],
	[
		"s3870598",
		"Prunus tartarea",
		"prunus",
		3870598
	],
	[
		"s1642869",
		"Prunus tatsienensis",
		"prunus",
		1642869
	],
	[
		"s3870599",
		"Prunus tayulinensis",
		"prunus",
		3870599
	],
	[
		"s140661",
		"Prunus tenella",
		"prunus",
		140661
	],
	[
		"s3015746",
		"Prunus tetradenia",
		"prunus",
		3015746
	],
	[
		"s217726",
		"Prunus texana",
		"prunus",
		217726
	],
	[
		"s2133964",
		"Prunus tianshanica",
		"prunus",
		2133964
	],
	[
		"s105667",
		"Prunus tomentosa",
		"prunus",
		105667
	],
	[
		"s2907459",
		"Prunus tongmuensis",
		"prunus",
		2907459
	],
	[
		"s401067",
		"Prunus topengii",
		"prunus",
		401067
	],
	[
		"s3870600",
		"Prunus topkegolensis",
		"prunus",
		3870600
	],
	[
		"s2803528",
		"Prunus transarisanensis",
		"prunus",
		2803528
	],
	[
		"s1431500",
		"Prunus trichamygdalus",
		"prunus",
		1431500
	],
	[
		"s1642870",
		"Prunus trichantha",
		"prunus",
		1642870
	],
	[
		"s1642871",
		"Prunus trichostoma",
		"prunus",
		1642871
	],
	[
		"s552838",
		"Prunus triloba",
		"prunus",
		552838
	],
	[
		"s3870601",
		"Prunus tuberculata",
		"prunus",
		3870601
	],
	[
		"s928664",
		"Prunus tucumanensis",
		"prunus",
		928664
	],
	[
		"s1431501",
		"Prunus turcomanica",
		"prunus",
		1431501
	],
	[
		"s3091687",
		"Prunus turfosa",
		"prunus",
		3091687
	],
	[
		"s1182932",
		"Prunus turneriana",
		"prunus",
		1182932
	],
	[
		"s3870602",
		"Prunus ulei",
		"prunus",
		3870602
	],
	[
		"s3091688",
		"Prunus ulmifolia",
		"prunus",
		3091688
	],
	[
		"s122121",
		"Prunus umbellata",
		"prunus",
		122121
	],
	[
		"s552839",
		"Prunus undulata",
		"prunus",
		552839
	],
	[
		"s3870603",
		"Prunus urartu",
		"prunus",
		3870603
	],
	[
		"s3870604",
		"Prunus urotaenia",
		"prunus",
		3870604
	],
	[
		"s391057",
		"Prunus ursina",
		"prunus",
		391057
	],
	[
		"s3870605",
		"Prunus urumiensis",
		"prunus",
		3870605
	],
	[
		"s391058",
		"Prunus ussuriensis",
		"prunus",
		391058
	],
	[
		"s3870606",
		"Prunus vachuschtii",
		"prunus",
		3870606
	],
	[
		"s552840",
		"Prunus vana",
		"prunus",
		552840
	],
	[
		"s2291149",
		"Prunus vaniotii",
		"prunus",
		2291149
	],
	[
		"s3870607",
		"Prunus veitchii",
		"prunus",
		3870607
	],
	[
		"s3091689",
		"Prunus velutina",
		"prunus",
		3091689
	],
	[
		"s3091690",
		"Prunus venosa",
		"prunus",
		3091690
	],
	[
		"s3091691",
		"Prunus verrucosa",
		"prunus",
		3091691
	],
	[
		"s3091692",
		"Prunus versteeghii",
		"prunus",
		3091692
	],
	[
		"s133204",
		"Prunus virginiana",
		"prunus",
		133204
	],
	[
		"s3870608",
		"Prunus walkeri",
		"prunus",
		3870608
	],
	[
		"s2576278",
		"Prunus wallaceana",
		"prunus",
		2576278
	],
	[
		"s151333",
		"Prunus webbii",
		"prunus",
		151333
	],
	[
		"s1431469",
		"Prunus wendelboi",
		"prunus",
		1431469
	],
	[
		"s983205",
		"Prunus wilsonii",
		"prunus",
		983205
	],
	[
		"s3870609",
		"Prunus wurdackii",
		"prunus",
		3870609
	],
	[
		"s1398537",
		"Prunus x cistena",
		"prunus",
		1398537
	],
	[
		"s1963777",
		"Prunus x dasycarpa",
		"prunus",
		1963777
	],
	[
		"s1642850",
		"Prunus x eminens",
		"prunus",
		1642850
	],
	[
		"s2597810",
		"Prunus x fruticans",
		"prunus",
		2597810
	],
	[
		"s2518327",
		"Prunus x introrsa",
		"prunus",
		2518327
	],
	[
		"s749919",
		"Prunus x keredjensis",
		"prunus",
		749919
	],
	[
		"s1642851",
		"Prunus x mochidzukiana",
		"prunus",
		1642851
	],
	[
		"s3870610",
		"Prunus xianjuxing",
		"prunus",
		3870610
	],
	[
		"s3870611",
		"Prunus xingshanensis",
		"prunus",
		3870611
	],
	[
		"s1813371",
		"Prunus xueluoensis",
		"prunus",
		1813371
	],
	[
		"s1643559",
		"Prunus yaoiana",
		"prunus",
		1643559
	],
	[
		"s3870612",
		"Prunus yazdiana",
		"prunus",
		3870612
	],
	[
		"s3759",
		"Prunus yedoensis",
		"prunus",
		3759
	],
	[
		"s2518595",
		"Prunus yedoensis x Prunus campanulata",
		"prunus",
		2518595
	],
	[
		"s2986970",
		"Prunus yedoensis x Prunus itosakura",
		"prunus",
		2986970
	],
	[
		"s2986969",
		"Prunus yedoensis x Prunus speciosa",
		"prunus",
		2986969
	],
	[
		"s2828042",
		"Prunus yedoensis x Prunus subhirtella",
		"prunus",
		2828042
	],
	[
		"s2901893",
		"Prunus yunkaishanensis",
		"prunus",
		2901893
	],
	[
		"s1642872",
		"Prunus yunnanensis",
		"prunus",
		1642872
	],
	[
		"s3870613",
		"Prunus zabulica",
		"prunus",
		3870613
	],
	[
		"s1052178",
		"Prunus zhengheensis",
		"prunus",
		1052178
	],
	[
		"s3402843",
		"Prunus zhuxiensis",
		"prunus",
		3402843
	],
	[
		"s3870614",
		"Prunus zielinskii",
		"prunus",
		3870614
	],
	[
		"s3870615",
		"Prunus zinggii",
		"prunus",
		3870615
	],
	[
		"s232787",
		"Prunus zippeliana",
		"prunus",
		232787
	],
	[
		"s36622",
		"Pseudocydonia sinensis",
		"pseudocydonia",
		36622
	],
	[
		"s3870806",
		"Pseudolmedia boliviana",
		"pseudolmedia",
		3870806
	],
	[
		"s3870807",
		"Pseudolmedia gentryi",
		"pseudolmedia",
		3870807
	],
	[
		"s2771402",
		"Pseudolmedia glabrata",
		"pseudolmedia",
		2771402
	],
	[
		"s2771403",
		"Pseudolmedia hirtula",
		"pseudolmedia",
		2771403
	],
	[
		"s241915",
		"Pseudolmedia laevigata",
		"pseudolmedia",
		241915
	],
	[
		"s241916",
		"Pseudolmedia laevis",
		"pseudolmedia",
		241916
	],
	[
		"s241917",
		"Pseudolmedia macrophylla",
		"pseudolmedia",
		241917
	],
	[
		"s3870808",
		"Pseudolmedia manabiensis",
		"pseudolmedia",
		3870808
	],
	[
		"s3870809",
		"Pseudolmedia mollis",
		"pseudolmedia",
		3870809
	],
	[
		"s2771404",
		"Pseudolmedia rigida",
		"pseudolmedia",
		2771404
	],
	[
		"s241918",
		"Pseudolmedia spuria",
		"pseudolmedia",
		241918
	],
	[
		"s2887222",
		"Pseudomorus brunoniana",
		"pseudomorus",
		2887222
	],
	[
		"s714510",
		"Pseudostreblus indicus",
		"pseudostreblus",
		714510
	],
	[
		"s345806",
		"Pseudoziziphus celata",
		"pseudoziziphus",
		345806
	],
	[
		"s1226772",
		"Pseudoziziphus parryi",
		"pseudoziziphus",
		1226772
	],
	[
		"s63062",
		"Pteroceltis tatarinowii",
		"pteroceltis",
		63062
	],
	[
		"s3091417",
		"Purshia ericifolia",
		"purshia",
		3091417
	],
	[
		"s3091706",
		"Purshia glandulosa",
		"purshia",
		3091706
	],
	[
		"s1795987",
		"Purshia mexicana",
		"purshia",
		1795987
	],
	[
		"s1841638",
		"Purshia plicata",
		"purshia",
		1841638
	],
	[
		"s48229",
		"Purshia stansburyana",
		"purshia",
		48229
	],
	[
		"s3091418",
		"Purshia subintegra",
		"purshia",
		3091418
	],
	[
		"s32243",
		"Purshia tridentata",
		"purshia",
		32243
	],
	[
		"s1170646",
		"Pygeum ceylanica",
		"pygeum",
		1170646
	],
	[
		"s1679317",
		"Pygeum macrocarpum",
		"pygeum",
		1679317
	],
	[
		"s1170648",
		"Pygeum maingayi",
		"pygeum",
		1170648
	],
	[
		"s1188057",
		"Pygeum oblongum",
		"pygeum",
		1188057
	],
	[
		"s2576280",
		"Pygeum patens",
		"pygeum",
		2576280
	],
	[
		"s1170650",
		"Pygeum sessiliflorum",
		"pygeum",
		1170650
	],
	[
		"s1205771",
		"Pygeum zeylanicum",
		"pygeum",
		1205771
	],
	[
		"s690342",
		"Pyracantha angustifolia",
		"pyracantha",
		690342
	],
	[
		"s2306257",
		"Pyracantha atalantioides",
		"pyracantha",
		2306257
	],
	[
		"s193309",
		"Pyracantha coccinea",
		"pyracantha",
		193309
	],
	[
		"s3091419",
		"Pyracantha crenatoserrata",
		"pyracantha",
		3091419
	],
	[
		"s1044925",
		"Pyracantha crenulata",
		"pyracantha",
		1044925
	],
	[
		"s3091707",
		"Pyracantha densiflora",
		"pyracantha",
		3091707
	],
	[
		"s144562",
		"Pyracantha fortuneana",
		"pyracantha",
		144562
	],
	[
		"s3091708",
		"Pyracantha inermis",
		"pyracantha",
		3091708
	],
	[
		"s3015654",
		"Pyracantha koidzumii",
		"pyracantha",
		3015654
	],
	[
		"s3091420",
		"Pyracantha rogersiana",
		"pyracantha",
		3091420
	],
	[
		"s3872278",
		"Pyrus acutiserrata",
		"pyrus",
		3872278
	],
	[
		"s3872279",
		"Pyrus alpinotaiwaniana",
		"pyrus",
		3872279
	],
	[
		"s470518",
		"Pyrus amygdaliformis",
		"pyrus",
		470518
	],
	[
		"s1943538",
		"Pyrus argyrophylla",
		"pyrus",
		1943538
	],
	[
		"s3872280",
		"Pyrus asiae-mediae",
		"pyrus",
		3872280
	],
	[
		"s436086",
		"Pyrus betulifolia",
		"pyrus",
		436086
	],
	[
		"s1565113",
		"Pyrus boissieriana",
		"pyrus",
		1565113
	],
	[
		"s2720245",
		"Pyrus bourgaeana",
		"pyrus",
		2720245
	],
	[
		"s3872281",
		"Pyrus browiczii",
		"pyrus",
		3872281
	],
	[
		"s3872282",
		"Pyrus cajon",
		"pyrus",
		3872282
	],
	[
		"s36597",
		"Pyrus calleryana",
		"pyrus",
		36597
	],
	[
		"s3872283",
		"Pyrus castribonensis",
		"pyrus",
		3872283
	],
	[
		"s1943546",
		"Pyrus cf. hyrcana MG-2017",
		"pyrus",
		1943546
	],
	[
		"s1943540",
		"Pyrus chosrovica",
		"pyrus",
		1943540
	],
	[
		"s3872284",
		"Pyrus ciancioi",
		"pyrus",
		3872284
	],
	[
		"s23211",
		"Pyrus communis",
		"pyrus",
		23211
	],
	[
		"s633654",
		"Pyrus communis x Pyrus pyrifolia",
		"pyrus",
		633654
	],
	[
		"s352373",
		"Pyrus communis x Pyrus ussuriensis",
		"pyrus",
		352373
	],
	[
		"s3872285",
		"Pyrus complexa",
		"pyrus",
		3872285
	],
	[
		"s761867",
		"Pyrus cordata",
		"pyrus",
		761867
	],
	[
		"s3872286",
		"Pyrus cordifolia",
		"pyrus",
		3872286
	],
	[
		"s470524",
		"Pyrus cossonii",
		"pyrus",
		470524
	],
	[
		"s3872287",
		"Pyrus costata",
		"pyrus",
		3872287
	],
	[
		"s2911580",
		"Pyrus demetrii",
		"pyrus",
		2911580
	],
	[
		"s470519",
		"Pyrus dimorphophylla",
		"pyrus",
		470519
	],
	[
		"s147046",
		"Pyrus elaeagrifolia",
		"pyrus",
		147046
	],
	[
		"s1943541",
		"Pyrus elata",
		"pyrus",
		1943541
	],
	[
		"s3872288",
		"Pyrus eldarica",
		"pyrus",
		3872288
	],
	[
		"s470520",
		"Pyrus fauriei",
		"pyrus",
		470520
	],
	[
		"s1943542",
		"Pyrus fedorovii",
		"pyrus",
		1943542
	],
	[
		"s3872289",
		"Pyrus ferganensis",
		"pyrus",
		3872289
	],
	[
		"s1943543",
		"Pyrus georgica",
		"pyrus",
		1943543
	],
	[
		"s3872290",
		"Pyrus gergeriana",
		"pyrus",
		3872290
	],
	[
		"s1565114",
		"Pyrus ghahremanii",
		"pyrus",
		1565114
	],
	[
		"s935638",
		"Pyrus gharbiana",
		"pyrus",
		935638
	],
	[
		"s1565115",
		"Pyrus glabra",
		"pyrus",
		1565115
	],
	[
		"s1943544",
		"Pyrus grossheimii",
		"pyrus",
		1943544
	],
	[
		"s3872291",
		"Pyrus hakkiarica",
		"pyrus",
		3872291
	],
	[
		"s470521",
		"Pyrus hondoensis",
		"pyrus",
		470521
	],
	[
		"s470522",
		"Pyrus hopeiensis",
		"pyrus",
		470522
	],
	[
		"s239770",
		"Pyrus hybrid cultivar",
		"pyrus",
		239770
	],
	[
		"s2902760",
		"Pyrus hybrid rootstock",
		"pyrus",
		2902760
	],
	[
		"s1943545",
		"Pyrus hyrcana",
		"pyrus",
		1943545
	],
	[
		"s3872292",
		"Pyrus jacquemontiana",
		"pyrus",
		3872292
	],
	[
		"s3872293",
		"Pyrus ketzkhovelii",
		"pyrus",
		3872293
	],
	[
		"s470523",
		"Pyrus koehnei",
		"pyrus",
		470523
	],
	[
		"s586327",
		"Pyrus korshinskyi",
		"pyrus",
		586327
	],
	[
		"s1943547",
		"Pyrus lindleyi",
		"pyrus",
		1943547
	],
	[
		"s1943548",
		"Pyrus magyarica",
		"pyrus",
		1943548
	],
	[
		"s935639",
		"Pyrus mamorensis",
		"pyrus",
		935639
	],
	[
		"s3872294",
		"Pyrus mazanderanica",
		"pyrus",
		3872294
	],
	[
		"s1943549",
		"Pyrus medvedevii",
		"pyrus",
		1943549
	],
	[
		"s1943550",
		"Pyrus megrica",
		"pyrus",
		1943550
	],
	[
		"s470528",
		"Pyrus neoserrulata",
		"pyrus",
		470528
	],
	[
		"s1943551",
		"Pyrus nutans",
		"pyrus",
		1943551
	],
	[
		"s1943552",
		"Pyrus oxyprion",
		"pyrus",
		1943552
	],
	[
		"s470525",
		"Pyrus pashia",
		"pyrus",
		470525
	],
	[
		"s3872295",
		"Pyrus pedrottiana",
		"pyrus",
		3872295
	],
	[
		"s470526",
		"Pyrus phaeocarpa",
		"pyrus",
		470526
	],
	[
		"s470527",
		"Pyrus pseudopashia",
		"pyrus",
		470527
	],
	[
		"s356590",
		"Pyrus pyraster",
		"pyrus",
		356590
	],
	[
		"s3767",
		"Pyrus pyrifolia",
		"pyrus",
		3767
	],
	[
		"s2588587",
		"Pyrus pyrifolia x Pyrus communis",
		"pyrus",
		2588587
	],
	[
		"s2927084",
		"Pyrus raddeana",
		"pyrus",
		2927084
	],
	[
		"s935640",
		"Pyrus regelii",
		"pyrus",
		935640
	],
	[
		"s3384921",
		"Pyrus sachokiana",
		"pyrus",
		3384921
	],
	[
		"s106573",
		"Pyrus salicifolia",
		"pyrus",
		106573
	],
	[
		"s3872296",
		"Pyrus sicanorum",
		"pyrus",
		3872296
	],
	[
		"s363829",
		"Pyrus sinkiangensis",
		"pyrus",
		363829
	],
	[
		"s2653926",
		"Pyrus sinkiangensis x Pyrus pyrifolia",
		"pyrus",
		2653926
	],
	[
		"s3872297",
		"Pyrus sogdiana",
		"pyrus",
		3872297
	],
	[
		"s1943553",
		"Pyrus sosnovskyi",
		"pyrus",
		1943553
	],
	[
		"s1143245",
		"Pyrus spinosa",
		"pyrus",
		1143245
	],
	[
		"s500142",
		"Pyrus syriaca",
		"pyrus",
		500142
	],
	[
		"s3872298",
		"Pyrus tadshikistanica",
		"pyrus",
		3872298
	],
	[
		"s1943554",
		"Pyrus takhtadzhianii",
		"pyrus",
		1943554
	],
	[
		"s1943555",
		"Pyrus tamamschianae",
		"pyrus",
		1943555
	],
	[
		"s3872299",
		"Pyrus terpoi",
		"pyrus",
		3872299
	],
	[
		"s3872300",
		"Pyrus theodorovii",
		"pyrus",
		3872300
	],
	[
		"s2967311",
		"Pyrus trilocularis",
		"pyrus",
		2967311
	],
	[
		"s1943556",
		"Pyrus turcomanica",
		"pyrus",
		1943556
	],
	[
		"s3872301",
		"Pyrus tuskaulensis",
		"pyrus",
		3872301
	],
	[
		"s309349",
		"Pyrus ussuriensis",
		"pyrus",
		309349
	],
	[
		"s2448454",
		"Pyrus ussuriensis x Pyrus communis",
		"pyrus",
		2448454
	],
	[
		"s3454945",
		"Pyrus uyematsuana",
		"pyrus",
		3454945
	],
	[
		"s3872302",
		"Pyrus voronovii",
		"pyrus",
		3872302
	],
	[
		"s3872303",
		"Pyrus vsevolodovii",
		"pyrus",
		3872303
	],
	[
		"s225117",
		"Pyrus x bretschneideri",
		"pyrus",
		225117
	],
	[
		"s561258",
		"Pyrus x bretschneideri x Pyrus communis",
		"pyrus",
		561258
	],
	[
		"s1663675",
		"Pyrus x bretschneideri x Pyrus pyrifolia",
		"pyrus",
		1663675
	],
	[
		"s1943537",
		"Pyrus x daralagezii",
		"pyrus",
		1943537
	],
	[
		"s3899393",
		"Pyrus x michauxii",
		"pyrus",
		3899393
	],
	[
		"s935637",
		"Pyrus x nivalis",
		"pyrus",
		935637
	],
	[
		"s3128508",
		"Pyrus x sinkiangensis",
		"pyrus",
		3128508
	],
	[
		"s470529",
		"Pyrus xerophila",
		"pyrus",
		470529
	],
	[
		"s3872304",
		"Pyrus yaltirikii",
		"pyrus",
		3872304
	],
	[
		"s1943557",
		"Pyrus zangezura",
		"pyrus",
		1943557
	],
	[
		"s106700",
		"Reissekia smilacina",
		"reissekia",
		106700
	],
	[
		"s262941",
		"Retanilla ephedra",
		"retanilla",
		262941
	],
	[
		"s262942",
		"Retanilla patagonica",
		"retanilla",
		262942
	],
	[
		"s262943",
		"Retanilla stricta",
		"retanilla",
		262943
	],
	[
		"s48247",
		"Retanilla trinervia",
		"retanilla",
		48247
	],
	[
		"s3874318",
		"Reynosia affinis",
		"reynosia",
		3874318
	],
	[
		"s1812994",
		"Reynosia camagueyensis",
		"reynosia",
		1812994
	],
	[
		"s3874319",
		"Reynosia cuneifolia",
		"reynosia",
		3874319
	],
	[
		"s3091722",
		"Reynosia domingensis",
		"reynosia",
		3091722
	],
	[
		"s3091723",
		"Reynosia guama",
		"reynosia",
		3091723
	],
	[
		"s3874320",
		"Reynosia jamaicensis",
		"reynosia",
		3874320
	],
	[
		"s1465349",
		"Reynosia krugii",
		"reynosia",
		1465349
	],
	[
		"s3874321",
		"Reynosia latifolia",
		"reynosia",
		3874321
	],
	[
		"s3874322",
		"Reynosia microphylla",
		"reynosia",
		3874322
	],
	[
		"s3874323",
		"Reynosia moaensis",
		"reynosia",
		3874323
	],
	[
		"s3091724",
		"Reynosia mucronata",
		"reynosia",
		3091724
	],
	[
		"s3874324",
		"Reynosia regia",
		"reynosia",
		3874324
	],
	[
		"s3874325",
		"Reynosia retusa",
		"reynosia",
		3874325
	],
	[
		"s1226765",
		"Reynosia septentrionalis",
		"reynosia",
		1226765
	],
	[
		"s106702",
		"Reynosia uncinata",
		"reynosia",
		106702
	],
	[
		"s1465360",
		"Reynosia vivesiana",
		"reynosia",
		1465360
	],
	[
		"s3874326",
		"Reynosia wrightii",
		"reynosia",
		3874326
	],
	[
		"s2753858",
		"Rhamnella brachycarpa",
		"rhamnella",
		2753858
	],
	[
		"s3091725",
		"Rhamnella caudata",
		"rhamnella",
		3091725
	],
	[
		"s3091726",
		"Rhamnella forrestii",
		"rhamnella",
		3091726
	],
	[
		"s106704",
		"Rhamnella franguloides",
		"rhamnella",
		106704
	],
	[
		"s1630244",
		"Rhamnella gilgitica",
		"rhamnella",
		1630244
	],
	[
		"s2753868",
		"Rhamnella intermedia",
		"rhamnella",
		2753868
	],
	[
		"s3091727",
		"Rhamnella julianae",
		"rhamnella",
		3091727
	],
	[
		"s1812995",
		"Rhamnella martinii",
		"rhamnella",
		1812995
	],
	[
		"s2594499",
		"Rhamnella rubrinervis",
		"rhamnella",
		2594499
	],
	[
		"s2753859",
		"Rhamnella tonkinensis",
		"rhamnella",
		2753859
	],
	[
		"s1382012",
		"Rhamnella vitiensis",
		"rhamnella",
		1382012
	],
	[
		"s2930418",
		"Rhamnella wilsonii",
		"rhamnella",
		2930418
	],
	[
		"s3810681",
		"Rhamnidium brevifolium",
		"rhamnidium",
		3810681
	],
	[
		"s3810682",
		"Rhamnidium dictyophyllum",
		"rhamnidium",
		3810682
	],
	[
		"s106706",
		"Rhamnidium elaeocarpum",
		"rhamnidium",
		106706
	],
	[
		"s3810683",
		"Rhamnidium ellipticum",
		"rhamnidium",
		3810683
	],
	[
		"s1226766",
		"Rhamnidium glabrum",
		"rhamnidium",
		1226766
	],
	[
		"s1226767",
		"Rhamnidium hasslerianum",
		"rhamnidium",
		1226767
	],
	[
		"s3091728",
		"Rhamnidium molle",
		"rhamnidium",
		3091728
	],
	[
		"s3810684",
		"Rhamnidium nipense",
		"rhamnidium",
		3810684
	],
	[
		"s3810685",
		"Rhamnidium pruinosum",
		"rhamnidium",
		3810685
	],
	[
		"s3810686",
		"Rhamnidium riograndense",
		"rhamnidium",
		3810686
	],
	[
		"s3810687",
		"Rhamnidium shaferi",
		"rhamnidium",
		3810687
	],
	[
		"s280017",
		"Rhamnus alaternus",
		"rhamnus",
		280017
	],
	[
		"s280016",
		"Rhamnus alpina",
		"rhamnus",
		280016
	],
	[
		"s1813047",
		"Rhamnus arguta",
		"rhamnus",
		1813047
	],
	[
		"s3810688",
		"Rhamnus arnottiana",
		"rhamnus",
		3810688
	],
	[
		"s1813048",
		"Rhamnus aurea",
		"rhamnus",
		1813048
	],
	[
		"s3810689",
		"Rhamnus baldschuanica",
		"rhamnus",
		3810689
	],
	[
		"s3086316",
		"Rhamnus biglandulosa",
		"rhamnus",
		3086316
	],
	[
		"s1813049",
		"Rhamnus bodinieri",
		"rhamnus",
		1813049
	],
	[
		"s3091729",
		"Rhamnus brachypoda",
		"rhamnus",
		3091729
	],
	[
		"s3091730",
		"Rhamnus bungeana",
		"rhamnus",
		3091730
	],
	[
		"s3050878",
		"Rhamnus calcicola",
		"rhamnus",
		3050878
	],
	[
		"s3610",
		"Rhamnus cathartica",
		"rhamnus",
		3610
	],
	[
		"s1821543",
		"Rhamnus cathartica x Rhamnus saxatilis",
		"rhamnus",
		1821543
	],
	[
		"s2984747",
		"Rhamnus cf. staddo QZ-2022",
		"rhamnus",
		2984747
	],
	[
		"s2803342",
		"Rhamnus chingshuiensis",
		"rhamnus",
		2803342
	],
	[
		"s2982851",
		"Rhamnus chugokuensis",
		"rhamnus",
		2982851
	],
	[
		"s3810690",
		"Rhamnus collettii",
		"rhamnus",
		3810690
	],
	[
		"s3050879",
		"Rhamnus coriophylla",
		"rhamnus",
		3050879
	],
	[
		"s3144235",
		"Rhamnus cornifolia",
		"rhamnus",
		3144235
	],
	[
		"s1813077",
		"Rhamnus costata",
		"rhamnus",
		1813077
	],
	[
		"s280014",
		"Rhamnus crenata",
		"rhamnus",
		280014
	],
	[
		"s280018",
		"Rhamnus crenulata",
		"rhamnus",
		280018
	],
	[
		"s280019",
		"Rhamnus crocea",
		"rhamnus",
		280019
	],
	[
		"s3810691",
		"Rhamnus dalianensis",
		"rhamnus",
		3810691
	],
	[
		"s3810692",
		"Rhamnus daliensis",
		"rhamnus",
		3810692
	],
	[
		"s105902",
		"Rhamnus davurica",
		"rhamnus",
		105902
	],
	[
		"s3810693",
		"Rhamnus depressa",
		"rhamnus",
		3810693
	],
	[
		"s1813050",
		"Rhamnus diamantiaca",
		"rhamnus",
		1813050
	],
	[
		"s3027757",
		"Rhamnus diffusa",
		"rhamnus",
		3027757
	],
	[
		"s1813078",
		"Rhamnus disperma",
		"rhamnus",
		1813078
	],
	[
		"s3810694",
		"Rhamnus dolichophylla",
		"rhamnus",
		3810694
	],
	[
		"s1813051",
		"Rhamnus dumetorum",
		"rhamnus",
		1813051
	],
	[
		"s3091430",
		"Rhamnus erythroxyloides",
		"rhamnus",
		3091430
	],
	[
		"s1813079",
		"Rhamnus erythroxylon",
		"rhamnus",
		1813079
	],
	[
		"s2768815",
		"Rhamnus erythroxylum",
		"rhamnus",
		2768815
	],
	[
		"s280020",
		"Rhamnus esquirolii",
		"rhamnus",
		280020
	],
	[
		"s1813052",
		"Rhamnus flavescens",
		"rhamnus",
		1813052
	],
	[
		"s1813053",
		"Rhamnus formosana",
		"rhamnus",
		1813053
	],
	[
		"s1819794",
		"Rhamnus fulvotincta",
		"rhamnus",
		1819794
	],
	[
		"s1813054",
		"Rhamnus gilgiana",
		"rhamnus",
		1813054
	],
	[
		"s280021",
		"Rhamnus glandulosa",
		"rhamnus",
		280021
	],
	[
		"s1616486",
		"Rhamnus globosa",
		"rhamnus",
		1616486
	],
	[
		"s3050880",
		"Rhamnus grandiflora",
		"rhamnus",
		3050880
	],
	[
		"s1813062",
		"Rhamnus grubovii",
		"rhamnus",
		1813062
	],
	[
		"s1819795",
		"Rhamnus hainanensis",
		"rhamnus",
		1819795
	],
	[
		"s1813080",
		"Rhamnus heldreichii",
		"rhamnus",
		1813080
	],
	[
		"s1813056",
		"Rhamnus hemsleyana",
		"rhamnus",
		1813056
	],
	[
		"s2291152",
		"Rhamnus heterophylla",
		"rhamnus",
		2291152
	],
	[
		"s1813081",
		"Rhamnus hirtella",
		"rhamnus",
		1813081
	],
	[
		"s3091731",
		"Rhamnus hupehensis",
		"rhamnus",
		3091731
	],
	[
		"s1566429",
		"Rhamnus integrifolia",
		"rhamnus",
		1566429
	],
	[
		"s3810695",
		"Rhamnus ishidae",
		"rhamnus",
		3810695
	],
	[
		"s1813058",
		"Rhamnus iteinophylla",
		"rhamnus",
		1813058
	],
	[
		"s860326",
		"Rhamnus japonica",
		"rhamnus",
		860326
	],
	[
		"s1813083",
		"Rhamnus kanagusukii",
		"rhamnus",
		1813083
	],
	[
		"s3810696",
		"Rhamnus kayacikii",
		"rhamnus",
		3810696
	],
	[
		"s1577576",
		"Rhamnus koraiensis",
		"rhamnus",
		1577576
	],
	[
		"s1813059",
		"Rhamnus kurdica",
		"rhamnus",
		1813059
	],
	[
		"s3810697",
		"Rhamnus kwangsiensis",
		"rhamnus",
		3810697
	],
	[
		"s1813060",
		"Rhamnus lamprophylla",
		"rhamnus",
		1813060
	],
	[
		"s3810698",
		"Rhamnus laoshanensis",
		"rhamnus",
		3810698
	],
	[
		"s3810699",
		"Rhamnus ledermannii",
		"rhamnus",
		3810699
	],
	[
		"s3064228",
		"Rhamnus leptacantha",
		"rhamnus",
		3064228
	],
	[
		"s1603822",
		"Rhamnus leptophylla",
		"rhamnus",
		1603822
	],
	[
		"s1813084",
		"Rhamnus libanotica",
		"rhamnus",
		1813084
	],
	[
		"s3810700",
		"Rhamnus liboensis",
		"rhamnus",
		3810700
	],
	[
		"s1813061",
		"Rhamnus liukiuensis",
		"rhamnus",
		1813061
	],
	[
		"s1813085",
		"Rhamnus lojaconoi",
		"rhamnus",
		1813085
	],
	[
		"s1813086",
		"Rhamnus ludovici-salvatoris",
		"rhamnus",
		1813086
	],
	[
		"s72169",
		"Rhamnus lycioides",
		"rhamnus",
		72169
	],
	[
		"s2768816",
		"Rhamnus maximovicziana",
		"rhamnus",
		2768816
	],
	[
		"s3144272",
		"Rhamnus mehreganii",
		"rhamnus",
		3144272
	],
	[
		"s3091732",
		"Rhamnus microcarpa",
		"rhamnus",
		3091732
	],
	[
		"s3810701",
		"Rhamnus mildbraedii",
		"rhamnus",
		3810701
	],
	[
		"s3810702",
		"Rhamnus minnanensis",
		"rhamnus",
		3810702
	],
	[
		"s3810703",
		"Rhamnus mollis",
		"rhamnus",
		3810703
	],
	[
		"s3810704",
		"Rhamnus mongolica",
		"rhamnus",
		3810704
	],
	[
		"s2053683",
		"Rhamnus myrtifolia",
		"rhamnus",
		2053683
	],
	[
		"s1813207",
		"Rhamnus nakaharae",
		"rhamnus",
		1813207
	],
	[
		"s3091427",
		"Rhamnus napalensis",
		"rhamnus",
		3091427
	],
	[
		"s3810705",
		"Rhamnus nigrescens",
		"rhamnus",
		3810705
	],
	[
		"s1813063",
		"Rhamnus nigricans",
		"rhamnus",
		1813063
	],
	[
		"s3810706",
		"Rhamnus ninglangensis",
		"rhamnus",
		3810706
	],
	[
		"s3810707",
		"Rhamnus nitida",
		"rhamnus",
		3810707
	],
	[
		"s1813064",
		"Rhamnus oleoides",
		"rhamnus",
		1813064
	],
	[
		"s1819796",
		"Rhamnus orbiculata",
		"rhamnus",
		1819796
	],
	[
		"s1813088",
		"Rhamnus palaestina",
		"rhamnus",
		1813088
	],
	[
		"s1813065",
		"Rhamnus pallasii",
		"rhamnus",
		1813065
	],
	[
		"s1813089",
		"Rhamnus papuana",
		"rhamnus",
		1813089
	],
	[
		"s1226768",
		"Rhamnus parvifolia",
		"rhamnus",
		1226768
	],
	[
		"s1813090",
		"Rhamnus pendula",
		"rhamnus",
		1813090
	],
	[
		"s1630245",
		"Rhamnus pentapomica",
		"rhamnus",
		1630245
	],
	[
		"s1630246",
		"Rhamnus persica",
		"rhamnus",
		1630246
	],
	[
		"s2720248",
		"Rhamnus persicifolia",
		"rhamnus",
		2720248
	],
	[
		"s3810708",
		"Rhamnus petiolaris",
		"rhamnus",
		3810708
	],
	[
		"s3810709",
		"Rhamnus philippinensis",
		"rhamnus",
		3810709
	],
	[
		"s1813091",
		"Rhamnus pilushanensis",
		"rhamnus",
		1813091
	],
	[
		"s1814966",
		"Rhamnus pompana",
		"rhamnus",
		1814966
	],
	[
		"s280022",
		"Rhamnus prinoides",
		"rhamnus",
		280022
	],
	[
		"s1813066",
		"Rhamnus procumbens",
		"rhamnus",
		1813066
	],
	[
		"s1813067",
		"Rhamnus prostrata",
		"rhamnus",
		1813067
	],
	[
		"s1433213",
		"Rhamnus prunifolia",
		"rhamnus",
		1433213
	],
	[
		"s1813092",
		"Rhamnus pulogensis",
		"rhamnus",
		1813092
	],
	[
		"s1778787",
		"Rhamnus punctata",
		"rhamnus",
		1778787
	],
	[
		"s280024",
		"Rhamnus purpurea",
		"rhamnus",
		280024
	],
	[
		"s3810710",
		"Rhamnus pyrella",
		"rhamnus",
		3810710
	],
	[
		"s3810711",
		"Rhamnus qianweiensis",
		"rhamnus",
		3810711
	],
	[
		"s3144273",
		"Rhamnus rahiminejadii",
		"rhamnus",
		3144273
	],
	[
		"s1813093",
		"Rhamnus rhodopea",
		"rhamnus",
		1813093
	],
	[
		"s3091733",
		"Rhamnus rosei",
		"rhamnus",
		3091733
	],
	[
		"s3091734",
		"Rhamnus rosthornii",
		"rhamnus",
		3091734
	],
	[
		"s1813068",
		"Rhamnus rugulosa",
		"rhamnus",
		1813068
	],
	[
		"s1819797",
		"Rhamnus sagorskii",
		"rhamnus",
		1819797
	],
	[
		"s3810712",
		"Rhamnus salixiophylla",
		"rhamnus",
		3810712
	],
	[
		"s1813069",
		"Rhamnus sargentiana",
		"rhamnus",
		1813069
	],
	[
		"s280025",
		"Rhamnus saxatilis",
		"rhamnus",
		280025
	],
	[
		"s3810713",
		"Rhamnus schlechteri",
		"rhamnus",
		3810713
	],
	[
		"s860327",
		"Rhamnus schneideri",
		"rhamnus",
		860327
	],
	[
		"s3810714",
		"Rhamnus seravschanica",
		"rhamnus",
		3810714
	],
	[
		"s3810715",
		"Rhamnus serpyllacea",
		"rhamnus",
		3810715
	],
	[
		"s3810716",
		"Rhamnus songmaoensis",
		"rhamnus",
		3810716
	],
	[
		"s1813071",
		"Rhamnus songorica",
		"rhamnus",
		1813071
	],
	[
		"s1813095",
		"Rhamnus spathulifolia",
		"rhamnus",
		1813095
	],
	[
		"s1465361",
		"Rhamnus sphaerosperma",
		"rhamnus",
		1465361
	],
	[
		"s280026",
		"Rhamnus staddo",
		"rhamnus",
		280026
	],
	[
		"s3091735",
		"Rhamnus standleyana",
		"rhamnus",
		3091735
	],
	[
		"s1813096",
		"Rhamnus subapetala",
		"rhamnus",
		1813096
	],
	[
		"s3810717",
		"Rhamnus sumatrensis",
		"rhamnus",
		3810717
	],
	[
		"s3810718",
		"Rhamnus sumbawana",
		"rhamnus",
		3810718
	],
	[
		"s1813072",
		"Rhamnus tangutica",
		"rhamnus",
		1813072
	],
	[
		"s1577577",
		"Rhamnus taquetii",
		"rhamnus",
		1577577
	],
	[
		"s3810719",
		"Rhamnus thymifolia",
		"rhamnus",
		3810719
	],
	[
		"s3810720",
		"Rhamnus tonkinensis",
		"rhamnus",
		3810720
	],
	[
		"s3810721",
		"Rhamnus tortuosa",
		"rhamnus",
		3810721
	],
	[
		"s1630247",
		"Rhamnus triquetra",
		"rhamnus",
		1630247
	],
	[
		"s3810722",
		"Rhamnus tzekweiensis",
		"rhamnus",
		3810722
	],
	[
		"s1577578",
		"Rhamnus ussuriensis",
		"rhamnus",
		1577578
	],
	[
		"s1037062",
		"Rhamnus utilis",
		"rhamnus",
		1037062
	],
	[
		"s3810723",
		"Rhamnus velutina",
		"rhamnus",
		3810723
	],
	[
		"s1630248",
		"Rhamnus virgata",
		"rhamnus",
		1630248
	],
	[
		"s1819798",
		"Rhamnus wightii",
		"rhamnus",
		1819798
	],
	[
		"s1813074",
		"Rhamnus wilsonii",
		"rhamnus",
		1813074
	],
	[
		"s3091736",
		"Rhamnus wumingensis",
		"rhamnus",
		3091736
	],
	[
		"s3092072",
		"Rhamnus x intermedia",
		"rhamnus",
		3092072
	],
	[
		"s1813075",
		"Rhamnus xizangensis",
		"rhamnus",
		1813075
	],
	[
		"s1577579",
		"Rhamnus yoshinoi",
		"rhamnus",
		1577579
	],
	[
		"s2890411",
		"Rhaphiolepis brevipetiolata",
		"rhaphiolepis",
		2890411
	],
	[
		"s2675834",
		"Rhaphiolepis ferruginea",
		"rhaphiolepis",
		2675834
	],
	[
		"s2675829",
		"Rhaphiolepis impressivena",
		"rhaphiolepis",
		2675829
	],
	[
		"s36624",
		"Rhaphiolepis indica",
		"rhaphiolepis",
		36624
	],
	[
		"s3447177",
		"Rhaphiolepis jiulongjiangensis",
		"rhaphiolepis",
		3447177
	],
	[
		"s2675835",
		"Rhaphiolepis lanceolata",
		"rhaphiolepis",
		2675835
	],
	[
		"s2675836",
		"Rhaphiolepis major",
		"rhaphiolepis",
		2675836
	],
	[
		"s3810798",
		"Rhaphiolepis oblongifolia",
		"rhaphiolepis",
		3810798
	],
	[
		"s2905425",
		"Rhaphiolepis philippinensis",
		"rhaphiolepis",
		2905425
	],
	[
		"s1603823",
		"Rhaphiolepis salicifolia",
		"rhaphiolepis",
		1603823
	],
	[
		"s398295",
		"Rhaphiolepis umbellata",
		"rhaphiolepis",
		398295
	],
	[
		"s2905426",
		"Rhaphiolepis wuzhishanensis",
		"rhaphiolepis",
		2905426
	],
	[
		"s2024529",
		"Rhaphiolepis x daduheensis",
		"rhaphiolepis",
		2024529
	],
	[
		"s2029341",
		"Rhaphiolepis x delacourii",
		"rhaphiolepis",
		2029341
	],
	[
		"s32245",
		"Rhodotypos scandens",
		"rhodotypos",
		32245
	],
	[
		"s267228",
		"Rosa abietina",
		"rosa",
		267228
	],
	[
		"s3876292",
		"Rosa abrica",
		"rosa",
		3876292
	],
	[
		"s3876293",
		"Rosa abscissa",
		"rosa",
		3876293
	],
	[
		"s3876294",
		"Rosa abutalybovii",
		"rosa",
		3876294
	],
	[
		"s136997",
		"Rosa abyssinica",
		"rosa",
		136997
	],
	[
		"s3091756",
		"Rosa achburensis",
		"rosa",
		3091756
	],
	[
		"s117260",
		"Rosa acicularis",
		"rosa",
		117260
	],
	[
		"s3876295",
		"Rosa agnesii",
		"rosa",
		3876295
	],
	[
		"s267229",
		"Rosa agrestis",
		"rosa",
		267229
	],
	[
		"s3876296",
		"Rosa aharbalensis",
		"rosa",
		3876296
	],
	[
		"s3876297",
		"Rosa alabukensis",
		"rosa",
		3876297
	],
	[
		"s267224",
		"Rosa alba x Rosa corymbifera",
		"rosa",
		267224
	],
	[
		"s396727",
		"Rosa alberti",
		"rosa",
		396727
	],
	[
		"s3876298",
		"Rosa alexeenkoi",
		"rosa",
		3876298
	],
	[
		"s3876299",
		"Rosa altidaghestanica",
		"rosa",
		3876299
	],
	[
		"s3876300",
		"Rosa amblyophylla",
		"rosa",
		3876300
	],
	[
		"s1165904",
		"Rosa amblyotis",
		"rosa",
		1165904
	],
	[
		"s396728",
		"Rosa andegavensis",
		"rosa",
		396728
	],
	[
		"s1608485",
		"Rosa anemoniflora",
		"rosa",
		1608485
	],
	[
		"s2728881",
		"Rosa arabica",
		"rosa",
		2728881
	],
	[
		"s3876301",
		"Rosa arensii",
		"rosa",
		3876301
	],
	[
		"s267231",
		"Rosa arkansana",
		"rosa",
		267231
	],
	[
		"s136998",
		"Rosa arvensis",
		"rosa",
		136998
	],
	[
		"s3373249",
		"Rosa austrotibetana",
		"rosa",
		3373249
	],
	[
		"s3876302",
		"Rosa awarica",
		"rosa",
		3876302
	],
	[
		"s3153348",
		"Rosa baitagensis",
		"rosa",
		3153348
	],
	[
		"s3809261",
		"Rosa baiyushanensis",
		"rosa",
		3809261
	],
	[
		"s3876303",
		"Rosa balakhtensis",
		"rosa",
		3876303
	],
	[
		"s3876304",
		"Rosa balcarica",
		"rosa",
		3876304
	],
	[
		"s2604301",
		"Rosa balsamica",
		"rosa",
		2604301
	],
	[
		"s74651",
		"Rosa banksiae",
		"rosa",
		74651
	],
	[
		"s396729",
		"Rosa banksiopsis",
		"rosa",
		396729
	],
	[
		"s3876305",
		"Rosa barbeyi",
		"rosa",
		3876305
	],
	[
		"s3876306",
		"Rosa beauvaisii",
		"rosa",
		3876306
	],
	[
		"s267232",
		"Rosa beggeriana",
		"rosa",
		267232
	],
	[
		"s396730",
		"Rosa bella",
		"rosa",
		396730
	],
	[
		"s3876307",
		"Rosa bellicosa",
		"rosa",
		3876307
	],
	[
		"s1608486",
		"Rosa berberifolia",
		"rosa",
		1608486
	],
	[
		"s3876308",
		"Rosa bidentata",
		"rosa",
		3876308
	],
	[
		"s3091767",
		"Rosa biebersteiniana",
		"rosa",
		3091767
	],
	[
		"s74640",
		"Rosa blanda",
		"rosa",
		74640
	],
	[
		"s2282113",
		"Rosa blinovskyana",
		"rosa",
		2282113
	],
	[
		"s3091757",
		"Rosa boissieri",
		"rosa",
		3091757
	],
	[
		"s74653",
		"Rosa bracteata",
		"rosa",
		74653
	],
	[
		"s396731",
		"Rosa bridgesii",
		"rosa",
		396731
	],
	[
		"s3876309",
		"Rosa brotherorum",
		"rosa",
		3876309
	],
	[
		"s396891",
		"Rosa brownii",
		"rosa",
		396891
	],
	[
		"s119236",
		"Rosa brunonii",
		"rosa",
		119236
	],
	[
		"s2775116",
		"Rosa bugensis",
		"rosa",
		2775116
	],
	[
		"s3091758",
		"Rosa buschiana",
		"rosa",
		3091758
	],
	[
		"s267233",
		"Rosa caesia",
		"rosa",
		267233
	],
	[
		"s3876310",
		"Rosa calantha",
		"rosa",
		3876310
	],
	[
		"s74641",
		"Rosa californica",
		"rosa",
		74641
	],
	[
		"s74635",
		"Rosa canina",
		"rosa",
		74635
	],
	[
		"s3876311",
		"Rosa cannadas-teydensis",
		"rosa",
		3876311
	],
	[
		"s74638",
		"Rosa carolina",
		"rosa",
		74638
	],
	[
		"s1006178",
		"Rosa caryophyllacea",
		"rosa",
		1006178
	],
	[
		"s396732",
		"Rosa caudata",
		"rosa",
		396732
	],
	[
		"s3177546",
		"Rosa cf. bella",
		"rosa",
		3177546
	],
	[
		"s1843290",
		"Rosa cf. canina OMH-C11",
		"rosa",
		1843290
	],
	[
		"s3177545",
		"Rosa cf. caudata",
		"rosa",
		3177545
	],
	[
		"s3177544",
		"Rosa cf. longicuspis",
		"rosa",
		3177544
	],
	[
		"s1608487",
		"Rosa cf. sicula Fougere-Danezan 199",
		"rosa",
		1608487
	],
	[
		"s74649",
		"Rosa chinensis",
		"rosa",
		74649
	],
	[
		"s2508182",
		"Rosa chinensis x Rosa lucieae",
		"rosa",
		2508182
	],
	[
		"s1080142",
		"Rosa chinensis x Rosa moschata",
		"rosa",
		1080142
	],
	[
		"s3876312",
		"Rosa chionistrae",
		"rosa",
		3876312
	],
	[
		"s559337",
		"Rosa clinophylla",
		"rosa",
		559337
	],
	[
		"s3876313",
		"Rosa coalita",
		"rosa",
		3876313
	],
	[
		"s267234",
		"Rosa columnifera",
		"rosa",
		267234
	],
	[
		"s267235",
		"Rosa corymbifera",
		"rosa",
		267235
	],
	[
		"s396734",
		"Rosa corymbulosa",
		"rosa",
		396734
	],
	[
		"s1851393",
		"Rosa coziae",
		"rosa",
		1851393
	],
	[
		"s2776721",
		"Rosa cuneicarpa",
		"rosa",
		2776721
	],
	[
		"s117261",
		"Rosa cymosa",
		"rosa",
		117261
	],
	[
		"s3876314",
		"Rosa cziragensis",
		"rosa",
		3876314
	],
	[
		"s3373229",
		"Rosa daishanensis",
		"rosa",
		3373229
	],
	[
		"s2705058",
		"Rosa dalmatica",
		"rosa",
		2705058
	],
	[
		"s3876315",
		"Rosa darginica",
		"rosa",
		3876315
	],
	[
		"s396735",
		"Rosa davidii",
		"rosa",
		396735
	],
	[
		"s237596",
		"Rosa davurica",
		"rosa",
		237596
	],
	[
		"s1642043",
		"Rosa deqenensis",
		"rosa",
		1642043
	],
	[
		"s1642044",
		"Rosa derongensis",
		"rosa",
		1642044
	],
	[
		"s1616082",
		"Rosa deseglisei",
		"rosa",
		1616082
	],
	[
		"s3876316",
		"Rosa diacantha",
		"rosa",
		3876316
	],
	[
		"s2775117",
		"Rosa dimorpha",
		"rosa",
		2775117
	],
	[
		"s3091759",
		"Rosa diplodonta",
		"rosa",
		3091759
	],
	[
		"s3876317",
		"Rosa dolichocarpa",
		"rosa",
		3876317
	],
	[
		"s3876318",
		"Rosa doluchanovii",
		"rosa",
		3876318
	],
	[
		"s1165905",
		"Rosa donetzica",
		"rosa",
		1165905
	],
	[
		"s3876319",
		"Rosa dsharkenti",
		"rosa",
		3876319
	],
	[
		"s3876320",
		"Rosa dubovikiae",
		"rosa",
		3876320
	],
	[
		"s291166",
		"Rosa dumalis",
		"rosa",
		291166
	],
	[
		"s3091760",
		"Rosa dumetorum",
		"rosa",
		3091760
	],
	[
		"s1642045",
		"Rosa duplicata",
		"rosa",
		1642045
	],
	[
		"s267236",
		"Rosa ecae",
		"rosa",
		267236
	],
	[
		"s323240",
		"Rosa elliptica",
		"rosa",
		323240
	],
	[
		"s3876321",
		"Rosa elymaitica",
		"rosa",
		3876321
	],
	[
		"s3876322",
		"Rosa ermanica",
		"rosa",
		3876322
	],
	[
		"s3876323",
		"Rosa facsarii",
		"rosa",
		3876323
	],
	[
		"s1608488",
		"Rosa farreri",
		"rosa",
		1608488
	],
	[
		"s127554",
		"Rosa fedtschenkoana",
		"rosa",
		127554
	],
	[
		"s1608489",
		"Rosa filipes",
		"rosa",
		1608489
	],
	[
		"s3876324",
		"Rosa flavida",
		"rosa",
		3876324
	],
	[
		"s74629",
		"Rosa foetida",
		"rosa",
		74629
	],
	[
		"s119234",
		"Rosa foliolosa",
		"rosa",
		119234
	],
	[
		"s1282843",
		"Rosa forrestiana",
		"rosa",
		1282843
	],
	[
		"s3373230",
		"Rosa freitagii",
		"rosa",
		3373230
	],
	[
		"s1642046",
		"Rosa fujisanensis",
		"rosa",
		1642046
	],
	[
		"s3876325",
		"Rosa funingensis",
		"rosa",
		3876325
	],
	[
		"s3876326",
		"Rosa gadzhievii",
		"rosa",
		3876326
	],
	[
		"s74632",
		"Rosa gallica",
		"rosa",
		74632
	],
	[
		"s267225",
		"Rosa gallica x Rosa dumetorum",
		"rosa",
		267225
	],
	[
		"s3876327",
		"Rosa galushkoi",
		"rosa",
		3876327
	],
	[
		"s3876328",
		"Rosa geninae",
		"rosa",
		3876328
	],
	[
		"s1608490",
		"Rosa giraldii",
		"rosa",
		1608490
	],
	[
		"s3373408",
		"Rosa glabrifolia",
		"rosa",
		3373408
	],
	[
		"s74637",
		"Rosa glauca",
		"rosa",
		74637
	],
	[
		"s1608491",
		"Rosa glomerata",
		"rosa",
		1608491
	],
	[
		"s2503011",
		"Rosa glutinosa",
		"rosa",
		2503011
	],
	[
		"s3091761",
		"Rosa gorenkensis",
		"rosa",
		3091761
	],
	[
		"s971287",
		"Rosa graciliflora",
		"rosa",
		971287
	],
	[
		"s3876329",
		"Rosa gracilipes",
		"rosa",
		3876329
	],
	[
		"s3876330",
		"Rosa gran-canariae",
		"rosa",
		3876330
	],
	[
		"s396737",
		"Rosa granulata",
		"rosa",
		396737
	],
	[
		"s2774405",
		"Rosa grossheimii",
		"rosa",
		2774405
	],
	[
		"s3876331",
		"Rosa gulczensis",
		"rosa",
		3876331
	],
	[
		"s339615",
		"Rosa gymnocarpa",
		"rosa",
		339615
	],
	[
		"s267237",
		"Rosa helenae",
		"rosa",
		267237
	],
	[
		"s2282111",
		"Rosa hemisphaerica",
		"rosa",
		2282111
	],
	[
		"s396738",
		"Rosa hemsleyana",
		"rosa",
		396738
	],
	[
		"s117262",
		"Rosa henryi",
		"rosa",
		117262
	],
	[
		"s3876332",
		"Rosa hirtissima",
		"rosa",
		3876332
	],
	[
		"s2133963",
		"Rosa hissarica",
		"rosa",
		2133963
	],
	[
		"s3876333",
		"Rosa hohuanlinparvifolia",
		"rosa",
		3876333
	],
	[
		"s2705060",
		"Rosa horrida",
		"rosa",
		2705060
	],
	[
		"s267238",
		"Rosa hugonis",
		"rosa",
		267238
	],
	[
		"s2776722",
		"Rosa hungarica",
		"rosa",
		2776722
	],
	[
		"s3091762",
		"Rosa huntica",
		"rosa",
		3091762
	],
	[
		"s128735",
		"Rosa hybrid cultivar",
		"rosa",
		128735
	],
	[
		"s3091763",
		"Rosa iberica",
		"rosa",
		3091763
	],
	[
		"s3410055",
		"Rosa iliensis",
		"rosa",
		3410055
	],
	[
		"s3876334",
		"Rosa iljinii",
		"rosa",
		3876334
	],
	[
		"s3876335",
		"Rosa incisa",
		"rosa",
		3876335
	],
	[
		"s2056386",
		"Rosa indica",
		"rosa",
		2056386
	],
	[
		"s3876336",
		"Rosa irinae",
		"rosa",
		3876336
	],
	[
		"s3876337",
		"Rosa irysthonica",
		"rosa",
		3876337
	],
	[
		"s3876338",
		"Rosa isaevii",
		"rosa",
		3876338
	],
	[
		"s3876339",
		"Rosa issyksuensis",
		"rosa",
		3876339
	],
	[
		"s1642048",
		"Rosa jacutica",
		"rosa",
		1642048
	],
	[
		"s3876340",
		"Rosa jaroschenkoi",
		"rosa",
		3876340
	],
	[
		"s267239",
		"Rosa jundzillii",
		"rosa",
		267239
	],
	[
		"s3876341",
		"Rosa juzepczukiana",
		"rosa",
		3876341
	],
	[
		"s3876342",
		"Rosa kamelinii",
		"rosa",
		3876342
	],
	[
		"s3876343",
		"Rosa karaalmensis",
		"rosa",
		3876343
	],
	[
		"s3876344",
		"Rosa karjaginii",
		"rosa",
		3876344
	],
	[
		"s3876345",
		"Rosa kazarjanii",
		"rosa",
		3876345
	],
	[
		"s3876346",
		"Rosa khasautensis",
		"rosa",
		3876346
	],
	[
		"s2282112",
		"Rosa kokanica",
		"rosa",
		2282112
	],
	[
		"s3876347",
		"Rosa kokijrimensis",
		"rosa",
		3876347
	],
	[
		"s3876348",
		"Rosa komarovii",
		"rosa",
		3876348
	],
	[
		"s396739",
		"Rosa koreana",
		"rosa",
		396739
	],
	[
		"s3876349",
		"Rosa kuhitangi",
		"rosa",
		3876349
	],
	[
		"s3876350",
		"Rosa kujmanica",
		"rosa",
		3876350
	],
	[
		"s3876351",
		"Rosa kunmingensis",
		"rosa",
		3876351
	],
	[
		"s1603827",
		"Rosa kwangtungensis",
		"rosa",
		1603827
	],
	[
		"s2836953",
		"Rosa kweichowensis",
		"rosa",
		2836953
	],
	[
		"s74652",
		"Rosa laevigata",
		"rosa",
		74652
	],
	[
		"s3373225",
		"Rosa langyashanica",
		"rosa",
		3373225
	],
	[
		"s3091764",
		"Rosa lapidosa",
		"rosa",
		3091764
	],
	[
		"s1642049",
		"Rosa lasiosepala",
		"rosa",
		1642049
	],
	[
		"s2705061",
		"Rosa latibracteata",
		"rosa",
		2705061
	],
	[
		"s267240",
		"Rosa laxa",
		"rosa",
		267240
	],
	[
		"s3047107",
		"Rosa laxa x Rosa hybrid cultivar",
		"rosa",
		3047107
	],
	[
		"s396740",
		"Rosa leschenaultiana",
		"rosa",
		396740
	],
	[
		"s396741",
		"Rosa lesterae",
		"rosa",
		396741
	],
	[
		"s649269",
		"Rosa lichiangensis",
		"rosa",
		649269
	],
	[
		"s3876352",
		"Rosa livescens",
		"rosa",
		3876352
	],
	[
		"s648850",
		"Rosa longicuspis",
		"rosa",
		648850
	],
	[
		"s3421125",
		"Rosa luciae x Rosa x odorata",
		"rosa",
		3421125
	],
	[
		"s1642051",
		"Rosa lucidissima",
		"rosa",
		1642051
	],
	[
		"s74648",
		"Rosa lucieae",
		"rosa",
		74648
	],
	[
		"s3373226",
		"Rosa ludingensis",
		"rosa",
		3373226
	],
	[
		"s3876353",
		"Rosa machailensis",
		"rosa",
		3876353
	],
	[
		"s1036029",
		"Rosa macrophylla",
		"rosa",
		1036029
	],
	[
		"s3091765",
		"Rosa maeotica",
		"rosa",
		3091765
	],
	[
		"s649270",
		"Rosa mairei",
		"rosa",
		649270
	],
	[
		"s57935",
		"Rosa majalis",
		"rosa",
		57935
	],
	[
		"s3876354",
		"Rosa mandenovae",
		"rosa",
		3876354
	],
	[
		"s3876355",
		"Rosa mandonii",
		"rosa",
		3876355
	],
	[
		"s3876356",
		"Rosa manshurica",
		"rosa",
		3876356
	],
	[
		"s3091766",
		"Rosa maracandica",
		"rosa",
		3091766
	],
	[
		"s396742",
		"Rosa marginata",
		"rosa",
		396742
	],
	[
		"s117264",
		"Rosa marretii",
		"rosa",
		117264
	],
	[
		"s117265",
		"Rosa maximowicziana",
		"rosa",
		117265
	],
	[
		"s3876357",
		"Rosa memoryae",
		"rosa",
		3876357
	],
	[
		"s3876358",
		"Rosa mesatlantica",
		"rosa",
		3876358
	],
	[
		"s267241",
		"Rosa micrantha",
		"rosa",
		267241
	],
	[
		"s396743",
		"Rosa minutifolia",
		"rosa",
		396743
	],
	[
		"s3876359",
		"Rosa mironovae",
		"rosa",
		3876359
	],
	[
		"s3876360",
		"Rosa miyiensis",
		"rosa",
		3876360
	],
	[
		"s396744",
		"Rosa mohavensis",
		"rosa",
		396744
	],
	[
		"s267242",
		"Rosa mollis",
		"rosa",
		267242
	],
	[
		"s267243",
		"Rosa montana",
		"rosa",
		267243
	],
	[
		"s3091768",
		"Rosa morrisonensis",
		"rosa",
		3091768
	],
	[
		"s74646",
		"Rosa moschata",
		"rosa",
		74646
	],
	[
		"s74644",
		"Rosa moyesii",
		"rosa",
		74644
	],
	[
		"s2705062",
		"Rosa mulliganii",
		"rosa",
		2705062
	],
	[
		"s267244",
		"Rosa multibracteata",
		"rosa",
		267244
	],
	[
		"s74647",
		"Rosa multiflora",
		"rosa",
		74647
	],
	[
		"s3349724",
		"Rosa multiflora x Rosa maximowicziana",
		"rosa",
		3349724
	],
	[
		"s1608492",
		"Rosa murielae",
		"rosa",
		1608492
	],
	[
		"s1439924",
		"Rosa nanothamnus",
		"rosa",
		1439924
	],
	[
		"s3091769",
		"Rosa nipponensis",
		"rosa",
		3091769
	],
	[
		"s267245",
		"Rosa nitida",
		"rosa",
		267245
	],
	[
		"s2056078",
		"Rosa nitida x Rosa rugosa",
		"rosa",
		2056078
	],
	[
		"s396745",
		"Rosa nutkana",
		"rosa",
		396745
	],
	[
		"s3091770",
		"Rosa obtegens",
		"rosa",
		3091770
	],
	[
		"s1155355",
		"Rosa obtusifolia",
		"rosa",
		1155355
	],
	[
		"s267246",
		"Rosa odorata",
		"rosa",
		267246
	],
	[
		"s648851",
		"Rosa omeiensis",
		"rosa",
		648851
	],
	[
		"s396747",
		"Rosa orientalis",
		"rosa",
		396747
	],
	[
		"s1538555",
		"Rosa oskolensis",
		"rosa",
		1538555
	],
	[
		"s3809262",
		"Rosa osmastonii",
		"rosa",
		3809262
	],
	[
		"s3876361",
		"Rosa ossethica",
		"rosa",
		3876361
	],
	[
		"s3091771",
		"Rosa ovczinnikovii",
		"rosa",
		3091771
	],
	[
		"s2844922",
		"Rosa oxyacantha",
		"rosa",
		2844922
	],
	[
		"s1165906",
		"Rosa oxyodon",
		"rosa",
		1165906
	],
	[
		"s267247",
		"Rosa palustris",
		"rosa",
		267247
	],
	[
		"s1642052",
		"Rosa paniculigera",
		"rosa",
		1642052
	],
	[
		"s1006179",
		"Rosa parviuscula",
		"rosa",
		1006179
	],
	[
		"s3876362",
		"Rosa pedunculata",
		"rosa",
		3876362
	],
	[
		"s74642",
		"Rosa pendulina",
		"rosa",
		74642
	],
	[
		"s648852",
		"Rosa persetosa",
		"rosa",
		648852
	],
	[
		"s74628",
		"Rosa persica",
		"rosa",
		74628
	],
	[
		"s127555",
		"Rosa phoenicia",
		"rosa",
		127555
	],
	[
		"s396748",
		"Rosa pinetorum",
		"rosa",
		396748
	],
	[
		"s3106189",
		"Rosa pisiformis",
		"rosa",
		3106189
	],
	[
		"s339616",
		"Rosa pisocarpa",
		"rosa",
		339616
	],
	[
		"s117266",
		"Rosa platyacantha",
		"rosa",
		117266
	],
	[
		"s3876363",
		"Rosa pocsii",
		"rosa",
		3876363
	],
	[
		"s3876364",
		"Rosa popovii",
		"rosa",
		3876364
	],
	[
		"s3876365",
		"Rosa potentilliflora",
		"rosa",
		3876365
	],
	[
		"s1533351",
		"Rosa pouzinii",
		"rosa",
		1533351
	],
	[
		"s577514",
		"Rosa praelucens",
		"rosa",
		577514
	],
	[
		"s3876366",
		"Rosa praetermissa",
		"rosa",
		3876366
	],
	[
		"s971288",
		"Rosa prattii",
		"rosa",
		971288
	],
	[
		"s1642053",
		"Rosa pricei",
		"rosa",
		1642053
	],
	[
		"s3876367",
		"Rosa prilipkoana",
		"rosa",
		3876367
	],
	[
		"s267249",
		"Rosa primula",
		"rosa",
		267249
	],
	[
		"s3876368",
		"Rosa prokhanovii",
		"rosa",
		3876368
	],
	[
		"s2722879",
		"Rosa pseudobanksiae",
		"rosa",
		2722879
	],
	[
		"s3876369",
		"Rosa pseudodigitata",
		"rosa",
		3876369
	],
	[
		"s267250",
		"Rosa pseudoscabriuscula",
		"rosa",
		267250
	],
	[
		"s3876370",
		"Rosa pubicaulis",
		"rosa",
		3876370
	],
	[
		"s689230",
		"Rosa pulverulenta",
		"rosa",
		689230
	],
	[
		"s1538554",
		"Rosa pygmaea",
		"rosa",
		1538554
	],
	[
		"s2705059",
		"Rosa rapinii",
		"rosa",
		2705059
	],
	[
		"s1533352",
		"Rosa rhaetica",
		"rosa",
		1533352
	],
	[
		"s3876371",
		"Rosa roopiae",
		"rosa",
		3876371
	],
	[
		"s3876372",
		"Rosa roque-muchachensis",
		"rosa",
		3876372
	],
	[
		"s74654",
		"Rosa roxburghii",
		"rosa",
		74654
	],
	[
		"s74636",
		"Rosa rubiginosa",
		"rosa",
		74636
	],
	[
		"s1826186",
		"Rosa rubrifolia",
		"rosa",
		1826186
	],
	[
		"s648853",
		"Rosa rubus",
		"rosa",
		648853
	],
	[
		"s74645",
		"Rosa rugosa",
		"rosa",
		74645
	],
	[
		"s1133298",
		"Rosa rugosa x Rosa sertata",
		"rosa",
		1133298
	],
	[
		"s3876373",
		"Rosa russanovii",
		"rosa",
		3876373
	],
	[
		"s117267",
		"Rosa sambucina",
		"rosa",
		117267
	],
	[
		"s2776723",
		"Rosa sancti-andreae",
		"rosa",
		2776723
	],
	[
		"s971289",
		"Rosa saturata",
		"rosa",
		971289
	],
	[
		"s3876374",
		"Rosa schergiana",
		"rosa",
		3876374
	],
	[
		"s2775118",
		"Rosa schistosa",
		"rosa",
		2775118
	],
	[
		"s3876375",
		"Rosa schrenkiana",
		"rosa",
		3876375
	],
	[
		"s136999",
		"Rosa sempervirens",
		"rosa",
		136999
	],
	[
		"s2705063",
		"Rosa serafinii",
		"rosa",
		2705063
	],
	[
		"s74631",
		"Rosa sericea",
		"rosa",
		74631
	],
	[
		"s267252",
		"Rosa sertata",
		"rosa",
		267252
	],
	[
		"s3047108",
		"Rosa sertata x Rosa rugosa",
		"rosa",
		3047108
	],
	[
		"s137000",
		"Rosa setigera",
		"rosa",
		137e3
	],
	[
		"s1608494",
		"Rosa setipoda",
		"rosa",
		1608494
	],
	[
		"s3876376",
		"Rosa shaolinchiensis",
		"rosa",
		3876376
	],
	[
		"s267253",
		"Rosa sherardii",
		"rosa",
		267253
	],
	[
		"s267254",
		"Rosa sicula",
		"rosa",
		267254
	],
	[
		"s648854",
		"Rosa sikangensis",
		"rosa",
		648854
	],
	[
		"s1439925",
		"Rosa silverhjelmii",
		"rosa",
		1439925
	],
	[
		"s3876377",
		"Rosa similis",
		"rosa",
		3876377
	],
	[
		"s3044383",
		"Rosa sinobiflora",
		"rosa",
		3044383
	],
	[
		"s2056077",
		"Rosa slancensis",
		"rosa",
		2056077
	],
	[
		"s3876378",
		"Rosa smoljanensis",
		"rosa",
		3876378
	],
	[
		"s3876379",
		"Rosa sogdiana",
		"rosa",
		3876379
	],
	[
		"s577515",
		"Rosa soulieana",
		"rosa",
		577515
	],
	[
		"s3091772",
		"Rosa spaldingii",
		"rosa",
		3091772
	],
	[
		"s74630",
		"Rosa spinosissima",
		"rosa",
		74630
	],
	[
		"s396750",
		"Rosa spithamea",
		"rosa",
		396750
	],
	[
		"s74655",
		"Rosa stellata",
		"rosa",
		74655
	],
	[
		"s2783860",
		"Rosa sterilis (nom. nud.)",
		"rosa",
		2783860
	],
	[
		"s3049958",
		"Rosa sterilis var. leioclada (nom. nud.)",
		"rosa",
		3049958
	],
	[
		"s267255",
		"Rosa stylosa",
		"rosa",
		267255
	],
	[
		"s2775119",
		"Rosa subafzeliana",
		"rosa",
		2775119
	],
	[
		"s267256",
		"Rosa subcanina",
		"rosa",
		267256
	],
	[
		"s267257",
		"Rosa subcollina",
		"rosa",
		267257
	],
	[
		"s3876380",
		"Rosa subulata",
		"rosa",
		3876380
	],
	[
		"s267258",
		"Rosa suffulta",
		"rosa",
		267258
	],
	[
		"s971290",
		"Rosa sweginzowii",
		"rosa",
		971290
	],
	[
		"s1826188",
		"Rosa taiwanensis",
		"rosa",
		1826188
	],
	[
		"s1608495",
		"Rosa taronensis",
		"rosa",
		1608495
	],
	[
		"s3876381",
		"Rosa teberdensis",
		"rosa",
		3876381
	],
	[
		"s3876382",
		"Rosa tianschanica",
		"rosa",
		3876382
	],
	[
		"s3091773",
		"Rosa tibetica",
		"rosa",
		3091773
	],
	[
		"s3876383",
		"Rosa tlaratensis",
		"rosa",
		3876383
	],
	[
		"s267259",
		"Rosa tomentella",
		"rosa",
		267259
	],
	[
		"s267260",
		"Rosa tomentosa",
		"rosa",
		267260
	],
	[
		"s1608496",
		"Rosa trachyphylla",
		"rosa",
		1608496
	],
	[
		"s3876384",
		"Rosa transcaucasica",
		"rosa",
		3876384
	],
	[
		"s1608497",
		"Rosa transmorrisonensis",
		"rosa",
		1608497
	],
	[
		"s3091774",
		"Rosa transsilvanica",
		"rosa",
		3091774
	],
	[
		"s3876385",
		"Rosa transturkestanica",
		"rosa",
		3876385
	],
	[
		"s1608498",
		"Rosa tsinglingensis",
		"rosa",
		1608498
	],
	[
		"s3876386",
		"Rosa tsinlingensis",
		"rosa",
		3876386
	],
	[
		"s117268",
		"Rosa tunquinensis",
		"rosa",
		117268
	],
	[
		"s2774403",
		"Rosa turcica",
		"rosa",
		2774403
	],
	[
		"s3876387",
		"Rosa turkestanica",
		"rosa",
		3876387
	],
	[
		"s1642055",
		"Rosa uniflorella",
		"rosa",
		1642055
	],
	[
		"s3876388",
		"Rosa valentinae",
		"rosa",
		3876388
	],
	[
		"s3876389",
		"Rosa vassilczenkoi",
		"rosa",
		3876389
	],
	[
		"s3876390",
		"Rosa veronikae",
		"rosa",
		3876390
	],
	[
		"s267261",
		"Rosa villosa",
		"rosa",
		267261
	],
	[
		"s74639",
		"Rosa virginiana",
		"rosa",
		74639
	],
	[
		"s1608499",
		"Rosa vosagiaca",
		"rosa",
		1608499
	],
	[
		"s396751",
		"Rosa webbiana",
		"rosa",
		396751
	],
	[
		"s1036030",
		"Rosa weisiensis",
		"rosa",
		1036030
	],
	[
		"s119235",
		"Rosa willmottiae",
		"rosa",
		119235
	],
	[
		"s3438246",
		"Rosa willmottiae x Rosa rugosa",
		"rosa",
		3438246
	],
	[
		"s32246",
		"Rosa woodsii",
		"rosa",
		32246
	],
	[
		"s3091775",
		"Rosa woronowii",
		"rosa",
		3091775
	],
	[
		"s267226",
		"Rosa x alba",
		"rosa",
		267226
	],
	[
		"s3092073",
		"Rosa x andegavensis",
		"rosa",
		3092073
	],
	[
		"s2572618",
		"Rosa x archipelagica",
		"rosa",
		2572618
	],
	[
		"s2584556",
		"Rosa x binaloudensis",
		"rosa",
		2584556
	],
	[
		"s358216",
		"Rosa x burboniana",
		"rosa",
		358216
	],
	[
		"s396733",
		"Rosa x centifolia",
		"rosa",
		396733
	],
	[
		"s1533350",
		"Rosa x chavinii",
		"rosa",
		1533350
	],
	[
		"s3765",
		"Rosa x damascena",
		"rosa",
		3765
	],
	[
		"s107237",
		"Rosa x fortuneana",
		"rosa",
		107237
	],
	[
		"s3092074",
		"Rosa x karakalensis",
		"rosa",
		3092074
	],
	[
		"s1608484",
		"Rosa x nitidula",
		"rosa",
		1608484
	],
	[
		"s413030",
		"Rosa x waitziana",
		"rosa",
		413030
	],
	[
		"s267264",
		"Rosa xanthina",
		"rosa",
		267264
	],
	[
		"s3876391",
		"Rosa yangii",
		"rosa",
		3876391
	],
	[
		"s3876392",
		"Rosa yilanalpina",
		"rosa",
		3876392
	],
	[
		"s3091776",
		"Rosa zangezura",
		"rosa",
		3091776
	],
	[
		"s3876393",
		"Rosa zaramagensis",
		"rosa",
		3876393
	],
	[
		"s648855",
		"Rosa zhongdianensis",
		"rosa",
		648855
	],
	[
		"s3876394",
		"Rosa zuvandica",
		"rosa",
		3876394
	],
	[
		"s3091777",
		"Rousselia erratica",
		"rousselia",
		3091777
	],
	[
		"s1399744",
		"Rousselia humilis",
		"rousselia",
		1399744
	],
	[
		"s3876645",
		"Rousselia impariflora",
		"rousselia",
		3876645
	],
	[
		"s3091778",
		"Rubus aboriginum",
		"rubus",
		3091778
	],
	[
		"s1546371",
		"Rubus acanthodes",
		"rubus",
		1546371
	],
	[
		"s2497804",
		"Rubus acanthophyllus",
		"rubus",
		2497804
	],
	[
		"s1813480",
		"Rubus acuminatus",
		"rubus",
		1813480
	],
	[
		"s3054258",
		"Rubus adenophorus",
		"rubus",
		3054258
	],
	[
		"s2892302",
		"Rubus adenothallus",
		"rubus",
		2892302
	],
	[
		"s420769",
		"Rubus adenotrichos",
		"rubus",
		420769
	],
	[
		"s3091779",
		"Rubus adornatus",
		"rubus",
		3091779
	],
	[
		"s3091780",
		"Rubus adscitus",
		"rubus",
		3091780
	],
	[
		"s1546372",
		"Rubus adspersus",
		"rubus",
		1546372
	],
	[
		"s420772",
		"Rubus aff. adenotrichos PGGS-2007",
		"rubus",
		420772
	],
	[
		"s1546373",
		"Rubus aff. arduennensis MS-2014",
		"rubus",
		1546373
	],
	[
		"s1546374",
		"Rubus aff. barrandienicus MS-2014",
		"rubus",
		1546374
	],
	[
		"s2995208",
		"Rubus aff. bergii MS-2022",
		"rubus",
		2995208
	],
	[
		"s1908210",
		"Rubus aff. cissburiensis MS-2016",
		"rubus",
		1908210
	],
	[
		"s1546375",
		"Rubus aff. clusii MS-2014",
		"rubus",
		1546375
	],
	[
		"s1546376",
		"Rubus aff. fabrimontanus MS-2014",
		"rubus",
		1546376
	],
	[
		"s420777",
		"Rubus aff. idaeus PGGS-2007",
		"rubus",
		420777
	],
	[
		"s1546377",
		"Rubus aff. praecox",
		"rubus",
		1546377
	],
	[
		"s1546379",
		"Rubus aff. wahlbergii MS-2014",
		"rubus",
		1546379
	],
	[
		"s3091781",
		"Rubus alaskensis",
		"rubus",
		3091781
	],
	[
		"s124693",
		"Rubus alceifolius",
		"rubus",
		124693
	],
	[
		"s421239",
		"Rubus alexeterius",
		"rubus",
		421239
	],
	[
		"s75062",
		"Rubus allegheniensis",
		"rubus",
		75062
	],
	[
		"s2803531",
		"Rubus alnifoliolatus",
		"rubus",
		2803531
	],
	[
		"s75063",
		"Rubus alpinus",
		"rubus",
		75063
	],
	[
		"s2527788",
		"Rubus alumnus",
		"rubus",
		2527788
	],
	[
		"s616954",
		"Rubus amabilis",
		"rubus",
		616954
	],
	[
		"s1546332",
		"Rubus ambrosius",
		"rubus",
		1546332
	],
	[
		"s1546382",
		"Rubus amisiensis",
		"rubus",
		1546382
	],
	[
		"s1546383",
		"Rubus ammobius",
		"rubus",
		1546383
	],
	[
		"s190220",
		"Rubus amphidasys",
		"rubus",
		190220
	],
	[
		"s3091782",
		"Rubus analogus",
		"rubus",
		3091782
	],
	[
		"s3091440",
		"Rubus anatolicus",
		"rubus",
		3091440
	],
	[
		"s2892303",
		"Rubus andicola",
		"rubus",
		2892303
	],
	[
		"s1197687",
		"Rubus anglocandicans",
		"rubus",
		1197687
	],
	[
		"s1220086",
		"Rubus apetalus",
		"rubus",
		1220086
	],
	[
		"s2904932",
		"Rubus apetalus x Rubus ludwigii",
		"rubus",
		2904932
	],
	[
		"s2995200",
		"Rubus apetalus x Rubus pinnatus",
		"rubus",
		2995200
	],
	[
		"s3091783",
		"Rubus apogaeus",
		"rubus",
		3091783
	],
	[
		"s1546384",
		"Rubus apricus",
		"rubus",
		1546384
	],
	[
		"s3377207",
		"Rubus arachnoideus",
		"rubus",
		3377207
	],
	[
		"s70741",
		"Rubus arcticus",
		"rubus",
		70741
	],
	[
		"s1546385",
		"Rubus arduennensis",
		"rubus",
		1546385
	],
	[
		"s59490",
		"Rubus argutus",
		"rubus",
		59490
	],
	[
		"s926038",
		"Rubus armeniacus",
		"rubus",
		926038
	],
	[
		"s3091784",
		"Rubus arvensis",
		"rubus",
		3091784
	],
	[
		"s75136",
		"Rubus assamensis",
		"rubus",
		75136
	],
	[
		"s1813483",
		"Rubus aurantiacus",
		"rubus",
		1813483
	],
	[
		"s3091785",
		"Rubus aureolus",
		"rubus",
		3091785
	],
	[
		"s3714016",
		"Rubus auritus",
		"rubus",
		3714016
	],
	[
		"s75135",
		"Rubus australis",
		"rubus",
		75135
	],
	[
		"s1546386",
		"Rubus austromoravicus",
		"rubus",
		1546386
	],
	[
		"s1546333",
		"Rubus austroslovacus",
		"rubus",
		1546333
	],
	[
		"s1813517",
		"Rubus austrotibetanus",
		"rubus",
		1813517
	],
	[
		"s3091786",
		"Rubus axillaris",
		"rubus",
		3091786
	],
	[
		"s3091787",
		"Rubus baileyanus",
		"rubus",
		3091787
	],
	[
		"s1521119",
		"Rubus bambusarum",
		"rubus",
		1521119
	],
	[
		"s1546387",
		"Rubus barrandienicus",
		"rubus",
		1546387
	],
	[
		"s1546388",
		"Rubus bavaricus",
		"rubus",
		1546388
	],
	[
		"s2904922",
		"Rubus bergii",
		"rubus",
		2904922
	],
	[
		"s2904929",
		"Rubus bergii x Rubus pinnatus",
		"rubus",
		2904929
	],
	[
		"s2904930",
		"Rubus bergii x Rubus rigidus",
		"rubus",
		2904930
	],
	[
		"s2904931",
		"Rubus bergii x Rubus thaumasius",
		"rubus",
		2904931
	],
	[
		"s1546389",
		"Rubus bertramii",
		"rubus",
		1546389
	],
	[
		"s411214",
		"Rubus biflorus",
		"rubus",
		411214
	],
	[
		"s75064",
		"Rubus bifrons",
		"rubus",
		75064
	],
	[
		"s1546390",
		"Rubus bohemiicola",
		"rubus",
		1546390
	],
	[
		"s1519687",
		"Rubus bollei",
		"rubus",
		1519687
	],
	[
		"s3377006",
		"Rubus bonatianus",
		"rubus",
		3377006
	],
	[
		"s2609018",
		"Rubus boninensis",
		"rubus",
		2609018
	],
	[
		"s3091788",
		"Rubus braeuckeriformis",
		"rubus",
		3091788
	],
	[
		"s1546369",
		"Rubus brunneri",
		"rubus",
		1546369
	],
	[
		"s321604",
		"Rubus buergeri",
		"rubus",
		321604
	],
	[
		"s1546391",
		"Rubus buhnensis",
		"rubus",
		1546391
	],
	[
		"s3091789",
		"Rubus bushii",
		"rubus",
		3091789
	],
	[
		"s75065",
		"Rubus caesius",
		"rubus",
		75065
	],
	[
		"s168320",
		"Rubus caesius x Rubus idaeus",
		"rubus",
		168320
	],
	[
		"s3298995",
		"Rubus caesius x Rubus ulmifolius",
		"rubus",
		3298995
	],
	[
		"s421240",
		"Rubus calophyllus",
		"rubus",
		421240
	],
	[
		"s3091790",
		"Rubus calvus",
		"rubus",
		3091790
	],
	[
		"s1813486",
		"Rubus calycacanthus",
		"rubus",
		1813486
	],
	[
		"s421241",
		"Rubus calycinus",
		"rubus",
		421241
	],
	[
		"s1546393",
		"Rubus camptostachys",
		"rubus",
		1546393
	],
	[
		"s75066",
		"Rubus canadensis",
		"rubus",
		75066
	],
	[
		"s1546334",
		"Rubus canaliculatus",
		"rubus",
		1546334
	],
	[
		"s3091791",
		"Rubus candicans",
		"rubus",
		3091791
	],
	[
		"s190221",
		"Rubus canescens",
		"rubus",
		190221
	],
	[
		"s1546362",
		"Rubus canescens x Rubus crispomarginatus",
		"rubus",
		1546362
	],
	[
		"s1546365",
		"Rubus canescens x Rubus sanctus",
		"rubus",
		1546365
	],
	[
		"s1546364",
		"Rubus canescens x Rubus ulmifolius",
		"rubus",
		1546364
	],
	[
		"s1546335",
		"Rubus capricollensis",
		"rubus",
		1546335
	],
	[
		"s1908211",
		"Rubus cardiophyllus",
		"rubus",
		1908211
	],
	[
		"s2813831",
		"Rubus cardotii",
		"rubus",
		2813831
	],
	[
		"s190222",
		"Rubus caucasicus",
		"rubus",
		190222
	],
	[
		"s616955",
		"Rubus caudifolius",
		"rubus",
		616955
	],
	[
		"s1341823",
		"Rubus cf. alceifolius MR-2013",
		"rubus",
		1341823
	],
	[
		"s1546394",
		"Rubus cf. allegheniensis MS-2014",
		"rubus",
		1546394
	],
	[
		"s3128352",
		"Rubus cf. apetalus",
		"rubus",
		3128352
	],
	[
		"s1546395",
		"Rubus cf. biflorus MS-2014",
		"rubus",
		1546395
	],
	[
		"s1546392",
		"Rubus cf. caesius MS-2014",
		"rubus",
		1546392
	],
	[
		"s1705287",
		"Rubus cf. hirtus MS-2015",
		"rubus",
		1705287
	],
	[
		"s1705288",
		"Rubus cf. ibericus MS-2015",
		"rubus",
		1705288
	],
	[
		"s1732051",
		"Rubus cf. moschus MS-2015-1",
		"rubus",
		1732051
	],
	[
		"s1732050",
		"Rubus cf. moschus MS-2015-2",
		"rubus",
		1732050
	],
	[
		"s1341824",
		"Rubus cf. paniculatus MR-2013",
		"rubus",
		1341824
	],
	[
		"s1546396",
		"Rubus cf. platyphyllus MS-2014",
		"rubus",
		1546396
	],
	[
		"s1546397",
		"Rubus cf. serrae MS-2014",
		"rubus",
		1546397
	],
	[
		"s1346561",
		"Rubus cf. sumatranus MR-2013",
		"rubus",
		1346561
	],
	[
		"s1546477",
		"Rubus cf. ulmifolius MS-2014",
		"rubus",
		1546477
	],
	[
		"s1908217",
		"Rubus cf. ulmifolius MS-2016",
		"rubus",
		1908217
	],
	[
		"s1546398",
		"Rubus cf. x wolfredoi-wildpretii MS-2014",
		"rubus",
		1546398
	],
	[
		"s1546399",
		"Rubus cf. zangezurus MS-2014",
		"rubus",
		1546399
	],
	[
		"s1546400",
		"Rubus chaerophyllus",
		"rubus",
		1546400
	],
	[
		"s57936",
		"Rubus chamaemorus",
		"rubus",
		57936
	],
	[
		"s3252300",
		"Rubus chiliadenus",
		"rubus",
		3252300
	],
	[
		"s714495",
		"Rubus chingii",
		"rubus",
		714495
	],
	[
		"s3091792",
		"Rubus chloocladus",
		"rubus",
		3091792
	],
	[
		"s1813484",
		"Rubus chroosepalus",
		"rubus",
		1813484
	],
	[
		"s3058172",
		"Rubus chrysobotrys",
		"rubus",
		3058172
	],
	[
		"s3091793",
		"Rubus cinclidodictyus",
		"rubus",
		3091793
	],
	[
		"s1908212",
		"Rubus cissburiensis",
		"rubus",
		1908212
	],
	[
		"s1016832",
		"Rubus cissoides",
		"rubus",
		1016832
	],
	[
		"s2497809",
		"Rubus clinocephalus",
		"rubus",
		2497809
	],
	[
		"s1546401",
		"Rubus clusii",
		"rubus",
		1546401
	],
	[
		"s714648",
		"Rubus cochinchinensis",
		"rubus",
		714648
	],
	[
		"s1813485",
		"Rubus cockburnianus",
		"rubus",
		1813485
	],
	[
		"s3091794",
		"Rubus collinus",
		"rubus",
		3091794
	],
	[
		"s1603829",
		"Rubus columellaris",
		"rubus",
		1603829
	],
	[
		"s2949407",
		"Rubus conduplicatus",
		"rubus",
		2949407
	],
	[
		"s1546402",
		"Rubus conothyrsoides",
		"rubus",
		1546402
	],
	[
		"s1546403",
		"Rubus constrictus",
		"rubus",
		1546403
	],
	[
		"s190223",
		"Rubus corchorifolius",
		"rubus",
		190223
	],
	[
		"s3091795",
		"Rubus cordiformis",
		"rubus",
		3091795
	],
	[
		"s321593",
		"Rubus coreanus",
		"rubus",
		321593
	],
	[
		"s2497805",
		"Rubus coriifolius",
		"rubus",
		2497805
	],
	[
		"s1521120",
		"Rubus crassifolius",
		"rubus",
		1521120
	],
	[
		"s75067",
		"Rubus crataegifolius",
		"rubus",
		75067
	],
	[
		"s1546404",
		"Rubus crispomarginatus",
		"rubus",
		1546404
	],
	[
		"s321601",
		"Rubus croceacanthus",
		"rubus",
		321601
	],
	[
		"s59491",
		"Rubus cuneifolius",
		"rubus",
		59491
	],
	[
		"s2520628",
		"Rubus curtipes",
		"rubus",
		2520628
	],
	[
		"s3091441",
		"Rubus dasyphyllus",
		"rubus",
		3091441
	],
	[
		"s3058173",
		"Rubus delavayi",
		"rubus",
		3058173
	],
	[
		"s75068",
		"Rubus deliciosus",
		"rubus",
		75068
	],
	[
		"s2501733",
		"Rubus diclinis",
		"rubus",
		2501733
	],
	[
		"s457917",
		"Rubus discolor",
		"rubus",
		457917
	],
	[
		"s2785553",
		"Rubus dissimulans",
		"rubus",
		2785553
	],
	[
		"s75112",
		"Rubus divaricatus",
		"rubus",
		75112
	],
	[
		"s3714014",
		"Rubus divulgatus",
		"rubus",
		3714014
	],
	[
		"s3127061",
		"Rubus dolichocarpus",
		"rubus",
		3127061
	],
	[
		"s1546407",
		"Rubus dollnensis",
		"rubus",
		1546407
	],
	[
		"s1546408",
		"Rubus egregius",
		"rubus",
		1546408
	],
	[
		"s1546409",
		"Rubus elatior",
		"rubus",
		1546409
	],
	[
		"s1546410",
		"Rubus elegans",
		"rubus",
		1546410
	],
	[
		"s1546411",
		"Rubus elegantispinosus",
		"rubus",
		1546411
	],
	[
		"s59492",
		"Rubus ellipticus",
		"rubus",
		59492
	],
	[
		"s2527789",
		"Rubus enslenii",
		"rubus",
		2527789
	],
	[
		"s1546412",
		"Rubus epipsilos",
		"rubus",
		1546412
	],
	[
		"s2497806",
		"Rubus eriocarpus",
		"rubus",
		2497806
	],
	[
		"s1813487",
		"Rubus erythrocarpus",
		"rubus",
		1813487
	],
	[
		"s3091796",
		"Rubus erythroclados",
		"rubus",
		3091796
	],
	[
		"s1813488",
		"Rubus eucalyptus",
		"rubus",
		1813488
	],
	[
		"s616957",
		"Rubus eustephanos",
		"rubus",
		616957
	],
	[
		"s616958",
		"Rubus faberi",
		"rubus",
		616958
	],
	[
		"s1546413",
		"Rubus fabrimontanus",
		"rubus",
		1546413
	],
	[
		"s3015750",
		"Rubus fagifolius",
		"rubus",
		3015750
	],
	[
		"s2487652",
		"Rubus fairholmianus",
		"rubus",
		2487652
	],
	[
		"s3091797",
		"Rubus fanjingshanensis",
		"rubus",
		3091797
	],
	[
		"s1546414",
		"Rubus fasciculatus",
		"rubus",
		1546414
	],
	[
		"s1813489",
		"Rubus feddei",
		"rubus",
		1813489
	],
	[
		"s1546415",
		"Rubus ferocior",
		"rubus",
		1546415
	],
	[
		"s2785550",
		"Rubus firmus",
		"rubus",
		2785550
	],
	[
		"s2785554",
		"Rubus fissus",
		"rubus",
		2785554
	],
	[
		"s1546336",
		"Rubus flaccidus",
		"rubus",
		1546336
	],
	[
		"s190224",
		"Rubus flagellaris",
		"rubus",
		190224
	],
	[
		"s2576054",
		"Rubus flagelliflorus",
		"rubus",
		2576054
	],
	[
		"s3091799",
		"Rubus florulentus",
		"rubus",
		3091799
	],
	[
		"s1546337",
		"Rubus flos-amygdalae",
		"rubus",
		1546337
	],
	[
		"s2291158",
		"Rubus flosculosus",
		"rubus",
		2291158
	],
	[
		"s421242",
		"Rubus fockeanus",
		"rubus",
		421242
	],
	[
		"s3058174",
		"Rubus foliaceistipulatus",
		"rubus",
		3058174
	],
	[
		"s1546416",
		"Rubus foliosus",
		"rubus",
		1546416
	],
	[
		"s3091800",
		"Rubus formidabilis",
		"rubus",
		3091800
	],
	[
		"s2803532",
		"Rubus formosensis",
		"rubus",
		2803532
	],
	[
		"s1813490",
		"Rubus fragarioides",
		"rubus",
		1813490
	],
	[
		"s1546417",
		"Rubus franconicus",
		"rubus",
		1546417
	],
	[
		"s3091801",
		"Rubus fraxinifoliolus",
		"rubus",
		3091801
	],
	[
		"s3091802",
		"Rubus fraxinifolius",
		"rubus",
		3091802
	],
	[
		"s2520629",
		"Rubus frondosus",
		"rubus",
		2520629
	],
	[
		"s211815",
		"Rubus fruticosus",
		"rubus",
		211815
	],
	[
		"s2520630",
		"Rubus fulleri",
		"rubus",
		2520630
	],
	[
		"s1908213",
		"Rubus furnarius",
		"rubus",
		1908213
	],
	[
		"s3091803",
		"Rubus fuscifolius",
		"rubus",
		3091803
	],
	[
		"s3091804",
		"Rubus fuscus",
		"rubus",
		3091804
	],
	[
		"s2487653",
		"Rubus gardnerianus",
		"rubus",
		2487653
	],
	[
		"s1546418",
		"Rubus gelertii",
		"rubus",
		1546418
	],
	[
		"s2057742",
		"Rubus genevieri",
		"rubus",
		2057742
	],
	[
		"s1546419",
		"Rubus geniculatus",
		"rubus",
		1546419
	],
	[
		"s75134",
		"Rubus geoides",
		"rubus",
		75134
	],
	[
		"s3091805",
		"Rubus gillotii",
		"rubus",
		3091805
	],
	[
		"s1546338",
		"Rubus gizellae",
		"rubus",
		1546338
	],
	[
		"s190225",
		"Rubus glabratus",
		"rubus",
		190225
	],
	[
		"s1521121",
		"Rubus glabricarpus",
		"rubus",
		1521121
	],
	[
		"s2520631",
		"Rubus glandicaulis",
		"rubus",
		2520631
	],
	[
		"s3377007",
		"Rubus glandulifer",
		"rubus",
		3377007
	],
	[
		"s3091806",
		"Rubus glandulosocalycinus",
		"rubus",
		3091806
	],
	[
		"s2814614",
		"Rubus glandulosopunctatus",
		"rubus",
		2814614
	],
	[
		"s3714017",
		"Rubus glandulosus",
		"rubus",
		3714017
	],
	[
		"s3091807",
		"Rubus glaucifolius",
		"rubus",
		3091807
	],
	[
		"s2785551",
		"Rubus glauciformis",
		"rubus",
		2785551
	],
	[
		"s190226",
		"Rubus glaucus",
		"rubus",
		190226
	],
	[
		"s1546420",
		"Rubus glivicensis",
		"rubus",
		1546420
	],
	[
		"s2487654",
		"Rubus glomeratus",
		"rubus",
		2487654
	],
	[
		"s3058175",
		"Rubus gongshanensis",
		"rubus",
		3058175
	],
	[
		"s1546339",
		"Rubus goniophorus",
		"rubus",
		1546339
	],
	[
		"s1546421",
		"Rubus gothicus",
		"rubus",
		1546421
	],
	[
		"s1546422",
		"Rubus grabowskii",
		"rubus",
		1546422
	],
	[
		"s1546423",
		"Rubus gracilis",
		"rubus",
		1546423
	],
	[
		"s1546424",
		"Rubus graecensis",
		"rubus",
		1546424
	],
	[
		"s3091808",
		"Rubus granulatus",
		"rubus",
		3091808
	],
	[
		"s3091809",
		"Rubus gratiosus",
		"rubus",
		3091809
	],
	[
		"s1546425",
		"Rubus gratus",
		"rubus",
		1546425
	],
	[
		"s1497950",
		"Rubus grayanus",
		"rubus",
		1497950
	],
	[
		"s3042589",
		"Rubus grayanus x Rubus palmatus",
		"rubus",
		3042589
	],
	[
		"s3091810",
		"Rubus gremlii",
		"rubus",
		3091810
	],
	[
		"s3091811",
		"Rubus gressittii",
		"rubus",
		3091811
	],
	[
		"s3091812",
		"Rubus griffithianus",
		"rubus",
		3091812
	],
	[
		"s1546426",
		"Rubus grossus",
		"rubus",
		1546426
	],
	[
		"s75069",
		"Rubus gunnianus",
		"rubus",
		75069
	],
	[
		"s1546340",
		"Rubus guttiferus",
		"rubus",
		1546340
	],
	[
		"s1813507",
		"Rubus gyamdaensis",
		"rubus",
		1813507
	],
	[
		"s1546427",
		"Rubus hadracanthus",
		"rubus",
		1546427
	],
	[
		"s3091813",
		"Rubus hakonensis",
		"rubus",
		3091813
	],
	[
		"s2785555",
		"Rubus hallandicus",
		"rubus",
		2785555
	],
	[
		"s3091814",
		"Rubus hanceanus",
		"rubus",
		3091814
	],
	[
		"s3091815",
		"Rubus hartmanii",
		"rubus",
		3091815
	],
	[
		"s3091816",
		"Rubus hastifolius",
		"rubus",
		3091816
	],
	[
		"s59493",
		"Rubus hawaiensis",
		"rubus",
		59493
	],
	[
		"s209395",
		"Rubus hawaiensis x Rubus rosifolius",
		"rubus",
		209395
	],
	[
		"s3091817",
		"Rubus hebecarpos",
		"rubus",
		3091817
	],
	[
		"s3091818",
		"Rubus hemithyrsus",
		"rubus",
		3091818
	],
	[
		"s1546428",
		"Rubus henrici-egonis",
		"rubus",
		1546428
	],
	[
		"s1521122",
		"Rubus henryi",
		"rubus",
		1521122
	],
	[
		"s3091819",
		"Rubus hercynicus",
		"rubus",
		3091819
	],
	[
		"s3091820",
		"Rubus heterophyllus",
		"rubus",
		3091820
	],
	[
		"s1546341",
		"Rubus hilsianus",
		"rubus",
		1546341
	],
	[
		"s321600",
		"Rubus hirsutus",
		"rubus",
		321600
	],
	[
		"s2136372",
		"Rubus hirtus",
		"rubus",
		2136372
	],
	[
		"s43104",
		"Rubus hispidus",
		"rubus",
		43104
	],
	[
		"s260091",
		"Rubus hochstetterorum",
		"rubus",
		260091
	],
	[
		"s421243",
		"Rubus hoffmeisterianus",
		"rubus",
		421243
	],
	[
		"s1546429",
		"Rubus holosericeus",
		"rubus",
		1546429
	],
	[
		"s3091821",
		"Rubus horrefactus",
		"rubus",
		3091821
	],
	[
		"s3695205",
		"Rubus howii",
		"rubus",
		3695205
	],
	[
		"s2233528",
		"Rubus huangpingensis",
		"rubus",
		2233528
	],
	[
		"s3091822",
		"Rubus humistratus",
		"rubus",
		3091822
	],
	[
		"s75070",
		"Rubus humulifolius",
		"rubus",
		75070
	],
	[
		"s411215",
		"Rubus hunanensis",
		"rubus",
		411215
	],
	[
		"s564016",
		"Rubus hybrid cultivar",
		"rubus",
		564016
	],
	[
		"s3091823",
		"Rubus hylonomus",
		"rubus",
		3091823
	],
	[
		"s1546370",
		"Rubus hypomalacus",
		"rubus",
		1546370
	],
	[
		"s1813492",
		"Rubus hypopitys",
		"rubus",
		1813492
	],
	[
		"s3091824",
		"Rubus hystrix",
		"rubus",
		3091824
	],
	[
		"s1705294",
		"Rubus ibericus",
		"rubus",
		1705294
	],
	[
		"s421244",
		"Rubus ichangensis",
		"rubus",
		421244
	],
	[
		"s616959",
		"Rubus idaeopsis",
		"rubus",
		616959
	],
	[
		"s32247",
		"Rubus idaeus",
		"rubus",
		32247
	],
	[
		"s1546366",
		"Rubus idaeus x Rubus caesius",
		"rubus",
		1546366
	],
	[
		"s225694",
		"Rubus idaeus x Rubus inermis",
		"rubus",
		225694
	],
	[
		"s2823975",
		"Rubus ikenoensis",
		"rubus",
		2823975
	],
	[
		"s2071525",
		"Rubus illecebrosus",
		"rubus",
		2071525
	],
	[
		"s3091825",
		"Rubus imbricatus",
		"rubus",
		3091825
	],
	[
		"s3091826",
		"Rubus imperialis",
		"rubus",
		3091826
	],
	[
		"s3091827",
		"Rubus impressinervus",
		"rubus",
		3091827
	],
	[
		"s1546430",
		"Rubus incanescens",
		"rubus",
		1546430
	],
	[
		"s2814615",
		"Rubus incanus",
		"rubus",
		2814615
	],
	[
		"s2487655",
		"Rubus indicus",
		"rubus",
		2487655
	],
	[
		"s421245",
		"Rubus indotibetanus",
		"rubus",
		421245
	],
	[
		"s1546431",
		"Rubus indusiatus",
		"rubus",
		1546431
	],
	[
		"s3091828",
		"Rubus infestisepalus",
		"rubus",
		3091828
	],
	[
		"s1546432",
		"Rubus infestus",
		"rubus",
		1546432
	],
	[
		"s421246",
		"Rubus innominatus",
		"rubus",
		421246
	],
	[
		"s616960",
		"Rubus inopertus",
		"rubus",
		616960
	],
	[
		"s3091829",
		"Rubus insericatus",
		"rubus",
		3091829
	],
	[
		"s3091830",
		"Rubus insularis",
		"rubus",
		3091830
	],
	[
		"s1546433",
		"Rubus integribasis",
		"rubus",
		1546433
	],
	[
		"s3091831",
		"Rubus irasuensis",
		"rubus",
		3091831
	],
	[
		"s421247",
		"Rubus irenaeus",
		"rubus",
		421247
	],
	[
		"s1813497",
		"Rubus irritans",
		"rubus",
		1813497
	],
	[
		"s2520632",
		"Rubus ithacanus",
		"rubus",
		2520632
	],
	[
		"s1546342",
		"Rubus iuvenis",
		"rubus",
		1546342
	],
	[
		"s3058176",
		"Rubus jambosoides",
		"rubus",
		3058176
	],
	[
		"s1813512",
		"Rubus jianensis",
		"rubus",
		1813512
	],
	[
		"s1546343",
		"Rubus juennensis",
		"rubus",
		1546343
	],
	[
		"s2527790",
		"Rubus junceus",
		"rubus",
		2527790
	],
	[
		"s3091832",
		"Rubus kaltenbachii",
		"rubus",
		3091832
	],
	[
		"s2814610",
		"Rubus kawakamii",
		"rubus",
		2814610
	],
	[
		"s2984593",
		"Rubus keniensis",
		"rubus",
		2984593
	],
	[
		"s2823974",
		"Rubus kisoensis",
		"rubus",
		2823974
	],
	[
		"s1546434",
		"Rubus koehleri",
		"rubus",
		1546434
	],
	[
		"s1546435",
		"Rubus kuleszae",
		"rubus",
		1546435
	],
	[
		"s1521124",
		"Rubus kulinganus",
		"rubus",
		1521124
	],
	[
		"s3058177",
		"Rubus kumaonensis",
		"rubus",
		3058177
	],
	[
		"s2814616",
		"Rubus laciniatostipulatus",
		"rubus",
		2814616
	],
	[
		"s1546436",
		"Rubus laciniatus",
		"rubus",
		1546436
	],
	[
		"s2497807",
		"Rubus laegaardii",
		"rubus",
		2497807
	],
	[
		"s3091833",
		"Rubus lagerbergii",
		"rubus",
		3091833
	],
	[
		"s3366685",
		"Rubus lainzii",
		"rubus",
		3366685
	],
	[
		"s75113",
		"Rubus lambertianus",
		"rubus",
		75113
	],
	[
		"s2785556",
		"Rubus langei",
		"rubus",
		2785556
	],
	[
		"s75071",
		"Rubus lasiococcus",
		"rubus",
		75071
	],
	[
		"s421248",
		"Rubus lasiostylus",
		"rubus",
		421248
	],
	[
		"s1521125",
		"Rubus lasiotrichos",
		"rubus",
		1521125
	],
	[
		"s3091834",
		"Rubus latoauriculatus",
		"rubus",
		3091834
	],
	[
		"s3091835",
		"Rubus laudatus",
		"rubus",
		3091835
	],
	[
		"s2892304",
		"Rubus lechleri",
		"rubus",
		2892304
	],
	[
		"s3091836",
		"Rubus leptothyrsos",
		"rubus",
		3091836
	],
	[
		"s1546344",
		"Rubus leucandrus",
		"rubus",
		1546344
	],
	[
		"s1603830",
		"Rubus leucanthus",
		"rubus",
		1603830
	],
	[
		"s2932497",
		"Rubus leucocarpus",
		"rubus",
		2932497
	],
	[
		"s190227",
		"Rubus leucodermis",
		"rubus",
		190227
	],
	[
		"s3091837",
		"Rubus leucostachys",
		"rubus",
		3091837
	],
	[
		"s3091838",
		"Rubus leviculus",
		"rubus",
		3091838
	],
	[
		"s3091839",
		"Rubus lichuanensis",
		"rubus",
		3091839
	],
	[
		"s3091443",
		"Rubus lidforssii",
		"rubus",
		3091443
	],
	[
		"s1546437",
		"Rubus lindebergii",
		"rubus",
		1546437
	],
	[
		"s2666040",
		"Rubus lindleianus",
		"rubus",
		2666040
	],
	[
		"s75072",
		"Rubus lineatus",
		"rubus",
		75072
	],
	[
		"s3091840",
		"Rubus linkianus",
		"rubus",
		3091840
	],
	[
		"s2803533",
		"Rubus liui",
		"rubus",
		2803533
	],
	[
		"s1546438",
		"Rubus lividus",
		"rubus",
		1546438
	],
	[
		"s3058178",
		"Rubus lobophyllus",
		"rubus",
		3058178
	],
	[
		"s1546439",
		"Rubus loehrii",
		"rubus",
		1546439
	],
	[
		"s3091444",
		"Rubus longepedicellatus",
		"rubus",
		3091444
	],
	[
		"s3091841",
		"Rubus longii",
		"rubus",
		3091841
	],
	[
		"s321597",
		"Rubus longisepalus",
		"rubus",
		321597
	],
	[
		"s2497808",
		"Rubus loxensis",
		"rubus",
		2497808
	],
	[
		"s3058179",
		"Rubus lucens",
		"rubus",
		3058179
	],
	[
		"s3058180",
		"Rubus luchunensis",
		"rubus",
		3058180
	],
	[
		"s3091842",
		"Rubus lucidus",
		"rubus",
		3091842
	],
	[
		"s2774447",
		"Rubus ludwigii",
		"rubus",
		2774447
	],
	[
		"s2995199",
		"Rubus ludwigii x Rubus pinnatus",
		"rubus",
		2995199
	],
	[
		"s3091843",
		"Rubus lusaticus",
		"rubus",
		3091843
	],
	[
		"s3091844",
		"Rubus lutescens",
		"rubus",
		3091844
	],
	[
		"s421249",
		"Rubus macilentus",
		"rubus",
		421249
	],
	[
		"s59494",
		"Rubus macraei",
		"rubus",
		59494
	],
	[
		"s1546440",
		"Rubus macrophyllus",
		"rubus",
		1546440
	],
	[
		"s3091845",
		"Rubus macrostachys",
		"rubus",
		3091845
	],
	[
		"s1813499",
		"Rubus malifolius",
		"rubus",
		1813499
	],
	[
		"s3091846",
		"Rubus malipoensis",
		"rubus",
		3091846
	],
	[
		"s2259407",
		"Rubus matsumuranus",
		"rubus",
		2259407
	],
	[
		"s168319",
		"Rubus maximiformis",
		"rubus",
		168319
	],
	[
		"s2823979",
		"Rubus medius",
		"rubus",
		2823979
	],
	[
		"s3058181",
		"Rubus menglaensis",
		"rubus",
		3058181
	],
	[
		"s2527791",
		"Rubus meracus",
		"rubus",
		2527791
	],
	[
		"s3091847",
		"Rubus mercieri",
		"rubus",
		3091847
	],
	[
		"s411216",
		"Rubus mesogaeus",
		"rubus",
		411216
	],
	[
		"s3058182",
		"Rubus metoensis",
		"rubus",
		3058182
	],
	[
		"s1546442",
		"Rubus micans",
		"rubus",
		1546442
	],
	[
		"s3091445",
		"Rubus michiganensis",
		"rubus",
		3091445
	],
	[
		"s2487656",
		"Rubus micropetalus",
		"rubus",
		2487656
	],
	[
		"s2697231",
		"Rubus microphyllus",
		"rubus",
		2697231
	],
	[
		"s75073",
		"Rubus minusculus",
		"rubus",
		75073
	],
	[
		"s2527792",
		"Rubus missouricus",
		"rubus",
		2527792
	],
	[
		"s1546443",
		"Rubus moestus",
		"rubus",
		1546443
	],
	[
		"s3091848",
		"Rubus mollior",
		"rubus",
		3091848
	],
	[
		"s1546444",
		"Rubus mollis",
		"rubus",
		1546444
	],
	[
		"s1619541",
		"Rubus moluccanus",
		"rubus",
		1619541
	],
	[
		"s1546445",
		"Rubus montanus",
		"rubus",
		1546445
	],
	[
		"s75074",
		"Rubus moorei",
		"rubus",
		75074
	],
	[
		"s2835572",
		"Rubus mortensenii",
		"rubus",
		2835572
	],
	[
		"s1546446",
		"Rubus moschus",
		"rubus",
		1546446
	],
	[
		"s1546367",
		"Rubus moschus x Rubus cf. ser. Discolores MS-2014",
		"rubus",
		1546367
	],
	[
		"s3091849",
		"Rubus mucronulatus",
		"rubus",
		3091849
	],
	[
		"s2785557",
		"Rubus muenteri",
		"rubus",
		2785557
	],
	[
		"s1546346",
		"Rubus muhelicus",
		"rubus",
		1546346
	],
	[
		"s2520633",
		"Rubus multifer",
		"rubus",
		2520633
	],
	[
		"s3091446",
		"Rubus multisetosus",
		"rubus",
		3091446
	],
	[
		"s3128718",
		"Rubus myrianthus",
		"rubus",
		3128718
	],
	[
		"s3091850",
		"Rubus nagasawanus",
		"rubus",
		3091850
	],
	[
		"s2823977",
		"Rubus nakaii",
		"rubus",
		2823977
	],
	[
		"s1619542",
		"Rubus nebulosus",
		"rubus",
		1619542
	],
	[
		"s1546447",
		"Rubus nemoralis",
		"rubus",
		1546447
	],
	[
		"s3091851",
		"Rubus nemorensis",
		"rubus",
		3091851
	],
	[
		"s3091852",
		"Rubus nemorosus",
		"rubus",
		3091852
	],
	[
		"s3058183",
		"Rubus neofuscifolius",
		"rubus",
		3058183
	],
	[
		"s190229",
		"Rubus neomexicanus",
		"rubus",
		190229
	],
	[
		"s75075",
		"Rubus nepalensis",
		"rubus",
		75075
	],
	[
		"s75076",
		"Rubus nessensis",
		"rubus",
		75076
	],
	[
		"s3714015",
		"Rubus nigricans",
		"rubus",
		3714015
	],
	[
		"s3091853",
		"Rubus nigricatus",
		"rubus",
		3091853
	],
	[
		"s1540538",
		"Rubus nishimuranus",
		"rubus",
		1540538
	],
	[
		"s75077",
		"Rubus nivalis",
		"rubus",
		75077
	],
	[
		"s59495",
		"Rubus niveus",
		"rubus",
		59495
	],
	[
		"s2904933",
		"Rubus niveus x Rubus transvaalensis",
		"rubus",
		2904933
	],
	[
		"s2678698",
		"Rubus norvegicus",
		"rubus",
		2678698
	],
	[
		"s75078",
		"Rubus nubigenus",
		"rubus",
		75078
	],
	[
		"s1813501",
		"Rubus nyalamensis",
		"rubus",
		1813501
	],
	[
		"s1521126",
		"Rubus oblongus",
		"rubus",
		1521126
	],
	[
		"s3091854",
		"Rubus obscurus",
		"rubus",
		3091854
	],
	[
		"s75079",
		"Rubus occidentalis",
		"rubus",
		75079
	],
	[
		"s3058184",
		"Rubus ochraceus",
		"rubus",
		3058184
	],
	[
		"s3091855",
		"Rubus ochrosetus",
		"rubus",
		3091855
	],
	[
		"s75080",
		"Rubus odoratus",
		"rubus",
		75080
	],
	[
		"s2823973",
		"Rubus okinawensis",
		"rubus",
		2823973
	],
	[
		"s3091856",
		"Rubus orthosepalus",
		"rubus",
		3091856
	],
	[
		"s1546448",
		"Rubus orthostachys",
		"rubus",
		1546448
	],
	[
		"s3091447",
		"Rubus ortivus",
		"rubus",
		3091447
	],
	[
		"s3091857",
		"Rubus ourosepalus",
		"rubus",
		3091857
	],
	[
		"s1521127",
		"Rubus pacificus",
		"rubus",
		1521127
	],
	[
		"s1546347",
		"Rubus palaefolius",
		"rubus",
		1546347
	],
	[
		"s2835571",
		"Rubus pallidus",
		"rubus",
		2835571
	],
	[
		"s190230",
		"Rubus palmatus",
		"rubus",
		190230
	],
	[
		"s1519688",
		"Rubus palmensis",
		"rubus",
		1519688
	],
	[
		"s1813502",
		"Rubus panduratus",
		"rubus",
		1813502
	],
	[
		"s1672631",
		"Rubus paniculatus",
		"rubus",
		1672631
	],
	[
		"s2904924",
		"Rubus pappei",
		"rubus",
		2904924
	],
	[
		"s616964",
		"Rubus parkeri",
		"rubus",
		616964
	],
	[
		"s1546348",
		"Rubus parthenocissus",
		"rubus",
		1546348
	],
	[
		"s2814612",
		"Rubus parviaraliifolius",
		"rubus",
		2814612
	],
	[
		"s59496",
		"Rubus parviflorus",
		"rubus",
		59496
	],
	[
		"s176136",
		"Rubus parvifolius",
		"rubus",
		176136
	],
	[
		"s75081",
		"Rubus parvus",
		"rubus",
		75081
	],
	[
		"s1546349",
		"Rubus passaviensis",
		"rubus",
		1546349
	],
	[
		"s1521128",
		"Rubus paucidentatus",
		"rubus",
		1521128
	],
	[
		"s421250",
		"Rubus pectinarioides",
		"rubus",
		421250
	],
	[
		"s2761760",
		"Rubus pectinaris",
		"rubus",
		2761760
	],
	[
		"s75133",
		"Rubus pectinellus",
		"rubus",
		75133
	],
	[
		"s75082",
		"Rubus pedatus",
		"rubus",
		75082
	],
	[
		"s75083",
		"Rubus pedemontanus",
		"rubus",
		75083
	],
	[
		"s3049248",
		"Rubus pedunculosus",
		"rubus",
		3049248
	],
	[
		"s1813504",
		"Rubus peltatus",
		"rubus",
		1813504
	],
	[
		"s75084",
		"Rubus pensilvanicus",
		"rubus",
		75084
	],
	[
		"s421251",
		"Rubus pentagonus",
		"rubus",
		421251
	],
	[
		"s1546449",
		"Rubus pericrispatus",
		"rubus",
		1546449
	],
	[
		"s1546450",
		"Rubus peripragensis",
		"rubus",
		1546450
	],
	[
		"s1546350",
		"Rubus perlongus",
		"rubus",
		1546350
	],
	[
		"s2520634",
		"Rubus permixtus",
		"rubus",
		2520634
	],
	[
		"s1546351",
		"Rubus perpedatus",
		"rubus",
		1546351
	],
	[
		"s1546352",
		"Rubus perperus",
		"rubus",
		1546352
	],
	[
		"s1546452",
		"Rubus perrobustus",
		"rubus",
		1546452
	],
	[
		"s3091858",
		"Rubus persicinus",
		"rubus",
		3091858
	],
	[
		"s411217",
		"Rubus phengodes",
		"rubus",
		411217
	],
	[
		"s75085",
		"Rubus phoenicolasius",
		"rubus",
		75085
	],
	[
		"s1546453",
		"Rubus phyllostachys",
		"rubus",
		1546453
	],
	[
		"s168318",
		"Rubus picticaulis",
		"rubus",
		168318
	],
	[
		"s1813505",
		"Rubus pileatus",
		"rubus",
		1813505
	],
	[
		"s1521130",
		"Rubus pilulifer",
		"rubus",
		1521130
	],
	[
		"s616965",
		"Rubus pinfaensis",
		"rubus",
		616965
	],
	[
		"s616966",
		"Rubus pinnatisepalus",
		"rubus",
		616966
	],
	[
		"s2904923",
		"Rubus pinnatus",
		"rubus",
		2904923
	],
	[
		"s2904941",
		"Rubus pinnatus x Rubus rigidus",
		"rubus",
		2904941
	],
	[
		"s1546455",
		"Rubus platyacanthus",
		"rubus",
		1546455
	],
	[
		"s1546353",
		"Rubus platyphyllus",
		"rubus",
		1546353
	],
	[
		"s3091859",
		"Rubus platysepalus",
		"rubus",
		3091859
	],
	[
		"s1521131",
		"Rubus playfairianus",
		"rubus",
		1521131
	],
	[
		"s2527793",
		"Rubus plicatifolius",
		"rubus",
		2527793
	],
	[
		"s3091448",
		"Rubus pliocenicus",
		"rubus",
		3091448
	],
	[
		"s3058185",
		"Rubus poliophyllus",
		"rubus",
		3058185
	],
	[
		"s1546486",
		"Rubus polyanthemus",
		"rubus",
		1546486
	],
	[
		"s3091860",
		"Rubus polyodontus",
		"rubus",
		3091860
	],
	[
		"s1546354",
		"Rubus portae-moravicae",
		"rubus",
		1546354
	],
	[
		"s3091861",
		"Rubus potentilloides",
		"rubus",
		3091861
	],
	[
		"s926033",
		"Rubus praecox",
		"rubus",
		926033
	],
	[
		"s3091862",
		"Rubus preptanthus",
		"rubus",
		3091862
	],
	[
		"s2829525",
		"Rubus pringlei",
		"rubus",
		2829525
	],
	[
		"s3091863",
		"Rubus probabilis",
		"rubus",
		3091863
	],
	[
		"s1619543",
		"Rubus probus",
		"rubus",
		1619543
	],
	[
		"s3091864",
		"Rubus proiectus",
		"rubus",
		3091864
	],
	[
		"s1546456",
		"Rubus pruinosus",
		"rubus",
		1546456
	],
	[
		"s1546355",
		"Rubus pseudargenteus",
		"rubus",
		1546355
	],
	[
		"s2823962",
		"Rubus pseudoacer",
		"rubus",
		2823962
	],
	[
		"s2823970",
		"Rubus pseudojaponicus",
		"rubus",
		2823970
	],
	[
		"s1813506",
		"Rubus pseudopileatus",
		"rubus",
		1813506
	],
	[
		"s3091865",
		"Rubus ptilocarpus",
		"rubus",
		3091865
	],
	[
		"s75086",
		"Rubus pubescens",
		"rubus",
		75086
	],
	[
		"s321608",
		"Rubus pungens",
		"rubus",
		321608
	],
	[
		"s1546458",
		"Rubus pyramidalis",
		"rubus",
		1546458
	],
	[
		"s616967",
		"Rubus pyrifolius",
		"rubus",
		616967
	],
	[
		"s1382180",
		"Rubus queenslandicus",
		"rubus",
		1382180
	],
	[
		"s2916457",
		"Rubus quinquefoliolatus",
		"rubus",
		2916457
	],
	[
		"s2487658",
		"Rubus racemosus",
		"rubus",
		2487658
	],
	[
		"s3091866",
		"Rubus radicans",
		"rubus",
		3091866
	],
	[
		"s1546459",
		"Rubus radula",
		"rubus",
		1546459
	],
	[
		"s1546460",
		"Rubus raduloides",
		"rubus",
		1546460
	],
	[
		"s3091867",
		"Rubus raopingensis",
		"rubus",
		3091867
	],
	[
		"s2520635",
		"Rubus recurvans",
		"rubus",
		2520635
	],
	[
		"s1078262",
		"Rubus reflexus",
		"rubus",
		1078262
	],
	[
		"s3058186",
		"Rubus refractus",
		"rubus",
		3058186
	],
	[
		"s2520636",
		"Rubus regionalis",
		"rubus",
		2520636
	],
	[
		"s75061",
		"Rubus repens",
		"rubus",
		75061
	],
	[
		"s1813510",
		"Rubus reticulatus",
		"rubus",
		1813510
	],
	[
		"s1546461",
		"Rubus rhamnifolius",
		"rubus",
		1546461
	],
	[
		"s1546462",
		"Rubus rhombifolius",
		"rubus",
		1546462
	],
	[
		"s3091868",
		"Rubus rhombophyllus",
		"rubus",
		3091868
	],
	[
		"s2823972",
		"Rubus ribifolius",
		"rubus",
		2823972
	],
	[
		"s321596",
		"Rubus ribisoideus",
		"rubus",
		321596
	],
	[
		"s59497",
		"Rubus rigidus",
		"rubus",
		59497
	],
	[
		"s2995203",
		"Rubus rigidus x Rubus bergii",
		"rubus",
		2995203
	],
	[
		"s2904935",
		"Rubus rigidus x Rubus ulmifolius",
		"rubus",
		2904935
	],
	[
		"s3091869",
		"Rubus riograndis",
		"rubus",
		3091869
	],
	[
		"s3091870",
		"Rubus rivularis",
		"rubus",
		3091870
	],
	[
		"s75087",
		"Rubus robustus",
		"rubus",
		75087
	],
	[
		"s3091871",
		"Rubus rolfei",
		"rubus",
		3091871
	],
	[
		"s3091449",
		"Rubus roribaccus",
		"rubus",
		3091449
	],
	[
		"s2520637",
		"Rubus rosa",
		"rubus",
		2520637
	],
	[
		"s3091872",
		"Rubus rosanthus",
		"rubus",
		3091872
	],
	[
		"s75088",
		"Rubus roseus",
		"rubus",
		75088
	],
	[
		"s59498",
		"Rubus rosifolius",
		"rubus",
		59498
	],
	[
		"s3091873",
		"Rubus rubiginosus",
		"rubus",
		3091873
	],
	[
		"s3695206",
		"Rubus rubrisetulosus",
		"rubus",
		3695206
	],
	[
		"s1908214",
		"Rubus rubritinctus",
		"rubus",
		1908214
	],
	[
		"s2814617",
		"Rubus rubroangustifolius",
		"rubus",
		2814617
	],
	[
		"s655866",
		"Rubus rudis",
		"rubus",
		655866
	],
	[
		"s3091874",
		"Rubus rufescens",
		"rubus",
		3091874
	],
	[
		"s616968",
		"Rubus rufus",
		"rubus",
		616968
	],
	[
		"s2487660",
		"Rubus rugosus",
		"rubus",
		2487660
	],
	[
		"s59502",
		"Rubus sachalinensis",
		"rubus",
		59502
	],
	[
		"s3091875",
		"Rubus salisburgensis",
		"rubus",
		3091875
	],
	[
		"s3091876",
		"Rubus salwinensis",
		"rubus",
		3091876
	],
	[
		"s75089",
		"Rubus sanctus",
		"rubus",
		75089
	],
	[
		"s75090",
		"Rubus sapidus",
		"rubus",
		75090
	],
	[
		"s75091",
		"Rubus saxatilis",
		"rubus",
		75091
	],
	[
		"s3091877",
		"Rubus scaber",
		"rubus",
		3091877
	],
	[
		"s2984594",
		"Rubus scheffleri",
		"rubus",
		2984594
	],
	[
		"s3015751",
		"Rubus schiedeanus",
		"rubus",
		3015751
	],
	[
		"s321595",
		"Rubus schizostylus",
		"rubus",
		321595
	],
	[
		"s1546463",
		"Rubus schlechtendalii",
		"rubus",
		1546463
	],
	[
		"s1546464",
		"Rubus schleicheri",
		"rubus",
		1546464
	],
	[
		"s2044933",
		"Rubus schmidelioides",
		"rubus",
		2044933
	],
	[
		"s3091878",
		"Rubus schottii",
		"rubus",
		3091878
	],
	[
		"s1546465",
		"Rubus sciocharis",
		"rubus",
		1546465
	],
	[
		"s3091879",
		"Rubus sciophilus",
		"rubus",
		3091879
	],
	[
		"s1546356",
		"Rubus scissoides",
		"rubus",
		1546356
	],
	[
		"s1546466",
		"Rubus scissus",
		"rubus",
		1546466
	],
	[
		"s3091880",
		"Rubus sellowii",
		"rubus",
		3091880
	],
	[
		"s3418160",
		"Rubus semiplenus",
		"rubus",
		3418160
	],
	[
		"s2520638",
		"Rubus semisetosus",
		"rubus",
		2520638
	],
	[
		"s421252",
		"Rubus sengorensis",
		"rubus",
		421252
	],
	[
		"s1546468",
		"Rubus senticosus",
		"rubus",
		1546468
	],
	[
		"s2042671",
		"Rubus septentrionalis",
		"rubus",
		2042671
	],
	[
		"s3091798",
		"Rubus serpens",
		"rubus",
		3091798
	],
	[
		"s1546357",
		"Rubus serrae",
		"rubus",
		1546357
	],
	[
		"s421253",
		"Rubus setchuenensis",
		"rubus",
		421253
	],
	[
		"s75092",
		"Rubus setosus",
		"rubus",
		75092
	],
	[
		"s3054259",
		"Rubus shihae",
		"rubus",
		3054259
	],
	[
		"s2823971",
		"Rubus sieboldii",
		"rubus",
		2823971
	],
	[
		"s3091881",
		"Rubus sikkimensis",
		"rubus",
		3091881
	],
	[
		"s3091882",
		"Rubus silesiacus",
		"rubus",
		3091882
	],
	[
		"s1546358",
		"Rubus silvae-bohemicae",
		"rubus",
		1546358
	],
	[
		"s1546359",
		"Rubus silvae-norticae",
		"rubus",
		1546359
	],
	[
		"s1546471",
		"Rubus silvaticus",
		"rubus",
		1546471
	],
	[
		"s1866306",
		"Rubus simplex",
		"rubus",
		1866306
	],
	[
		"s3091883",
		"Rubus solvensis",
		"rubus",
		3091883
	],
	[
		"s321602",
		"Rubus sorbifolius",
		"rubus",
		321602
	],
	[
		"s2892305",
		"Rubus sparsiflorus",
		"rubus",
		2892305
	],
	[
		"s59499",
		"Rubus spectabilis",
		"rubus",
		59499
	],
	[
		"s2527794",
		"Rubus spectatus",
		"rubus",
		2527794
	],
	[
		"s1546472",
		"Rubus sprengelii",
		"rubus",
		1546472
	],
	[
		"s616969",
		"Rubus stans",
		"rubus",
		616969
	],
	[
		"s2520639",
		"Rubus steelei",
		"rubus",
		2520639
	],
	[
		"s1546473",
		"Rubus stereacanthos",
		"rubus",
		1546473
	],
	[
		"s1220087",
		"Rubus steudneri",
		"rubus",
		1220087
	],
	[
		"s1813513",
		"Rubus stimulans",
		"rubus",
		1813513
	],
	[
		"s1546360",
		"Rubus stimulifer",
		"rubus",
		1546360
	],
	[
		"s2527795",
		"Rubus stipulatus",
		"rubus",
		2527795
	],
	[
		"s1813514",
		"Rubus stipulosus",
		"rubus",
		1813514
	],
	[
		"s1521132",
		"Rubus subcoreanus",
		"rubus",
		1521132
	],
	[
		"s2697232",
		"Rubus subcrataegifolius",
		"rubus",
		2697232
	],
	[
		"s616970",
		"Rubus subinopertus",
		"rubus",
		616970
	],
	[
		"s2294065",
		"Rubus subornatus",
		"rubus",
		2294065
	],
	[
		"s616971",
		"Rubus subtibetanus",
		"rubus",
		616971
	],
	[
		"s75093",
		"Rubus sulcatus",
		"rubus",
		75093
	],
	[
		"s1521133",
		"Rubus sumatranus",
		"rubus",
		1521133
	],
	[
		"s2527801",
		"Rubus superioris",
		"rubus",
		2527801
	],
	[
		"s3714018",
		"Rubus suspiciosus",
		"rubus",
		3714018
	],
	[
		"s421255",
		"Rubus swinhoei",
		"rubus",
		421255
	],
	[
		"s1546475",
		"Rubus tabanimontanus",
		"rubus",
		1546475
	],
	[
		"s2814611",
		"Rubus taitoensis",
		"rubus",
		2814611
	],
	[
		"s2814613",
		"Rubus taiwanicola",
		"rubus",
		2814613
	],
	[
		"s321598",
		"Rubus takesimensis",
		"rubus",
		321598
	],
	[
		"s3091884",
		"Rubus tardus",
		"rubus",
		3091884
	],
	[
		"s75094",
		"Rubus tephrodes",
		"rubus",
		75094
	],
	[
		"s1546476",
		"Rubus tereticaulis",
		"rubus",
		1546476
	],
	[
		"s2904926",
		"Rubus thaumasius",
		"rubus",
		2904926
	],
	[
		"s2995202",
		"Rubus thaumasius x Rubus pinnatus",
		"rubus",
		2995202
	],
	[
		"s2291159",
		"Rubus thibetanus",
		"rubus",
		2291159
	],
	[
		"s421256",
		"Rubus thomsonii",
		"rubus",
		421256
	],
	[
		"s3091885",
		"Rubus thyrsiflorus",
		"rubus",
		3091885
	],
	[
		"s519941",
		"Rubus thyrsiger",
		"rubus",
		519941
	],
	[
		"s2904927",
		"Rubus titanus",
		"rubus",
		2904927
	],
	[
		"s2844385",
		"Rubus tokin-ibara",
		"rubus",
		2844385
	],
	[
		"s2904925",
		"Rubus transvaalensis",
		"rubus",
		2904925
	],
	[
		"s421257",
		"Rubus treutleri",
		"rubus",
		421257
	],
	[
		"s190232",
		"Rubus trianthus",
		"rubus",
		190232
	],
	[
		"s2904928",
		"Rubus trichogynus",
		"rubus",
		2904928
	],
	[
		"s75095",
		"Rubus tricolor",
		"rubus",
		75095
	],
	[
		"s75096",
		"Rubus trifidus",
		"rubus",
		75096
	],
	[
		"s3091886",
		"Rubus trijugus",
		"rubus",
		3091886
	],
	[
		"s75097",
		"Rubus trilobus",
		"rubus",
		75097
	],
	[
		"s75098",
		"Rubus trivialis",
		"rubus",
		75098
	],
	[
		"s616972",
		"Rubus tsangii",
		"rubus",
		616972
	],
	[
		"s1521134",
		"Rubus tsangiorum",
		"rubus",
		1521134
	],
	[
		"s1843275",
		"Rubus tuberculatus",
		"rubus",
		1843275
	],
	[
		"s75099",
		"Rubus ulmifolius",
		"rubus",
		75099
	],
	[
		"s519942",
		"Rubus ulmifolius var. inermis x Rubus thyrsiger",
		"rubus",
		519942
	],
	[
		"s1546368",
		"Rubus ulmifolius x Rubus caesius",
		"rubus",
		1546368
	],
	[
		"s2527796",
		"Rubus uniformis",
		"rubus",
		2527796
	],
	[
		"s75100",
		"Rubus ursinus",
		"rubus",
		75100
	],
	[
		"s2497802",
		"Rubus ursinus x Rubus armeniacus",
		"rubus",
		2497802
	],
	[
		"s190233",
		"Rubus urticifolius",
		"rubus",
		190233
	],
	[
		"s2823976",
		"Rubus utchinensis",
		"rubus",
		2823976
	],
	[
		"s2520640",
		"Rubus uvidus",
		"rubus",
		2520640
	],
	[
		"s2527802",
		"Rubus vagus",
		"rubus",
		2527802
	],
	[
		"s3714019",
		"Rubus vahlii",
		"rubus",
		3714019
	],
	[
		"s1546478",
		"Rubus vatavensis",
		"rubus",
		1546478
	],
	[
		"s2527797",
		"Rubus vermontanus",
		"rubus",
		2527797
	],
	[
		"s2697233",
		"Rubus vernus",
		"rubus",
		2697233
	],
	[
		"s1546479",
		"Rubus vestitus",
		"rubus",
		1546479
	],
	[
		"s75101",
		"Rubus vigorosus",
		"rubus",
		75101
	],
	[
		"s3091887",
		"Rubus villicaulis",
		"rubus",
		3091887
	],
	[
		"s2984595",
		"Rubus volkensii",
		"rubus",
		2984595
	],
	[
		"s1546480",
		"Rubus vratnensis",
		"rubus",
		1546480
	],
	[
		"s1807088",
		"Rubus vulcanicola",
		"rubus",
		1807088
	],
	[
		"s2728858",
		"Rubus vulgaris",
		"rubus",
		2728858
	],
	[
		"s1546481",
		"Rubus wahlbergii",
		"rubus",
		1546481
	],
	[
		"s2743669",
		"Rubus wallichianus",
		"rubus",
		2743669
	],
	[
		"s3091888",
		"Rubus wardii",
		"rubus",
		3091888
	],
	[
		"s2892306",
		"Rubus weberbaueri",
		"rubus",
		2892306
	],
	[
		"s3091889",
		"Rubus weizensis",
		"rubus",
		3091889
	],
	[
		"s2520641",
		"Rubus wheeleri",
		"rubus",
		2520641
	],
	[
		"s1546483",
		"Rubus wimmerianus",
		"rubus",
		1546483
	],
	[
		"s1546484",
		"Rubus winteri",
		"rubus",
		1546484
	],
	[
		"s2520642",
		"Rubus wisconsinensis",
		"rubus",
		2520642
	],
	[
		"s3092075",
		"Rubus x biformispinus",
		"rubus",
		3092075
	],
	[
		"s3118391",
		"Rubus x calopalmatus",
		"rubus",
		3118391
	],
	[
		"s2527805",
		"Rubus x elegantulus",
		"rubus",
		2527805
	],
	[
		"s483748",
		"Rubus x loganobaccus",
		"rubus",
		483748
	],
	[
		"s3118395",
		"Rubus x masakihisashii",
		"rubus",
		3118395
	],
	[
		"s2527806",
		"Rubus x miscix",
		"rubus",
		2527806
	],
	[
		"s3092076",
		"Rubus x neglectus",
		"rubus",
		3092076
	],
	[
		"s3092077",
		"Rubus x paracaulis",
		"rubus",
		3092077
	],
	[
		"s3118393",
		"Rubus x pseudochingii",
		"rubus",
		3118393
	],
	[
		"s2823978",
		"Rubus x pseudoyoshinoi",
		"rubus",
		2823978
	],
	[
		"s3092078",
		"Rubus x recurvicaulis",
		"rubus",
		3092078
	],
	[
		"s3092079",
		"Rubus x trifrons",
		"rubus",
		3092079
	],
	[
		"s3092080",
		"Rubus x trux",
		"rubus",
		3092080
	],
	[
		"s1546361",
		"Rubus x wolfredoi-wildpretii",
		"rubus",
		1546361
	],
	[
		"s2761762",
		"Rubus xanthocarpus",
		"rubus",
		2761762
	],
	[
		"s2761761",
		"Rubus xanthoneurus",
		"rubus",
		2761761
	],
	[
		"s2697235",
		"Rubus yabei",
		"rubus",
		2697235
	],
	[
		"s616973",
		"Rubus yiwuanus",
		"rubus",
		616973
	],
	[
		"s2697236",
		"Rubus yoshinoi",
		"rubus",
		2697236
	],
	[
		"s3058187",
		"Rubus yunanicus",
		"rubus",
		3058187
	],
	[
		"s1546485",
		"Rubus zangezurus",
		"rubus",
		1546485
	],
	[
		"s3091890",
		"Rubus zhaogoshanensis",
		"rubus",
		3091890
	],
	[
		"s3377008",
		"Rubus zixishanensis",
		"rubus",
		3377008
	],
	[
		"s1630250",
		"Sageretia brandrethiana",
		"sageretia",
		1630250
	],
	[
		"s2038663",
		"Sageretia camelliifolia",
		"sageretia",
		2038663
	],
	[
		"s3777137",
		"Sageretia coimbatorensis",
		"sageretia",
		3777137
	],
	[
		"s3777138",
		"Sageretia cordifolia",
		"sageretia",
		3777138
	],
	[
		"s3877553",
		"Sageretia devendrae",
		"sageretia",
		3877553
	],
	[
		"s2321340",
		"Sageretia elegans",
		"sageretia",
		2321340
	],
	[
		"s3877554",
		"Sageretia ellipsoidea",
		"sageretia",
		3877554
	],
	[
		"s1630249",
		"Sageretia filiformis",
		"sageretia",
		1630249
	],
	[
		"s3877555",
		"Sageretia gongshanensis",
		"sageretia",
		3877555
	],
	[
		"s2038664",
		"Sageretia gracilis",
		"sageretia",
		2038664
	],
	[
		"s1312842",
		"Sageretia hamosa",
		"sageretia",
		1312842
	],
	[
		"s1812996",
		"Sageretia hayatae",
		"sageretia",
		1812996
	],
	[
		"s2552194",
		"Sageretia henryi",
		"sageretia",
		2552194
	],
	[
		"s2038665",
		"Sageretia horrida",
		"sageretia",
		2038665
	],
	[
		"s3877556",
		"Sageretia kashmirensis",
		"sageretia",
		3877556
	],
	[
		"s3877557",
		"Sageretia kishtwarensis",
		"sageretia",
		3877557
	],
	[
		"s2552195",
		"Sageretia latifolia",
		"sageretia",
		2552195
	],
	[
		"s3091891",
		"Sageretia laxiflora",
		"sageretia",
		3091891
	],
	[
		"s3877558",
		"Sageretia lijiangensis",
		"sageretia",
		3877558
	],
	[
		"s2038666",
		"Sageretia liuzhouensis",
		"sageretia",
		2038666
	],
	[
		"s2306259",
		"Sageretia lucida",
		"sageretia",
		2306259
	],
	[
		"s2038667",
		"Sageretia melliana",
		"sageretia",
		2038667
	],
	[
		"s3877559",
		"Sageretia mexicana",
		"sageretia",
		3877559
	],
	[
		"s1620185",
		"Sageretia minutiflora",
		"sageretia",
		1620185
	],
	[
		"s2552196",
		"Sageretia omeiensis",
		"sageretia",
		2552196
	],
	[
		"s3445678",
		"Sageretia parviflora",
		"sageretia",
		3445678
	],
	[
		"s1616488",
		"Sageretia paucicostata",
		"sageretia",
		1616488
	],
	[
		"s3877560",
		"Sageretia pedicellata",
		"sageretia",
		3877560
	],
	[
		"s2038668",
		"Sageretia pycnophylla",
		"sageretia",
		2038668
	],
	[
		"s2552197",
		"Sageretia randaiensis",
		"sageretia",
		2552197
	],
	[
		"s3877561",
		"Sageretia rebmanii",
		"sageretia",
		3877561
	],
	[
		"s2038669",
		"Sageretia rugosa",
		"sageretia",
		2038669
	],
	[
		"s3877562",
		"Sageretia santapaui",
		"sageretia",
		3877562
	],
	[
		"s2552198",
		"Sageretia spicata",
		"sageretia",
		2552198
	],
	[
		"s2551833",
		"Sageretia spiciflora",
		"sageretia",
		2551833
	],
	[
		"s2038670",
		"Sageretia subcaudata",
		"sageretia",
		2038670
	],
	[
		"s72166",
		"Sageretia thea",
		"sageretia",
		72166
	],
	[
		"s3877563",
		"Sageretia wallichii",
		"sageretia",
		3877563
	],
	[
		"s1226769",
		"Sageretia wrightii",
		"sageretia",
		1226769
	],
	[
		"s2552201",
		"Sageretia yilinii",
		"sageretia",
		2552201
	],
	[
		"s176130",
		"Sanguisorba albiflora",
		"sanguisorba",
		176130
	],
	[
		"s281910",
		"Sanguisorba alpina",
		"sanguisorba",
		281910
	],
	[
		"s137454",
		"Sanguisorba ancistroides",
		"sanguisorba",
		137454
	],
	[
		"s3040768",
		"Sanguisorba applanata",
		"sanguisorba",
		3040768
	],
	[
		"s3877658",
		"Sanguisorba armena",
		"sanguisorba",
		3877658
	],
	[
		"s3379670",
		"Sanguisorba azovtsevii",
		"sanguisorba",
		3379670
	],
	[
		"s137455",
		"Sanguisorba canadensis",
		"sanguisorba",
		137455
	],
	[
		"s3091893",
		"Sanguisorba cretica",
		"sanguisorba",
		3091893
	],
	[
		"s2054570",
		"Sanguisorba diandra",
		"sanguisorba",
		2054570
	],
	[
		"s1533365",
		"Sanguisorba dodecandra",
		"sanguisorba",
		1533365
	],
	[
		"s3877659",
		"Sanguisorba durui",
		"sanguisorba",
		3877659
	],
	[
		"s176129",
		"Sanguisorba filiformis",
		"sanguisorba",
		176129
	],
	[
		"s176132",
		"Sanguisorba hakusanensis",
		"sanguisorba",
		176132
	],
	[
		"s3877660",
		"Sanguisorba indica",
		"sanguisorba",
		3877660
	],
	[
		"s176131",
		"Sanguisorba japonensis",
		"sanguisorba",
		176131
	],
	[
		"s3877661",
		"Sanguisorba mauritanica",
		"sanguisorba",
		3877661
	],
	[
		"s3877662",
		"Sanguisorba megacarpa",
		"sanguisorba",
		3877662
	],
	[
		"s2071538",
		"Sanguisorba menziesii",
		"sanguisorba",
		2071538
	],
	[
		"s137456",
		"Sanguisorba minor",
		"sanguisorba",
		137456
	],
	[
		"s176133",
		"Sanguisorba obtusa",
		"sanguisorba",
		176133
	],
	[
		"s3091894",
		"Sanguisorba occidentalis",
		"sanguisorba",
		3091894
	],
	[
		"s137457",
		"Sanguisorba officinalis",
		"sanguisorba",
		137457
	],
	[
		"s57938",
		"Sanguisorba parviflora",
		"sanguisorba",
		57938
	],
	[
		"s3877663",
		"Sanguisorba riparia",
		"sanguisorba",
		3877663
	],
	[
		"s3877664",
		"Sanguisorba sirnakia",
		"sanguisorba",
		3877664
	],
	[
		"s1037063",
		"Sanguisorba sitchensis",
		"sanguisorba",
		1037063
	],
	[
		"s176134",
		"Sanguisorba stipulata",
		"sanguisorba",
		176134
	],
	[
		"s176135",
		"Sanguisorba tenuifolia",
		"sanguisorba",
		176135
	],
	[
		"s1533367",
		"Sanguisorba verrucosa",
		"sanguisorba",
		1533367
	],
	[
		"s1399746",
		"Sarcochlamys pulcherrima",
		"sarcochlamys",
		1399746
	],
	[
		"s3092042",
		"Sarcomphalus acutifolius",
		"sarcomphalus",
		3092042
	],
	[
		"s345804",
		"Sarcomphalus amole",
		"sarcomphalus",
		345804
	],
	[
		"s3877875",
		"Sarcomphalus bidens",
		"sarcomphalus",
		3877875
	],
	[
		"s1569041",
		"Sarcomphalus cinnamomum",
		"sarcomphalus",
		1569041
	],
	[
		"s3877876",
		"Sarcomphalus crenatus",
		"sarcomphalus",
		3877876
	],
	[
		"s3091613",
		"Sarcomphalus cyclocardius",
		"sarcomphalus",
		3091613
	],
	[
		"s3877877",
		"Sarcomphalus divaricatus",
		"sarcomphalus",
		3877877
	],
	[
		"s3877878",
		"Sarcomphalus glaziovii",
		"sarcomphalus",
		3877878
	],
	[
		"s345807",
		"Sarcomphalus guatemalensis",
		"sarcomphalus",
		345807
	],
	[
		"s3877879",
		"Sarcomphalus havanensis",
		"sarcomphalus",
		3877879
	],
	[
		"s3103840",
		"Sarcomphalus joazeiro",
		"sarcomphalus",
		3103840
	],
	[
		"s3092046",
		"Sarcomphalus laurinus",
		"sarcomphalus",
		3092046
	],
	[
		"s3092045",
		"Sarcomphalus microdictyus",
		"sarcomphalus",
		3092045
	],
	[
		"s345810",
		"Sarcomphalus mistol",
		"sarcomphalus",
		345810
	],
	[
		"s3877880",
		"Sarcomphalus obovatus",
		"sarcomphalus",
		3877880
	],
	[
		"s73717",
		"Sarcomphalus obtusifolius",
		"sarcomphalus",
		73717
	],
	[
		"s3877881",
		"Sarcomphalus parvifolius",
		"sarcomphalus",
		3877881
	],
	[
		"s3877882",
		"Sarcomphalus piurensis",
		"sarcomphalus",
		3877882
	],
	[
		"s3877883",
		"Sarcomphalus platyphyllus",
		"sarcomphalus",
		3877883
	],
	[
		"s1465381",
		"Sarcomphalus reticulatus",
		"sarcomphalus",
		1465381
	],
	[
		"s3091614",
		"Sarcomphalus rhodoxylon",
		"sarcomphalus",
		3091614
	],
	[
		"s3091615",
		"Sarcomphalus saeri",
		"sarcomphalus",
		3091615
	],
	[
		"s345816",
		"Sarcomphalus taylorii",
		"sarcomphalus",
		345816
	],
	[
		"s345817",
		"Sarcomphalus thyrsiflorus",
		"sarcomphalus",
		345817
	],
	[
		"s3877884",
		"Sarcomphalus undulatus",
		"sarcomphalus",
		3877884
	],
	[
		"s1198268",
		"Sarcopilea domingensis",
		"sarcopilea",
		1198268
	],
	[
		"s137458",
		"Sarcopoterium spinosum",
		"sarcopoterium",
		137458
	],
	[
		"s691236",
		"Scandosorbus intermedia",
		"scandosorbus",
		691236
	],
	[
		"s3878572",
		"Scandosorbus liljeforsii",
		"scandosorbus",
		3878572
	],
	[
		"s1470436",
		"Scepocarpus batesii",
		"scepocarpus",
		1470436
	],
	[
		"s2306705",
		"Scepocarpus cordifolius",
		"scepocarpus",
		2306705
	],
	[
		"s3711212",
		"Scepocarpus flamignianus",
		"scepocarpus",
		3711212
	],
	[
		"s2794933",
		"Scepocarpus gabonensis",
		"scepocarpus",
		2794933
	],
	[
		"s1399752",
		"Scepocarpus hypselodendron",
		"scepocarpus",
		1399752
	],
	[
		"s2792730",
		"Scepocarpus oblongifolius",
		"scepocarpus",
		2792730
	],
	[
		"s2792731",
		"Scepocarpus obovatus",
		"scepocarpus",
		2792731
	],
	[
		"s2792733",
		"Scepocarpus repens",
		"scepocarpus",
		2792733
	],
	[
		"s2306706",
		"Scepocarpus rigidus",
		"scepocarpus",
		2306706
	],
	[
		"s2792734",
		"Scepocarpus robustus",
		"scepocarpus",
		2792734
	],
	[
		"s1586317",
		"Scepocarpus sansibaricus",
		"scepocarpus",
		1586317
	],
	[
		"s2792735",
		"Scepocarpus thonneri",
		"scepocarpus",
		2792735
	],
	[
		"s1237843",
		"Scepocarpus trinervis",
		"scepocarpus",
		1237843
	],
	[
		"s106708",
		"Schistocarpaea johnsonii",
		"schistocarpaea",
		106708
	],
	[
		"s2490916",
		"Scutia arenicola",
		"scutia",
		2490916
	],
	[
		"s106710",
		"Scutia buxifolia",
		"scutia",
		106710
	],
	[
		"s2552202",
		"Scutia eberhardtii",
		"scutia",
		2552202
	],
	[
		"s1158817",
		"Scutia myrtina",
		"scutia",
		1158817
	],
	[
		"s3091461",
		"Scutia spicata",
		"scutia",
		3091461
	],
	[
		"s2605020",
		"Scyphosyce manniana",
		"scyphosyce",
		2605020
	],
	[
		"s2605021",
		"Scyphosyce pandurata",
		"scyphosyce",
		2605021
	],
	[
		"s323942",
		"Serichonus gracilipes",
		"serichonus",
		323942
	],
	[
		"s72158",
		"Shepherdia argentea",
		"shepherdia",
		72158
	],
	[
		"s36905",
		"Shepherdia canadensis",
		"shepherdia",
		36905
	],
	[
		"s2774627",
		"Sibbaldia aphanopetala",
		"sibbaldia",
		2774627
	],
	[
		"s478373",
		"Sibbaldia cuneata",
		"sibbaldia",
		478373
	],
	[
		"s3121384",
		"Sibbaldia cuneifolia",
		"sibbaldia",
		3121384
	],
	[
		"s3091925",
		"Sibbaldia olgae",
		"sibbaldia",
		3091925
	],
	[
		"s637901",
		"Sibbaldia parviflora",
		"sibbaldia",
		637901
	],
	[
		"s57947",
		"Sibbaldia procumbens",
		"sibbaldia",
		57947
	],
	[
		"s57934",
		"Sibbaldia retusa",
		"sibbaldia",
		57934
	],
	[
		"s637902",
		"Sibbaldia semiglabra",
		"sibbaldia",
		637902
	],
	[
		"s637904",
		"Sibbaldianthe adpressa",
		"sibbaldianthe",
		637904
	],
	[
		"s57928",
		"Sibbaldianthe bifurca",
		"sibbaldianthe",
		57928
	],
	[
		"s3121459",
		"Sibbaldianthe moorcroftii",
		"sibbaldianthe",
		3121459
	],
	[
		"s3121456",
		"Sibbaldianthe semiglabra",
		"sibbaldianthe",
		3121456
	],
	[
		"s1732554",
		"Sibbaldianthe sericea",
		"sibbaldianthe",
		1732554
	],
	[
		"s310218",
		"Sibiraea altaiensis",
		"sibiraea",
		310218
	],
	[
		"s1055022",
		"Sibiraea angustata",
		"sibiraea",
		1055022
	],
	[
		"s310219",
		"Sibiraea croatica",
		"sibiraea",
		310219
	],
	[
		"s409504",
		"Sibiraea laevigata",
		"sibiraea",
		409504
	],
	[
		"s3091530",
		"Sibiraea tianschanica",
		"sibiraea",
		3091530
	],
	[
		"s3091926",
		"Sibiraea tomentosa",
		"sibiraea",
		3091926
	],
	[
		"s106712",
		"Siegfriedia darwinioides",
		"siegfriedia",
		106712
	],
	[
		"s148907",
		"Sieversia pentapetala",
		"sieversia",
		148907
	],
	[
		"s148908",
		"Sieversia pusilla",
		"sieversia",
		148908
	],
	[
		"s2604997",
		"Sloetia elongata",
		"sloetia",
		2604997
	],
	[
		"s2708985",
		"Sloetiopsis usambarensis",
		"sloetiopsis",
		2708985
	],
	[
		"s3140265",
		"Smythea bombaiensis",
		"smythea",
		3140265
	],
	[
		"s3091531",
		"Smythea lanceata",
		"smythea",
		3091531
	],
	[
		"s3140266",
		"Smythea macrocarpa",
		"smythea",
		3140266
	],
	[
		"s3091604",
		"Smythea oblongifolia",
		"smythea",
		3091604
	],
	[
		"s3140267",
		"Smythea poilanei",
		"smythea",
		3140267
	],
	[
		"s3140268",
		"Smythea velutina",
		"smythea",
		3140268
	],
	[
		"s1053382",
		"Soleirolia soleirolii",
		"soleirolia",
		1053382
	],
	[
		"s714504",
		"Sorbaria kirilowii",
		"sorbaria",
		714504
	],
	[
		"s3091935",
		"Sorbaria pallasii",
		"sorbaria",
		3091935
	],
	[
		"s141005",
		"Sorbaria sorbifolia",
		"sorbaria",
		141005
	],
	[
		"s3091533",
		"Sorbaria tomentosa",
		"sorbaria",
		3091533
	],
	[
		"s2992294",
		"Sorbus aestivalis",
		"sorbus",
		2992294
	],
	[
		"s1826782",
		"Sorbus albopilosa",
		"sorbus",
		1826782
	],
	[
		"s3091936",
		"Sorbus albovii",
		"sorbus",
		3091936
	],
	[
		"s691227",
		"Sorbus amabilis",
		"sorbus",
		691227
	],
	[
		"s193310",
		"Sorbus americana",
		"sorbus",
		193310
	],
	[
		"s3881244",
		"Sorbus amoena",
		"sorbus",
		3881244
	],
	[
		"s3881245",
		"Sorbus arachnoidea",
		"sorbus",
		3881245
	],
	[
		"s36599",
		"Sorbus aucuparia",
		"sorbus",
		36599
	],
	[
		"s1826783",
		"Sorbus bissetii",
		"sorbus",
		1826783
	],
	[
		"s3881246",
		"Sorbus bulleyana",
		"sorbus",
		3881246
	],
	[
		"s3091937",
		"Sorbus buschiana",
		"sorbus",
		3091937
	],
	[
		"s141006",
		"Sorbus californica",
		"sorbus",
		141006
	],
	[
		"s3881247",
		"Sorbus carmesina",
		"sorbus",
		3881247
	],
	[
		"s1826784",
		"Sorbus cashmiriana",
		"sorbus",
		1826784
	],
	[
		"s2992295",
		"Sorbus cibagouensis",
		"sorbus",
		2992295
	],
	[
		"s3881248",
		"Sorbus cinereopubescens",
		"sorbus",
		3881248
	],
	[
		"s186521",
		"Sorbus commixta",
		"sorbus",
		186521
	],
	[
		"s3881249",
		"Sorbus coxii",
		"sorbus",
		3881249
	],
	[
		"s1770154",
		"Sorbus cuspidata",
		"sorbus",
		1770154
	],
	[
		"s1851446",
		"Sorbus dacica",
		"sorbus",
		1851446
	],
	[
		"s3091938",
		"Sorbus decipiens",
		"sorbus",
		3091938
	],
	[
		"s765745",
		"Sorbus decora",
		"sorbus",
		765745
	],
	[
		"s691232",
		"Sorbus discolor",
		"sorbus",
		691232
	],
	[
		"s1825964",
		"Sorbus dolichofoliolatus",
		"sorbus",
		1825964
	],
	[
		"s3881250",
		"Sorbus domugledica",
		"sorbus",
		3881250
	],
	[
		"s3881251",
		"Sorbus doshonglaensis",
		"sorbus",
		3881251
	],
	[
		"s691233",
		"Sorbus dumosa",
		"sorbus",
		691233
	],
	[
		"s3881252",
		"Sorbus eburnea",
		"sorbus",
		3881252
	],
	[
		"s3881253",
		"Sorbus ellipsoidalis",
		"sorbus",
		3881253
	],
	[
		"s3881254",
		"Sorbus erythrosepala",
		"sorbus",
		3881254
	],
	[
		"s3881255",
		"Sorbus erzincanica",
		"sorbus",
		3881255
	],
	[
		"s1825961",
		"Sorbus esserteauiana",
		"sorbus",
		1825961
	],
	[
		"s3095565",
		"Sorbus fansipanensis",
		"sorbus",
		3095565
	],
	[
		"s3881256",
		"Sorbus faohraei",
		"sorbus",
		3881256
	],
	[
		"s2992296",
		"Sorbus filipes",
		"sorbus",
		2992296
	],
	[
		"s1826785",
		"Sorbus foliolosa",
		"sorbus",
		1826785
	],
	[
		"s691234",
		"Sorbus forrestii",
		"sorbus",
		691234
	],
	[
		"s3881257",
		"Sorbus frutescens",
		"sorbus",
		3881257
	],
	[
		"s3881258",
		"Sorbus gilgitana",
		"sorbus",
		3881258
	],
	[
		"s1826786",
		"Sorbus glabriuscula",
		"sorbus",
		1826786
	],
	[
		"s1826787",
		"Sorbus glomerulata",
		"sorbus",
		1826787
	],
	[
		"s1826788",
		"Sorbus gonggashanica",
		"sorbus",
		1826788
	],
	[
		"s3881259",
		"Sorbus gongshanensis",
		"sorbus",
		3881259
	],
	[
		"s1826789",
		"Sorbus gracilis",
		"sorbus",
		1826789
	],
	[
		"s2820172",
		"Sorbus groenlandica",
		"sorbus",
		2820172
	],
	[
		"s3091940",
		"Sorbus hajastana",
		"sorbus",
		3091940
	],
	[
		"s1826790",
		"Sorbus harrowiana",
		"sorbus",
		1826790
	],
	[
		"s1826791",
		"Sorbus helenae",
		"sorbus",
		1826791
	],
	[
		"s3870882",
		"Sorbus hercegovinae",
		"sorbus",
		3870882
	],
	[
		"s3881260",
		"Sorbus herculis",
		"sorbus",
		3881260
	],
	[
		"s1826792",
		"Sorbus himalaica",
		"sorbus",
		1826792
	],
	[
		"s1826793",
		"Sorbus hugh-mcallisteri",
		"sorbus",
		1826793
	],
	[
		"s186522",
		"Sorbus hupehensis",
		"sorbus",
		186522
	],
	[
		"s1577862",
		"Sorbus hybrid cultivar",
		"sorbus",
		1577862
	],
	[
		"s1826794",
		"Sorbus hypoglauca",
		"sorbus",
		1826794
	],
	[
		"s1826795",
		"Sorbus insignis",
		"sorbus",
		1826795
	],
	[
		"s3881261",
		"Sorbus keenanii",
		"sorbus",
		3881261
	],
	[
		"s1770157",
		"Sorbus keissleri",
		"sorbus",
		1770157
	],
	[
		"s1826796",
		"Sorbus khumbuensis",
		"sorbus",
		1826796
	],
	[
		"s3091941",
		"Sorbus kiukiangensis",
		"sorbus",
		3091941
	],
	[
		"s691237",
		"Sorbus koehneana",
		"sorbus",
		691237
	],
	[
		"s3881262",
		"Sorbus kongboensis",
		"sorbus",
		3881262
	],
	[
		"s3091539",
		"Sorbus kurzii",
		"sorbus",
		3091539
	],
	[
		"s3091942",
		"Sorbus kusnetzovii",
		"sorbus",
		3091942
	],
	[
		"s3473546",
		"Sorbus lanpingensis",
		"sorbus",
		3473546
	],
	[
		"s3881263",
		"Sorbus lingshiensis",
		"sorbus",
		3881263
	],
	[
		"s3881264",
		"Sorbus longii",
		"sorbus",
		3881264
	],
	[
		"s3881265",
		"Sorbus lushanensis",
		"sorbus",
		3881265
	],
	[
		"s3095566",
		"Sorbus macallisteri",
		"sorbus",
		3095566
	],
	[
		"s1826797",
		"Sorbus macrantha",
		"sorbus",
		1826797
	],
	[
		"s1826798",
		"Sorbus maderensis",
		"sorbus",
		1826798
	],
	[
		"s1826799",
		"Sorbus matsumurana",
		"sorbus",
		1826799
	],
	[
		"s1826800",
		"Sorbus microphylla",
		"sorbus",
		1826800
	],
	[
		"s1825962",
		"Sorbus monbeigii",
		"sorbus",
		1825962
	],
	[
		"s1826801",
		"Sorbus muliensis",
		"sorbus",
		1826801
	],
	[
		"s1826802",
		"Sorbus multijuga",
		"sorbus",
		1826802
	],
	[
		"s1826803",
		"Sorbus munda",
		"sorbus",
		1826803
	],
	[
		"s2005312",
		"Sorbus neglecta",
		"sorbus",
		2005312
	],
	[
		"s1891596",
		"Sorbus norvegica",
		"sorbus",
		1891596
	],
	[
		"s3091541",
		"Sorbus obsoletidentata",
		"sorbus",
		3091541
	],
	[
		"s3091542",
		"Sorbus occidentalis",
		"sorbus",
		3091542
	],
	[
		"s1826804",
		"Sorbus oligodonta",
		"sorbus",
		1826804
	],
	[
		"s1826805",
		"Sorbus olivacea",
		"sorbus",
		1826805
	],
	[
		"s1826806",
		"Sorbus ovalis",
		"sorbus",
		1826806
	],
	[
		"s3881266",
		"Sorbus parva",
		"sorbus",
		3881266
	],
	[
		"s3881267",
		"Sorbus parvifolia",
		"sorbus",
		3881267
	],
	[
		"s3095563",
		"Sorbus parvifructa",
		"sorbus",
		3095563
	],
	[
		"s1826807",
		"Sorbus poteriifolia",
		"sorbus",
		1826807
	],
	[
		"s691239",
		"Sorbus prattii",
		"sorbus",
		691239
	],
	[
		"s3881268",
		"Sorbus pseudohupehensis",
		"sorbus",
		3881268
	],
	[
		"s1826808",
		"Sorbus pseudovilmorinii",
		"sorbus",
		1826808
	],
	[
		"s691240",
		"Sorbus pteridophylla",
		"sorbus",
		691240
	],
	[
		"s656924",
		"Sorbus randaiensis",
		"sorbus",
		656924
	],
	[
		"s1826809",
		"Sorbus reducta",
		"sorbus",
		1826809
	],
	[
		"s1825963",
		"Sorbus rehderiana",
		"sorbus",
		1825963
	],
	[
		"s1826810",
		"Sorbus rinzenii",
		"sorbus",
		1826810
	],
	[
		"s3881269",
		"Sorbus rockii",
		"sorbus",
		3881269
	],
	[
		"s3881270",
		"Sorbus rosea",
		"sorbus",
		3881270
	],
	[
		"s3881271",
		"Sorbus rubescens",
		"sorbus",
		3881271
	],
	[
		"s1826811",
		"Sorbus rufopilosa",
		"sorbus",
		1826811
	],
	[
		"s3881272",
		"Sorbus rushforthii",
		"sorbus",
		3881272
	],
	[
		"s2992298",
		"Sorbus rutilans",
		"sorbus",
		2992298
	],
	[
		"s2831160",
		"Sorbus salwinensis",
		"sorbus",
		2831160
	],
	[
		"s691241",
		"Sorbus sambucifolia",
		"sorbus",
		691241
	],
	[
		"s1826812",
		"Sorbus sargentiana",
		"sorbus",
		1826812
	],
	[
		"s2034696",
		"Sorbus scalaris",
		"sorbus",
		2034696
	],
	[
		"s32249",
		"Sorbus scopulina",
		"sorbus",
		32249
	],
	[
		"s1826813",
		"Sorbus setschwanensis",
		"sorbus",
		1826813
	],
	[
		"s3881273",
		"Sorbus shirinensis",
		"sorbus",
		3881273
	],
	[
		"s186523",
		"Sorbus sibirica",
		"sorbus",
		186523
	],
	[
		"s1284347",
		"Sorbus sitchensis",
		"sorbus",
		1284347
	],
	[
		"s2873987",
		"Sorbus slavnicensis (nom. inval.)",
		"sorbus",
		2873987
	],
	[
		"s3095562",
		"Sorbus splendens",
		"sorbus",
		3095562
	],
	[
		"s3091547",
		"Sorbus subfusca",
		"sorbus",
		3091547
	],
	[
		"s3881274",
		"Sorbus sujoyi",
		"sorbus",
		3881274
	],
	[
		"s3108495",
		"Sorbus tapashana",
		"sorbus",
		3108495
	],
	[
		"s3881275",
		"Sorbus tenuis",
		"sorbus",
		3881275
	],
	[
		"s691244",
		"Sorbus tianschanica",
		"sorbus",
		691244
	],
	[
		"s3881276",
		"Sorbus tiantangensis",
		"sorbus",
		3881276
	],
	[
		"s3881277",
		"Sorbus tiliifolia",
		"sorbus",
		3881277
	],
	[
		"s2080251",
		"Sorbus ulleungensis",
		"sorbus",
		2080251
	],
	[
		"s1770164",
		"Sorbus verrucosa",
		"sorbus",
		1770164
	],
	[
		"s691246",
		"Sorbus vilmorinii",
		"sorbus",
		691246
	],
	[
		"s3091551",
		"Sorbus wallichii",
		"sorbus",
		3091551
	],
	[
		"s691247",
		"Sorbus wilfordii",
		"sorbus",
		691247
	],
	[
		"s1826814",
		"Sorbus wilsoniana",
		"sorbus",
		1826814
	],
	[
		"s3108496",
		"Sorbus xanthoneura",
		"sorbus",
		3108496
	],
	[
		"s3091943",
		"Sorbus zayuensis",
		"sorbus",
		3091943
	],
	[
		"s241920",
		"Sorocea affinis",
		"sorocea",
		241920
	],
	[
		"s3777296",
		"Sorocea angustifolia",
		"sorocea",
		3777296
	],
	[
		"s241921",
		"Sorocea bonplandii",
		"sorocea",
		241921
	],
	[
		"s241922",
		"Sorocea briquetii",
		"sorocea",
		241922
	],
	[
		"s3777297",
		"Sorocea carautana",
		"sorocea",
		3777297
	],
	[
		"s1807109",
		"Sorocea cufodontii",
		"sorocea",
		1807109
	],
	[
		"s2732306",
		"Sorocea duckei",
		"sorocea",
		2732306
	],
	[
		"s3777298",
		"Sorocea ganevii",
		"sorocea",
		3777298
	],
	[
		"s2321349",
		"Sorocea guilleminiana",
		"sorocea",
		2321349
	],
	[
		"s2732307",
		"Sorocea hilarii",
		"sorocea",
		2732307
	],
	[
		"s1835416",
		"Sorocea jaramilloi",
		"sorocea",
		1835416
	],
	[
		"s1924226",
		"Sorocea jureiana",
		"sorocea",
		1924226
	],
	[
		"s2781883",
		"Sorocea klotzschiana",
		"sorocea",
		2781883
	],
	[
		"s2781884",
		"Sorocea longipedicellata",
		"sorocea",
		2781884
	],
	[
		"s241923",
		"Sorocea muriculata",
		"sorocea",
		241923
	],
	[
		"s709070",
		"Sorocea pileata",
		"sorocea",
		709070
	],
	[
		"s241924",
		"Sorocea pubivena",
		"sorocea",
		241924
	],
	[
		"s2364066",
		"Sorocea racemosa",
		"sorocea",
		2364066
	],
	[
		"s3091944",
		"Sorocea ruminata",
		"sorocea",
		3091944
	],
	[
		"s3091945",
		"Sorocea sarcocarpa",
		"sorocea",
		3091945
	],
	[
		"s872017",
		"Sorocea sprucei",
		"sorocea",
		872017
	],
	[
		"s382338",
		"Sorocea steinbachii",
		"sorocea",
		382338
	],
	[
		"s2732312",
		"Sorocea subumbellata",
		"sorocea",
		2732312
	],
	[
		"s2732313",
		"Sorocea trophoides",
		"sorocea",
		2732313
	],
	[
		"s241926",
		"Sparattosyce dioica",
		"sparattosyce",
		241926
	],
	[
		"s398531",
		"Spenceria ramalana",
		"spenceria",
		398531
	],
	[
		"s2598862",
		"Spiraea adiantoides",
		"spiraea",
		2598862
	],
	[
		"s3882007",
		"Spiraea affinis",
		"spiraea",
		3882007
	],
	[
		"s3882008",
		"Spiraea alaschanica",
		"spiraea",
		3882008
	],
	[
		"s410739",
		"Spiraea alba",
		"spiraea",
		410739
	],
	[
		"s1195654",
		"Spiraea alpina",
		"spiraea",
		1195654
	],
	[
		"s3882009",
		"Spiraea anomala",
		"spiraea",
		3882009
	],
	[
		"s1450208",
		"Spiraea aquilegiifolia",
		"spiraea",
		1450208
	],
	[
		"s2008504",
		"Spiraea arcuata",
		"spiraea",
		2008504
	],
	[
		"s3091949",
		"Spiraea baldshuanica",
		"spiraea",
		3091949
	],
	[
		"s2071545",
		"Spiraea beauverdiana",
		"spiraea",
		2071545
	],
	[
		"s2598864",
		"Spiraea bella",
		"spiraea",
		2598864
	],
	[
		"s85272",
		"Spiraea betulifolia",
		"spiraea",
		85272
	],
	[
		"s409505",
		"Spiraea blumei",
		"spiraea",
		409505
	],
	[
		"s3882010",
		"Spiraea brahuica",
		"spiraea",
		3882010
	],
	[
		"s3091950",
		"Spiraea brumalis",
		"spiraea",
		3091950
	],
	[
		"s2008506",
		"Spiraea calcicola",
		"spiraea",
		2008506
	],
	[
		"s3882011",
		"Spiraea cana",
		"spiraea",
		3882011
	],
	[
		"s409506",
		"Spiraea canescens",
		"spiraea",
		409506
	],
	[
		"s141007",
		"Spiraea cantoniensis",
		"spiraea",
		141007
	],
	[
		"s3882012",
		"Spiraea cardotiana",
		"spiraea",
		3882012
	],
	[
		"s701263",
		"Spiraea chamaedryfolia",
		"spiraea",
		701263
	],
	[
		"s3882013",
		"Spiraea chambaensis",
		"spiraea",
		3882013
	],
	[
		"s1803870",
		"Spiraea chartacea",
		"spiraea",
		1803870
	],
	[
		"s1161165",
		"Spiraea chinensis",
		"spiraea",
		1161165
	],
	[
		"s3091951",
		"Spiraea compsophylla",
		"spiraea",
		3091951
	],
	[
		"s2071546",
		"Spiraea corymbosa",
		"spiraea",
		2071546
	],
	[
		"s409507",
		"Spiraea crenata",
		"spiraea",
		409507
	],
	[
		"s3882014",
		"Spiraea cudidaghensis",
		"spiraea",
		3882014
	],
	[
		"s1450209",
		"Spiraea dahurica",
		"spiraea",
		1450209
	],
	[
		"s3882015",
		"Spiraea daochengensis",
		"spiraea",
		3882015
	],
	[
		"s2008508",
		"Spiraea dasyantha",
		"spiraea",
		2008508
	],
	[
		"s409508",
		"Spiraea decumbens",
		"spiraea",
		409508
	],
	[
		"s144563",
		"Spiraea densiflora",
		"spiraea",
		144563
	],
	[
		"s3882016",
		"Spiraea diversifolia",
		"spiraea",
		3882016
	],
	[
		"s409509",
		"Spiraea douglasii",
		"spiraea",
		409509
	],
	[
		"s3882017",
		"Spiraea duthieana",
		"spiraea",
		3882017
	],
	[
		"s1851244",
		"Spiraea elegans",
		"spiraea",
		1851244
	],
	[
		"s3882018",
		"Spiraea emarginata",
		"spiraea",
		3882018
	],
	[
		"s1851245",
		"Spiraea flexuosa",
		"spiraea",
		1851245
	],
	[
		"s409510",
		"Spiraea formosana",
		"spiraea",
		409510
	],
	[
		"s3882019",
		"Spiraea fornicata",
		"spiraea",
		3882019
	],
	[
		"s409511",
		"Spiraea fritschiana",
		"spiraea",
		409511
	],
	[
		"s2598873",
		"Spiraea glabrescens",
		"spiraea",
		2598873
	],
	[
		"s3882021",
		"Spiraea gracilis",
		"spiraea",
		3882021
	],
	[
		"s3882022",
		"Spiraea hailarensis",
		"spiraea",
		3882022
	],
	[
		"s2803537",
		"Spiraea hayatana",
		"spiraea",
		2803537
	],
	[
		"s2598863",
		"Spiraea hemicryptophyta",
		"spiraea",
		2598863
	],
	[
		"s2008511",
		"Spiraea henryi",
		"spiraea",
		2008511
	],
	[
		"s2008513",
		"Spiraea hingshanensis",
		"spiraea",
		2008513
	],
	[
		"s2008514",
		"Spiraea hirsuta",
		"spiraea",
		2008514
	],
	[
		"s1851246",
		"Spiraea humilis",
		"spiraea",
		1851246
	],
	[
		"s409512",
		"Spiraea hypericifolia",
		"spiraea",
		409512
	],
	[
		"s3882023",
		"Spiraea hypoleuca",
		"spiraea",
		3882023
	],
	[
		"s701338",
		"Spiraea insularis",
		"spiraea",
		701338
	],
	[
		"s309823",
		"Spiraea japonica",
		"spiraea",
		309823
	],
	[
		"s2008516",
		"Spiraea kwangsiensis",
		"spiraea",
		2008516
	],
	[
		"s2008517",
		"Spiraea kweichowensis",
		"spiraea",
		2008517
	],
	[
		"s1450210",
		"Spiraea laeta",
		"spiraea",
		1450210
	],
	[
		"s3882024",
		"Spiraea lanatissima",
		"spiraea",
		3882024
	],
	[
		"s2598869",
		"Spiraea lancifolia",
		"spiraea",
		2598869
	],
	[
		"s409513",
		"Spiraea lasiocarpa",
		"spiraea",
		409513
	],
	[
		"s2008519",
		"Spiraea lichiangensis",
		"spiraea",
		2008519
	],
	[
		"s2517372",
		"Spiraea litwinowii",
		"spiraea",
		2517372
	],
	[
		"s2598870",
		"Spiraea lobulata",
		"spiraea",
		2598870
	],
	[
		"s409515",
		"Spiraea longigemmis",
		"spiraea",
		409515
	],
	[
		"s2071547",
		"Spiraea lucida",
		"spiraea",
		2071547
	],
	[
		"s1961211",
		"Spiraea martini",
		"spiraea",
		1961211
	],
	[
		"s1161166",
		"Spiraea media",
		"spiraea",
		1161166
	],
	[
		"s3882025",
		"Spiraea micrantha",
		"spiraea",
		3882025
	],
	[
		"s3695377",
		"Spiraea microgyna",
		"spiraea",
		3695377
	],
	[
		"s409516",
		"Spiraea miyabei",
		"spiraea",
		409516
	],
	[
		"s1450211",
		"Spiraea mollifolia",
		"spiraea",
		1450211
	],
	[
		"s714505",
		"Spiraea mongolica",
		"spiraea",
		714505
	],
	[
		"s2017994",
		"Spiraea morrisonicola",
		"spiraea",
		2017994
	],
	[
		"s3091952",
		"Spiraea muliensis",
		"spiraea",
		3091952
	],
	[
		"s858963",
		"Spiraea myrtilloides",
		"spiraea",
		858963
	],
	[
		"s3882026",
		"Spiraea naxiorum",
		"spiraea",
		3882026
	],
	[
		"s3882027",
		"Spiraea nayarii",
		"spiraea",
		3882027
	],
	[
		"s2598871",
		"Spiraea nervosa",
		"spiraea",
		2598871
	],
	[
		"s3882028",
		"Spiraea ningshiaensis",
		"spiraea",
		3882028
	],
	[
		"s216037",
		"Spiraea nipponica",
		"spiraea",
		216037
	],
	[
		"s2008526",
		"Spiraea nishimurae",
		"spiraea",
		2008526
	],
	[
		"s2008527",
		"Spiraea ovalis",
		"spiraea",
		2008527
	],
	[
		"s3882029",
		"Spiraea panchananii",
		"spiraea",
		3882029
	],
	[
		"s3882030",
		"Spiraea panigrahiana",
		"spiraea",
		3882030
	],
	[
		"s2008528",
		"Spiraea papillosa",
		"spiraea",
		2008528
	],
	[
		"s3882031",
		"Spiraea parkeri",
		"spiraea",
		3882031
	],
	[
		"s3091953",
		"Spiraea pilosa",
		"spiraea",
		3091953
	],
	[
		"s2517373",
		"Spiraea polonica",
		"spiraea",
		2517373
	],
	[
		"s409517",
		"Spiraea prunifolia",
		"spiraea",
		409517
	],
	[
		"s3882032",
		"Spiraea pseudocrenata",
		"spiraea",
		3882032
	],
	[
		"s409518",
		"Spiraea pubescens",
		"spiraea",
		409518
	],
	[
		"s1450212",
		"Spiraea purpurea",
		"spiraea",
		1450212
	],
	[
		"s1450213",
		"Spiraea rosthornii",
		"spiraea",
		1450213
	],
	[
		"s409519",
		"Spiraea salicifolia",
		"spiraea",
		409519
	],
	[
		"s2008532",
		"Spiraea sargentiana",
		"spiraea",
		2008532
	],
	[
		"s1450214",
		"Spiraea schneideriana",
		"spiraea",
		1450214
	],
	[
		"s2008533",
		"Spiraea schochiana",
		"spiraea",
		2008533
	],
	[
		"s3091954",
		"Spiraea septentrionalis",
		"spiraea",
		3091954
	],
	[
		"s3882033",
		"Spiraea sericeoides",
		"spiraea",
		3882033
	],
	[
		"s3882034",
		"Spiraea siccanea",
		"spiraea",
		3882034
	],
	[
		"s3882035",
		"Spiraea sozykinii",
		"spiraea",
		3882035
	],
	[
		"s1981259",
		"Spiraea splendens",
		"spiraea",
		1981259
	],
	[
		"s669841",
		"Spiraea stevenii",
		"spiraea",
		669841
	],
	[
		"s3091955",
		"Spiraea subcanescens",
		"spiraea",
		3091955
	],
	[
		"s3882036",
		"Spiraea subdioica",
		"spiraea",
		3882036
	],
	[
		"s1450216",
		"Spiraea sublobata",
		"spiraea",
		1450216
	],
	[
		"s3882037",
		"Spiraea subrotundifolia",
		"spiraea",
		3882037
	],
	[
		"s3882038",
		"Spiraea tanguensis",
		"spiraea",
		3882038
	],
	[
		"s2017996",
		"Spiraea tarokoensis",
		"spiraea",
		2017996
	],
	[
		"s2017997",
		"Spiraea tatakaensis",
		"spiraea",
		2017997
	],
	[
		"s2008534",
		"Spiraea teniana",
		"spiraea",
		2008534
	],
	[
		"s409520",
		"Spiraea thunbergii",
		"spiraea",
		409520
	],
	[
		"s2764681",
		"Spiraea tianschanica",
		"spiraea",
		2764681
	],
	[
		"s473049",
		"Spiraea tomentosa",
		"spiraea",
		473049
	],
	[
		"s409521",
		"Spiraea trichocarpa",
		"spiraea",
		409521
	],
	[
		"s403696",
		"Spiraea trilobata",
		"spiraea",
		403696
	],
	[
		"s3882039",
		"Spiraea turczaninowii",
		"spiraea",
		3882039
	],
	[
		"s2517374",
		"Spiraea ulmifolia",
		"spiraea",
		2517374
	],
	[
		"s3091956",
		"Spiraea uratensis",
		"spiraea",
		3091956
	],
	[
		"s3091957",
		"Spiraea vacciniifolia",
		"spiraea",
		3091957
	],
	[
		"s409522",
		"Spiraea veitchii",
		"spiraea",
		409522
	],
	[
		"s2008535",
		"Spiraea velutina",
		"spiraea",
		2008535
	],
	[
		"s3882040",
		"Spiraea villosicarpa",
		"spiraea",
		3882040
	],
	[
		"s2598874",
		"Spiraea virgata",
		"spiraea",
		2598874
	],
	[
		"s409523",
		"Spiraea virginiana",
		"spiraea",
		409523
	],
	[
		"s1712251",
		"Spiraea wilsonii",
		"spiraea",
		1712251
	],
	[
		"s1640689",
		"Spiraea x arguta",
		"spiraea",
		1640689
	],
	[
		"s1891284",
		"Spiraea x billardii",
		"spiraea",
		1891284
	],
	[
		"s3092081",
		"Spiraea x brachybotrys",
		"spiraea",
		3092081
	],
	[
		"s2527813",
		"Spiraea x bumalda",
		"spiraea",
		2527813
	],
	[
		"s3379672",
		"Spiraea x micropetala",
		"spiraea",
		3379672
	],
	[
		"s3092082",
		"Spiraea x pyramidata",
		"spiraea",
		3092082
	],
	[
		"s1891584",
		"Spiraea x rosalba",
		"spiraea",
		1891584
	],
	[
		"s3092083",
		"Spiraea x superba",
		"spiraea",
		3092083
	],
	[
		"s23225",
		"Spiraea x vanhouttei",
		"spiraea",
		23225
	],
	[
		"s2598875",
		"Spiraea xizangensis",
		"spiraea",
		2598875
	],
	[
		"s2008537",
		"Spiraea yunnanensis",
		"spiraea",
		2008537
	],
	[
		"s398529",
		"Spiraeanthus schrenkianus",
		"spiraeanthus",
		398529
	],
	[
		"s2945635",
		"Spyridium bifidum",
		"spyridium",
		2945635
	],
	[
		"s3882108",
		"Spyridium bracteatum",
		"spyridium",
		3882108
	],
	[
		"s323971",
		"Spyridium burragorang",
		"spyridium",
		323971
	],
	[
		"s323972",
		"Spyridium buxifolium",
		"spyridium",
		323972
	],
	[
		"s2945652",
		"Spyridium cinereum",
		"spyridium",
		2945652
	],
	[
		"s2945653",
		"Spyridium coactilifolium",
		"spyridium",
		2945653
	],
	[
		"s2945654",
		"Spyridium coalitum",
		"spyridium",
		2945654
	],
	[
		"s323922",
		"Spyridium cordatum",
		"spyridium",
		323922
	],
	[
		"s323975",
		"Spyridium daltonii",
		"spyridium",
		323975
	],
	[
		"s2945636",
		"Spyridium daphnoides",
		"spyridium",
		2945636
	],
	[
		"s323960",
		"Spyridium eriocephalum",
		"spyridium",
		323960
	],
	[
		"s2945656",
		"Spyridium erymnocladum",
		"spyridium",
		2945656
	],
	[
		"s2945657",
		"Spyridium fontis-woodii",
		"spyridium",
		2945657
	],
	[
		"s2945658",
		"Spyridium furculentum",
		"spyridium",
		2945658
	],
	[
		"s2945655",
		"Spyridium glabrisepalum",
		"spyridium",
		2945655
	],
	[
		"s2945659",
		"Spyridium glaucum",
		"spyridium",
		2945659
	],
	[
		"s106715",
		"Spyridium globulosum",
		"spyridium",
		106715
	],
	[
		"s323970",
		"Spyridium gunnii",
		"spyridium",
		323970
	],
	[
		"s323961",
		"Spyridium halmaturinum",
		"spyridium",
		323961
	],
	[
		"s3882109",
		"Spyridium latifolium",
		"spyridium",
		3882109
	],
	[
		"s2945637",
		"Spyridium lawrencei",
		"spyridium",
		2945637
	],
	[
		"s2945638",
		"Spyridium leucopogon",
		"spyridium",
		2945638
	],
	[
		"s3882110",
		"Spyridium longicor",
		"spyridium",
		3882110
	],
	[
		"s2945639",
		"Spyridium majoranifolium",
		"spyridium",
		2945639
	],
	[
		"s2945640",
		"Spyridium microcephalum",
		"spyridium",
		2945640
	],
	[
		"s2945660",
		"Spyridium minutum",
		"spyridium",
		2945660
	],
	[
		"s2945661",
		"Spyridium montanum",
		"spyridium",
		2945661
	],
	[
		"s323967",
		"Spyridium mucronatum",
		"spyridium",
		323967
	],
	[
		"s323963",
		"Spyridium nitidum",
		"spyridium",
		323963
	],
	[
		"s2945641",
		"Spyridium obcordatum",
		"spyridium",
		2945641
	],
	[
		"s2945642",
		"Spyridium obovatum",
		"spyridium",
		2945642
	],
	[
		"s2945644",
		"Spyridium oligocephalum",
		"spyridium",
		2945644
	],
	[
		"s73716",
		"Spyridium parvifolium",
		"spyridium",
		73716
	],
	[
		"s2945645",
		"Spyridium phlebophyllum",
		"spyridium",
		2945645
	],
	[
		"s2945664",
		"Spyridium phylicoides",
		"spyridium",
		2945664
	],
	[
		"s2945646",
		"Spyridium polycephalum",
		"spyridium",
		2945646
	],
	[
		"s2945665",
		"Spyridium riparium",
		"spyridium",
		2945665
	],
	[
		"s2945647",
		"Spyridium scabridum",
		"spyridium",
		2945647
	],
	[
		"s323973",
		"Spyridium scortechinii",
		"spyridium",
		323973
	],
	[
		"s2945648",
		"Spyridium spadiceum",
		"spyridium",
		2945648
	],
	[
		"s2945649",
		"Spyridium stenophyllum",
		"spyridium",
		2945649
	],
	[
		"s323964",
		"Spyridium subochreatum",
		"spyridium",
		323964
	],
	[
		"s323965",
		"Spyridium thymifolium",
		"spyridium",
		323965
	],
	[
		"s323968",
		"Spyridium tricolor",
		"spyridium",
		323968
	],
	[
		"s323969",
		"Spyridium ulicinum",
		"spyridium",
		323969
	],
	[
		"s3882111",
		"Spyridium undulifolium",
		"spyridium",
		3882111
	],
	[
		"s1813578",
		"Spyridium vexilliferum",
		"spyridium",
		1813578
	],
	[
		"s2945650",
		"Spyridium villosum",
		"spyridium",
		2945650
	],
	[
		"s456994",
		"Spyridium waterhousei",
		"spyridium",
		456994
	],
	[
		"s587195",
		"Stenanthemum arens",
		"stenanthemum",
		587195
	],
	[
		"s323979",
		"Stenanthemum argenteum",
		"stenanthemum",
		323979
	],
	[
		"s3883915",
		"Stenanthemum bilobum",
		"stenanthemum",
		3883915
	],
	[
		"s3883916",
		"Stenanthemum bremerense",
		"stenanthemum",
		3883916
	],
	[
		"s323982",
		"Stenanthemum centrale",
		"stenanthemum",
		323982
	],
	[
		"s106713",
		"Stenanthemum complicatum",
		"stenanthemum",
		106713
	],
	[
		"s3883917",
		"Stenanthemum cristatum",
		"stenanthemum",
		3883917
	],
	[
		"s3883918",
		"Stenanthemum divaricatum",
		"stenanthemum",
		3883918
	],
	[
		"s3883919",
		"Stenanthemum emarginatum",
		"stenanthemum",
		3883919
	],
	[
		"s323977",
		"Stenanthemum humile",
		"stenanthemum",
		323977
	],
	[
		"s3883920",
		"Stenanthemum intricatum",
		"stenanthemum",
		3883920
	],
	[
		"s3883921",
		"Stenanthemum liberum",
		"stenanthemum",
		3883921
	],
	[
		"s3883922",
		"Stenanthemum limitatum",
		"stenanthemum",
		3883922
	],
	[
		"s3883923",
		"Stenanthemum mediale",
		"stenanthemum",
		3883923
	],
	[
		"s2986275",
		"Stenanthemum nanum",
		"stenanthemum",
		2986275
	],
	[
		"s3883924",
		"Stenanthemum newbeyi",
		"stenanthemum",
		3883924
	],
	[
		"s3883925",
		"Stenanthemum notiale",
		"stenanthemum",
		3883925
	],
	[
		"s3883926",
		"Stenanthemum patens",
		"stenanthemum",
		3883926
	],
	[
		"s323978",
		"Stenanthemum petraeum",
		"stenanthemum",
		323978
	],
	[
		"s323983",
		"Stenanthemum pimeleoides",
		"stenanthemum",
		323983
	],
	[
		"s3883927",
		"Stenanthemum poicilum",
		"stenanthemum",
		3883927
	],
	[
		"s432373",
		"Stenanthemum pomaderroides",
		"stenanthemum",
		432373
	],
	[
		"s3883928",
		"Stenanthemum radiatum",
		"stenanthemum",
		3883928
	],
	[
		"s323980",
		"Stenanthemum reissekii",
		"stenanthemum",
		323980
	],
	[
		"s3883929",
		"Stenanthemum sublineare",
		"stenanthemum",
		3883929
	],
	[
		"s3883930",
		"Stenanthemum yorkense",
		"stenanthemum",
		3883930
	],
	[
		"s193312",
		"Stranvaesia davidiana",
		"stranvaesia",
		193312
	],
	[
		"s661366",
		"Stranvaesia nussia",
		"stranvaesia",
		661366
	],
	[
		"s1248461",
		"Stranvaesia oblanceolata",
		"stranvaesia",
		1248461
	],
	[
		"s648879",
		"Streblus asper",
		"streblus",
		648879
	],
	[
		"s3809151",
		"Streblus celebensis",
		"streblus",
		3809151
	],
	[
		"s241927",
		"Streblus elongatus",
		"streblus",
		241927
	],
	[
		"s384980",
		"Streblus heterophyllus",
		"streblus",
		384980
	],
	[
		"s3809152",
		"Streblus mitis",
		"streblus",
		3809152
	],
	[
		"s3809153",
		"Streblus monoicus",
		"streblus",
		3809153
	],
	[
		"s1898886",
		"Streblus tonkinensis",
		"streblus",
		1898886
	],
	[
		"s3809154",
		"Streblus vidalii",
		"streblus",
		3809154
	],
	[
		"s148910",
		"Taihangia rupestris",
		"taihangia",
		148910
	],
	[
		"s1745981",
		"Taxotrophis aquifolioides",
		"taxotrophis",
		1745981
	],
	[
		"s3136878",
		"Taxotrophis ilicifolia",
		"taxotrophis",
		3136878
	],
	[
		"s3054366",
		"Taxotrophis macrophylla",
		"taxotrophis",
		3054366
	],
	[
		"s3886752",
		"Taxotrophis perakensis",
		"taxotrophis",
		3886752
	],
	[
		"s2732298",
		"Taxotrophis spinosa",
		"taxotrophis",
		2732298
	],
	[
		"s1745979",
		"Taxotrophis taxoides",
		"taxotrophis",
		1745979
	],
	[
		"s2732317",
		"Taxotrophis zeylanica",
		"taxotrophis",
		2732317
	],
	[
		"s2024726",
		"Tetraglochin acanthocarpa",
		"tetraglochin",
		2024726
	],
	[
		"s2024727",
		"Tetraglochin alata",
		"tetraglochin",
		2024727
	],
	[
		"s2024728",
		"Tetraglochin ameghinoi",
		"tetraglochin",
		2024728
	],
	[
		"s2024729",
		"Tetraglochin andina",
		"tetraglochin",
		2024729
	],
	[
		"s2024730",
		"Tetraglochin caespitosa",
		"tetraglochin",
		2024730
	],
	[
		"s211875",
		"Tetraglochin cristata",
		"tetraglochin",
		211875
	],
	[
		"s2024732",
		"Tetraglochin inermis",
		"tetraglochin",
		2024732
	],
	[
		"s691229",
		"Thomsonaria aronioides",
		"thomsonaria",
		691229
	],
	[
		"s3091535",
		"Thomsonaria astateria",
		"thomsonaria",
		3091535
	],
	[
		"s3095553",
		"Thomsonaria brevipetiolata",
		"thomsonaria",
		3095553
	],
	[
		"s691230",
		"Thomsonaria caloneura",
		"thomsonaria",
		691230
	],
	[
		"s1770153",
		"Thomsonaria corymbifera",
		"thomsonaria",
		1770153
	],
	[
		"s3393891",
		"Thomsonaria decaisneana",
		"thomsonaria",
		3393891
	],
	[
		"s3091939",
		"Thomsonaria epidendron",
		"thomsonaria",
		3091939
	],
	[
		"s2873989",
		"Thomsonaria ferruginea",
		"thomsonaria",
		2873989
	],
	[
		"s1828479",
		"Thomsonaria globosa",
		"thomsonaria",
		1828479
	],
	[
		"s1770159",
		"Thomsonaria meliosmifolia",
		"thomsonaria",
		1770159
	],
	[
		"s1770160",
		"Thomsonaria ochracea",
		"thomsonaria",
		1770160
	],
	[
		"s3095556",
		"Thomsonaria subulata",
		"thomsonaria",
		3095556
	],
	[
		"s691243",
		"Thomsonaria thomsonii",
		"thomsonaria",
		691243
	],
	[
		"s3879929",
		"Thomsonaria verticillata",
		"thomsonaria",
		3879929
	],
	[
		"s193503",
		"Torminalis clusii",
		"torminalis",
		193503
	],
	[
		"s2914000",
		"Torminalis glaberrima",
		"torminalis",
		2914e3
	],
	[
		"s1399750",
		"Touchardia latifolia",
		"touchardia",
		1399750
	],
	[
		"s1317894",
		"Treculia acuminata",
		"treculia",
		1317894
	],
	[
		"s709072",
		"Treculia africana",
		"treculia",
		709072
	],
	[
		"s3869138",
		"Treculia lamiana",
		"treculia",
		3869138
	],
	[
		"s3092020",
		"Treculia madagascarica",
		"treculia",
		3092020
	],
	[
		"s709073",
		"Treculia obovoidea",
		"treculia",
		709073
	],
	[
		"s3869139",
		"Treculia zenkeri",
		"treculia",
		3869139
	],
	[
		"s3091575",
		"Trema amboinense",
		"trema",
		3091575
	],
	[
		"s3476",
		"Trema andersonii",
		"trema",
		3476
	],
	[
		"s1037064",
		"Trema angustifolium",
		"trema",
		1037064
	],
	[
		"s258496",
		"Trema asperum",
		"trema",
		258496
	],
	[
		"s258494",
		"Trema cannabina",
		"trema",
		258494
	],
	[
		"s3128369",
		"Trema cf. humbertii",
		"trema",
		3128369
	],
	[
		"s2306167",
		"Trema cubense",
		"trema",
		2306167
	],
	[
		"s1184761",
		"Trema discolor",
		"trema",
		1184761
	],
	[
		"s1184762",
		"Trema domingense",
		"trema",
		1184762
	],
	[
		"s3889473",
		"Trema eurhynchum",
		"trema",
		3889473
	],
	[
		"s258499",
		"Trema integerrimum",
		"trema",
		258499
	],
	[
		"s258498",
		"Trema lamarckianum",
		"trema",
		258498
	],
	[
		"s1184763",
		"Trema levigatum",
		"trema",
		1184763
	],
	[
		"s1184760",
		"Trema melastomatifolium",
		"trema",
		1184760
	],
	[
		"s28954",
		"Trema micranthum",
		"trema",
		28954
	],
	[
		"s258495",
		"Trema nitens",
		"trema",
		258495
	],
	[
		"s1679369",
		"Trema nitidum",
		"trema",
		1679369
	],
	[
		"s63057",
		"Trema orientale",
		"trema",
		63057
	],
	[
		"s194262",
		"Trema parviflorum",
		"trema",
		194262
	],
	[
		"s258493",
		"Trema politoria",
		"trema",
		258493
	],
	[
		"s258492",
		"Trema simulans",
		"trema",
		258492
	],
	[
		"s3480",
		"Trema tomentosum",
		"trema",
		3480
	],
	[
		"s2606463",
		"Trema vieillardii",
		"trema",
		2606463
	],
	[
		"s85756",
		"Trema virgatum",
		"trema",
		85756
	],
	[
		"s3889482",
		"Trevoa campanulata",
		"trevoa",
		3889482
	],
	[
		"s3889483",
		"Trevoa glauca",
		"trevoa",
		3889483
	],
	[
		"s262945",
		"Trevoa quinquenervia",
		"trevoa",
		262945
	],
	[
		"s172232",
		"Trichocephalus stipularis",
		"trichocephalus",
		172232
	],
	[
		"s241931",
		"Trilepisium madagascariense",
		"trilepisium",
		241931
	],
	[
		"s681501",
		"Trophis caucana",
		"trophis",
		681501
	],
	[
		"s2732318",
		"Trophis cuspidata",
		"trophis",
		2732318
	],
	[
		"s241933",
		"Trophis involucrata",
		"trophis",
		241933
	],
	[
		"s2732319",
		"Trophis mexicana",
		"trophis",
		2732319
	],
	[
		"s2675501",
		"Trophis montana",
		"trophis",
		2675501
	],
	[
		"s3891020",
		"Trophis noraminervae",
		"trophis",
		3891020
	],
	[
		"s241934",
		"Trophis racemosa",
		"trophis",
		241934
	],
	[
		"s3891047",
		"Trymalium albicans",
		"trymalium",
		3891047
	],
	[
		"s323959",
		"Trymalium angustifolium",
		"trymalium",
		323959
	],
	[
		"s489693",
		"Trymalium cf. floribundum MVSP-2007",
		"trymalium",
		489693
	],
	[
		"s3891048",
		"Trymalium daphnifolium",
		"trymalium",
		3891048
	],
	[
		"s3891049",
		"Trymalium densiflorum",
		"trymalium",
		3891049
	],
	[
		"s323957",
		"Trymalium elachophyllum",
		"trymalium",
		323957
	],
	[
		"s106718",
		"Trymalium ledifolium",
		"trymalium",
		106718
	],
	[
		"s3891050",
		"Trymalium litorale",
		"trymalium",
		3891050
	],
	[
		"s323958",
		"Trymalium monospermum",
		"trymalium",
		323958
	],
	[
		"s3891051",
		"Trymalium myrtillus",
		"trymalium",
		3891051
	],
	[
		"s106717",
		"Trymalium odoratissimum",
		"trymalium",
		106717
	],
	[
		"s1812997",
		"Trymalium spathulatum",
		"trymalium",
		1812997
	],
	[
		"s3891052",
		"Trymalium urceolare",
		"trymalium",
		3891052
	],
	[
		"s3891053",
		"Trymalium venustum",
		"trymalium",
		3891053
	],
	[
		"s323944",
		"Trymalium wayi",
		"trymalium",
		323944
	],
	[
		"s323974",
		"Trymalium x ramosissimum",
		"trymalium",
		323974
	],
	[
		"s24736",
		"Ulmus alata",
		"ulmus",
		24736
	],
	[
		"s3053385",
		"Ulmus alta",
		"ulmus",
		3053385
	],
	[
		"s29740",
		"Ulmus americana",
		"ulmus",
		29740
	],
	[
		"s3051265",
		"Ulmus androssowii",
		"ulmus",
		3051265
	],
	[
		"s3053414",
		"Ulmus atrovirens",
		"ulmus",
		3053414
	],
	[
		"s2291175",
		"Ulmus bergmanniana",
		"ulmus",
		2291175
	],
	[
		"s3800742",
		"Ulmus boissieri",
		"ulmus",
		3800742
	],
	[
		"s2774196",
		"Ulmus canescens",
		"ulmus",
		2774196
	],
	[
		"s3053415",
		"Ulmus cantabrigiensis",
		"ulmus",
		3053415
	],
	[
		"s1357738",
		"Ulmus castaneifolia",
		"ulmus",
		1357738
	],
	[
		"s1961212",
		"Ulmus changii",
		"ulmus",
		1961212
	],
	[
		"s1737302",
		"Ulmus chenmoui",
		"ulmus",
		1737302
	],
	[
		"s3800743",
		"Ulmus chumlia",
		"ulmus",
		3800743
	],
	[
		"s3053388",
		"Ulmus coritana",
		"ulmus",
		3053388
	],
	[
		"s3053416",
		"Ulmus crassa",
		"ulmus",
		3053416
	],
	[
		"s102694",
		"Ulmus crassifolia",
		"ulmus",
		102694
	],
	[
		"s3053413",
		"Ulmus curvifolia",
		"ulmus",
		3053413
	],
	[
		"s1297873",
		"Ulmus davidiana",
		"ulmus",
		1297873
	],
	[
		"s1055329",
		"Ulmus densa",
		"ulmus",
		1055329
	],
	[
		"s1428769",
		"Ulmus elliptica",
		"ulmus",
		1428769
	],
	[
		"s2699524",
		"Ulmus elongata",
		"ulmus",
		2699524
	],
	[
		"s1737301",
		"Ulmus gaussenii",
		"ulmus",
		1737301
	],
	[
		"s172265",
		"Ulmus glabra",
		"ulmus",
		172265
	],
	[
		"s1428770",
		"Ulmus glaucescens",
		"ulmus",
		1428770
	],
	[
		"s3053375",
		"Ulmus harbinensis",
		"ulmus",
		3053375
	],
	[
		"s1747487",
		"Ulmus hybrid cultivar",
		"ulmus",
		1747487
	],
	[
		"s3053376",
		"Ulmus ismaelis",
		"ulmus",
		3053376
	],
	[
		"s198265",
		"Ulmus laciniata",
		"ulmus",
		198265
	],
	[
		"s2782712",
		"Ulmus laciniata x Ulmus pumila",
		"ulmus",
		2782712
	],
	[
		"s233204",
		"Ulmus laevis",
		"ulmus",
		233204
	],
	[
		"s1357739",
		"Ulmus lamellosa",
		"ulmus",
		1357739
	],
	[
		"s1679378",
		"Ulmus lanceifolia",
		"ulmus",
		1679378
	],
	[
		"s3053417",
		"Ulmus longidentata",
		"ulmus",
		3053417
	],
	[
		"s1043716",
		"Ulmus macrocarpa",
		"ulmus",
		1043716
	],
	[
		"s2782714",
		"Ulmus mexicana",
		"ulmus",
		2782714
	],
	[
		"s3018408",
		"Ulmus mianzhuensis",
		"ulmus",
		3018408
	],
	[
		"s1184764",
		"Ulmus microcarpa",
		"ulmus",
		1184764
	],
	[
		"s262084",
		"Ulmus minor",
		"ulmus",
		262084
	],
	[
		"s3053418",
		"Ulmus oblanceolata",
		"ulmus",
		3053418
	],
	[
		"s63058",
		"Ulmus parvifolia",
		"ulmus",
		63058
	],
	[
		"s3053386",
		"Ulmus pinnato-racemosa",
		"ulmus",
		3053386
	],
	[
		"s2695391",
		"Ulmus plotii",
		"ulmus",
		2695391
	],
	[
		"s186427",
		"Ulmus procera",
		"ulmus",
		186427
	],
	[
		"s2713447",
		"Ulmus prunifolia",
		"ulmus",
		2713447
	],
	[
		"s198266",
		"Ulmus pumila",
		"ulmus",
		198266
	],
	[
		"s3832122",
		"Ulmus pumila x Ulmus rubra",
		"ulmus",
		3832122
	],
	[
		"s102693",
		"Ulmus rubra",
		"ulmus",
		102693
	],
	[
		"s2713448",
		"Ulmus serotina",
		"ulmus",
		2713448
	],
	[
		"s3053419",
		"Ulmus serratifrons",
		"ulmus",
		3053419
	],
	[
		"s3053420",
		"Ulmus sylvatica",
		"ulmus",
		3053420
	],
	[
		"s2713449",
		"Ulmus szechuanica",
		"ulmus",
		2713449
	],
	[
		"s3053377",
		"Ulmus taihangshanensis",
		"ulmus",
		3053377
	],
	[
		"s180953",
		"Ulmus thomasii",
		"ulmus",
		180953
	],
	[
		"s2713450",
		"Ulmus uyematsui",
		"ulmus",
		2713450
	],
	[
		"s2782715",
		"Ulmus villosa",
		"ulmus",
		2782715
	],
	[
		"s647291",
		"Ulmus wallichiana",
		"ulmus",
		647291
	],
	[
		"s1211425",
		"Ulmus x hollandica",
		"ulmus",
		1211425
	],
	[
		"s2792723",
		"Urera acuminata",
		"urera",
		2792723
	],
	[
		"s1399751",
		"Urera alceifolia",
		"urera",
		1399751
	],
	[
		"s2792724",
		"Urera altissima",
		"urera",
		2792724
	],
	[
		"s2792725",
		"Urera aurantiaca",
		"urera",
		2792725
	],
	[
		"s681502",
		"Urera baccifera",
		"urera",
		681502
	],
	[
		"s2952670",
		"Urera cameroonensis",
		"urera",
		2952670
	],
	[
		"s2952671",
		"Urera capitata",
		"urera",
		2952671
	],
	[
		"s1130851",
		"Urera caracasana",
		"urera",
		1130851
	],
	[
		"s2952676",
		"Urera cf. cordifolia Ur15",
		"urera",
		2952676
	],
	[
		"s1471892",
		"Urera chlorocarpa",
		"urera",
		1471892
	],
	[
		"s1475448",
		"Urera corallina",
		"urera",
		1475448
	],
	[
		"s3777473",
		"Urera cuneata",
		"urera",
		3777473
	],
	[
		"s3777474",
		"Urera domingensis",
		"urera",
		3777474
	],
	[
		"s1130853",
		"Urera elata",
		"urera",
		1130853
	],
	[
		"s3777475",
		"Urera expansa",
		"urera",
		3777475
	],
	[
		"s2792726",
		"Urera fenestrata",
		"urera",
		2792726
	],
	[
		"s3777476",
		"Urera filiformis",
		"urera",
		3777476
	],
	[
		"s1586316",
		"Urera fischeri",
		"urera",
		1586316
	],
	[
		"s194275",
		"Urera glabra",
		"urera",
		194275
	],
	[
		"s2792727",
		"Urera glabriuscula",
		"urera",
		2792727
	],
	[
		"s3777477",
		"Urera gravenreuthii",
		"urera",
		3777477
	],
	[
		"s3092027",
		"Urera guanacastensis",
		"urera",
		3092027
	],
	[
		"s2093312",
		"Urera kaalae",
		"urera",
		2093312
	],
	[
		"s2792738",
		"Urera keayi",
		"urera",
		2792738
	],
	[
		"s2792728",
		"Urera killipiana",
		"urera",
		2792728
	],
	[
		"s344863",
		"Urera laciniata",
		"urera",
		344863
	],
	[
		"s1399753",
		"Urera lianoides",
		"urera",
		1399753
	],
	[
		"s3777478",
		"Urera lobulata",
		"urera",
		3777478
	],
	[
		"s2792729",
		"Urera mannii",
		"urera",
		2792729
	],
	[
		"s3777479",
		"Urera martiniana",
		"urera",
		3777479
	],
	[
		"s2072305",
		"Urera nitida",
		"urera",
		2072305
	],
	[
		"s2792732",
		"Urera pacifica",
		"urera",
		2792732
	],
	[
		"s3015770",
		"Urera rzedowskii",
		"urera",
		3015770
	],
	[
		"s2306707",
		"Urera sandwicensis",
		"urera",
		2306707
	],
	[
		"s1130852",
		"Urera simplex",
		"urera",
		1130852
	],
	[
		"s3092028",
		"Urera talbotii",
		"urera",
		3092028
	],
	[
		"s3015664",
		"Urera verrucosa",
		"urera",
		3015664
	],
	[
		"s2306708",
		"Urera woodii",
		"urera",
		2306708
	],
	[
		"s1435568",
		"Urtica andicola",
		"urtica",
		1435568
	],
	[
		"s1399756",
		"Urtica ardens",
		"urtica",
		1399756
	],
	[
		"s1853081",
		"Urtica aspera",
		"urtica",
		1853081
	],
	[
		"s1399757",
		"Urtica atrichocaulis",
		"urtica",
		1399757
	],
	[
		"s1435570",
		"Urtica atrovirens",
		"urtica",
		1435570
	],
	[
		"s1853082",
		"Urtica australis",
		"urtica",
		1853082
	],
	[
		"s3891468",
		"Urtica ballotifolia",
		"urtica",
		3891468
	],
	[
		"s1853083",
		"Urtica berteroana",
		"urtica",
		1853083
	],
	[
		"s1435571",
		"Urtica bianorii",
		"urtica",
		1435571
	],
	[
		"s3891469",
		"Urtica bracteola",
		"urtica",
		3891469
	],
	[
		"s3891470",
		"Urtica bullata",
		"urtica",
		3891470
	],
	[
		"s546995",
		"Urtica cannabina",
		"urtica",
		546995
	],
	[
		"s1853085",
		"Urtica cf. tibetica Dickore 3647",
		"urtica",
		1853085
	],
	[
		"s1470437",
		"Urtica chamaedryoides",
		"urtica",
		1470437
	],
	[
		"s3891471",
		"Urtica chengkouensis",
		"urtica",
		3891471
	],
	[
		"s1470438",
		"Urtica circularis",
		"urtica",
		1470438
	],
	[
		"s1435572",
		"Urtica cypria",
		"urtica",
		1435572
	],
	[
		"s3501",
		"Urtica dioica",
		"urtica",
		3501
	],
	[
		"s1853086",
		"Urtica domingensis",
		"urtica",
		1853086
	],
	[
		"s1435580",
		"Urtica echinata",
		"urtica",
		1435580
	],
	[
		"s1435581",
		"Urtica ferox",
		"urtica",
		1435581
	],
	[
		"s644075",
		"Urtica fissa",
		"urtica",
		644075
	],
	[
		"s1435582",
		"Urtica flabellata",
		"urtica",
		1435582
	],
	[
		"s1853087",
		"Urtica fragilis",
		"urtica",
		1853087
	],
	[
		"s2995339",
		"Urtica galeopsifolia",
		"urtica",
		2995339
	],
	[
		"s1853088",
		"Urtica glomeruliflora",
		"urtica",
		1853088
	],
	[
		"s1470440",
		"Urtica gracilenta",
		"urtica",
		1470440
	],
	[
		"s1435576",
		"Urtica gracilis",
		"urtica",
		1435576
	],
	[
		"s1853089",
		"Urtica grandidentata",
		"urtica",
		1853089
	],
	[
		"s3891472",
		"Urtica helanshanica",
		"urtica",
		3891472
	],
	[
		"s2067462",
		"Urtica himalayensis",
		"urtica",
		2067462
	],
	[
		"s1399758",
		"Urtica hyperborea",
		"urtica",
		1399758
	],
	[
		"s1435583",
		"Urtica incisa",
		"urtica",
		1435583
	],
	[
		"s1435584",
		"Urtica kioviensis",
		"urtica",
		1435584
	],
	[
		"s1303699",
		"Urtica laetevirens",
		"urtica",
		1303699
	],
	[
		"s1435585",
		"Urtica lalibertadensis",
		"urtica",
		1435585
	],
	[
		"s3891473",
		"Urtica laurifolia",
		"urtica",
		3891473
	],
	[
		"s1435586",
		"Urtica leptophylla",
		"urtica",
		1435586
	],
	[
		"s3891474",
		"Urtica lilloi",
		"urtica",
		3891474
	],
	[
		"s1793853",
		"Urtica linearifolia",
		"urtica",
		1793853
	],
	[
		"s3891475",
		"Urtica lobata",
		"urtica",
		3891475
	],
	[
		"s2753882",
		"Urtica lobatifolia",
		"urtica",
		2753882
	],
	[
		"s1853091",
		"Urtica lobulata",
		"urtica",
		1853091
	],
	[
		"s1435587",
		"Urtica longispica",
		"urtica",
		1435587
	],
	[
		"s1853092",
		"Urtica macbridei",
		"urtica",
		1853092
	],
	[
		"s2928716",
		"Urtica macrorrhiza",
		"urtica",
		2928716
	],
	[
		"s1435588",
		"Urtica magellanica",
		"urtica",
		1435588
	],
	[
		"s540250",
		"Urtica mairei",
		"urtica",
		540250
	],
	[
		"s3891476",
		"Urtica malipoensis",
		"urtica",
		3891476
	],
	[
		"s1853093",
		"Urtica masafuerae",
		"urtica",
		1853093
	],
	[
		"s1586318",
		"Urtica massaica",
		"urtica",
		1586318
	],
	[
		"s1053403",
		"Urtica membranacea",
		"urtica",
		1053403
	],
	[
		"s2306710",
		"Urtica membranifolia",
		"urtica",
		2306710
	],
	[
		"s1470441",
		"Urtica mexicana",
		"urtica",
		1470441
	],
	[
		"s1853094",
		"Urtica minutifolia",
		"urtica",
		1853094
	],
	[
		"s1435590",
		"Urtica morifolia",
		"urtica",
		1435590
	],
	[
		"s1853095",
		"Urtica neubaueri",
		"urtica",
		1853095
	],
	[
		"s3092029",
		"Urtica orizabae",
		"urtica",
		3092029
	],
	[
		"s1853096",
		"Urtica papuana",
		"urtica",
		1853096
	],
	[
		"s2067463",
		"Urtica parviflora",
		"urtica",
		2067463
	],
	[
		"s1853097",
		"Urtica perconfusa",
		"urtica",
		1853097
	],
	[
		"s1435591",
		"Urtica peruviana",
		"urtica",
		1435591
	],
	[
		"s1435592",
		"Urtica pilulifera",
		"urtica",
		1435592
	],
	[
		"s1435593",
		"Urtica platyphylla",
		"urtica",
		1435593
	],
	[
		"s1435594",
		"Urtica portosanctana",
		"urtica",
		1435594
	],
	[
		"s3092030",
		"Urtica praetermissa",
		"urtica",
		3092030
	],
	[
		"s1853098",
		"Urtica pseudomagellanica",
		"urtica",
		1853098
	],
	[
		"s2952674",
		"Urtica radicans",
		"urtica",
		2952674
	],
	[
		"s1853099",
		"Urtica rupestris",
		"urtica",
		1853099
	],
	[
		"s3891477",
		"Urtica sansibarica",
		"urtica",
		3891477
	],
	[
		"s1853100",
		"Urtica simensis",
		"urtica",
		1853100
	],
	[
		"s1853101",
		"Urtica spatulata",
		"urtica",
		1853101
	],
	[
		"s1470442",
		"Urtica spirealis",
		"urtica",
		1470442
	],
	[
		"s1435595",
		"Urtica stachyoides",
		"urtica",
		1435595
	],
	[
		"s1470443",
		"Urtica subincisa",
		"urtica",
		1470443
	],
	[
		"s1853102",
		"Urtica sykesii",
		"urtica",
		1853102
	],
	[
		"s1435596",
		"Urtica taiwaniana",
		"urtica",
		1435596
	],
	[
		"s1303703",
		"Urtica thunbergiana",
		"urtica",
		1303703
	],
	[
		"s1853084",
		"Urtica tibetica",
		"urtica",
		1853084
	],
	[
		"s1303701",
		"Urtica triangularis",
		"urtica",
		1303701
	],
	[
		"s1435597",
		"Urtica trichantha",
		"urtica",
		1435597
	],
	[
		"s473050",
		"Urtica urens",
		"urtica",
		473050
	],
	[
		"s1435598",
		"Urtica urentivelutina",
		"urtica",
		1435598
	],
	[
		"s1399762",
		"Urtica zayuensis",
		"urtica",
		1399762
	],
	[
		"s2605018",
		"Utsetela gabonensis",
		"utsetela",
		2605018
	],
	[
		"s241940",
		"Utsetela neglecta",
		"utsetela",
		241940
	],
	[
		"s1898939",
		"Vauquelinia angustifolia",
		"vauquelinia",
		1898939
	],
	[
		"s2675841",
		"Vauquelinia australis",
		"vauquelinia",
		2675841
	],
	[
		"s36600",
		"Vauquelinia californica",
		"vauquelinia",
		36600
	],
	[
		"s32250",
		"Vauquelinia corymbosa",
		"vauquelinia",
		32250
	],
	[
		"s2675844",
		"Vauquelinia pauciflora",
		"vauquelinia",
		2675844
	],
	[
		"s527216",
		"Ventia alnifolia",
		"ventia",
		527216
	],
	[
		"s706615",
		"Ventia lanceolata",
		"ventia",
		706615
	],
	[
		"s1813070",
		"Ventia serrata",
		"ventia",
		1813070
	],
	[
		"s3092031",
		"Ventilago africana",
		"ventilago",
		3092031
	],
	[
		"s3715987",
		"Ventilago batanensis",
		"ventilago",
		3715987
	],
	[
		"s3715988",
		"Ventilago beccarii",
		"ventilago",
		3715988
	],
	[
		"s3715997",
		"Ventilago borneensis",
		"ventilago",
		3715997
	],
	[
		"s3715998",
		"Ventilago brunnea",
		"ventilago",
		3715998
	],
	[
		"s3092032",
		"Ventilago buxoides",
		"ventilago",
		3092032
	],
	[
		"s3715991",
		"Ventilago calpicarpa",
		"ventilago",
		3715991
	],
	[
		"s3445675",
		"Ventilago calyculata",
		"ventilago",
		3445675
	],
	[
		"s1390085",
		"Ventilago denticulata",
		"ventilago",
		1390085
	],
	[
		"s3140269",
		"Ventilago dichotoma",
		"ventilago",
		3140269
	],
	[
		"s3091603",
		"Ventilago diffusa",
		"ventilago",
		3091603
	],
	[
		"s1619561",
		"Ventilago ecorollata",
		"ventilago",
		1619561
	],
	[
		"s1898907",
		"Ventilago elegans",
		"ventilago",
		1898907
	],
	[
		"s3716009",
		"Ventilago ferruginea",
		"ventilago",
		3716009
	],
	[
		"s3716010",
		"Ventilago flavovirens",
		"ventilago",
		3716010
	],
	[
		"s3715999",
		"Ventilago gamblei",
		"ventilago",
		3715999
	],
	[
		"s3716000",
		"Ventilago gladiata",
		"ventilago",
		3716e3
	],
	[
		"s3716001",
		"Ventilago goughii",
		"ventilago",
		3716001
	],
	[
		"s1489956",
		"Ventilago harmandiana",
		"ventilago",
		1489956
	],
	[
		"s3715989",
		"Ventilago hirtella",
		"ventilago",
		3715989
	],
	[
		"s3092033",
		"Ventilago inaequilateralis",
		"ventilago",
		3092033
	],
	[
		"s1813015",
		"Ventilago kurzii",
		"ventilago",
		1813015
	],
	[
		"s108868",
		"Ventilago leiocarpa",
		"ventilago",
		108868
	],
	[
		"s3092034",
		"Ventilago leptadenia",
		"ventilago",
		3092034
	],
	[
		"s345802",
		"Ventilago madraspatana",
		"ventilago",
		345802
	],
	[
		"s1813016",
		"Ventilago maingayi",
		"ventilago",
		1813016
	],
	[
		"s3122865",
		"Ventilago malaccensis",
		"ventilago",
		3122865
	],
	[
		"s3716002",
		"Ventilago microcarpa",
		"ventilago",
		3716002
	],
	[
		"s1813017",
		"Ventilago neocaledonica",
		"ventilago",
		1813017
	],
	[
		"s3716003",
		"Ventilago nisidai",
		"ventilago",
		3716003
	],
	[
		"s3715992",
		"Ventilago novoguineensis",
		"ventilago",
		3715992
	],
	[
		"s3716004",
		"Ventilago palawanensis",
		"ventilago",
		3716004
	],
	[
		"s3716005",
		"Ventilago pauciflora",
		"ventilago",
		3716005
	],
	[
		"s3715990",
		"Ventilago poomae",
		"ventilago",
		3715990
	],
	[
		"s1812998",
		"Ventilago pseudocalyculata",
		"ventilago",
		1812998
	],
	[
		"s1619562",
		"Ventilago pubiflora",
		"ventilago",
		1619562
	],
	[
		"s3716006",
		"Ventilago sororia",
		"ventilago",
		3716006
	],
	[
		"s3716007",
		"Ventilago tinctoria",
		"ventilago",
		3716007
	],
	[
		"s3716008",
		"Ventilago vanuatuana",
		"ventilago",
		3716008
	],
	[
		"s106720",
		"Ventilago viminalis",
		"ventilago",
		106720
	],
	[
		"s3716011",
		"Ventilago zhengdei",
		"ventilago",
		3716011
	],
	[
		"s3893412",
		"Waldsteinia idahoensis",
		"waldsteinia",
		3893412
	],
	[
		"s2726006",
		"Waldsteinia maximowicziana",
		"waldsteinia",
		2726006
	],
	[
		"s2726005",
		"Waldsteinia trifolia",
		"waldsteinia",
		2726005
	],
	[
		"s3710351",
		"Weniomeles atropurpurea",
		"weniomeles",
		3710351
	],
	[
		"s2305210",
		"Weniomeles bodinieri",
		"weniomeles",
		2305210
	],
	[
		"s1770158",
		"Wilsonaria megalocarpa",
		"wilsonaria",
		1770158
	],
	[
		"s2080238",
		"x Amelasorbus jackii",
		"x-amelasorbus",
		2080238
	],
	[
		"s2841020",
		"x Comagaria rosea",
		"x-comagaria",
		2841020
	],
	[
		"s356587",
		"x Crataemespilus grandiflora",
		"x-crataemespilus",
		356587
	],
	[
		"s343458",
		"x Pyronia veitchii",
		"x-pyronia",
		343458
	],
	[
		"s2604225",
		"x Sorbaronia fallax",
		"x-sorbaronia",
		2604225
	],
	[
		"s3091380",
		"x Sorbaronia jackii",
		"x-sorbaronia",
		3091380
	],
	[
		"s1530595",
		"x Sorbocotoneaster pozdnjakovii",
		"x-sorbocotoneaster",
		1530595
	],
	[
		"s409525",
		"Xerospiraea hartwegiana",
		"xerospiraea",
		409525
	],
	[
		"s160988",
		"Zelkova abelicea",
		"zelkova",
		160988
	],
	[
		"s160986",
		"Zelkova carpinifolia",
		"zelkova",
		160986
	],
	[
		"s262083",
		"Zelkova cf. serrata GG-2004",
		"zelkova",
		262083
	],
	[
		"s3053387",
		"Zelkova hyrcana",
		"zelkova",
		3053387
	],
	[
		"s172643",
		"Zelkova schneideriana",
		"zelkova",
		172643
	],
	[
		"s45187",
		"Zelkova serrata",
		"zelkova",
		45187
	],
	[
		"s160987",
		"Zelkova sicula",
		"zelkova",
		160987
	],
	[
		"s1214907",
		"Zelkova sinica",
		"zelkova",
		1214907
	],
	[
		"s1312523",
		"Zhengyia shennongensis",
		"zhengyia",
		1312523
	],
	[
		"s1237853",
		"Ziziphus abyssinica",
		"ziziphus",
		1237853
	],
	[
		"s345803",
		"Ziziphus acidojujuba",
		"ziziphus",
		345803
	],
	[
		"s3158344",
		"Ziziphus affinis",
		"ziziphus",
		3158344
	],
	[
		"s3755092",
		"Ziziphus andamanica",
		"ziziphus",
		3755092
	],
	[
		"s1085521",
		"Ziziphus angustifolia",
		"ziziphus",
		1085521
	],
	[
		"s478035",
		"Ziziphus apetala",
		"ziziphus",
		478035
	],
	[
		"s478036",
		"Ziziphus attopensis",
		"ziziphus",
		478036
	],
	[
		"s3137418",
		"Ziziphus bhandarii",
		"ziziphus",
		3137418
	],
	[
		"s3028811",
		"Ziziphus bhansalii",
		"ziziphus",
		3028811
	],
	[
		"s3375744",
		"Ziziphus borneensis",
		"ziziphus",
		3375744
	],
	[
		"s1812999",
		"Ziziphus brunoniana",
		"ziziphus",
		1812999
	],
	[
		"s3755093",
		"Ziziphus budhensis",
		"ziziphus",
		3755093
	],
	[
		"s345805",
		"Ziziphus calophylla",
		"ziziphus",
		345805
	],
	[
		"s3755094",
		"Ziziphus cambodiana",
		"ziziphus",
		3755094
	],
	[
		"s1489967",
		"Ziziphus cambodianus",
		"ziziphus",
		1489967
	],
	[
		"s3028825",
		"Ziziphus caracutta",
		"ziziphus",
		3028825
	],
	[
		"s1346573",
		"Ziziphus cf. fungii MR-2013",
		"ziziphus",
		1346573
	],
	[
		"s2984748",
		"Ziziphus cf. spina-christi QZ-2022",
		"ziziphus",
		2984748
	],
	[
		"s3755095",
		"Ziziphus colombiana",
		"ziziphus",
		3755095
	],
	[
		"s2743319",
		"Ziziphus cotinifolia",
		"ziziphus",
		2743319
	],
	[
		"s3755096",
		"Ziziphus crebrivenosa",
		"ziziphus",
		3755096
	],
	[
		"s3158346",
		"Ziziphus cumingiana",
		"ziziphus",
		3158346
	],
	[
		"s1085522",
		"Ziziphus djamuensis",
		"ziziphus",
		1085522
	],
	[
		"s3122874",
		"Ziziphus elegans",
		"ziziphus",
		3122874
	],
	[
		"s478037",
		"Ziziphus fungii",
		"ziziphus",
		478037
	],
	[
		"s3229293",
		"Ziziphus funiculosa",
		"ziziphus",
		3229293
	],
	[
		"s72172",
		"Ziziphus glabrata",
		"ziziphus",
		72172
	],
	[
		"s3755097",
		"Ziziphus globularis",
		"ziziphus",
		3755097
	],
	[
		"s3755098",
		"Ziziphus guaranitica",
		"ziziphus",
		3755098
	],
	[
		"s2884084",
		"Ziziphus hajarensis",
		"ziziphus",
		2884084
	],
	[
		"s3092043",
		"Ziziphus hamur",
		"ziziphus",
		3092043
	],
	[
		"s3158348",
		"Ziziphus havilandii",
		"ziziphus",
		3158348
	],
	[
		"s3755099",
		"Ziziphus hoaensis",
		"ziziphus",
		3755099
	],
	[
		"s3028816",
		"Ziziphus horrida",
		"ziziphus",
		3028816
	],
	[
		"s345808",
		"Ziziphus horsfieldii",
		"ziziphus",
		345808
	],
	[
		"s3755100",
		"Ziziphus hutchinsonii",
		"ziziphus",
		3755100
	],
	[
		"s478038",
		"Ziziphus incurva",
		"ziziphus",
		478038
	],
	[
		"s3755101",
		"Ziziphus javanensis",
		"ziziphus",
		3755101
	],
	[
		"s326968",
		"Ziziphus jujuba",
		"ziziphus",
		326968
	],
	[
		"s3158345",
		"Ziziphus kunstleri",
		"ziziphus",
		3158345
	],
	[
		"s3092044",
		"Ziziphus laui",
		"ziziphus",
		3092044
	],
	[
		"s3158342",
		"Ziziphus leucodermis",
		"ziziphus",
		3158342
	],
	[
		"s3755102",
		"Ziziphus linnaei",
		"ziziphus",
		3755102
	],
	[
		"s345809",
		"Ziziphus lotus",
		"ziziphus",
		345809
	],
	[
		"s478039",
		"Ziziphus mairei",
		"ziziphus",
		478039
	],
	[
		"s157914",
		"Ziziphus mauritiana",
		"ziziphus",
		157914
	],
	[
		"s3755103",
		"Ziziphus melastomoides",
		"ziziphus",
		3755103
	],
	[
		"s478040",
		"Ziziphus montana",
		"ziziphus",
		478040
	],
	[
		"s345811",
		"Ziziphus mucronata",
		"ziziphus",
		345811
	],
	[
		"s3028810",
		"Ziziphus naikii",
		"ziziphus",
		3028810
	],
	[
		"s498071",
		"Ziziphus nummularia",
		"ziziphus",
		498071
	],
	[
		"s345151",
		"Ziziphus oenopolia",
		"ziziphus",
		345151
	],
	[
		"s106721",
		"Ziziphus ornata",
		"ziziphus",
		106721
	],
	[
		"s3755104",
		"Ziziphus otanesii",
		"ziziphus",
		3755104
	],
	[
		"s1819812",
		"Ziziphus oxyphylla",
		"ziziphus",
		1819812
	],
	[
		"s3755105",
		"Ziziphus papuana",
		"ziziphus",
		3755105
	],
	[
		"s3755106",
		"Ziziphus pernettyoides",
		"ziziphus",
		3755106
	],
	[
		"s345814",
		"Ziziphus pubescens",
		"ziziphus",
		345814
	],
	[
		"s478041",
		"Ziziphus pubinervis",
		"ziziphus",
		478041
	],
	[
		"s3158343",
		"Ziziphus quadrilocularis",
		"ziziphus",
		3158343
	],
	[
		"s3755107",
		"Ziziphus ridleyana",
		"ziziphus",
		3755107
	],
	[
		"s1465382",
		"Ziziphus rignonii",
		"ziziphus",
		1465382
	],
	[
		"s992816",
		"Ziziphus rivularis",
		"ziziphus",
		992816
	],
	[
		"s3755108",
		"Ziziphus robertsoniana",
		"ziziphus",
		3755108
	],
	[
		"s2493993",
		"Ziziphus rotundifolia",
		"ziziphus",
		2493993
	],
	[
		"s3755109",
		"Ziziphus rubiginosa",
		"ziziphus",
		3755109
	],
	[
		"s345815",
		"Ziziphus rugosa",
		"ziziphus",
		345815
	],
	[
		"s264981",
		"Ziziphus spina-christi",
		"ziziphus",
		264981
	],
	[
		"s3755110",
		"Ziziphus subquinquenervia",
		"ziziphus",
		3755110
	],
	[
		"s3158347",
		"Ziziphus suluensis",
		"ziziphus",
		3158347
	],
	[
		"s3755111",
		"Ziziphus timoriensis",
		"ziziphus",
		3755111
	],
	[
		"s3755112",
		"Ziziphus trinervis",
		"ziziphus",
		3755112
	],
	[
		"s3755113",
		"Ziziphus truncata",
		"ziziphus",
		3755113
	],
	[
		"s3755114",
		"Ziziphus williamii",
		"ziziphus",
		3755114
	],
	[
		"s478043",
		"Ziziphus xiangchengensis",
		"ziziphus",
		478043
	],
	[
		"s2690205",
		"Ziziphus xylopyrus",
		"ziziphus",
		2690205
	],
	[
		"s1389781",
		"Ziziphus zeyheriana",
		"ziziphus",
		1389781
	],
	[
		"s44762",
		"Abobra tenuifolia",
		"abobra",
		44762
	],
	[
		"s387122",
		"Acanthosicyos horridus",
		"acanthosicyos",
		387122
	],
	[
		"s1635145",
		"Actinostemma lobatum",
		"actinostemma",
		1635145
	],
	[
		"s381647",
		"Actinostemma tenerum",
		"actinostemma",
		381647
	],
	[
		"s386130",
		"Alsomitra macrocarpa",
		"alsomitra",
		386130
	],
	[
		"s387132",
		"Ampelosycios bosseri",
		"ampelosycios",
		387132
	],
	[
		"s386639",
		"Ampelosycios humblotii",
		"ampelosycios",
		386639
	],
	[
		"s383673",
		"Ampelosycios leandrii",
		"ampelosycios",
		383673
	],
	[
		"s3748595",
		"Ampelosycios major",
		"ampelosycios",
		3748595
	],
	[
		"s3748596",
		"Ampelosycios meridionalis",
		"ampelosycios",
		3748596
	],
	[
		"s388286",
		"Ampelosycios scandens",
		"ampelosycios",
		388286
	],
	[
		"s3750793",
		"Anisophyllea apetala",
		"anisophyllea",
		3750793
	],
	[
		"s3750794",
		"Anisophyllea bakoensis",
		"anisophyllea",
		3750794
	],
	[
		"s3750795",
		"Anisophyllea beccariana",
		"anisophyllea",
		3750795
	],
	[
		"s1899094",
		"Anisophyllea boehmii",
		"anisophyllea",
		1899094
	],
	[
		"s3750796",
		"Anisophyllea borneensis",
		"anisophyllea",
		3750796
	],
	[
		"s3750797",
		"Anisophyllea buchneri",
		"anisophyllea",
		3750797
	],
	[
		"s3750798",
		"Anisophyllea buettneri",
		"anisophyllea",
		3750798
	],
	[
		"s3750799",
		"Anisophyllea chartacea",
		"anisophyllea",
		3750799
	],
	[
		"s328790",
		"Anisophyllea cinnamomoides",
		"anisophyllea",
		328790
	],
	[
		"s68824",
		"Anisophyllea corneri",
		"anisophyllea",
		68824
	],
	[
		"s3750800",
		"Anisophyllea curtisii",
		"anisophyllea",
		3750800
	],
	[
		"s3750801",
		"Anisophyllea dinghoui",
		"anisophyllea",
		3750801
	],
	[
		"s106631",
		"Anisophyllea disticha",
		"anisophyllea",
		106631
	],
	[
		"s3750802",
		"Anisophyllea exellii",
		"anisophyllea",
		3750802
	],
	[
		"s106632",
		"Anisophyllea fallax",
		"anisophyllea",
		106632
	],
	[
		"s2990735",
		"Anisophyllea ferruginea",
		"anisophyllea",
		2990735
	],
	[
		"s3750803",
		"Anisophyllea fissipetala",
		"anisophyllea",
		3750803
	],
	[
		"s3750804",
		"Anisophyllea glandibeccariana",
		"anisophyllea",
		3750804
	],
	[
		"s3750805",
		"Anisophyllea glandulipetiolata",
		"anisophyllea",
		3750805
	],
	[
		"s3750806",
		"Anisophyllea globosa",
		"anisophyllea",
		3750806
	],
	[
		"s3750807",
		"Anisophyllea gossweileri",
		"anisophyllea",
		3750807
	],
	[
		"s3750808",
		"Anisophyllea grandis",
		"anisophyllea",
		3750808
	],
	[
		"s3750809",
		"Anisophyllea griffithii",
		"anisophyllea",
		3750809
	],
	[
		"s3126642",
		"Anisophyllea guianensis",
		"anisophyllea",
		3126642
	],
	[
		"s3750810",
		"Anisophyllea impressinervia",
		"anisophyllea",
		3750810
	],
	[
		"s3750811",
		"Anisophyllea insularis",
		"anisophyllea",
		3750811
	],
	[
		"s3750812",
		"Anisophyllea ismailii",
		"anisophyllea",
		3750812
	],
	[
		"s2708713",
		"Anisophyllea laurina",
		"anisophyllea",
		2708713
	],
	[
		"s3750813",
		"Anisophyllea madagascarensis",
		"anisophyllea",
		3750813
	],
	[
		"s202328",
		"Anisophyllea manausensis",
		"anisophyllea",
		202328
	],
	[
		"s3750814",
		"Anisophyllea masoalensis",
		"anisophyllea",
		3750814
	],
	[
		"s328791",
		"Anisophyllea meniaudi",
		"anisophyllea",
		328791
	],
	[
		"s328792",
		"Anisophyllea myriosticta",
		"anisophyllea",
		328792
	],
	[
		"s2990736",
		"Anisophyllea nitida",
		"anisophyllea",
		2990736
	],
	[
		"s328793",
		"Anisophyllea obtusifolia",
		"anisophyllea",
		328793
	],
	[
		"s3750815",
		"Anisophyllea parafallax",
		"anisophyllea",
		3750815
	],
	[
		"s3750816",
		"Anisophyllea penninervata",
		"anisophyllea",
		3750816
	],
	[
		"s328794",
		"Anisophyllea polyneura",
		"anisophyllea",
		328794
	],
	[
		"s328795",
		"Anisophyllea pomifera",
		"anisophyllea",
		328795
	],
	[
		"s328796",
		"Anisophyllea purpurascens",
		"anisophyllea",
		328796
	],
	[
		"s3750817",
		"Anisophyllea quangensis",
		"anisophyllea",
		3750817
	],
	[
		"s3750818",
		"Anisophyllea rengamensis",
		"anisophyllea",
		3750818
	],
	[
		"s3750819",
		"Anisophyllea reticulata",
		"anisophyllea",
		3750819
	],
	[
		"s3750820",
		"Anisophyllea rhomboidea",
		"anisophyllea",
		3750820
	],
	[
		"s3750821",
		"Anisophyllea rubroglandula",
		"anisophyllea",
		3750821
	],
	[
		"s3750822",
		"Anisophyllea sabahensis",
		"anisophyllea",
		3750822
	],
	[
		"s3750823",
		"Anisophyllea sarawakensis",
		"anisophyllea",
		3750823
	],
	[
		"s3750824",
		"Anisophyllea schatzii",
		"anisophyllea",
		3750824
	],
	[
		"s3750825",
		"Anisophyllea scortechinii",
		"anisophyllea",
		3750825
	],
	[
		"s3750826",
		"Anisophyllea sessiliflora",
		"anisophyllea",
		3750826
	],
	[
		"s328797",
		"Anisophyllea sororia",
		"anisophyllea",
		328797
	],
	[
		"s3750827",
		"Anisophyllea strychnoides",
		"anisophyllea",
		3750827
	],
	[
		"s3750828",
		"Anisophyllea sumatrana",
		"anisophyllea",
		3750828
	],
	[
		"s672803",
		"Anisosperma passiflora",
		"anisosperma",
		672803
	],
	[
		"s931226",
		"Apodanthera anatuyana",
		"apodanthera",
		931226
	],
	[
		"s2894838",
		"Apodanthera argentea",
		"apodanthera",
		2894838
	],
	[
		"s2726052",
		"Apodanthera aspera",
		"apodanthera",
		2726052
	],
	[
		"s3753623",
		"Apodanthera biflora",
		"apodanthera",
		3753623
	],
	[
		"s3753624",
		"Apodanthera bradei",
		"apodanthera",
		3753624
	],
	[
		"s3753625",
		"Apodanthera cinerea",
		"apodanthera",
		3753625
	],
	[
		"s2743205",
		"Apodanthera congestiflora",
		"apodanthera",
		2743205
	],
	[
		"s3753626",
		"Apodanthera eriocalyx",
		"apodanthera",
		3753626
	],
	[
		"s3753627",
		"Apodanthera fasciculata",
		"apodanthera",
		3753627
	],
	[
		"s3083826",
		"Apodanthera ferreyrana",
		"apodanthera",
		3083826
	],
	[
		"s2743206",
		"Apodanthera glaziovii",
		"apodanthera",
		2743206
	],
	[
		"s3753628",
		"Apodanthera hindii",
		"apodanthera",
		3753628
	],
	[
		"s3753629",
		"Apodanthera hirtella",
		"apodanthera",
		3753629
	],
	[
		"s3753630",
		"Apodanthera laciniosa",
		"apodanthera",
		3753630
	],
	[
		"s3753631",
		"Apodanthera linearis",
		"apodanthera",
		3753631
	],
	[
		"s386176",
		"Apodanthera longipedicellata",
		"apodanthera",
		386176
	],
	[
		"s386136",
		"Apodanthera mandonii",
		"apodanthera",
		386136
	],
	[
		"s3083827",
		"Apodanthera palmeri",
		"apodanthera",
		3083827
	],
	[
		"s515852",
		"Apodanthera sagittifolia",
		"apodanthera",
		515852
	],
	[
		"s3753632",
		"Apodanthera tumbeziana",
		"apodanthera",
		3753632
	],
	[
		"s3753633",
		"Apodanthera ulei",
		"apodanthera",
		3753633
	],
	[
		"s3083828",
		"Apodanthera undulata",
		"apodanthera",
		3083828
	],
	[
		"s2894839",
		"Apodanthera villosa",
		"apodanthera",
		2894839
	],
	[
		"s3753634",
		"Apodanthera weberbaueri",
		"apodanthera",
		3753634
	],
	[
		"s301892",
		"Apodanthes caseariae",
		"apodanthes",
		301892
	],
	[
		"s452817",
		"Austrobryonia argillicola",
		"austrobryonia",
		452817
	],
	[
		"s452818",
		"Austrobryonia centralis",
		"austrobryonia",
		452818
	],
	[
		"s452819",
		"Austrobryonia micrantha",
		"austrobryonia",
		452819
	],
	[
		"s452820",
		"Austrobryonia pilbarensis",
		"austrobryonia",
		452820
	],
	[
		"s381649",
		"Baijiania borneensis",
		"baijiania",
		381649
	],
	[
		"s2726053",
		"Baijiania taiwaniana",
		"baijiania",
		2726053
	],
	[
		"s386138",
		"Bambekea racemosa",
		"bambekea",
		386138
	],
	[
		"s387124",
		"Bayabusua clarkei",
		"bayabusua",
		387124
	],
	[
		"s1979616",
		"Begonia abdullahpieei",
		"begonia",
		1979616
	],
	[
		"s2099525",
		"Begonia aberrans",
		"begonia",
		2099525
	],
	[
		"s1979617",
		"Begonia aborensis",
		"begonia",
		1979617
	],
	[
		"s3732620",
		"Begonia absiana",
		"begonia",
		3732620
	],
	[
		"s2093550",
		"Begonia acclivis",
		"begonia",
		2093550
	],
	[
		"s1979618",
		"Begonia acerifolia",
		"begonia",
		1979618
	],
	[
		"s1051755",
		"Begonia aceroides",
		"begonia",
		1051755
	],
	[
		"s1683985",
		"Begonia acetosa",
		"begonia",
		1683985
	],
	[
		"s172090",
		"Begonia acetosella",
		"begonia",
		172090
	],
	[
		"s1683986",
		"Begonia acida",
		"begonia",
		1683986
	],
	[
		"s1683987",
		"Begonia aconitifolia",
		"begonia",
		1683987
	],
	[
		"s1671947",
		"Begonia acuminatissima",
		"begonia",
		1671947
	],
	[
		"s212815",
		"Begonia acutifolia",
		"begonia",
		212815
	],
	[
		"s198545",
		"Begonia aequata",
		"begonia",
		198545
	],
	[
		"s3084489",
		"Begonia aequatorialis",
		"begonia",
		3084489
	],
	[
		"s3706504",
		"Begonia afromigrata",
		"begonia",
		3706504
	],
	[
		"s3084490",
		"Begonia aggeloptera",
		"begonia",
		3084490
	],
	[
		"s1977235",
		"Begonia alabensis",
		"begonia",
		1977235
	],
	[
		"s3084491",
		"Begonia alba",
		"begonia",
		3084491
	],
	[
		"s1671948",
		"Begonia albococcinea",
		"begonia",
		1671948
	],
	[
		"s1979619",
		"Begonia albomaculata",
		"begonia",
		1979619
	],
	[
		"s3084492",
		"Begonia albopicta",
		"begonia",
		3084492
	],
	[
		"s1683990",
		"Begonia alice-clarkiae",
		"begonia",
		1683990
	],
	[
		"s1051756",
		"Begonia alicida",
		"begonia",
		1051756
	],
	[
		"s1979620",
		"Begonia almedana",
		"begonia",
		1979620
	],
	[
		"s294963",
		"Begonia alpina",
		"begonia",
		294963
	],
	[
		"s1979621",
		"Begonia altoperuviana",
		"begonia",
		1979621
	],
	[
		"s172092",
		"Begonia alveolata",
		"begonia",
		172092
	],
	[
		"s3018801",
		"Begonia amoeboides",
		"begonia",
		3018801
	],
	[
		"s3861958",
		"Begonia amparoae",
		"begonia",
		3861958
	],
	[
		"s199983",
		"Begonia amphioxus",
		"begonia",
		199983
	],
	[
		"s234366",
		"Begonia ampla",
		"begonia",
		234366
	],
	[
		"s1979622",
		"Begonia anemoniflora",
		"begonia",
		1979622
	],
	[
		"s189378",
		"Begonia angularis",
		"begonia",
		189378
	],
	[
		"s3084493",
		"Begonia angulata",
		"begonia",
		3084493
	],
	[
		"s1979623",
		"Begonia angustifolia",
		"begonia",
		1979623
	],
	[
		"s1354279",
		"Begonia anisoptera",
		"begonia",
		1354279
	],
	[
		"s3018802",
		"Begonia anisosepala",
		"begonia",
		3018802
	],
	[
		"s198546",
		"Begonia ankaranensis",
		"begonia",
		198546
	],
	[
		"s198547",
		"Begonia annobonensis",
		"begonia",
		198547
	],
	[
		"s199984",
		"Begonia annulata",
		"begonia",
		199984
	],
	[
		"s1406257",
		"Begonia anthonyi",
		"begonia",
		1406257
	],
	[
		"s1977201",
		"Begonia antongilensis",
		"begonia",
		1977201
	],
	[
		"s71278",
		"Begonia aptera",
		"begonia",
		71278
	],
	[
		"s1406249",
		"Begonia arachnoidea",
		"begonia",
		1406249
	],
	[
		"s3880207",
		"Begonia araneumoides",
		"begonia",
		3880207
	],
	[
		"s1683991",
		"Begonia arborescens",
		"begonia",
		1683991
	],
	[
		"s1691892",
		"Begonia arboreta",
		"begonia",
		1691892
	],
	[
		"s1069550",
		"Begonia areolata",
		"begonia",
		1069550
	],
	[
		"s1979624",
		"Begonia arfakensis",
		"begonia",
		1979624
	],
	[
		"s1069551",
		"Begonia argenteomarginata",
		"begonia",
		1069551
	],
	[
		"s1979625",
		"Begonia arrogans",
		"begonia",
		1979625
	],
	[
		"s3148871",
		"Begonia asperifolia",
		"begonia",
		3148871
	],
	[
		"s198548",
		"Begonia aspleniifolia",
		"begonia",
		198548
	],
	[
		"s2489288",
		"Begonia asteropyrifolia",
		"begonia",
		2489288
	],
	[
		"s1051757",
		"Begonia atricha",
		"begonia",
		1051757
	],
	[
		"s2936858",
		"Begonia atrofusca",
		"begonia",
		2936858
	],
	[
		"s1979626",
		"Begonia augustae",
		"begonia",
		1979626
	],
	[
		"s702303",
		"Begonia augustinei",
		"begonia",
		702303
	],
	[
		"s2953633",
		"Begonia aurantiflora",
		"begonia",
		2953633
	],
	[
		"s1406250",
		"Begonia auritistipula",
		"begonia",
		1406250
	],
	[
		"s1406251",
		"Begonia austroguangxiensis",
		"begonia",
		1406251
	],
	[
		"s146768",
		"Begonia austrotaiwanensis",
		"begonia",
		146768
	],
	[
		"s234367",
		"Begonia baccata",
		"begonia",
		234367
	],
	[
		"s2716965",
		"Begonia bahiensis",
		"begonia",
		2716965
	],
	[
		"s1977236",
		"Begonia baik",
		"begonia",
		1977236
	],
	[
		"s2086441",
		"Begonia balangcodiae",
		"begonia",
		2086441
	],
	[
		"s198549",
		"Begonia balansana",
		"begonia",
		198549
	],
	[
		"s3020251",
		"Begonia baliensis",
		"begonia",
		3020251
	],
	[
		"s3084494",
		"Begonia balmisiana",
		"begonia",
		3084494
	],
	[
		"s1406252",
		"Begonia bamaensis",
		"begonia",
		1406252
	],
	[
		"s3084495",
		"Begonia banaoensis",
		"begonia",
		3084495
	],
	[
		"s3084496",
		"Begonia bangii",
		"begonia",
		3084496
	],
	[
		"s1979627",
		"Begonia baramensis",
		"begonia",
		1979627
	],
	[
		"s1977202",
		"Begonia barbellata",
		"begonia",
		1977202
	],
	[
		"s1683988",
		"Begonia barkeri",
		"begonia",
		1683988
	],
	[
		"s1977203",
		"Begonia barkleyana",
		"begonia",
		1977203
	],
	[
		"s1406253",
		"Begonia bataiensis",
		"begonia",
		1406253
	],
	[
		"s443338",
		"Begonia baviensis",
		"begonia",
		443338
	],
	[
		"s3084497",
		"Begonia beccariana",
		"begonia",
		3084497
	],
	[
		"s199985",
		"Begonia beddomei",
		"begonia",
		199985
	],
	[
		"s1979594",
		"Begonia beludruvenea",
		"begonia",
		1979594
	],
	[
		"s1406254",
		"Begonia berhamanii",
		"begonia",
		1406254
	],
	[
		"s3084498",
		"Begonia bernicei",
		"begonia",
		3084498
	],
	[
		"s1659824",
		"Begonia beryllae",
		"begonia",
		1659824
	],
	[
		"s234368",
		"Begonia betsimisaraka",
		"begonia",
		234368
	],
	[
		"s3084499",
		"Begonia bettinae",
		"begonia",
		3084499
	],
	[
		"s3084500",
		"Begonia bidentata",
		"begonia",
		3084500
	],
	[
		"s1045238",
		"Begonia biflora",
		"begonia",
		1045238
	],
	[
		"s1974347",
		"Begonia bifurcata",
		"begonia",
		1974347
	],
	[
		"s1671949",
		"Begonia biliranensis",
		"begonia",
		1671949
	],
	[
		"s1406255",
		"Begonia bipinnatifida",
		"begonia",
		1406255
	],
	[
		"s3084501",
		"Begonia biserrata",
		"begonia",
		3084501
	],
	[
		"s890403",
		"Begonia bissei",
		"begonia",
		890403
	],
	[
		"s1671950",
		"Begonia blancii",
		"begonia",
		1671950
	],
	[
		"s199986",
		"Begonia bogneri",
		"begonia",
		199986
	],
	[
		"s62973",
		"Begonia boisiana",
		"begonia",
		62973
	],
	[
		"s3084502",
		"Begonia boissieri",
		"begonia",
		3084502
	],
	[
		"s3128555",
		"Begonia boiviniana",
		"begonia",
		3128555
	],
	[
		"s199987",
		"Begonia boliviensis",
		"begonia",
		199987
	],
	[
		"s2866704",
		"Begonia boliviensis x Begonia micranthera",
		"begonia",
		2866704
	],
	[
		"s3026388",
		"Begonia boliviensis x Begonia micranthera var. flava",
		"begonia",
		3026388
	],
	[
		"s3084503",
		"Begonia bolleana",
		"begonia",
		3084503
	],
	[
		"s1406256",
		"Begonia bolsteri",
		"begonia",
		1406256
	],
	[
		"s1671951",
		"Begonia bonthainensis",
		"begonia",
		1671951
	],
	[
		"s234369",
		"Begonia bonus-henricus",
		"begonia",
		234369
	],
	[
		"s1979628",
		"Begonia boquetensis",
		"begonia",
		1979628
	],
	[
		"s2184938",
		"Begonia botryoides",
		"begonia",
		2184938
	],
	[
		"s662553",
		"Begonia bowerae",
		"begonia",
		662553
	],
	[
		"s3084504",
		"Begonia brachypoda",
		"begonia",
		3084504
	],
	[
		"s1683993",
		"Begonia bracteata",
		"begonia",
		1683993
	],
	[
		"s1977204",
		"Begonia bracteosa",
		"begonia",
		1977204
	],
	[
		"s1683994",
		"Begonia bradei",
		"begonia",
		1683994
	],
	[
		"s1069552",
		"Begonia brandisiana",
		"begonia",
		1069552
	],
	[
		"s1683995",
		"Begonia breedlovei",
		"begonia",
		1683995
	],
	[
		"s1979629",
		"Begonia brevicordata",
		"begonia",
		1979629
	],
	[
		"s1051758",
		"Begonia brevipes",
		"begonia",
		1051758
	],
	[
		"s199988",
		"Begonia brevirimosa",
		"begonia",
		199988
	],
	[
		"s1979630",
		"Begonia broussonetiifolia",
		"begonia",
		1979630
	],
	[
		"s1979631",
		"Begonia bruneiana",
		"begonia",
		1979631
	],
	[
		"s3693804",
		"Begonia brunneosquamata",
		"begonia",
		3693804
	],
	[
		"s1080397",
		"Begonia bryophila (nom. ined.)",
		"begonia",
		1080397
	],
	[
		"s1974348",
		"Begonia buddleiifolia",
		"begonia",
		1974348
	],
	[
		"s1979632",
		"Begonia bufoderma",
		"begonia",
		1979632
	],
	[
		"s1974349",
		"Begonia bullatifolia",
		"begonia",
		1974349
	],
	[
		"s1051759",
		"Begonia burbidgei",
		"begonia",
		1051759
	],
	[
		"s1354280",
		"Begonia calcicola",
		"begonia",
		1354280
	],
	[
		"s1979633",
		"Begonia calderonii",
		"begonia",
		1979633
	],
	[
		"s1979634",
		"Begonia callosa",
		"begonia",
		1979634
	],
	[
		"s1979635",
		"Begonia calzadae",
		"begonia",
		1979635
	],
	[
		"s1354281",
		"Begonia camiguinensis",
		"begonia",
		1354281
	],
	[
		"s1683996",
		"Begonia capanemae",
		"begonia",
		1683996
	],
	[
		"s1979636",
		"Begonia capensis",
		"begonia",
		1979636
	],
	[
		"s198550",
		"Begonia capillipes",
		"begonia",
		198550
	],
	[
		"s1127536",
		"Begonia capituliformis",
		"begonia",
		1127536
	],
	[
		"s1475374",
		"Begonia cardiocarpa",
		"begonia",
		1475374
	],
	[
		"s3084505",
		"Begonia carletonii",
		"begonia",
		3084505
	],
	[
		"s1683997",
		"Begonia caroliniifolia",
		"begonia",
		1683997
	],
	[
		"s1683998",
		"Begonia carrieae",
		"begonia",
		1683998
	],
	[
		"s3084506",
		"Begonia casiguranensis",
		"begonia",
		3084506
	],
	[
		"s1671952",
		"Begonia castilloi",
		"begonia",
		1671952
	],
	[
		"s1979637",
		"Begonia catharinensis",
		"begonia",
		1979637
	],
	[
		"s161527",
		"Begonia cathayana",
		"begonia",
		161527
	],
	[
		"s1979638",
		"Begonia cathcartii",
		"begonia",
		1979638
	],
	[
		"s1659829",
		"Begonia cauliflora",
		"begonia",
		1659829
	],
	[
		"s694480",
		"Begonia cavaleriei",
		"begonia",
		694480
	],
	[
		"s234370",
		"Begonia cavallyensis",
		"begonia",
		234370
	],
	[
		"s3084507",
		"Begonia cebadillensis",
		"begonia",
		3084507
	],
	[
		"s172093",
		"Begonia ceratocarpa",
		"begonia",
		172093
	],
	[
		"s3084508",
		"Begonia chaetocarpa",
		"begonia",
		3084508
	],
	[
		"s2184939",
		"Begonia chemillenensis",
		"begonia",
		2184939
	],
	[
		"s1051760",
		"Begonia chiasmogyna",
		"begonia",
		1051760
	],
	[
		"s1406259",
		"Begonia chingii",
		"begonia",
		1406259
	],
	[
		"s1671953",
		"Begonia chingipengii",
		"begonia",
		1671953
	],
	[
		"s78254",
		"Begonia chitoensis",
		"begonia",
		78254
	],
	[
		"s1777872",
		"Begonia chitoensis x Begonia longifolia",
		"begonia",
		1777872
	],
	[
		"s1979639",
		"Begonia chlorolepis",
		"begonia",
		1979639
	],
	[
		"s199989",
		"Begonia chloroneura",
		"begonia",
		199989
	],
	[
		"s199990",
		"Begonia chlorosticta",
		"begonia",
		199990
	],
	[
		"s3436155",
		"Begonia chongzuoensis",
		"begonia",
		3436155
	],
	[
		"s1979640",
		"Begonia chrysantha",
		"begonia",
		1979640
	],
	[
		"s3699225",
		"Begonia ciliobracteata",
		"begonia",
		3699225
	],
	[
		"s199991",
		"Begonia cinnabarina",
		"begonia",
		199991
	],
	[
		"s294964",
		"Begonia circumlobata",
		"begonia",
		294964
	],
	[
		"s172094",
		"Begonia cirrosa",
		"begonia",
		172094
	],
	[
		"s1974350",
		"Begonia clarkei",
		"begonia",
		1974350
	],
	[
		"s1069553",
		"Begonia cleopatrae",
		"begonia",
		1069553
	],
	[
		"s1683999",
		"Begonia coccinea",
		"begonia",
		1683999
	],
	[
		"s3732616",
		"Begonia collisiae",
		"begonia",
		3732616
	],
	[
		"s1979641",
		"Begonia colombiana",
		"begonia",
		1979641
	],
	[
		"s1127537",
		"Begonia comestibilis",
		"begonia",
		1127537
	],
	[
		"s234371",
		"Begonia comorensis",
		"begonia",
		234371
	],
	[
		"s212713",
		"Begonia conchifolia",
		"begonia",
		212713
	],
	[
		"s3084509",
		"Begonia confinis",
		"begonia",
		3084509
	],
	[
		"s1127530",
		"Begonia congesta",
		"begonia",
		1127530
	],
	[
		"s1979642",
		"Begonia consobrina",
		"begonia",
		1979642
	],
	[
		"s1406260",
		"Begonia contracta",
		"begonia",
		1406260
	],
	[
		"s1979643",
		"Begonia convallariodora",
		"begonia",
		1979643
	],
	[
		"s198551",
		"Begonia convolvulacea",
		"begonia",
		198551
	],
	[
		"s1684000",
		"Begonia cooperi",
		"begonia",
		1684e3
	],
	[
		"s1605914",
		"Begonia copelandii",
		"begonia",
		1605914
	],
	[
		"s1979644",
		"Begonia copeyana",
		"begonia",
		1979644
	],
	[
		"s1691893",
		"Begonia coptidifolia",
		"begonia",
		1691893
	],
	[
		"s2184940",
		"Begonia corallina",
		"begonia",
		2184940
	],
	[
		"s3084510",
		"Begonia cordifolia",
		"begonia",
		3084510
	],
	[
		"s1977205",
		"Begonia cornitepala",
		"begonia",
		1977205
	],
	[
		"s2592822",
		"Begonia cornuta",
		"begonia",
		2592822
	],
	[
		"s1354282",
		"Begonia coronensis",
		"begonia",
		1354282
	],
	[
		"s2184941",
		"Begonia corredorana",
		"begonia",
		2184941
	],
	[
		"s1069554",
		"Begonia corrugata",
		"begonia",
		1069554
	],
	[
		"s1979645",
		"Begonia coursii",
		"begonia",
		1979645
	],
	[
		"s3084511",
		"Begonia cowellii",
		"begonia",
		3084511
	],
	[
		"s212714",
		"Begonia crassicaulis",
		"begonia",
		212714
	],
	[
		"s1684001",
		"Begonia crassipes",
		"begonia",
		1684001
	],
	[
		"s146770",
		"Begonia crassirostris",
		"begonia",
		146770
	],
	[
		"s1974351",
		"Begonia cremnophila",
		"begonia",
		1974351
	],
	[
		"s1051761",
		"Begonia crispipila",
		"begonia",
		1051761
	],
	[
		"s1684002",
		"Begonia crispula",
		"begonia",
		1684002
	],
	[
		"s2907290",
		"Begonia cristobalensis",
		"begonia",
		2907290
	],
	[
		"s1979646",
		"Begonia croatii",
		"begonia",
		1979646
	],
	[
		"s3084512",
		"Begonia cryptocarpa",
		"begonia",
		3084512
	],
	[
		"s1045240",
		"Begonia crystallina",
		"begonia",
		1045240
	],
	[
		"s199992",
		"Begonia cubensis",
		"begonia",
		199992
	],
	[
		"s1977206",
		"Begonia cucphuongensis",
		"begonia",
		1977206
	],
	[
		"s473040",
		"Begonia cucullata",
		"begonia",
		473040
	],
	[
		"s1045241",
		"Begonia cucurbitifolia",
		"begonia",
		1045241
	],
	[
		"s1671938",
		"Begonia culasiensis",
		"begonia",
		1671938
	],
	[
		"s3084513",
		"Begonia cumingiana",
		"begonia",
		3084513
	],
	[
		"s1977207",
		"Begonia curtii",
		"begonia",
		1977207
	],
	[
		"s2605952",
		"Begonia curvicarpa",
		"begonia",
		2605952
	],
	[
		"s1979647",
		"Begonia cyanescens",
		"begonia",
		1979647
	],
	[
		"s1684003",
		"Begonia cyathophora",
		"begonia",
		1684003
	],
	[
		"s1045242",
		"Begonia cylindrica",
		"begonia",
		1045242
	],
	[
		"s2993661",
		"Begonia dalaiensis",
		"begonia",
		2993661
	],
	[
		"s2583036",
		"Begonia danxiaensis",
		"begonia",
		2583036
	],
	[
		"s2905994",
		"Begonia darthvaderiana",
		"begonia",
		2905994
	],
	[
		"s1045243",
		"Begonia daweishanensis",
		"begonia",
		1045243
	],
	[
		"s1045244",
		"Begonia daxinensis",
		"begonia",
		1045244
	],
	[
		"s3084514",
		"Begonia decandra",
		"begonia",
		3084514
	],
	[
		"s1069555",
		"Begonia decora",
		"begonia",
		1069555
	],
	[
		"s199993",
		"Begonia deliciosa",
		"begonia",
		199993
	],
	[
		"s1051762",
		"Begonia demissa",
		"begonia",
		1051762
	],
	[
		"s1684004",
		"Begonia dentatiloba",
		"begonia",
		1684004
	],
	[
		"s3018803",
		"Begonia depauperata",
		"begonia",
		3018803
	],
	[
		"s1979648",
		"Begonia descoleana",
		"begonia",
		1979648
	],
	[
		"s198552",
		"Begonia dewildei",
		"begonia",
		198552
	],
	[
		"s199994",
		"Begonia diadema",
		"begonia",
		199994
	],
	[
		"s1684005",
		"Begonia dichotoma",
		"begonia",
		1684005
	],
	[
		"s1684006",
		"Begonia dichroa",
		"begonia",
		1684006
	],
	[
		"s2936861",
		"Begonia dicressine",
		"begonia",
		2936861
	],
	[
		"s1127531",
		"Begonia didyma",
		"begonia",
		1127531
	],
	[
		"s1691894",
		"Begonia dielsiana",
		"begonia",
		1691894
	],
	[
		"s1684007",
		"Begonia dietrichiana",
		"begonia",
		1684007
	],
	[
		"s2936862",
		"Begonia difformis",
		"begonia",
		2936862
	],
	[
		"s3084515",
		"Begonia diffusa",
		"begonia",
		3084515
	],
	[
		"s1979649",
		"Begonia digitata",
		"begonia",
		1979649
	],
	[
		"s3695051",
		"Begonia digyna",
		"begonia",
		3695051
	],
	[
		"s1051763",
		"Begonia dioica",
		"begonia",
		1051763
	],
	[
		"s198423",
		"Begonia dipetala",
		"begonia",
		198423
	],
	[
		"s1051764",
		"Begonia discreta",
		"begonia",
		1051764
	],
	[
		"s2099526",
		"Begonia divaricata",
		"begonia",
		2099526
	],
	[
		"s1977237",
		"Begonia dolichocarpa",
		"begonia",
		1977237
	],
	[
		"s1977238",
		"Begonia doloisii",
		"begonia",
		1977238
	],
	[
		"s1977208",
		"Begonia domingensis",
		"begonia",
		1977208
	],
	[
		"s1684008",
		"Begonia dominicalis",
		"begonia",
		1684008
	],
	[
		"s198424",
		"Begonia dregei",
		"begonia",
		198424
	],
	[
		"s1979595",
		"Begonia droopiae",
		"begonia",
		1979595
	],
	[
		"s1406261",
		"Begonia dryadis",
		"begonia",
		1406261
	],
	[
		"s199995",
		"Begonia duncan-thomasii",
		"begonia",
		199995
	],
	[
		"s1979650",
		"Begonia dux",
		"begonia",
		1979650
	],
	[
		"s234372",
		"Begonia ebolowensis",
		"begonia",
		234372
	],
	[
		"s199996",
		"Begonia echinosepala",
		"begonia",
		199996
	],
	[
		"s199997",
		"Begonia edmundoi",
		"begonia",
		199997
	],
	[
		"s694481",
		"Begonia edulis",
		"begonia",
		694481
	],
	[
		"s199998",
		"Begonia egregia",
		"begonia",
		199998
	],
	[
		"s1974364",
		"Begonia elachista",
		"begonia",
		1974364
	],
	[
		"s234373",
		"Begonia elaeagnifolia",
		"begonia",
		234373
	],
	[
		"s3084516",
		"Begonia elatostemmoides",
		"begonia",
		3084516
	],
	[
		"s1069556",
		"Begonia elisabethae",
		"begonia",
		1069556
	],
	[
		"s1354283",
		"Begonia elmeri",
		"begonia",
		1354283
	],
	[
		"s1671940",
		"Begonia elnidoensis",
		"begonia",
		1671940
	],
	[
		"s1691895",
		"Begonia emeiensis",
		"begonia",
		1691895
	],
	[
		"s234374",
		"Begonia eminii",
		"begonia",
		234374
	],
	[
		"s198553",
		"Begonia engleri",
		"begonia",
		198553
	],
	[
		"s2716966",
		"Begonia epibaterium",
		"begonia",
		2716966
	],
	[
		"s1684009",
		"Begonia epipsila",
		"begonia",
		1684009
	],
	[
		"s3084517",
		"Begonia erectotricha",
		"begonia",
		3084517
	],
	[
		"s1979651",
		"Begonia erythrocarpa",
		"begonia",
		1979651
	],
	[
		"s1406262",
		"Begonia erythrogyna",
		"begonia",
		1406262
	],
	[
		"s3084518",
		"Begonia euryphylla",
		"begonia",
		3084518
	],
	[
		"s3084519",
		"Begonia everettii",
		"begonia",
		3084519
	],
	[
		"s1979652",
		"Begonia exigua",
		"begonia",
		1979652
	],
	[
		"s3084520",
		"Begonia exilis",
		"begonia",
		3084520
	],
	[
		"s3084521",
		"Begonia extranea",
		"begonia",
		3084521
	],
	[
		"s1045245",
		"Begonia fagifolia",
		"begonia",
		1045245
	],
	[
		"s3084522",
		"Begonia falciloba",
		"begonia",
		3084522
	],
	[
		"s198554",
		"Begonia fallax",
		"begonia",
		198554
	],
	[
		"s1045246",
		"Begonia fangii",
		"begonia",
		1045246
	],
	[
		"s3084523",
		"Begonia faustinoi",
		"begonia",
		3084523
	],
	[
		"s146767",
		"Begonia fenicis",
		"begonia",
		146767
	],
	[
		"s2824002",
		"Begonia fenshuilingensis",
		"begonia",
		2824002
	],
	[
		"s2974069",
		"Begonia ferox",
		"begonia",
		2974069
	],
	[
		"s1979653",
		"Begonia ferruginea",
		"begonia",
		1979653
	],
	[
		"s3084524",
		"Begonia fiebrigii",
		"begonia",
		3084524
	],
	[
		"s1045247",
		"Begonia filiformis",
		"begonia",
		1045247
	],
	[
		"s1979654",
		"Begonia filipes",
		"begonia",
		1979654
	],
	[
		"s3084525",
		"Begonia fimbriata",
		"begonia",
		3084525
	],
	[
		"s1406263",
		"Begonia fimbristipula",
		"begonia",
		1406263
	],
	[
		"s1977209",
		"Begonia fischeri",
		"begonia",
		1977209
	],
	[
		"s199999",
		"Begonia fissistyla",
		"begonia",
		199999
	],
	[
		"s1127538",
		"Begonia flacca",
		"begonia",
		1127538
	],
	[
		"s1051765",
		"Begonia flagellaris",
		"begonia",
		1051765
	],
	[
		"s198426",
		"Begonia floccifera",
		"begonia",
		198426
	],
	[
		"s1684010",
		"Begonia fluminensis",
		"begonia",
		1684010
	],
	[
		"s1979596",
		"Begonia fluvialis",
		"begonia",
		1979596
	],
	[
		"s200000",
		"Begonia foliosa",
		"begonia",
		2e5
	],
	[
		"s1354284",
		"Begonia forbesii",
		"begonia",
		1354284
	],
	[
		"s80370",
		"Begonia formosana",
		"begonia",
		80370
	],
	[
		"s99385",
		"Begonia formosana x Begonia aptera",
		"begonia",
		99385
	],
	[
		"s3084526",
		"Begonia formosissima",
		"begonia",
		3084526
	],
	[
		"s1354296",
		"Begonia foxworthyi",
		"begonia",
		1354296
	],
	[
		"s198555",
		"Begonia francoisii",
		"begonia",
		198555
	],
	[
		"s1979655",
		"Begonia friburgensis",
		"begonia",
		1979655
	],
	[
		"s1974352",
		"Begonia froebelii",
		"begonia",
		1974352
	],
	[
		"s1979656",
		"Begonia fruticosa",
		"begonia",
		1979656
	],
	[
		"s200001",
		"Begonia fuchsioides",
		"begonia",
		200001
	],
	[
		"s1974353",
		"Begonia fulvosetulosa",
		"begonia",
		1974353
	],
	[
		"s234375",
		"Begonia furfuracea",
		"begonia",
		234375
	],
	[
		"s1441982",
		"Begonia fusca",
		"begonia",
		1441982
	],
	[
		"s1406264",
		"Begonia fuscisetosa",
		"begonia",
		1406264
	],
	[
		"s234376",
		"Begonia fusialata",
		"begonia",
		234376
	],
	[
		"s1671941",
		"Begonia gabaldonensis",
		"begonia",
		1671941
	],
	[
		"s200002",
		"Begonia gabonensis",
		"begonia",
		200002
	],
	[
		"s1977239",
		"Begonia galeolepis",
		"begonia",
		1977239
	],
	[
		"s1977210",
		"Begonia gamolepis",
		"begonia",
		1977210
	],
	[
		"s1979657",
		"Begonia garagarana",
		"begonia",
		1979657
	],
	[
		"s1979658",
		"Begonia gardneri",
		"begonia",
		1979658
	],
	[
		"s1684011",
		"Begonia gehrtii",
		"begonia",
		1684011
	],
	[
		"s1974354",
		"Begonia geraniifolia",
		"begonia",
		1974354
	],
	[
		"s198427",
		"Begonia geranioides",
		"begonia",
		198427
	],
	[
		"s1977211",
		"Begonia germaineana",
		"begonia",
		1977211
	],
	[
		"s3372910",
		"Begonia gesneriifolia",
		"begonia",
		3372910
	],
	[
		"s1979659",
		"Begonia gesnerioides",
		"begonia",
		1979659
	],
	[
		"s1979660",
		"Begonia gigabracteata",
		"begonia",
		1979660
	],
	[
		"s2815986",
		"Begonia giganticaulis",
		"begonia",
		2815986
	],
	[
		"s2093552",
		"Begonia gironellae",
		"begonia",
		2093552
	],
	[
		"s1671954",
		"Begonia gitingensis",
		"begonia",
		1671954
	],
	[
		"s62974",
		"Begonia glabra",
		"begonia",
		62974
	],
	[
		"s1974355",
		"Begonia glandulifera",
		"begonia",
		1974355
	],
	[
		"s2899626",
		"Begonia glandulosa",
		"begonia",
		2899626
	],
	[
		"s200003",
		"Begonia goegoensis",
		"begonia",
		200003
	],
	[
		"s2716927",
		"Begonia goldingiana",
		"begonia",
		2716927
	],
	[
		"s234377",
		"Begonia goudotii",
		"begonia",
		234377
	],
	[
		"s2099527",
		"Begonia gracilicyma",
		"begonia",
		2099527
	],
	[
		"s200004",
		"Begonia gracilis",
		"begonia",
		200004
	],
	[
		"s79767",
		"Begonia grandis",
		"begonia",
		79767
	],
	[
		"s1968121",
		"Begonia griffithiana",
		"begonia",
		1968121
	],
	[
		"s1979661",
		"Begonia grisea",
		"begonia",
		1979661
	],
	[
		"s200005",
		"Begonia guaduensis",
		"begonia",
		200005
	],
	[
		"s3435973",
		"Begonia guangdongensis",
		"begonia",
		3435973
	],
	[
		"s1045248",
		"Begonia guangxiensis",
		"begonia",
		1045248
	],
	[
		"s1354285",
		"Begonia gueritziana",
		"begonia",
		1354285
	],
	[
		"s1406285",
		"Begonia guixiensis",
		"begonia",
		1406285
	],
	[
		"s2878119",
		"Begonia gulongshanensis",
		"begonia",
		2878119
	],
	[
		"s3084527",
		"Begonia gungshanensis",
		"begonia",
		3084527
	],
	[
		"s1671955",
		"Begonia gutierrezii",
		"begonia",
		1671955
	],
	[
		"s1069557",
		"Begonia guttapila",
		"begonia",
		1069557
	],
	[
		"s1406266",
		"Begonia hainanensis",
		"begonia",
		1406266
	],
	[
		"s200006",
		"Begonia halconensis",
		"begonia",
		200006
	],
	[
		"s172095",
		"Begonia handelii",
		"begonia",
		172095
	],
	[
		"s3779307",
		"Begonia handibadaganathensis",
		"begonia",
		3779307
	],
	[
		"s2099528",
		"Begonia harauensis",
		"begonia",
		2099528
	],
	[
		"s3084528",
		"Begonia harlingii",
		"begonia",
		3084528
	],
	[
		"s200007",
		"Begonia hatacoa",
		"begonia",
		200007
	],
	[
		"s1127539",
		"Begonia hekensis",
		"begonia",
		1127539
	],
	[
		"s1045249",
		"Begonia hekouensis",
		"begonia",
		1045249
	],
	[
		"s1979597",
		"Begonia heliantha",
		"begonia",
		1979597
	],
	[
		"s200008",
		"Begonia hemsleyana",
		"begonia",
		200008
	],
	[
		"s1535199",
		"Begonia hemsleyana x Begonia macrotoma",
		"begonia",
		1535199
	],
	[
		"s1977212",
		"Begonia henrilaportei",
		"begonia",
		1977212
	],
	[
		"s172097",
		"Begonia henryi",
		"begonia",
		172097
	],
	[
		"s200009",
		"Begonia heracleifolia",
		"begonia",
		200009
	],
	[
		"s48227",
		"Begonia herbacea",
		"begonia",
		48227
	],
	[
		"s1069558",
		"Begonia hernandioides",
		"begonia",
		1069558
	],
	[
		"s1979662",
		"Begonia heydei",
		"begonia",
		1979662
	],
	[
		"s234378",
		"Begonia hirsutula",
		"begonia",
		234378
	],
	[
		"s3084529",
		"Begonia hirta",
		"begonia",
		3084529
	],
	[
		"s1977213",
		"Begonia hirtella",
		"begonia",
		1977213
	],
	[
		"s1684012",
		"Begonia hispida",
		"begonia",
		1684012
	],
	[
		"s1127540",
		"Begonia hispidissima",
		"begonia",
		1127540
	],
	[
		"s2184942",
		"Begonia hitchcockii",
		"begonia",
		2184942
	],
	[
		"s1979663",
		"Begonia hoehneana",
		"begonia",
		1979663
	],
	[
		"s198556",
		"Begonia holtonis",
		"begonia",
		198556
	],
	[
		"s1977214",
		"Begonia holttumii",
		"begonia",
		1977214
	],
	[
		"s234379",
		"Begonia homonyma",
		"begonia",
		234379
	],
	[
		"s1979664",
		"Begonia hookeriana",
		"begonia",
		1979664
	],
	[
		"s200010",
		"Begonia horticola",
		"begonia",
		200010
	],
	[
		"s1045250",
		"Begonia huangii",
		"begonia",
		1045250
	],
	[
		"s1977215",
		"Begonia huegelii",
		"begonia",
		1977215
	],
	[
		"s1671942",
		"Begonia hughesii",
		"begonia",
		1671942
	],
	[
		"s1979665",
		"Begonia humbertii",
		"begonia",
		1979665
	],
	[
		"s1979666",
		"Begonia humilis",
		"begonia",
		1979666
	],
	[
		"s255344",
		"Begonia hybrid cultivar",
		"begonia",
		255344
	],
	[
		"s1684014",
		"Begonia hydrocotylifolia",
		"begonia",
		1684014
	],
	[
		"s1069559",
		"Begonia hymenophylla",
		"begonia",
		1069559
	],
	[
		"s3084530",
		"Begonia ignea",
		"begonia",
		3084530
	],
	[
		"s1671956",
		"Begonia ignorata",
		"begonia",
		1671956
	],
	[
		"s1659825",
		"Begonia imbricata",
		"begonia",
		1659825
	],
	[
		"s200011",
		"Begonia imperialis",
		"begonia",
		200011
	],
	[
		"s198557",
		"Begonia incarnata",
		"begonia",
		198557
	],
	[
		"s3712944",
		"Begonia incerta",
		"begonia",
		3712944
	],
	[
		"s694475",
		"Begonia incisa",
		"begonia",
		694475
	],
	[
		"s1977240",
		"Begonia inobongensis",
		"begonia",
		1977240
	],
	[
		"s1406267",
		"Begonia inostegia",
		"begonia",
		1406267
	],
	[
		"s1979667",
		"Begonia insularis",
		"begonia",
		1979667
	],
	[
		"s200012",
		"Begonia integerrima",
		"begonia",
		200012
	],
	[
		"s3084531",
		"Begonia integrifolia",
		"begonia",
		3084531
	],
	[
		"s200013",
		"Begonia involucrata",
		"begonia",
		200013
	],
	[
		"s3084532",
		"Begonia iridescens",
		"begonia",
		3084532
	],
	[
		"s234380",
		"Begonia isalensis",
		"begonia",
		234380
	],
	[
		"s200014",
		"Begonia isoptera",
		"begonia",
		200014
	],
	[
		"s3084533",
		"Begonia isopterocarpa",
		"begonia",
		3084533
	],
	[
		"s1977216",
		"Begonia itaguassuensis",
		"begonia",
		1977216
	],
	[
		"s1979668",
		"Begonia itatiaiensis",
		"begonia",
		1979668
	],
	[
		"s198558",
		"Begonia iucunda",
		"begonia",
		198558
	],
	[
		"s1979598",
		"Begonia jaguarensis",
		"begonia",
		1979598
	],
	[
		"s1979669",
		"Begonia jairii",
		"begonia",
		1979669
	],
	[
		"s1979599",
		"Begonia jamilahana",
		"begonia",
		1979599
	],
	[
		"s3084535",
		"Begonia jenmanii",
		"begonia",
		3084535
	],
	[
		"s1406268",
		"Begonia jingxiensis",
		"begonia",
		1406268
	],
	[
		"s1519595",
		"Begonia jinyunensis",
		"begonia",
		1519595
	],
	[
		"s1684015",
		"Begonia jocelinoi",
		"begonia",
		1684015
	],
	[
		"s1977241",
		"Begonia joffrei",
		"begonia",
		1977241
	],
	[
		"s200015",
		"Begonia johnstonii",
		"begonia",
		200015
	],
	[
		"s1051766",
		"Begonia josephii",
		"begonia",
		1051766
	],
	[
		"s2717259",
		"Begonia joshii",
		"begonia",
		2717259
	],
	[
		"s1684016",
		"Begonia juliana",
		"begonia",
		1684016
	],
	[
		"s3084536",
		"Begonia juntasensis",
		"begonia",
		3084536
	],
	[
		"s2592821",
		"Begonia kalbreyeri",
		"begonia",
		2592821
	],
	[
		"s1979600",
		"Begonia karangputihensis",
		"begonia",
		1979600
	],
	[
		"s1684017",
		"Begonia karwinskyana",
		"begonia",
		1684017
	],
	[
		"s1684018",
		"Begonia kautskyana",
		"begonia",
		1684018
	],
	[
		"s1684019",
		"Begonia kellermanii",
		"begonia",
		1684019
	],
	[
		"s1979601",
		"Begonia kemumuensis",
		"begonia",
		1979601
	],
	[
		"s3693808",
		"Begonia khammouanensis",
		"begonia",
		3693808
	],
	[
		"s1406269",
		"Begonia kinabaluensis",
		"begonia",
		1406269
	],
	[
		"s200016",
		"Begonia kingiana",
		"begonia",
		200016
	],
	[
		"s200017",
		"Begonia kisuluana",
		"begonia",
		200017
	],
	[
		"s1354286",
		"Begonia klemmei",
		"begonia",
		1354286
	],
	[
		"s1979670",
		"Begonia koksunii",
		"begonia",
		1979670
	],
	[
		"s234381",
		"Begonia komoensis",
		"begonia",
		234381
	],
	[
		"s1051767",
		"Begonia koordersii",
		"begonia",
		1051767
	],
	[
		"s1979671",
		"Begonia krystofii",
		"begonia",
		1979671
	],
	[
		"s1979602",
		"Begonia kudoensis",
		"begonia",
		1979602
	],
	[
		"s1684020",
		"Begonia kuhlmannii",
		"begonia",
		1684020
	],
	[
		"s2905992",
		"Begonia kui",
		"begonia",
		2905992
	],
	[
		"s1979672",
		"Begonia labiensis",
		"begonia",
		1979672
	],
	[
		"s200018",
		"Begonia labordei",
		"begonia",
		200018
	],
	[
		"s1406270",
		"Begonia lagunensis",
		"begonia",
		1406270
	],
	[
		"s1406271",
		"Begonia lambii",
		"begonia",
		1406271
	],
	[
		"s1406272",
		"Begonia laminariae",
		"begonia",
		1406272
	],
	[
		"s172098",
		"Begonia lancangensis",
		"begonia",
		172098
	],
	[
		"s1684021",
		"Begonia lanceolata",
		"begonia",
		1684021
	],
	[
		"s1045251",
		"Begonia lanternaria",
		"begonia",
		1045251
	],
	[
		"s1051768",
		"Begonia laruei",
		"begonia",
		1051768
	],
	[
		"s1127541",
		"Begonia lasioura",
		"begonia",
		1127541
	],
	[
		"s3084537",
		"Begonia leathermaniae",
		"begonia",
		3084537
	],
	[
		"s1658753",
		"Begonia leipingensis",
		"begonia",
		1658753
	],
	[
		"s3020252",
		"Begonia lempuyangensis",
		"begonia",
		3020252
	],
	[
		"s1069560",
		"Begonia lepida",
		"begonia",
		1069560
	],
	[
		"s294965",
		"Begonia leprosa",
		"begonia",
		294965
	],
	[
		"s1051769",
		"Begonia leptoptera",
		"begonia",
		1051769
	],
	[
		"s3084538",
		"Begonia leptostyla",
		"begonia",
		3084538
	],
	[
		"s3882276",
		"Begonia letestui",
		"begonia",
		3882276
	],
	[
		"s200019",
		"Begonia letouzeyi",
		"begonia",
		200019
	],
	[
		"s1979673",
		"Begonia limprichtii",
		"begonia",
		1979673
	],
	[
		"s1979674",
		"Begonia lindleyana",
		"begonia",
		1979674
	],
	[
		"s200020",
		"Begonia listada",
		"begonia",
		200020
	],
	[
		"s1691896",
		"Begonia lithophila",
		"begonia",
		1691896
	],
	[
		"s1052170",
		"Begonia liuyanii",
		"begonia",
		1052170
	],
	[
		"s198559",
		"Begonia lobata",
		"begonia",
		198559
	],
	[
		"s3436152",
		"Begonia locii",
		"begonia",
		3436152
	],
	[
		"s1684022",
		"Begonia lomensis",
		"begonia",
		1684022
	],
	[
		"s1418999",
		"Begonia longa",
		"begonia",
		1418999
	],
	[
		"s3096229",
		"Begonia longgangensis",
		"begonia",
		3096229
	],
	[
		"s172099",
		"Begonia longicarpa",
		"begonia",
		172099
	],
	[
		"s3437358",
		"Begonia longiciliata",
		"begonia",
		3437358
	],
	[
		"s200021",
		"Begonia longifolia",
		"begonia",
		200021
	],
	[
		"s1777874",
		"Begonia longifolia x Begonia palmata",
		"begonia",
		1777874
	],
	[
		"s200022",
		"Begonia longipetiolata",
		"begonia",
		200022
	],
	[
		"s2592823",
		"Begonia longirostris",
		"begonia",
		2592823
	],
	[
		"s1671957",
		"Begonia longiscapa",
		"begonia",
		1671957
	],
	[
		"s1045252",
		"Begonia longistyla",
		"begonia",
		1045252
	],
	[
		"s1979675",
		"Begonia lophoptera",
		"begonia",
		1979675
	],
	[
		"s200023",
		"Begonia loranthoides",
		"begonia",
		200023
	],
	[
		"s3059234",
		"Begonia lorentzonii",
		"begonia",
		3059234
	],
	[
		"s2936863",
		"Begonia lorenzii",
		"begonia",
		2936863
	],
	[
		"s3693809",
		"Begonia luangprabangensis",
		"begonia",
		3693809
	],
	[
		"s200024",
		"Begonia lubbersii",
		"begonia",
		200024
	],
	[
		"s1684023",
		"Begonia ludicra",
		"begonia",
		1684023
	],
	[
		"s1684024",
		"Begonia ludwigii",
		"begonia",
		1684024
	],
	[
		"s1979676",
		"Begonia lugonis",
		"begonia",
		1979676
	],
	[
		"s151040",
		"Begonia lukuana",
		"begonia",
		151040
	],
	[
		"s1979677",
		"Begonia lunaris",
		"begonia",
		1979677
	],
	[
		"s1707609",
		"Begonia luochengensis",
		"begonia",
		1707609
	],
	[
		"s1974356",
		"Begonia lutea",
		"begonia",
		1974356
	],
	[
		"s198560",
		"Begonia luxurians",
		"begonia",
		198560
	],
	[
		"s1045253",
		"Begonia luzhaiensis",
		"begonia",
		1045253
	],
	[
		"s1671958",
		"Begonia luzonensis",
		"begonia",
		1671958
	],
	[
		"s1977217",
		"Begonia lyallii",
		"begonia",
		1977217
	],
	[
		"s1684025",
		"Begonia lyman-smithii",
		"begonia",
		1684025
	],
	[
		"s1684026",
		"Begonia lyniceorum",
		"begonia",
		1684026
	],
	[
		"s350587",
		"Begonia macdougallii",
		"begonia",
		350587
	],
	[
		"s890404",
		"Begonia macduffieana",
		"begonia",
		890404
	],
	[
		"s1051770",
		"Begonia macintyreana",
		"begonia",
		1051770
	],
	[
		"s3234287",
		"Begonia macrantha",
		"begonia",
		3234287
	],
	[
		"s1979679",
		"Begonia macrocarpa",
		"begonia",
		1979679
	],
	[
		"s1535198",
		"Begonia macrotoma",
		"begonia",
		1535198
	],
	[
		"s1684027",
		"Begonia maculata",
		"begonia",
		1684027
	],
	[
		"s1406273",
		"Begonia madaiensis",
		"begonia",
		1406273
	],
	[
		"s198561",
		"Begonia madecassa",
		"begonia",
		198561
	],
	[
		"s3732617",
		"Begonia madulidii",
		"begonia",
		3732617
	],
	[
		"s1979680",
		"Begonia majungaensis",
		"begonia",
		1979680
	],
	[
		"s3732618",
		"Begonia makuruyot",
		"begonia",
		3732618
	],
	[
		"s890405",
		"Begonia malabarica",
		"begonia",
		890405
	],
	[
		"s200025",
		"Begonia malachosticta",
		"begonia",
		200025
	],
	[
		"s1659826",
		"Begonia mamutensis",
		"begonia",
		1659826
	],
	[
		"s200026",
		"Begonia mananjebensis",
		"begonia",
		200026
	],
	[
		"s1045254",
		"Begonia manhaoensis",
		"begonia",
		1045254
	],
	[
		"s200027",
		"Begonia manicata",
		"begonia",
		200027
	],
	[
		"s1354287",
		"Begonia manillensis",
		"begonia",
		1354287
	],
	[
		"s200028",
		"Begonia mannii",
		"begonia",
		200028
	],
	[
		"s2936864",
		"Begonia mariachristinae",
		"begonia",
		2936864
	],
	[
		"s1974357",
		"Begonia mariannensis",
		"begonia",
		1974357
	],
	[
		"s1684028",
		"Begonia mariti",
		"begonia",
		1684028
	],
	[
		"s2939663",
		"Begonia markiana",
		"begonia",
		2939663
	],
	[
		"s234382",
		"Begonia marnieri",
		"begonia",
		234382
	],
	[
		"s1979681",
		"Begonia martabanica",
		"begonia",
		1979681
	],
	[
		"s1069561",
		"Begonia masarangensis",
		"begonia",
		1069561
	],
	[
		"s1406286",
		"Begonia mashanica",
		"begonia",
		1406286
	],
	[
		"s198562",
		"Begonia masoniana",
		"begonia",
		198562
	],
	[
		"s1974358",
		"Begonia maurandiae",
		"begonia",
		1974358
	],
	[
		"s1428771",
		"Begonia maxwelliana",
		"begonia",
		1428771
	],
	[
		"s200029",
		"Begonia maynensis",
		"begonia",
		200029
	],
	[
		"s1684029",
		"Begonia mazae",
		"begonia",
		1684029
	],
	[
		"s1045255",
		"Begonia megalophyllaria",
		"begonia",
		1045255
	],
	[
		"s1127532",
		"Begonia mekonggensis",
		"begonia",
		1127532
	],
	[
		"s3084539",
		"Begonia membranacea",
		"begonia",
		3084539
	],
	[
		"s1127542",
		"Begonia mendumiae",
		"begonia",
		1127542
	],
	[
		"s1045256",
		"Begonia mengtzeana",
		"begonia",
		1045256
	],
	[
		"s200030",
		"Begonia meridensis",
		"begonia",
		200030
	],
	[
		"s1671943",
		"Begonia merrilliana",
		"begonia",
		1671943
	],
	[
		"s1406274",
		"Begonia merrittii",
		"begonia",
		1406274
	],
	[
		"s443340",
		"Begonia metallica",
		"begonia",
		443340
	],
	[
		"s3682",
		"Begonia metallica x Begonia sanguinea",
		"begonia",
		3682
	],
	[
		"s1979682",
		"Begonia mexicana",
		"begonia",
		1979682
	],
	[
		"s198563",
		"Begonia meyeri-johannis",
		"begonia",
		198563
	],
	[
		"s1684030",
		"Begonia micranthera",
		"begonia",
		1684030
	],
	[
		"s1684031",
		"Begonia microsperma",
		"begonia",
		1684031
	],
	[
		"s3699226",
		"Begonia mildbraedii",
		"begonia",
		3699226
	],
	[
		"s1354288",
		"Begonia mindorensis",
		"begonia",
		1354288
	],
	[
		"s200031",
		"Begonia minor",
		"begonia",
		200031
	],
	[
		"s1979683",
		"Begonia minutifolia",
		"begonia",
		1979683
	],
	[
		"s189379",
		"Begonia molleri",
		"begonia",
		189379
	],
	[
		"s1684032",
		"Begonia mollicaulis",
		"begonia",
		1684032
	],
	[
		"s1684033",
		"Begonia monadelpha",
		"begonia",
		1684033
	],
	[
		"s3084540",
		"Begonia monophylla",
		"begonia",
		3084540
	],
	[
		"s3436161",
		"Begonia montaniformis",
		"begonia",
		3436161
	],
	[
		"s200032",
		"Begonia morsei",
		"begonia",
		200032
	],
	[
		"s1979684",
		"Begonia motozintlensis",
		"begonia",
		1979684
	],
	[
		"s1977219",
		"Begonia moysesii",
		"begonia",
		1977219
	],
	[
		"s294966",
		"Begonia multangula",
		"begonia",
		294966
	],
	[
		"s1069562",
		"Begonia multijugata",
		"begonia",
		1069562
	],
	[
		"s1123541",
		"Begonia multinervia",
		"begonia",
		1123541
	],
	[
		"s1979685",
		"Begonia multistaminea",
		"begonia",
		1979685
	],
	[
		"s294967",
		"Begonia muricata",
		"begonia",
		294967
	],
	[
		"s1979686",
		"Begonia murina",
		"begonia",
		1979686
	],
	[
		"s2029890",
		"Begonia namkadingensis",
		"begonia",
		2029890
	],
	[
		"s234383",
		"Begonia nana",
		"begonia",
		234383
	],
	[
		"s78253",
		"Begonia nantoensis",
		"begonia",
		78253
	],
	[
		"s3234323",
		"Begonia naraharii",
		"begonia",
		3234323
	],
	[
		"s3452993",
		"Begonia natunaensis",
		"begonia",
		3452993
	],
	[
		"s2717011",
		"Begonia neglecta",
		"begonia",
		2717011
	],
	[
		"s1051771",
		"Begonia negrosensis",
		"begonia",
		1051771
	],
	[
		"s890406",
		"Begonia nelumbifolia",
		"begonia",
		890406
	],
	[
		"s2717012",
		"Begonia neocomensium",
		"begonia",
		2717012
	],
	[
		"s294968",
		"Begonia nepalensis",
		"begonia",
		294968
	],
	[
		"s212715",
		"Begonia nigritarum",
		"begonia",
		212715
	],
	[
		"s1045258",
		"Begonia ningmingensis",
		"begonia",
		1045258
	],
	[
		"s1979687",
		"Begonia nitida",
		"begonia",
		1979687
	],
	[
		"s1127543",
		"Begonia nobmanniae",
		"begonia",
		1127543
	],
	[
		"s198564",
		"Begonia nossibea",
		"begonia",
		198564
	],
	[
		"s2185191",
		"Begonia nosymangabensis",
		"begonia",
		2185191
	],
	[
		"s3084541",
		"Begonia notata",
		"begonia",
		3084541
	],
	[
		"s1979603",
		"Begonia nothobaramensis",
		"begonia",
		1979603
	],
	[
		"s1977220",
		"Begonia nurii",
		"begonia",
		1977220
	],
	[
		"s1051772",
		"Begonia nuwakotensis",
		"begonia",
		1051772
	],
	[
		"s212816",
		"Begonia oaxacana",
		"begonia",
		212816
	],
	[
		"s2716928",
		"Begonia obdeltata",
		"begonia",
		2716928
	],
	[
		"s3084542",
		"Begonia oblanceolata",
		"begonia",
		3084542
	],
	[
		"s189377",
		"Begonia obliqua",
		"begonia",
		189377
	],
	[
		"s1659827",
		"Begonia oblongifolia",
		"begonia",
		1659827
	],
	[
		"s1069563",
		"Begonia obovoidea",
		"begonia",
		1069563
	],
	[
		"s1684034",
		"Begonia obscura",
		"begonia",
		1684034
	],
	[
		"s3027246",
		"Begonia obsolescens",
		"begonia",
		3027246
	],
	[
		"s1977221",
		"Begonia obtecticaulis",
		"begonia",
		1977221
	],
	[
		"s1671960",
		"Begonia obtusifolia",
		"begonia",
		1671960
	],
	[
		"s3732623",
		"Begonia occidentalis",
		"begonia",
		3732623
	],
	[
		"s1979688",
		"Begonia octopetala",
		"begonia",
		1979688
	],
	[
		"s1684035",
		"Begonia odeteiantha",
		"begonia",
		1684035
	],
	[
		"s200033",
		"Begonia odorata",
		"begonia",
		200033
	],
	[
		"s200034",
		"Begonia olbia",
		"begonia",
		200034
	],
	[
		"s1979604",
		"Begonia olivacea",
		"begonia",
		1979604
	],
	[
		"s1684036",
		"Begonia olsoniae",
		"begonia",
		1684036
	],
	[
		"s1979689",
		"Begonia opuliflora",
		"begonia",
		1979689
	],
	[
		"s1045260",
		"Begonia oreodoxa",
		"begonia",
		1045260
	],
	[
		"s3084543",
		"Begonia ornithocarpa",
		"begonia",
		3084543
	],
	[
		"s1045261",
		"Begonia ornithophylla",
		"begonia",
		1045261
	],
	[
		"s1051773",
		"Begonia ovatifolia",
		"begonia",
		1051773
	],
	[
		"s234384",
		"Begonia oxyanthera",
		"begonia",
		234384
	],
	[
		"s48226",
		"Begonia oxyloba",
		"begonia",
		48226
	],
	[
		"s200035",
		"Begonia oxyphylla",
		"begonia",
		200035
	],
	[
		"s200036",
		"Begonia oxysperma",
		"begonia",
		200036
	],
	[
		"s1127544",
		"Begonia ozotothrix",
		"begonia",
		1127544
	],
	[
		"s1684037",
		"Begonia pachypoda",
		"begonia",
		1684037
	],
	[
		"s2099529",
		"Begonia padangensis",
		"begonia",
		2099529
	],
	[
		"s1671961",
		"Begonia palawanensis",
		"begonia",
		1671961
	],
	[
		"s1979690",
		"Begonia paleata",
		"begonia",
		1979690
	],
	[
		"s99386",
		"Begonia palmata",
		"begonia",
		99386
	],
	[
		"s1406275",
		"Begonia panayensis",
		"begonia",
		1406275
	],
	[
		"s3732622",
		"Begonia panayica",
		"begonia",
		3732622
	],
	[
		"s1051774",
		"Begonia panchtharensis",
		"begonia",
		1051774
	],
	[
		"s1979691",
		"Begonia papyraptera",
		"begonia",
		1979691
	],
	[
		"s1419000",
		"Begonia paracauliflora",
		"begonia",
		1419e3
	],
	[
		"s1684038",
		"Begonia paranaensis",
		"begonia",
		1684038
	],
	[
		"s1974359",
		"Begonia parcifolia",
		"begonia",
		1974359
	],
	[
		"s1979692",
		"Begonia parilis",
		"begonia",
		1979692
	],
	[
		"s1421037",
		"Begonia parviflora",
		"begonia",
		1421037
	],
	[
		"s3699227",
		"Begonia parvifolia",
		"begonia",
		3699227
	],
	[
		"s3712946",
		"Begonia parviglandulosa",
		"begonia",
		3712946
	],
	[
		"s694485",
		"Begonia parvula",
		"begonia",
		694485
	],
	[
		"s2184955",
		"Begonia parvuliflora",
		"begonia",
		2184955
	],
	[
		"s1051775",
		"Begonia pasamanensis",
		"begonia",
		1051775
	],
	[
		"s3084545",
		"Begonia pastoensis",
		"begonia",
		3084545
	],
	[
		"s3041679",
		"Begonia paucilobata",
		"begonia",
		3041679
	],
	[
		"s294969",
		"Begonia pavonina",
		"begonia",
		294969
	],
	[
		"s1979693",
		"Begonia pearcei",
		"begonia",
		1979693
	],
	[
		"s1979694",
		"Begonia pectennervia",
		"begonia",
		1979694
	],
	[
		"s3084546",
		"Begonia pedata",
		"begonia",
		3084546
	],
	[
		"s702304",
		"Begonia pedatifida",
		"begonia",
		702304
	],
	[
		"s200037",
		"Begonia peltata",
		"begonia",
		200037
	],
	[
		"s1406276",
		"Begonia peltatifolia",
		"begonia",
		1406276
	],
	[
		"s1069564",
		"Begonia pendula",
		"begonia",
		1069564
	],
	[
		"s1406277",
		"Begonia pengii",
		"begonia",
		1406277
	],
	[
		"s3084547",
		"Begonia pentaphylla",
		"begonia",
		3084547
	],
	[
		"s1979695",
		"Begonia per-dusenii",
		"begonia",
		1979695
	],
	[
		"s1979696",
		"Begonia perakensis",
		"begonia",
		1979696
	],
	[
		"s3084548",
		"Begonia pernambucensis",
		"begonia",
		3084548
	],
	[
		"s1979697",
		"Begonia peruviana",
		"begonia",
		1979697
	],
	[
		"s890407",
		"Begonia petasitifolia",
		"begonia",
		890407
	],
	[
		"s1977242",
		"Begonia phantasma",
		"begonia",
		1977242
	],
	[
		"s1051776",
		"Begonia picta",
		"begonia",
		1051776
	],
	[
		"s1707610",
		"Begonia picturata",
		"begonia",
		1707610
	],
	[
		"s1979698",
		"Begonia pilgeriana",
		"begonia",
		1979698
	],
	[
		"s1684039",
		"Begonia pinetorum",
		"begonia",
		1684039
	],
	[
		"s3084549",
		"Begonia pinheironis",
		"begonia",
		3084549
	],
	[
		"s1979754",
		"Begonia pinnatifida",
		"begonia",
		1979754
	],
	[
		"s890408",
		"Begonia piurensis",
		"begonia",
		890408
	],
	[
		"s476164",
		"Begonia plagioneura",
		"begonia",
		476164
	],
	[
		"s1977222",
		"Begonia platanifolia",
		"begonia",
		1977222
	],
	[
		"s1045262",
		"Begonia platycarpa",
		"begonia",
		1045262
	],
	[
		"s3084550",
		"Begonia platyptera",
		"begonia",
		3084550
	],
	[
		"s1047136",
		"Begonia plebeja",
		"begonia",
		1047136
	],
	[
		"s1977223",
		"Begonia pleiopetala",
		"begonia",
		1977223
	],
	[
		"s1977224",
		"Begonia plumieri",
		"begonia",
		1977224
	],
	[
		"s1979699",
		"Begonia pluvialis",
		"begonia",
		1979699
	],
	[
		"s198565",
		"Begonia poculifera",
		"begonia",
		198565
	],
	[
		"s1979700",
		"Begonia poilanei",
		"begonia",
		1979700
	],
	[
		"s1069565",
		"Begonia polilloensis",
		"begonia",
		1069565
	],
	[
		"s1979701",
		"Begonia polyandra",
		"begonia",
		1979701
	],
	[
		"s1684040",
		"Begonia polygonata",
		"begonia",
		1684040
	],
	[
		"s234385",
		"Begonia polygonoides",
		"begonia",
		234385
	],
	[
		"s1979702",
		"Begonia polypetala",
		"begonia",
		1979702
	],
	[
		"s1684041",
		"Begonia popenoei",
		"begonia",
		1684041
	],
	[
		"s443341",
		"Begonia porteri",
		"begonia",
		443341
	],
	[
		"s3084551",
		"Begonia portillana",
		"begonia",
		3084551
	],
	[
		"s200038",
		"Begonia potamophila",
		"begonia",
		200038
	],
	[
		"s234387",
		"Begonia preussii",
		"begonia",
		234387
	],
	[
		"s3084552",
		"Begonia prieurii",
		"begonia",
		3084552
	],
	[
		"s1979703",
		"Begonia princeps",
		"begonia",
		1979703
	],
	[
		"s1684042",
		"Begonia pringlei",
		"begonia",
		1684042
	],
	[
		"s1127545",
		"Begonia prionota",
		"begonia",
		1127545
	],
	[
		"s200039",
		"Begonia prismatocarpa",
		"begonia",
		200039
	],
	[
		"s209579",
		"Begonia prostrata x Begonia silletensis",
		"begonia",
		209579
	],
	[
		"s1684043",
		"Begonia pruinata",
		"begonia",
		1684043
	],
	[
		"s3695373",
		"Begonia pseudobrandisiana",
		"begonia",
		3695373
	],
	[
		"s1979605",
		"Begonia pseudodaedalea",
		"begonia",
		1979605
	],
	[
		"s1707611",
		"Begonia pseudodaxinensis",
		"begonia",
		1707611
	],
	[
		"s2184943",
		"Begonia pseudodryadis",
		"begonia",
		2184943
	],
	[
		"s2834456",
		"Begonia pseudoedulis",
		"begonia",
		2834456
	],
	[
		"s1051777",
		"Begonia pseudolateralis",
		"begonia",
		1051777
	],
	[
		"s1684044",
		"Begonia pseudolubbersii",
		"begonia",
		1684044
	],
	[
		"s2184944",
		"Begonia pseudopleiopetala",
		"begonia",
		2184944
	],
	[
		"s1045263",
		"Begonia psilophylla",
		"begonia",
		1045263
	],
	[
		"s1977243",
		"Begonia pteridiformis",
		"begonia",
		1977243
	],
	[
		"s3699228",
		"Begonia pteridoides",
		"begonia",
		3699228
	],
	[
		"s1979704",
		"Begonia pulchella",
		"begonia",
		1979704
	],
	[
		"s1691898",
		"Begonia pulchrifolia",
		"begonia",
		1691898
	],
	[
		"s2184945",
		"Begonia pululahuana",
		"begonia",
		2184945
	],
	[
		"s1406278",
		"Begonia pulvinifera",
		"begonia",
		1406278
	],
	[
		"s1045264",
		"Begonia purpureofolia",
		"begonia",
		1045264
	],
	[
		"s1684045",
		"Begonia purpusii",
		"begonia",
		1684045
	],
	[
		"s1979606",
		"Begonia puspitae",
		"begonia",
		1979606
	],
	[
		"s1684046",
		"Begonia pustulata",
		"begonia",
		1684046
	],
	[
		"s1051778",
		"Begonia puttii",
		"begonia",
		1051778
	],
	[
		"s200040",
		"Begonia quadrialata",
		"begonia",
		200040
	],
	[
		"s2093553",
		"Begonia quinquealata",
		"begonia",
		2093553
	],
	[
		"s1051779",
		"Begonia rabilii",
		"begonia",
		1051779
	],
	[
		"s1979705",
		"Begonia racemosa",
		"begonia",
		1979705
	],
	[
		"s1977225",
		"Begonia rachmatii",
		"begonia",
		1977225
	],
	[
		"s890409",
		"Begonia radicans",
		"begonia",
		890409
	],
	[
		"s3084553",
		"Begonia rafael-torresii",
		"begonia",
		3084553
	],
	[
		"s200041",
		"Begonia rajah",
		"begonia",
		200041
	],
	[
		"s1051780",
		"Begonia ramosii",
		"begonia",
		1051780
	],
	[
		"s1127546",
		"Begonia rantemarioensis",
		"begonia",
		1127546
	],
	[
		"s151406",
		"Begonia ravenii",
		"begonia",
		151406
	],
	[
		"s1979706",
		"Begonia reginula",
		"begonia",
		1979706
	],
	[
		"s200042",
		"Begonia reniformis",
		"begonia",
		200042
	],
	[
		"s2099530",
		"Begonia repanda",
		"begonia",
		2099530
	],
	[
		"s1684047",
		"Begonia resecta",
		"begonia",
		1684047
	],
	[
		"s1406279",
		"Begonia retinervia",
		"begonia",
		1406279
	],
	[
		"s3084554",
		"Begonia retusa",
		"begonia",
		3084554
	],
	[
		"s200043",
		"Begonia rex",
		"begonia",
		200043
	],
	[
		"s3084555",
		"Begonia rhodochlamys",
		"begonia",
		3084555
	],
	[
		"s1979707",
		"Begonia rhoephila",
		"begonia",
		1979707
	],
	[
		"s1354289",
		"Begonia rhombicarpa",
		"begonia",
		1354289
	],
	[
		"s1684048",
		"Begonia richardsoniana",
		"begonia",
		1684048
	],
	[
		"s1979708",
		"Begonia rigida",
		"begonia",
		1979708
	],
	[
		"s294970",
		"Begonia robusta",
		"begonia",
		294970
	],
	[
		"s1974360",
		"Begonia rossmanniae",
		"begonia",
		1974360
	],
	[
		"s1979709",
		"Begonia rotundifolia",
		"begonia",
		1979709
	],
	[
		"s198566",
		"Begonia roxburghii",
		"begonia",
		198566
	],
	[
		"s212817",
		"Begonia rubella",
		"begonia",
		212817
	],
	[
		"s1979710",
		"Begonia rubida",
		"begonia",
		1979710
	],
	[
		"s1671962",
		"Begonia rubiteae",
		"begonia",
		1671962
	],
	[
		"s172101",
		"Begonia ruboides",
		"begonia",
		172101
	],
	[
		"s1977226",
		"Begonia rubriflora",
		"begonia",
		1977226
	],
	[
		"s1354290",
		"Begonia rubrifolia",
		"begonia",
		1354290
	],
	[
		"s1974361",
		"Begonia rubrotincta",
		"begonia",
		1974361
	],
	[
		"s3696881",
		"Begonia ruchengensis",
		"begonia",
		3696881
	],
	[
		"s1979711",
		"Begonia rufa",
		"begonia",
		1979711
	],
	[
		"s1354291",
		"Begonia rufipila",
		"begonia",
		1354291
	],
	[
		"s200044",
		"Begonia rufosericea",
		"begonia",
		200044
	],
	[
		"s2936859",
		"Begonia rushforthii",
		"begonia",
		2936859
	],
	[
		"s2717013",
		"Begonia russelliana",
		"begonia",
		2717013
	],
	[
		"s3084556",
		"Begonia rutilans",
		"begonia",
		3084556
	],
	[
		"s1979712",
		"Begonia sageaensis",
		"begonia",
		1979712
	],
	[
		"s198567",
		"Begonia salaziensis",
		"begonia",
		198567
	],
	[
		"s1979713",
		"Begonia salesopolensis",
		"begonia",
		1979713
	],
	[
		"s2184946",
		"Begonia salicifolia",
		"begonia",
		2184946
	],
	[
		"s198428",
		"Begonia samhaensis",
		"begonia",
		198428
	],
	[
		"s3084557",
		"Begonia sandtii",
		"begonia",
		3084557
	],
	[
		"s1684049",
		"Begonia sanguinea",
		"begonia",
		1684049
	],
	[
		"s1127547",
		"Begonia sanguineopilosa",
		"begonia",
		1127547
	],
	[
		"s2592824",
		"Begonia santos-limae",
		"begonia",
		2592824
	],
	[
		"s1684050",
		"Begonia sarcophylla",
		"begonia",
		1684050
	],
	[
		"s1979714",
		"Begonia sartorii",
		"begonia",
		1979714
	],
	[
		"s3084558",
		"Begonia satrapis",
		"begonia",
		3084558
	],
	[
		"s1977227",
		"Begonia saxicola",
		"begonia",
		1977227
	],
	[
		"s3084559",
		"Begonia scabrida",
		"begonia",
		3084559
	],
	[
		"s2865988",
		"Begonia scabrifolia",
		"begonia",
		2865988
	],
	[
		"s198568",
		"Begonia scapigera",
		"begonia",
		198568
	],
	[
		"s1979715",
		"Begonia scharffiana",
		"begonia",
		1979715
	],
	[
		"s1684051",
		"Begonia scharffii",
		"begonia",
		1684051
	],
	[
		"s1684052",
		"Begonia schmidtiana",
		"begonia",
		1684052
	],
	[
		"s1979716",
		"Begonia sciaphila",
		"begonia",
		1979716
	],
	[
		"s2834150",
		"Begonia scorpiuroloba",
		"begonia",
		2834150
	],
	[
		"s1051781",
		"Begonia scottii",
		"begonia",
		1051781
	],
	[
		"s200045",
		"Begonia scutifolia",
		"begonia",
		200045
	],
	[
		"s1977228",
		"Begonia seemanniana",
		"begonia",
		1977228
	],
	[
		"s3084560",
		"Begonia segregata",
		"begonia",
		3084560
	],
	[
		"s1977229",
		"Begonia semidigitata",
		"begonia",
		1977229
	],
	[
		"s1807070",
		"Begonia semiovata",
		"begonia",
		1807070
	],
	[
		"s1406280",
		"Begonia semiparietalis",
		"begonia",
		1406280
	],
	[
		"s200046",
		"Begonia sericoneura",
		"begonia",
		200046
	],
	[
		"s1974362",
		"Begonia serotina",
		"begonia",
		1974362
	],
	[
		"s200047",
		"Begonia serratipetala",
		"begonia",
		200047
	],
	[
		"s172104",
		"Begonia setifolia",
		"begonia",
		172104
	],
	[
		"s3721704",
		"Begonia shenzhenensis",
		"begonia",
		3721704
	],
	[
		"s1979717",
		"Begonia sibthorpioides",
		"begonia",
		1979717
	],
	[
		"s1977230",
		"Begonia sibutensis",
		"begonia",
		1977230
	],
	[
		"s1069566",
		"Begonia siccacaudata",
		"begonia",
		1069566
	],
	[
		"s1051782",
		"Begonia sikkimensis",
		"begonia",
		1051782
	],
	[
		"s172102",
		"Begonia silletensis",
		"begonia",
		172102
	],
	[
		"s1979718",
		"Begonia silverstonii",
		"begonia",
		1979718
	],
	[
		"s1979607",
		"Begonia simolapensis",
		"begonia",
		1979607
	],
	[
		"s1406281",
		"Begonia sinofloribunda",
		"begonia",
		1406281
	],
	[
		"s3712945",
		"Begonia sinuata",
		"begonia",
		3712945
	],
	[
		"s1069567",
		"Begonia sizemoreae",
		"begonia",
		1069567
	],
	[
		"s2184947",
		"Begonia smilacina",
		"begonia",
		2184947
	],
	[
		"s1051783",
		"Begonia smithiae",
		"begonia",
		1051783
	],
	[
		"s3027247",
		"Begonia smithiana",
		"begonia",
		3027247
	],
	[
		"s169516",
		"Begonia socotrana",
		"begonia",
		169516
	],
	[
		"s2605299",
		"Begonia socotrana x Begonia dregei",
		"begonia",
		2605299
	],
	[
		"s1835376",
		"Begonia sodiroi",
		"begonia",
		1835376
	],
	[
		"s200048",
		"Begonia solananthera",
		"begonia",
		200048
	],
	[
		"s2184948",
		"Begonia solaniflora",
		"begonia",
		2184948
	],
	[
		"s1684053",
		"Begonia soli-mutata",
		"begonia",
		1684053
	],
	[
		"s200049",
		"Begonia sonderiana",
		"begonia",
		200049
	],
	[
		"s3732619",
		"Begonia sordidissima",
		"begonia",
		3732619
	],
	[
		"s1979719",
		"Begonia sousae",
		"begonia",
		1979719
	],
	[
		"s3084561",
		"Begonia sparsipila",
		"begonia",
		3084561
	],
	[
		"s2184949",
		"Begonia speculum",
		"begonia",
		2184949
	],
	[
		"s1979722",
		"Begonia speluncae",
		"begonia",
		1979722
	],
	[
		"s1684054",
		"Begonia squamulosa",
		"begonia",
		1684054
	],
	[
		"s1684055",
		"Begonia squarrosa",
		"begonia",
		1684055
	],
	[
		"s200050",
		"Begonia staudtii",
		"begonia",
		200050
	],
	[
		"s1979723",
		"Begonia stenogyna",
		"begonia",
		1979723
	],
	[
		"s1979724",
		"Begonia stevei",
		"begonia",
		1979724
	],
	[
		"s1354292",
		"Begonia stictopoda",
		"begonia",
		1354292
	],
	[
		"s1684056",
		"Begonia stigmosa",
		"begonia",
		1684056
	],
	[
		"s3084562",
		"Begonia stipulacea",
		"begonia",
		3084562
	],
	[
		"s1684057",
		"Begonia strigillosa",
		"begonia",
		1684057
	],
	[
		"s1069568",
		"Begonia strigosa",
		"begonia",
		1069568
	],
	[
		"s1979725",
		"Begonia suaveolens",
		"begonia",
		1979725
	],
	[
		"s2592825",
		"Begonia suaviola",
		"begonia",
		2592825
	],
	[
		"s1977231",
		"Begonia subacida",
		"begonia",
		1977231
	],
	[
		"s234388",
		"Begonia subalpestris",
		"begonia",
		234388
	],
	[
		"s1977232",
		"Begonia subciliata",
		"begonia",
		1977232
	],
	[
		"s3381711",
		"Begonia subcoriacea",
		"begonia",
		3381711
	],
	[
		"s3880208",
		"Begonia subfiliformis",
		"begonia",
		3880208
	],
	[
		"s2904471",
		"Begonia subhowii",
		"begonia",
		2904471
	],
	[
		"s1671963",
		"Begonia sublobata",
		"begonia",
		1671963
	],
	[
		"s1423671",
		"Begonia sublongipes",
		"begonia",
		1423671
	],
	[
		"s1354293",
		"Begonia subnummularifolia",
		"begonia",
		1354293
	],
	[
		"s1051785",
		"Begonia suborbiculata",
		"begonia",
		1051785
	],
	[
		"s200051",
		"Begonia subscutata",
		"begonia",
		200051
	],
	[
		"s1979726",
		"Begonia subspinulosa",
		"begonia",
		1979726
	],
	[
		"s1684058",
		"Begonia subvillosa",
		"begonia",
		1684058
	],
	[
		"s1069569",
		"Begonia sudjanae",
		"begonia",
		1069569
	],
	[
		"s3084563",
		"Begonia suprafastigiata",
		"begonia",
		3084563
	],
	[
		"s1769193",
		"Begonia susaniae",
		"begonia",
		1769193
	],
	[
		"s185333",
		"Begonia sutherlandii",
		"begonia",
		185333
	],
	[
		"s1671944",
		"Begonia sykakiengii",
		"begonia",
		1671944
	],
	[
		"s2717014",
		"Begonia sylvatica",
		"begonia",
		2717014
	],
	[
		"s1977233",
		"Begonia sylvestris",
		"begonia",
		1977233
	],
	[
		"s198571",
		"Begonia symsanguinea",
		"begonia",
		198571
	],
	[
		"s2093555",
		"Begonia tabonensis",
		"begonia",
		2093555
	],
	[
		"s3761841",
		"Begonia tadungensis",
		"begonia",
		3761841
	],
	[
		"s1671945",
		"Begonia tagbanua",
		"begonia",
		1671945
	],
	[
		"s151407",
		"Begonia taiwaniana",
		"begonia",
		151407
	],
	[
		"s1777875",
		"Begonia taiwaniana x Begonia formosana",
		"begonia",
		1777875
	],
	[
		"s1777876",
		"Begonia taiwaniana x Begonia longifolia",
		"begonia",
		1777876
	],
	[
		"s1051786",
		"Begonia taligera",
		"begonia",
		1051786
	],
	[
		"s1350403",
		"Begonia tandangii",
		"begonia",
		1350403
	],
	[
		"s1671946",
		"Begonia taraw",
		"begonia",
		1671946
	],
	[
		"s200052",
		"Begonia tayabensis",
		"begonia",
		200052
	],
	[
		"s1979727",
		"Begonia tenera",
		"begonia",
		1979727
	],
	[
		"s151408",
		"Begonia tengchiana",
		"begonia",
		151408
	],
	[
		"s1671934",
		"Begonia tenuibracteata",
		"begonia",
		1671934
	],
	[
		"s1056151",
		"Begonia tenuifolia",
		"begonia",
		1056151
	],
	[
		"s172103",
		"Begonia tetragona",
		"begonia",
		172103
	],
	[
		"s1979728",
		"Begonia tetrandra",
		"begonia",
		1979728
	],
	[
		"s1979729",
		"Begonia teuscheri",
		"begonia",
		1979729
	],
	[
		"s1051787",
		"Begonia teysmanniana",
		"begonia",
		1051787
	],
	[
		"s200054",
		"Begonia thelmae",
		"begonia",
		200054
	],
	[
		"s200053",
		"Begonia thiemei",
		"begonia",
		200053
	],
	[
		"s198569",
		"Begonia thomeana",
		"begonia",
		198569
	],
	[
		"s1979730",
		"Begonia thomsonii",
		"begonia",
		1979730
	],
	[
		"s1979731",
		"Begonia thwaitesii",
		"begonia",
		1979731
	],
	[
		"s1974365",
		"Begonia thyrsoidea",
		"begonia",
		1974365
	],
	[
		"s1354294",
		"Begonia tigrina",
		"begonia",
		1354294
	],
	[
		"s1979732",
		"Begonia tiliifolia",
		"begonia",
		1979732
	],
	[
		"s1979733",
		"Begonia toledana",
		"begonia",
		1979733
	],
	[
		"s1684059",
		"Begonia tomentosa",
		"begonia",
		1684059
	],
	[
		"s1979734",
		"Begonia tominana",
		"begonia",
		1979734
	],
	[
		"s1979735",
		"Begonia tonduzii",
		"begonia",
		1979735
	],
	[
		"s1127548",
		"Begonia torajana",
		"begonia",
		1127548
	],
	[
		"s1979736",
		"Begonia trianae",
		"begonia",
		1979736
	],
	[
		"s1051788",
		"Begonia tribenensis",
		"begonia",
		1051788
	],
	[
		"s1671964",
		"Begonia trichochila",
		"begonia",
		1671964
	],
	[
		"s1979737",
		"Begonia trichopoda",
		"begonia",
		1979737
	],
	[
		"s3084564",
		"Begonia trichosepala",
		"begonia",
		3084564
	],
	[
		"s3695374",
		"Begonia tripartifolia",
		"begonia",
		3695374
	],
	[
		"s1979738",
		"Begonia tropaeolifolia",
		"begonia",
		1979738
	],
	[
		"s3084565",
		"Begonia truncicola",
		"begonia",
		3084565
	],
	[
		"s1974366",
		"Begonia tumbezensis",
		"begonia",
		1974366
	],
	[
		"s48225",
		"Begonia ulmifolia",
		"begonia",
		48225
	],
	[
		"s1979739",
		"Begonia umbellata",
		"begonia",
		1979739
	],
	[
		"s2717001",
		"Begonia umbraculifera",
		"begonia",
		2717001
	],
	[
		"s1045265",
		"Begonia umbraculifolia",
		"begonia",
		1045265
	],
	[
		"s3084566",
		"Begonia unduavensis",
		"begonia",
		3084566
	],
	[
		"s1684060",
		"Begonia undulata",
		"begonia",
		1684060
	],
	[
		"s3681927",
		"Begonia urophylla",
		"begonia",
		3681927
	],
	[
		"s1568985",
		"Begonia urticae",
		"begonia",
		1568985
	],
	[
		"s1974367",
		"Begonia urubambensis",
		"begonia",
		1974367
	],
	[
		"s1659828",
		"Begonia vaccinioides",
		"begonia",
		1659828
	],
	[
		"s2184950",
		"Begonia valerioi",
		"begonia",
		2184950
	],
	[
		"s200055",
		"Begonia valida",
		"begonia",
		200055
	],
	[
		"s3084567",
		"Begonia valvata",
		"begonia",
		3084567
	],
	[
		"s1979740",
		"Begonia vankerckhovenii",
		"begonia",
		1979740
	],
	[
		"s294971",
		"Begonia variabilis",
		"begonia",
		294971
	],
	[
		"s1406282",
		"Begonia variegata",
		"begonia",
		1406282
	],
	[
		"s2605953",
		"Begonia variifolia",
		"begonia",
		2605953
	],
	[
		"s1051789",
		"Begonia varipeltata",
		"begonia",
		1051789
	],
	[
		"s1979741",
		"Begonia velata",
		"begonia",
		1979741
	],
	[
		"s1684061",
		"Begonia venosa",
		"begonia",
		1684061
	],
	[
		"s1047137",
		"Begonia venusta",
		"begonia",
		1047137
	],
	[
		"s1069570",
		"Begonia verecunda",
		"begonia",
		1069570
	],
	[
		"s1127549",
		"Begonia vermeulenii",
		"begonia",
		1127549
	],
	[
		"s200056",
		"Begonia versicolor",
		"begonia",
		200056
	],
	[
		"s3084568",
		"Begonia vicina",
		"begonia",
		3084568
	],
	[
		"s1045267",
		"Begonia villifolia",
		"begonia",
		1045267
	],
	[
		"s198570",
		"Begonia violifolia",
		"begonia",
		198570
	],
	[
		"s1979742",
		"Begonia viridiflora",
		"begonia",
		1979742
	],
	[
		"s3695375",
		"Begonia viriditenebris",
		"begonia",
		3695375
	],
	[
		"s3693807",
		"Begonia viscosa",
		"begonia",
		3693807
	],
	[
		"s2907133",
		"Begonia vittariifolia",
		"begonia",
		2907133
	],
	[
		"s3695376",
		"Begonia vivipara",
		"begonia",
		3695376
	],
	[
		"s2099531",
		"Begonia vuijckii",
		"begonia",
		2099531
	],
	[
		"s1354295",
		"Begonia wadei",
		"begonia",
		1354295
	],
	[
		"s1684062",
		"Begonia wallichiana",
		"begonia",
		1684062
	],
	[
		"s1045268",
		"Begonia wangii",
		"begonia",
		1045268
	],
	[
		"s1069571",
		"Begonia watuwilensis",
		"begonia",
		1069571
	],
	[
		"s1684063",
		"Begonia weberbaueri",
		"begonia",
		1684063
	],
	[
		"s3084569",
		"Begonia weddelliana",
		"begonia",
		3084569
	],
	[
		"s1127550",
		"Begonia weigallii",
		"begonia",
		1127550
	],
	[
		"s172089",
		"Begonia wenshanensis",
		"begonia",
		172089
	],
	[
		"s1691897",
		"Begonia wilsonii",
		"begonia",
		1691897
	],
	[
		"s3699229",
		"Begonia wollastonii",
		"begonia",
		3699229
	],
	[
		"s200057",
		"Begonia wollnyi",
		"begonia",
		200057
	],
	[
		"s1671965",
		"Begonia woodii",
		"begonia",
		1671965
	],
	[
		"s1069572",
		"Begonia wrayi",
		"begonia",
		1069572
	],
	[
		"s3084570",
		"Begonia wutaiana",
		"begonia",
		3084570
	],
	[
		"s146769",
		"Begonia x buimontana",
		"begonia",
		146769
	],
	[
		"s1777873",
		"Begonia x chungii",
		"begonia",
		1777873
	],
	[
		"s1671939",
		"Begonia x dinglensis",
		"begonia",
		1671939
	],
	[
		"s1087467",
		"Begonia x hiemalis",
		"begonia",
		1087467
	],
	[
		"s1423670",
		"Begonia x intermedia",
		"begonia",
		1423670
	],
	[
		"s2086442",
		"Begonia x kapangan",
		"begonia",
		2086442
	],
	[
		"s2029167",
		"Begonia x ricinifolia",
		"begonia",
		2029167
	],
	[
		"s589341",
		"Begonia x semperflorens-cultorum",
		"begonia",
		589341
	],
	[
		"s80371",
		"Begonia x taipeiensis",
		"begonia",
		80371
	],
	[
		"s447310",
		"Begonia x tuberhybrida",
		"begonia",
		447310
	],
	[
		"s294972",
		"Begonia xanthina",
		"begonia",
		294972
	],
	[
		"s3693805",
		"Begonia xenos",
		"begonia",
		3693805
	],
	[
		"s2583035",
		"Begonia xishuiensis",
		"begonia",
		2583035
	],
	[
		"s1979608",
		"Begonia yapenensis",
		"begonia",
		1979608
	],
	[
		"s1406283",
		"Begonia yappii",
		"begonia",
		1406283
	],
	[
		"s2488572",
		"Begonia yenyeniae",
		"begonia",
		2488572
	],
	[
		"s2605954",
		"Begonia yishanensis",
		"begonia",
		2605954
	],
	[
		"s2605956",
		"Begonia yizhouensis",
		"begonia",
		2605956
	],
	[
		"s1979745",
		"Begonia yunnanensis",
		"begonia",
		1979745
	],
	[
		"s1052171",
		"Begonia zhengyiana",
		"begonia",
		1052171
	],
	[
		"s252558",
		"Benincasa fistulosa",
		"benincasa",
		252558
	],
	[
		"s102211",
		"Benincasa hispida",
		"benincasa",
		102211
	],
	[
		"s309178",
		"Blastania cerasiformis",
		"blastania",
		309178
	],
	[
		"s1932176",
		"Blastania garcinii",
		"blastania",
		1932176
	],
	[
		"s383675",
		"Blastania lucorum",
		"blastania",
		383675
	],
	[
		"s2726054",
		"Bolbostemma biglandulosum",
		"bolbostemma",
		2726054
	],
	[
		"s381652",
		"Bolbostemma paniculatum",
		"bolbostemma",
		381652
	],
	[
		"s388288",
		"Borneosicyos simplex",
		"borneosicyos",
		388288
	],
	[
		"s463176",
		"Bryonia acuta",
		"bryonia",
		463176
	],
	[
		"s243967",
		"Bryonia alba",
		"bryonia",
		243967
	],
	[
		"s463177",
		"Bryonia aspera",
		"bryonia",
		463177
	],
	[
		"s61884",
		"Bryonia cretica",
		"bryonia",
		61884
	],
	[
		"s3764289",
		"Bryonia flexuosa",
		"bryonia",
		3764289
	],
	[
		"s463178",
		"Bryonia lappifolia",
		"bryonia",
		463178
	],
	[
		"s463179",
		"Bryonia marmorata",
		"bryonia",
		463179
	],
	[
		"s463180",
		"Bryonia melanocarpa",
		"bryonia",
		463180
	],
	[
		"s463181",
		"Bryonia monoica",
		"bryonia",
		463181
	],
	[
		"s463182",
		"Bryonia multiflora",
		"bryonia",
		463182
	],
	[
		"s463185",
		"Bryonia syriaca",
		"bryonia",
		463185
	],
	[
		"s463186",
		"Bryonia verrucosa",
		"bryonia",
		463186
	],
	[
		"s3767763",
		"Calycophysum gracile",
		"calycophysum",
		3767763
	],
	[
		"s386142",
		"Calycophysum pedunculatum",
		"calycophysum",
		386142
	],
	[
		"s2893811",
		"Calycophysum spectabile",
		"calycophysum",
		2893811
	],
	[
		"s1343733",
		"Calycophysum weberbaueri",
		"calycophysum",
		1343733
	],
	[
		"s387125",
		"Cayaponia africana",
		"cayaponia",
		387125
	],
	[
		"s3769733",
		"Cayaponia alarici",
		"cayaponia",
		3769733
	],
	[
		"s760991",
		"Cayaponia amazonica",
		"cayaponia",
		760991
	],
	[
		"s386144",
		"Cayaponia americana",
		"cayaponia",
		386144
	],
	[
		"s760992",
		"Cayaponia attenuata",
		"cayaponia",
		760992
	],
	[
		"s760993",
		"Cayaponia austin-smithii",
		"cayaponia",
		760993
	],
	[
		"s3769734",
		"Cayaponia bidentata",
		"cayaponia",
		3769734
	],
	[
		"s3769735",
		"Cayaponia biflora",
		"cayaponia",
		3769735
	],
	[
		"s760994",
		"Cayaponia boliviensis",
		"cayaponia",
		760994
	],
	[
		"s760995",
		"Cayaponia bonariensis",
		"cayaponia",
		760995
	],
	[
		"s3769736",
		"Cayaponia bonplandii",
		"cayaponia",
		3769736
	],
	[
		"s3769737",
		"Cayaponia botryocarpa",
		"cayaponia",
		3769737
	],
	[
		"s3769738",
		"Cayaponia breviloba",
		"cayaponia",
		3769738
	],
	[
		"s760996",
		"Cayaponia buraeavii",
		"cayaponia",
		760996
	],
	[
		"s760997",
		"Cayaponia cabocla",
		"cayaponia",
		760997
	],
	[
		"s3769739",
		"Cayaponia capitata",
		"cayaponia",
		3769739
	],
	[
		"s3086239",
		"Cayaponia caulobotrys",
		"cayaponia",
		3086239
	],
	[
		"s760998",
		"Cayaponia citrullifolia",
		"cayaponia",
		760998
	],
	[
		"s3769740",
		"Cayaponia cogniauxiana",
		"cayaponia",
		3769740
	],
	[
		"s761016",
		"Cayaponia cordata",
		"cayaponia",
		761016
	],
	[
		"s3086240",
		"Cayaponia coriacea",
		"cayaponia",
		3086240
	],
	[
		"s760999",
		"Cayaponia cruegeri",
		"cayaponia",
		760999
	],
	[
		"s3769741",
		"Cayaponia denticulata",
		"cayaponia",
		3769741
	],
	[
		"s1343736",
		"Cayaponia domingensis",
		"cayaponia",
		1343736
	],
	[
		"s3769742",
		"Cayaponia duckei",
		"cayaponia",
		3769742
	],
	[
		"s761000",
		"Cayaponia espelina",
		"cayaponia",
		761e3
	],
	[
		"s3086241",
		"Cayaponia ferruginea",
		"cayaponia",
		3086241
	],
	[
		"s3086242",
		"Cayaponia floribunda",
		"cayaponia",
		3086242
	],
	[
		"s627482",
		"Cayaponia glandulosa",
		"cayaponia",
		627482
	],
	[
		"s3769743",
		"Cayaponia gracillima",
		"cayaponia",
		3769743
	],
	[
		"s1504166",
		"Cayaponia granatensis",
		"cayaponia",
		1504166
	],
	[
		"s3769744",
		"Cayaponia guianensis",
		"cayaponia",
		3769744
	],
	[
		"s3086243",
		"Cayaponia hammelii",
		"cayaponia",
		3086243
	],
	[
		"s761001",
		"Cayaponia jenmanii",
		"cayaponia",
		761001
	],
	[
		"s3769745",
		"Cayaponia kathematophora",
		"cayaponia",
		3769745
	],
	[
		"s3085943",
		"Cayaponia laciniosa",
		"cayaponia",
		3085943
	],
	[
		"s3769746",
		"Cayaponia laxa",
		"cayaponia",
		3769746
	],
	[
		"s3769747",
		"Cayaponia lhotzkyana",
		"cayaponia",
		3769747
	],
	[
		"s3769748",
		"Cayaponia longifolia",
		"cayaponia",
		3769748
	],
	[
		"s3086244",
		"Cayaponia longiloba",
		"cayaponia",
		3086244
	],
	[
		"s1125350",
		"Cayaponia macrocalyx",
		"cayaponia",
		1125350
	],
	[
		"s3086245",
		"Cayaponia martiana",
		"cayaponia",
		3086245
	],
	[
		"s3086246",
		"Cayaponia membranacea",
		"cayaponia",
		3086246
	],
	[
		"s761002",
		"Cayaponia micrantha",
		"cayaponia",
		761002
	],
	[
		"s3769749",
		"Cayaponia nitida",
		"cayaponia",
		3769749
	],
	[
		"s3769750",
		"Cayaponia noronhae",
		"cayaponia",
		3769750
	],
	[
		"s761003",
		"Cayaponia ophthalmica",
		"cayaponia",
		761003
	],
	[
		"s3769751",
		"Cayaponia oppositifolia",
		"cayaponia",
		3769751
	],
	[
		"s3769752",
		"Cayaponia ovata",
		"cayaponia",
		3769752
	],
	[
		"s761004",
		"Cayaponia palmata",
		"cayaponia",
		761004
	],
	[
		"s3769753",
		"Cayaponia pedata",
		"cayaponia",
		3769753
	],
	[
		"s3769754",
		"Cayaponia peruviana",
		"cayaponia",
		3769754
	],
	[
		"s3769755",
		"Cayaponia petiolulata",
		"cayaponia",
		3769755
	],
	[
		"s761005",
		"Cayaponia pilosa",
		"cayaponia",
		761005
	],
	[
		"s387126",
		"Cayaponia podantha",
		"cayaponia",
		387126
	],
	[
		"s386228",
		"Cayaponia prunifera",
		"cayaponia",
		386228
	],
	[
		"s761006",
		"Cayaponia quinqueloba",
		"cayaponia",
		761006
	],
	[
		"s761007",
		"Cayaponia racemosa",
		"cayaponia",
		761007
	],
	[
		"s761008",
		"Cayaponia rigida",
		"cayaponia",
		761008
	],
	[
		"s761009",
		"Cayaponia rugosa",
		"cayaponia",
		761009
	],
	[
		"s3769756",
		"Cayaponia ruizii",
		"cayaponia",
		3769756
	],
	[
		"s761010",
		"Cayaponia selysioides",
		"cayaponia",
		761010
	],
	[
		"s3769757",
		"Cayaponia sessiliflora",
		"cayaponia",
		3769757
	],
	[
		"s3769758",
		"Cayaponia simplicifolia",
		"cayaponia",
		3769758
	],
	[
		"s761017",
		"Cayaponia smithii",
		"cayaponia",
		761017
	],
	[
		"s3085944",
		"Cayaponia tayuya",
		"cayaponia",
		3085944
	],
	[
		"s3769759",
		"Cayaponia ternata",
		"cayaponia",
		3769759
	],
	[
		"s3769760",
		"Cayaponia tessmannii",
		"cayaponia",
		3769760
	],
	[
		"s3769761",
		"Cayaponia tibiricae",
		"cayaponia",
		3769761
	],
	[
		"s761012",
		"Cayaponia triangularis",
		"cayaponia",
		761012
	],
	[
		"s3769762",
		"Cayaponia trifoliolata",
		"cayaponia",
		3769762
	],
	[
		"s3769763",
		"Cayaponia trilobata",
		"cayaponia",
		3769763
	],
	[
		"s761013",
		"Cayaponia tubulosa",
		"cayaponia",
		761013
	],
	[
		"s3769764",
		"Cayaponia ulei",
		"cayaponia",
		3769764
	],
	[
		"s3769765",
		"Cayaponia villosissima",
		"cayaponia",
		3769765
	],
	[
		"s213597",
		"Cephalopentandra ecirrhosa",
		"cephalopentandra",
		213597
	],
	[
		"s3770988",
		"Ceratosanthes angustiloba",
		"ceratosanthes",
		3770988
	],
	[
		"s3770989",
		"Ceratosanthes cuneata",
		"ceratosanthes",
		3770989
	],
	[
		"s3086265",
		"Ceratosanthes hilariana",
		"ceratosanthes",
		3086265
	],
	[
		"s3770990",
		"Ceratosanthes humilis",
		"ceratosanthes",
		3770990
	],
	[
		"s3770991",
		"Ceratosanthes multiloba",
		"ceratosanthes",
		3770991
	],
	[
		"s386146",
		"Ceratosanthes palmata",
		"ceratosanthes",
		386146
	],
	[
		"s3770992",
		"Ceratosanthes parviflora",
		"ceratosanthes",
		3770992
	],
	[
		"s3770993",
		"Ceratosanthes rupicola",
		"ceratosanthes",
		3770993
	],
	[
		"s3086266",
		"Ceratosanthes tomentosa",
		"ceratosanthes",
		3086266
	],
	[
		"s3770994",
		"Ceratosanthes trifoliata",
		"ceratosanthes",
		3770994
	],
	[
		"s3770995",
		"Ceratosanthes warmingii",
		"ceratosanthes",
		3770995
	],
	[
		"s931227",
		"Cionosicys excisus",
		"cionosicys",
		931227
	],
	[
		"s761188",
		"Cionosicys guabubu",
		"cionosicys",
		761188
	],
	[
		"s386150",
		"Cionosicys macranthus",
		"cionosicys",
		386150
	],
	[
		"s1343734",
		"Cionosicys pomiformis",
		"cionosicys",
		1343734
	],
	[
		"s1567104",
		"Citrullus amarus",
		"citrullus",
		1567104
	],
	[
		"s252529",
		"Citrullus colocynthis",
		"citrullus",
		252529
	],
	[
		"s433968",
		"Citrullus colocynthis x Citrullus lanatus var. lanatus",
		"citrullus",
		433968
	],
	[
		"s260672",
		"Citrullus ecirrhosus",
		"citrullus",
		260672
	],
	[
		"s3654",
		"Citrullus lanatus",
		"citrullus",
		3654
	],
	[
		"s2975461",
		"Citrullus lanatus x Citrullus amarus",
		"citrullus",
		2975461
	],
	[
		"s519315",
		"Citrullus mucosospermus",
		"citrullus",
		519315
	],
	[
		"s252528",
		"Citrullus naudinianus",
		"citrullus",
		252528
	],
	[
		"s260675",
		"Citrullus rehmii",
		"citrullus",
		260675
	],
	[
		"s929719",
		"Coccinia abyssinica",
		"coccinia",
		929719
	],
	[
		"s213599",
		"Coccinia adoensis",
		"coccinia",
		213599
	],
	[
		"s929723",
		"Coccinia barteri",
		"coccinia",
		929723
	],
	[
		"s929724",
		"Coccinia grandiflora",
		"coccinia",
		929724
	],
	[
		"s387127",
		"Coccinia grandis",
		"coccinia",
		387127
	],
	[
		"s929742",
		"Coccinia grandis x Coccinia pwaniensis",
		"coccinia",
		929742
	],
	[
		"s989178",
		"Coccinia heterophylla",
		"coccinia",
		989178
	],
	[
		"s929726",
		"Coccinia hirtella",
		"coccinia",
		929726
	],
	[
		"s1091429",
		"Coccinia intermedia",
		"coccinia",
		1091429
	],
	[
		"s519317",
		"Coccinia keayana",
		"coccinia",
		519317
	],
	[
		"s3778840",
		"Coccinia lalambensis",
		"coccinia",
		3778840
	],
	[
		"s519316",
		"Coccinia longicarpa",
		"coccinia",
		519316
	],
	[
		"s3778841",
		"Coccinia longipetiolata",
		"coccinia",
		3778841
	],
	[
		"s929727",
		"Coccinia mackenii",
		"coccinia",
		929727
	],
	[
		"s929728",
		"Coccinia megarrhiza",
		"coccinia",
		929728
	],
	[
		"s929729",
		"Coccinia microphylla",
		"coccinia",
		929729
	],
	[
		"s929730",
		"Coccinia mildbraedii",
		"coccinia",
		929730
	],
	[
		"s929731",
		"Coccinia ogadensis",
		"coccinia",
		929731
	],
	[
		"s252526",
		"Coccinia palmata",
		"coccinia",
		252526
	],
	[
		"s929725",
		"Coccinia pwaniensis",
		"coccinia",
		929725
	],
	[
		"s929733",
		"Coccinia quinqueloba",
		"coccinia",
		929733
	],
	[
		"s929734",
		"Coccinia racemiflora",
		"coccinia",
		929734
	],
	[
		"s386151",
		"Coccinia rehmannii",
		"coccinia",
		386151
	],
	[
		"s929735",
		"Coccinia samburuensis",
		"coccinia",
		929735
	],
	[
		"s929736",
		"Coccinia schliebenii",
		"coccinia",
		929736
	],
	[
		"s929737",
		"Coccinia senensis",
		"coccinia",
		929737
	],
	[
		"s328384",
		"Coccinia sessilifolia",
		"coccinia",
		328384
	],
	[
		"s3778842",
		"Coccinia subglabra",
		"coccinia",
		3778842
	],
	[
		"s929739",
		"Coccinia subsessiliflora",
		"coccinia",
		929739
	],
	[
		"s929740",
		"Coccinia trilobata",
		"coccinia",
		929740
	],
	[
		"s386153",
		"Cogniauxia podolaena",
		"cogniauxia",
		386153
	],
	[
		"s515854",
		"Cogniauxia trilobata",
		"cogniauxia",
		515854
	],
	[
		"s61144",
		"Combretocarpus rotundatus",
		"combretocarpus",
		61144
	],
	[
		"s62976",
		"Corallocarpus bainesii",
		"corallocarpus",
		62976
	],
	[
		"s386154",
		"Corallocarpus boehmii",
		"corallocarpus",
		386154
	],
	[
		"s3782168",
		"Corallocarpus conocarpus",
		"corallocarpus",
		3782168
	],
	[
		"s3782169",
		"Corallocarpus dissectus",
		"corallocarpus",
		3782169
	],
	[
		"s3782170",
		"Corallocarpus ellipticus",
		"corallocarpus",
		3782170
	],
	[
		"s519325",
		"Corallocarpus epigaeus",
		"corallocarpus",
		519325
	],
	[
		"s2726051",
		"Corallocarpus glomeruliflorus",
		"corallocarpus",
		2726051
	],
	[
		"s3782171",
		"Corallocarpus grevei",
		"corallocarpus",
		3782171
	],
	[
		"s3782172",
		"Corallocarpus perrieri",
		"corallocarpus",
		3782172
	],
	[
		"s3782173",
		"Corallocarpus poissonii",
		"corallocarpus",
		3782173
	],
	[
		"s1670845",
		"Corallocarpus schimperi",
		"corallocarpus",
		1670845
	],
	[
		"s3782174",
		"Corallocarpus schinzii",
		"corallocarpus",
		3782174
	],
	[
		"s3782175",
		"Corallocarpus tenuissimus",
		"corallocarpus",
		3782175
	],
	[
		"s515855",
		"Corallocarpus triangularis",
		"corallocarpus",
		515855
	],
	[
		"s931228",
		"Corallocarpus welwitschii",
		"corallocarpus",
		931228
	],
	[
		"s150727",
		"Coriaria angustissima",
		"coriaria",
		150727
	],
	[
		"s48248",
		"Coriaria arborea",
		"coriaria",
		48248
	],
	[
		"s3782450",
		"Coriaria duthiei",
		"coriaria",
		3782450
	],
	[
		"s79756",
		"Coriaria intermedia",
		"coriaria",
		79756
	],
	[
		"s79757",
		"Coriaria japonica",
		"coriaria",
		79757
	],
	[
		"s2724478",
		"Coriaria kingiana",
		"coriaria",
		2724478
	],
	[
		"s79758",
		"Coriaria lurida",
		"coriaria",
		79758
	],
	[
		"s79759",
		"Coriaria microphylla",
		"coriaria",
		79759
	],
	[
		"s3460",
		"Coriaria myrtifolia",
		"coriaria",
		3460
	],
	[
		"s2807205",
		"Coriaria napalensis",
		"coriaria",
		2807205
	],
	[
		"s79760",
		"Coriaria nepalensis",
		"coriaria",
		79760
	],
	[
		"s79761",
		"Coriaria papuana",
		"coriaria",
		79761
	],
	[
		"s2724479",
		"Coriaria plumosa",
		"coriaria",
		2724479
	],
	[
		"s3782451",
		"Coriaria pottsiana",
		"coriaria",
		3782451
	],
	[
		"s2724480",
		"Coriaria pteridoides",
		"coriaria",
		2724480
	],
	[
		"s79762",
		"Coriaria ruscifolia",
		"coriaria",
		79762
	],
	[
		"s79765",
		"Coriaria sarmentosa",
		"coriaria",
		79765
	],
	[
		"s79766",
		"Coriaria terminalis",
		"coriaria",
		79766
	],
	[
		"s95444",
		"Corynocarpus cribbianus",
		"corynocarpus",
		95444
	],
	[
		"s95445",
		"Corynocarpus dissimilis",
		"corynocarpus",
		95445
	],
	[
		"s4312",
		"Corynocarpus laevigatus",
		"corynocarpus",
		4312
	],
	[
		"s95446",
		"Corynocarpus rupestris",
		"corynocarpus",
		95446
	],
	[
		"s95448",
		"Corynocarpus similis",
		"corynocarpus",
		95448
	],
	[
		"s442819",
		"Cucumis aculeatus",
		"cucumis",
		442819
	],
	[
		"s3786328",
		"Cucumis aetheocarpus",
		"cucumis",
		3786328
	],
	[
		"s217618",
		"Cucumis africanus",
		"cucumis",
		217618
	],
	[
		"s3786329",
		"Cucumis afrotropicus",
		"cucumis",
		3786329
	],
	[
		"s869935",
		"Cucumis althaeoides",
		"cucumis",
		869935
	],
	[
		"s39473",
		"Cucumis anguria",
		"cucumis",
		39473
	],
	[
		"s869937",
		"Cucumis argenteus",
		"cucumis",
		869937
	],
	[
		"s396992",
		"Cucumis asper",
		"cucumis",
		396992
	],
	[
		"s442821",
		"Cucumis baladensis",
		"cucumis",
		442821
	],
	[
		"s309180",
		"Cucumis bryoniifolius",
		"cucumis",
		309180
	],
	[
		"s442822",
		"Cucumis canoxyi",
		"cucumis",
		442822
	],
	[
		"s217620",
		"Cucumis carolinus",
		"cucumis",
		217620
	],
	[
		"s442817",
		"Cucumis cinereus",
		"cucumis",
		442817
	],
	[
		"s2081796",
		"Cucumis clavipetiolatus",
		"cucumis",
		2081796
	],
	[
		"s869963",
		"Cucumis costatus",
		"cucumis",
		869963
	],
	[
		"s869828",
		"Cucumis debilis",
		"cucumis",
		869828
	],
	[
		"s217621",
		"Cucumis dinteri",
		"cucumis",
		217621
	],
	[
		"s61885",
		"Cucumis dipsaceus",
		"cucumis",
		61885
	],
	[
		"s3786330",
		"Cucumis engleri",
		"cucumis",
		3786330
	],
	[
		"s131071",
		"Cucumis ficifolius",
		"cucumis",
		131071
	],
	[
		"s217623",
		"Cucumis globosus",
		"cucumis",
		217623
	],
	[
		"s870212",
		"Cucumis gracilis",
		"cucumis",
		870212
	],
	[
		"s442823",
		"Cucumis hastatus",
		"cucumis",
		442823
	],
	[
		"s217624",
		"Cucumis heptadactylis",
		"cucumis",
		217624
	],
	[
		"s386155",
		"Cucumis hirsutus",
		"cucumis",
		386155
	],
	[
		"s396993",
		"Cucumis humifructus",
		"cucumis",
		396993
	],
	[
		"s3086497",
		"Cucumis humofructus",
		"cucumis",
		3086497
	],
	[
		"s396994",
		"Cucumis hystrix",
		"cucumis",
		396994
	],
	[
		"s869829",
		"Cucumis indicus",
		"cucumis",
		869829
	],
	[
		"s442824",
		"Cucumis insignis",
		"cucumis",
		442824
	],
	[
		"s418467",
		"Cucumis javanicus",
		"cucumis",
		418467
	],
	[
		"s3786331",
		"Cucumis jeffreyanus",
		"cucumis",
		3786331
	],
	[
		"s442825",
		"Cucumis kalahariensis",
		"cucumis",
		442825
	],
	[
		"s442818",
		"Cucumis kelleri",
		"cucumis",
		442818
	],
	[
		"s3786332",
		"Cucumis kirkbridei",
		"cucumis",
		3786332
	],
	[
		"s869830",
		"Cucumis leiospermus",
		"cucumis",
		869830
	],
	[
		"s386199",
		"Cucumis maderaspatanus",
		"cucumis",
		386199
	],
	[
		"s217626",
		"Cucumis meeusei",
		"cucumis",
		217626
	],
	[
		"s3656",
		"Cucumis melo",
		"cucumis",
		3656
	],
	[
		"s2761048",
		"Cucumis melo var. makuwa x (Cucurbita mixta x C. moschata)",
		"cucumisxcucurbita",
		2761048
	],
	[
		"s454233",
		"Cucumis melo x Cucurbita moschata",
		"cucumisxcucurbita",
		454233
	],
	[
		"s388299",
		"Cucumis messorius",
		"cucumis",
		388299
	],
	[
		"s61886",
		"Cucumis metuliferus",
		"cucumis",
		61886
	],
	[
		"s39474",
		"Cucumis myriocarpus",
		"cucumis",
		39474
	],
	[
		"s2528464",
		"Cucumis omissus",
		"cucumis",
		2528464
	],
	[
		"s217625",
		"Cucumis oreosyce",
		"cucumis",
		217625
	],
	[
		"s869832",
		"Cucumis picrocarpus",
		"cucumis",
		869832
	],
	[
		"s217627",
		"Cucumis prophetarum",
		"cucumis",
		217627
	],
	[
		"s217628",
		"Cucumis pubescens",
		"cucumis",
		217628
	],
	[
		"s442826",
		"Cucumis pubituberculatus",
		"cucumis",
		442826
	],
	[
		"s217629",
		"Cucumis pustulatus",
		"cucumis",
		217629
	],
	[
		"s869953",
		"Cucumis queenslandicus",
		"cucumis",
		869953
	],
	[
		"s442827",
		"Cucumis quintanilhae",
		"cucumis",
		442827
	],
	[
		"s3786333",
		"Cucumis reticulatus",
		"cucumis",
		3786333
	],
	[
		"s442828",
		"Cucumis rigidus",
		"cucumis",
		442828
	],
	[
		"s386161",
		"Cucumis ritchiei",
		"cucumis",
		386161
	],
	[
		"s442829",
		"Cucumis rostratus",
		"cucumis",
		442829
	],
	[
		"s424441",
		"Cucumis rumphianus",
		"cucumis",
		424441
	],
	[
		"s396997",
		"Cucumis sacleuxii",
		"cucumis",
		396997
	],
	[
		"s217630",
		"Cucumis sagittatus",
		"cucumis",
		217630
	],
	[
		"s3659",
		"Cucumis sativus",
		"cucumis",
		3659
	],
	[
		"s869881",
		"Cucumis setosus",
		"cucumis",
		869881
	],
	[
		"s869882",
		"Cucumis silentvalleyi",
		"cucumis",
		869882
	],
	[
		"s2082093",
		"Cucumis subsericeus",
		"cucumis",
		2082093
	],
	[
		"s442830",
		"Cucumis thulinianus",
		"cucumis",
		442830
	],
	[
		"s217631",
		"Cucumis trigonus",
		"cucumis",
		217631
	],
	[
		"s869961",
		"Cucumis umbellatus",
		"cucumis",
		869961
	],
	[
		"s869952",
		"Cucumis variabilis",
		"cucumis",
		869952
	],
	[
		"s442738",
		"Cucumis x hytivus",
		"cucumis",
		442738
	],
	[
		"s2081800",
		"Cucumis zambianus",
		"cucumis",
		2081800
	],
	[
		"s61887",
		"Cucumis zeyherii",
		"cucumis",
		61887
	],
	[
		"s34294",
		"Cucurbita argyrosperma",
		"cucurbita",
		34294
	],
	[
		"s1094862",
		"Cucurbita cordata",
		"cucurbita",
		1094862
	],
	[
		"s3086498",
		"Cucurbita cylindrata",
		"cucurbita",
		3086498
	],
	[
		"s200225",
		"Cucurbita digitata",
		"cucurbita",
		200225
	],
	[
		"s184135",
		"Cucurbita ecuadorensis",
		"cucurbita",
		184135
	],
	[
		"s37645",
		"Cucurbita ficifolia",
		"cucurbita",
		37645
	],
	[
		"s184136",
		"Cucurbita foetidissima",
		"cucurbita",
		184136
	],
	[
		"s3786334",
		"Cucurbita galeottii",
		"cucurbita",
		3786334
	],
	[
		"s170850",
		"Cucurbita hybrid cultivar",
		"cucurbita",
		170850
	],
	[
		"s37650",
		"Cucurbita lundelliana",
		"cucurbita",
		37650
	],
	[
		"s3661",
		"Cucurbita maxima",
		"cucurbita",
		3661
	],
	[
		"s334420",
		"Cucurbita maxima x Cucurbita moschata",
		"cucurbita",
		334420
	],
	[
		"s3665",
		"Cucurbita melopepo",
		"cucurbita",
		3665
	],
	[
		"s37646",
		"Cucurbita mixta",
		"cucurbita",
		37646
	],
	[
		"s3662",
		"Cucurbita moschata",
		"cucurbita",
		3662
	],
	[
		"s184137",
		"Cucurbita okeechobeensis",
		"cucurbita",
		184137
	],
	[
		"s931229",
		"Cucurbita palmata",
		"cucurbita",
		931229
	],
	[
		"s37647",
		"Cucurbita pedatifolia",
		"cucurbita",
		37647
	],
	[
		"s3663",
		"Cucurbita pepo",
		"cucurbita",
		3663
	],
	[
		"s2591908",
		"Cucurbita pepo subsp. pepo x Cucurbita melopepo subsp. texana var. fraterna",
		"cucurbita",
		2591908
	],
	[
		"s2302873",
		"Cucurbita radicans",
		"cucurbita",
		2302873
	],
	[
		"s3053777",
		"Cucurbita scabridifolia",
		"cucurbita",
		3053777
	],
	[
		"s386157",
		"Cucurbitella asperata",
		"cucurbitella",
		386157
	],
	[
		"s627483",
		"Cyclanthera brachybotrys",
		"cyclanthera",
		627483
	],
	[
		"s61892",
		"Cyclanthera brachystachya",
		"cyclanthera",
		61892
	],
	[
		"s3743366",
		"Cyclanthera brevisetosa",
		"cyclanthera",
		3743366
	],
	[
		"s1129543",
		"Cyclanthera carthagenensis",
		"cyclanthera",
		1129543
	],
	[
		"s3743367",
		"Cyclanthera cogniauxii",
		"cyclanthera",
		3743367
	],
	[
		"s1568992",
		"Cyclanthera cordifolia",
		"cyclanthera",
		1568992
	],
	[
		"s3743368",
		"Cyclanthera dieterleana",
		"cyclanthera",
		3743368
	],
	[
		"s3743369",
		"Cyclanthera dioscoreoides",
		"cyclanthera",
		3743369
	],
	[
		"s3085979",
		"Cyclanthera dissecta",
		"cyclanthera",
		3085979
	],
	[
		"s3086500",
		"Cyclanthera dressleri",
		"cyclanthera",
		3086500
	],
	[
		"s3743370",
		"Cyclanthera entata",
		"cyclanthera",
		3743370
	],
	[
		"s3743371",
		"Cyclanthera gracillima",
		"cyclanthera",
		3743371
	],
	[
		"s3743372",
		"Cyclanthera hastata",
		"cyclanthera",
		3743372
	],
	[
		"s3743373",
		"Cyclanthera heiseri",
		"cyclanthera",
		3743373
	],
	[
		"s3086501",
		"Cyclanthera integrifoliola",
		"cyclanthera",
		3086501
	],
	[
		"s3086502",
		"Cyclanthera jonesii",
		"cyclanthera",
		3086502
	],
	[
		"s3743374",
		"Cyclanthera lalajuela",
		"cyclanthera",
		3743374
	],
	[
		"s627484",
		"Cyclanthera langaei",
		"cyclanthera",
		627484
	],
	[
		"s3086503",
		"Cyclanthera leptostachya",
		"cyclanthera",
		3086503
	],
	[
		"s3086504",
		"Cyclanthera leptostachyoides",
		"cyclanthera",
		3086504
	],
	[
		"s3743375",
		"Cyclanthera longiflora",
		"cyclanthera",
		3743375
	],
	[
		"s2893872",
		"Cyclanthera longisepala",
		"cyclanthera",
		2893872
	],
	[
		"s3743376",
		"Cyclanthera macropoda",
		"cyclanthera",
		3743376
	],
	[
		"s2726056",
		"Cyclanthera mathewsii",
		"cyclanthera",
		2726056
	],
	[
		"s3085975",
		"Cyclanthera minima",
		"cyclanthera",
		3085975
	],
	[
		"s3743377",
		"Cyclanthera monticola",
		"cyclanthera",
		3743377
	],
	[
		"s3086505",
		"Cyclanthera multifoliola",
		"cyclanthera",
		3086505
	],
	[
		"s3743378",
		"Cyclanthera naudiniana",
		"cyclanthera",
		3743378
	],
	[
		"s3743379",
		"Cyclanthera oligoechinata",
		"cyclanthera",
		3743379
	],
	[
		"s198836",
		"Cyclanthera pedata",
		"cyclanthera",
		198836
	],
	[
		"s3092049",
		"Cyclanthera peruana",
		"cyclanthera",
		3092049
	],
	[
		"s3743380",
		"Cyclanthera phyllantha",
		"cyclanthera",
		3743380
	],
	[
		"s3091450",
		"Cyclanthera quadrifida",
		"cyclanthera",
		3091450
	],
	[
		"s3743381",
		"Cyclanthera quinquelobata",
		"cyclanthera",
		3743381
	],
	[
		"s3085980",
		"Cyclanthera ribiflora",
		"cyclanthera",
		3085980
	],
	[
		"s3743382",
		"Cyclanthera rostrata",
		"cyclanthera",
		3743382
	],
	[
		"s3743383",
		"Cyclanthera stenura",
		"cyclanthera",
		3743383
	],
	[
		"s3086506",
		"Cyclanthera steyermarkii",
		"cyclanthera",
		3086506
	],
	[
		"s2894911",
		"Cyclanthera tamnifolia",
		"cyclanthera",
		2894911
	],
	[
		"s3085981",
		"Cyclanthera tamnoides",
		"cyclanthera",
		3085981
	],
	[
		"s3086507",
		"Cyclanthera tenuifolia",
		"cyclanthera",
		3086507
	],
	[
		"s3086508",
		"Cyclanthera tenuisepala",
		"cyclanthera",
		3086508
	],
	[
		"s519328",
		"Cyclanthera tonduzii",
		"cyclanthera",
		519328
	],
	[
		"s3086509",
		"Cyclantheropsis madagascariensis",
		"cyclantheropsis",
		3086509
	],
	[
		"s3786895",
		"Cyclantheropsis occidentalis",
		"cyclantheropsis",
		3786895
	],
	[
		"s387129",
		"Cyclantheropsis parviflora",
		"cyclantheropsis",
		387129
	],
	[
		"s1932178",
		"Dactyliandra stefaninii",
		"dactyliandra",
		1932178
	],
	[
		"s386159",
		"Dactyliandra welwitschii",
		"dactyliandra",
		386159
	],
	[
		"s34296",
		"Datisca cannabina",
		"datisca",
		34296
	],
	[
		"s34297",
		"Datisca glomerata",
		"datisca",
		34297
	],
	[
		"s229694",
		"Dendrosicyos socotranus",
		"dendrosicyos",
		229694
	],
	[
		"s3793869",
		"Diplocyclos decipiens",
		"diplocyclos",
		3793869
	],
	[
		"s3793870",
		"Diplocyclos leiocarpus",
		"diplocyclos",
		3793870
	],
	[
		"s252525",
		"Diplocyclos palmatus",
		"diplocyclos",
		252525
	],
	[
		"s929741",
		"Diplocyclos schliebenii",
		"diplocyclos",
		929741
	],
	[
		"s3793871",
		"Diplocyclos tenuis",
		"diplocyclos",
		3793871
	],
	[
		"s388290",
		"Doyerea emetocathartica",
		"doyerea",
		388290
	],
	[
		"s3679",
		"Ecballium elaterium",
		"ecballium",
		3679
	],
	[
		"s252533",
		"Echinocystis lobata",
		"echinocystis",
		252533
	],
	[
		"s386134",
		"Echinopepon arachoideus",
		"echinopepon",
		386134
	],
	[
		"s3796481",
		"Echinopepon belizensis",
		"echinopepon",
		3796481
	],
	[
		"s386140",
		"Echinopepon bigelovii",
		"echinopepon",
		386140
	],
	[
		"s3796482",
		"Echinopepon calcitrapa",
		"echinopepon",
		3796482
	],
	[
		"s3086685",
		"Echinopepon cirrhopedunculatus",
		"echinopepon",
		3086685
	],
	[
		"s3086038",
		"Echinopepon coulteri",
		"echinopepon",
		3086038
	],
	[
		"s3796483",
		"Echinopepon disjunctus",
		"echinopepon",
		3796483
	],
	[
		"s386251",
		"Echinopepon insularis",
		"echinopepon",
		386251
	],
	[
		"s3086686",
		"Echinopepon jaliscanus",
		"echinopepon",
		3086686
	],
	[
		"s3796484",
		"Echinopepon longispinus",
		"echinopepon",
		3796484
	],
	[
		"s2885561",
		"Echinopepon milleflorus",
		"echinopepon",
		2885561
	],
	[
		"s3086039",
		"Echinopepon minimus",
		"echinopepon",
		3086039
	],
	[
		"s3086687",
		"Echinopepon palmeri",
		"echinopepon",
		3086687
	],
	[
		"s386165",
		"Echinopepon paniculatus",
		"echinopepon",
		386165
	],
	[
		"s3086688",
		"Echinopepon pringlei",
		"echinopepon",
		3086688
	],
	[
		"s3086040",
		"Echinopepon pubescens",
		"echinopepon",
		3086040
	],
	[
		"s387130",
		"Echinopepon racemosus",
		"echinopepon",
		387130
	],
	[
		"s3796485",
		"Echinopepon rosei",
		"echinopepon",
		3796485
	],
	[
		"s3086041",
		"Echinopepon torquatus",
		"echinopepon",
		3086041
	],
	[
		"s3796486",
		"Echinopepon tultitlanapaensis",
		"echinopepon",
		3796486
	],
	[
		"s61889",
		"Echinopepon wrightii",
		"echinopepon",
		61889
	],
	[
		"s3806485",
		"Eureiandra balfourii",
		"eureiandra",
		3806485
	],
	[
		"s3806486",
		"Eureiandra cogniauxii",
		"eureiandra",
		3806486
	],
	[
		"s2895315",
		"Eureiandra eburnea",
		"eureiandra",
		2895315
	],
	[
		"s3086048",
		"Eureiandra fasciculata",
		"eureiandra",
		3086048
	],
	[
		"s386169",
		"Eureiandra formosa",
		"eureiandra",
		386169
	],
	[
		"s3806487",
		"Eureiandra lasiandra",
		"eureiandra",
		3806487
	],
	[
		"s3806488",
		"Eureiandra leucantha",
		"eureiandra",
		3806488
	],
	[
		"s3806489",
		"Eureiandra somalensis",
		"eureiandra",
		3806489
	],
	[
		"s637376",
		"Fevillea anomalosperma",
		"fevillea",
		637376
	],
	[
		"s3086817",
		"Fevillea bahiensis",
		"fevillea",
		3086817
	],
	[
		"s931232",
		"Fevillea cordifolia",
		"fevillea",
		931232
	],
	[
		"s3807717",
		"Fevillea narae",
		"fevillea",
		3807717
	],
	[
		"s515857",
		"Fevillea pedatifolia",
		"fevillea",
		515857
	],
	[
		"s386171",
		"Fevillea pergamentacea",
		"fevillea",
		386171
	],
	[
		"s515858",
		"Fevillea trilobata",
		"fevillea",
		515858
	],
	[
		"s1132095",
		"Frantzia panamensis",
		"frantzia",
		1132095
	],
	[
		"s517551",
		"Frantzia pittieri",
		"frantzia",
		517551
	],
	[
		"s515860",
		"Frantzia tacaco",
		"frantzia",
		515860
	],
	[
		"s1132096",
		"Frantzia talamancensis",
		"frantzia",
		1132096
	],
	[
		"s1132097",
		"Frantzia venosa",
		"frantzia",
		1132097
	],
	[
		"s1132098",
		"Frantzia villosa",
		"frantzia",
		1132098
	],
	[
		"s446182",
		"Gerrardanthus grandiflorus",
		"gerrardanthus",
		446182
	],
	[
		"s931233",
		"Gerrardanthus lobatus",
		"gerrardanthus",
		931233
	],
	[
		"s386173",
		"Gerrardanthus macrorhizus",
		"gerrardanthus",
		386173
	],
	[
		"s515861",
		"Gerrardanthus paniculatus",
		"gerrardanthus",
		515861
	],
	[
		"s3811992",
		"Gerrardanthus tomentosus",
		"gerrardanthus",
		3811992
	],
	[
		"s3813260",
		"Gomphogyne bonii",
		"gomphogyne",
		3813260
	],
	[
		"s447109",
		"Gomphogyne cissiformis",
		"gomphogyne",
		447109
	],
	[
		"s64234",
		"Gomphogyne heterosperma",
		"gomphogyne",
		64234
	],
	[
		"s3813261",
		"Gomphogyne longgangensis",
		"gomphogyne",
		3813261
	],
	[
		"s3813262",
		"Gomphogyne nepalensis",
		"gomphogyne",
		3813262
	],
	[
		"s3813263",
		"Gomphogyne stenocarpa",
		"gomphogyne",
		3813263
	],
	[
		"s627485",
		"Gurania acuminata",
		"gurania",
		627485
	],
	[
		"s3814531",
		"Gurania brevipedunculata",
		"gurania",
		3814531
	],
	[
		"s3814532",
		"Gurania calathina",
		"gurania",
		3814532
	],
	[
		"s3814533",
		"Gurania candolleana",
		"gurania",
		3814533
	],
	[
		"s3814534",
		"Gurania capitata",
		"gurania",
		3814534
	],
	[
		"s3814535",
		"Gurania cinerea",
		"gurania",
		3814535
	],
	[
		"s3089878",
		"Gurania coccinea",
		"gurania",
		3089878
	],
	[
		"s3814536",
		"Gurania cogniauxiana",
		"gurania",
		3814536
	],
	[
		"s501917",
		"Gurania costaricensis",
		"gurania",
		501917
	],
	[
		"s3814537",
		"Gurania crinita",
		"gurania",
		3814537
	],
	[
		"s627486",
		"Gurania eriantha",
		"gurania",
		627486
	],
	[
		"s3814538",
		"Gurania gracilis",
		"gurania",
		3814538
	],
	[
		"s3814539",
		"Gurania guentheri",
		"gurania",
		3814539
	],
	[
		"s3089879",
		"Gurania huberi",
		"gurania",
		3089879
	],
	[
		"s3089880",
		"Gurania huebneri",
		"gurania",
		3089880
	],
	[
		"s703178",
		"Gurania insolita",
		"gurania",
		703178
	],
	[
		"s3814540",
		"Gurania jeffreyi",
		"gurania",
		3814540
	],
	[
		"s1076880",
		"Gurania killipii",
		"gurania",
		1076880
	],
	[
		"s3814541",
		"Gurania lignosa",
		"gurania",
		3814541
	],
	[
		"s703179",
		"Gurania lobata",
		"gurania",
		703179
	],
	[
		"s3814542",
		"Gurania longiflora",
		"gurania",
		3814542
	],
	[
		"s3814543",
		"Gurania longipetala",
		"gurania",
		3814543
	],
	[
		"s872001",
		"Gurania macrophylla",
		"gurania",
		872001
	],
	[
		"s213601",
		"Gurania makoyana",
		"gurania",
		213601
	],
	[
		"s3814544",
		"Gurania malacophylla",
		"gurania",
		3814544
	],
	[
		"s229678",
		"Gurania megistantha",
		"gurania",
		229678
	],
	[
		"s3814545",
		"Gurania neei",
		"gurania",
		3814545
	],
	[
		"s3814546",
		"Gurania nigrescens",
		"gurania",
		3814546
	],
	[
		"s3814547",
		"Gurania ovata",
		"gurania",
		3814547
	],
	[
		"s3814548",
		"Gurania oxyphylla",
		"gurania",
		3814548
	],
	[
		"s3814549",
		"Gurania paulista",
		"gurania",
		3814549
	],
	[
		"s1421039",
		"Gurania pedata",
		"gurania",
		1421039
	],
	[
		"s3814550",
		"Gurania pseudospinulosa",
		"gurania",
		3814550
	],
	[
		"s3814551",
		"Gurania pycnocephala",
		"gurania",
		3814551
	],
	[
		"s627487",
		"Gurania reticulata",
		"gurania",
		627487
	],
	[
		"s1568998",
		"Gurania rhizantha",
		"gurania",
		1568998
	],
	[
		"s1953767",
		"Gurania robusta",
		"gurania",
		1953767
	],
	[
		"s3814552",
		"Gurania rufipila",
		"gurania",
		3814552
	],
	[
		"s3814553",
		"Gurania sellowiana",
		"gurania",
		3814553
	],
	[
		"s3814554",
		"Gurania simplicifolia",
		"gurania",
		3814554
	],
	[
		"s3814555",
		"Gurania sinuata",
		"gurania",
		3814555
	],
	[
		"s3814556",
		"Gurania smithii",
		"gurania",
		3814556
	],
	[
		"s386174",
		"Gurania spinulosa",
		"gurania",
		386174
	],
	[
		"s3814557",
		"Gurania spruceana",
		"gurania",
		3814557
	],
	[
		"s3814558",
		"Gurania suberosa",
		"gurania",
		3814558
	],
	[
		"s627488",
		"Gurania subumbellata",
		"gurania",
		627488
	],
	[
		"s3814559",
		"Gurania trialata",
		"gurania",
		3814559
	],
	[
		"s3089881",
		"Gurania tricuspidata",
		"gurania",
		3089881
	],
	[
		"s328385",
		"Gurania tubulosa",
		"gurania",
		328385
	],
	[
		"s3814560",
		"Gurania vaupesana",
		"gurania",
		3814560
	],
	[
		"s3814561",
		"Gurania velutina",
		"gurania",
		3814561
	],
	[
		"s3814562",
		"Gurania villosa",
		"gurania",
		3814562
	],
	[
		"s3814563",
		"Gurania wawrae",
		"gurania",
		3814563
	],
	[
		"s486424",
		"Gymnopetalum chinense",
		"gymnopetalum",
		486424
	],
	[
		"s1898928",
		"Gymnopetalum cochinchinense",
		"gymnopetalum",
		1898928
	],
	[
		"s386178",
		"Gymnopetalum integrifolium",
		"gymnopetalum",
		386178
	],
	[
		"s1144425",
		"Gymnopetalum orientale",
		"gymnopetalum",
		1144425
	],
	[
		"s931234",
		"Gymnopetalum scabrum",
		"gymnopetalum",
		931234
	],
	[
		"s2726057",
		"Gynostemma aggregatum",
		"gynostemma",
		2726057
	],
	[
		"s1348122",
		"Gynostemma burmanicum (nom. inval.)",
		"gynostemma",
		1348122
	],
	[
		"s1739658",
		"Gynostemma cardiospermum",
		"gynostemma",
		1739658
	],
	[
		"s1592219",
		"Gynostemma caulopterum",
		"gynostemma",
		1592219
	],
	[
		"s1348125",
		"Gynostemma compressum",
		"gynostemma",
		1348125
	],
	[
		"s1348126",
		"Gynostemma guangxiense",
		"gynostemma",
		1348126
	],
	[
		"s3815107",
		"Gynostemma intermedium",
		"gynostemma",
		3815107
	],
	[
		"s2041848",
		"Gynostemma laxiflorum",
		"gynostemma",
		2041848
	],
	[
		"s1348127",
		"Gynostemma laxum",
		"gynostemma",
		1348127
	],
	[
		"s555431",
		"Gynostemma longipes",
		"gynostemma",
		555431
	],
	[
		"s1348128",
		"Gynostemma microspermum",
		"gynostemma",
		1348128
	],
	[
		"s3815108",
		"Gynostemma pallidinerve",
		"gynostemma",
		3815108
	],
	[
		"s3815109",
		"Gynostemma papuanum",
		"gynostemma",
		3815109
	],
	[
		"s555432",
		"Gynostemma pentagynum",
		"gynostemma",
		555432
	],
	[
		"s182084",
		"Gynostemma pentaphyllum",
		"gynostemma",
		182084
	],
	[
		"s2041849",
		"Gynostemma pubescens",
		"gynostemma",
		2041849
	],
	[
		"s2959665",
		"Gynostemma simplicifolium",
		"gynostemma",
		2959665
	],
	[
		"s3126534",
		"Gynostemma verrucosum",
		"gynostemma",
		3126534
	],
	[
		"s555433",
		"Gynostemma yixingense",
		"gynostemma",
		555433
	],
	[
		"s3815110",
		"Gynostemma zhejiangense",
		"gynostemma",
		3815110
	],
	[
		"s388294",
		"Halosicyos ragonesei",
		"halosicyos",
		388294
	],
	[
		"s3816113",
		"Hanburia caracasana",
		"hanburia",
		3816113
	],
	[
		"s3816114",
		"Hanburia grisebachii",
		"hanburia",
		3816114
	],
	[
		"s386180",
		"Hanburia mexicana",
		"hanburia",
		386180
	],
	[
		"s388292",
		"Hanburia oerstedii",
		"hanburia",
		388292
	],
	[
		"s3089884",
		"Hanburia parviflora",
		"hanburia",
		3089884
	],
	[
		"s3086717",
		"Hanburia spectabilis",
		"hanburia",
		3086717
	],
	[
		"s3816115",
		"Hanburia subcyclanthera",
		"hanburia",
		3816115
	],
	[
		"s3089894",
		"Helmontia cardiophylla",
		"helmontia",
		3089894
	],
	[
		"s383663",
		"Helmontia leptantha",
		"helmontia",
		383663
	],
	[
		"s3816928",
		"Helmontia trujilloi",
		"helmontia",
		3816928
	],
	[
		"s447484",
		"Hemsleya amabilis",
		"hemsleya",
		447484
	],
	[
		"s447110",
		"Hemsleya carnosiflora",
		"hemsleya",
		447110
	],
	[
		"s447111",
		"Hemsleya chengyihana",
		"hemsleya",
		447111
	],
	[
		"s447485",
		"Hemsleya chinensis",
		"hemsleya",
		447485
	],
	[
		"s515862",
		"Hemsleya cirromitrata",
		"hemsleya",
		515862
	],
	[
		"s447486",
		"Hemsleya delavayi",
		"hemsleya",
		447486
	],
	[
		"s447112",
		"Hemsleya dipterygia",
		"hemsleya",
		447112
	],
	[
		"s3817074",
		"Hemsleya dolichocarpa",
		"hemsleya",
		3817074
	],
	[
		"s447113",
		"Hemsleya dulongjiangensis",
		"hemsleya",
		447113
	],
	[
		"s447114",
		"Hemsleya ellipsoidea",
		"hemsleya",
		447114
	],
	[
		"s447115",
		"Hemsleya endecaphylla",
		"hemsleya",
		447115
	],
	[
		"s447116",
		"Hemsleya gigantha",
		"hemsleya",
		447116
	],
	[
		"s447117",
		"Hemsleya graciliflora",
		"hemsleya",
		447117
	],
	[
		"s447487",
		"Hemsleya kunmingensis",
		"hemsleya",
		447487
	],
	[
		"s210377",
		"Hemsleya lijiangensis",
		"hemsleya",
		210377
	],
	[
		"s447118",
		"Hemsleya longicarpa",
		"hemsleya",
		447118
	],
	[
		"s447129",
		"Hemsleya macrocarpa",
		"hemsleya",
		447129
	],
	[
		"s447119",
		"Hemsleya macrosperma",
		"hemsleya",
		447119
	],
	[
		"s447120",
		"Hemsleya mitrata",
		"hemsleya",
		447120
	],
	[
		"s447121",
		"Hemsleya omeiensis",
		"hemsleya",
		447121
	],
	[
		"s447122",
		"Hemsleya panacis-scandens",
		"hemsleya",
		447122
	],
	[
		"s447123",
		"Hemsleya panlongqi",
		"hemsleya",
		447123
	],
	[
		"s3817075",
		"Hemsleya peekelii",
		"hemsleya",
		3817075
	],
	[
		"s447124",
		"Hemsleya pengxianensis",
		"hemsleya",
		447124
	],
	[
		"s3817076",
		"Hemsleya revoluta",
		"hemsleya",
		3817076
	],
	[
		"s447125",
		"Hemsleya sphaerocarpa",
		"hemsleya",
		447125
	],
	[
		"s447126",
		"Hemsleya turbinata",
		"hemsleya",
		447126
	],
	[
		"s447127",
		"Hemsleya zhejiangensis",
		"hemsleya",
		447127
	],
	[
		"s386167",
		"Herpetospermum darjeelingense",
		"herpetospermum",
		386167
	],
	[
		"s386182",
		"Herpetospermum pedunculosum",
		"herpetospermum",
		386182
	],
	[
		"s388892",
		"Herpetospermum tonglense",
		"herpetospermum",
		388892
	],
	[
		"s48236",
		"Hillebrandia sandwicensis",
		"hillebrandia",
		48236
	],
	[
		"s386184",
		"Hodgsonia heteroclita",
		"hodgsonia",
		386184
	],
	[
		"s2184935",
		"Hodgsonia macrocarpa",
		"hodgsonia",
		2184935
	],
	[
		"s3157344",
		"Hodgsonia tsaii",
		"hodgsonia",
		3157344
	],
	[
		"s386163",
		"Ibervillea fusiformis",
		"ibervillea",
		386163
	],
	[
		"s386185",
		"Ibervillea hypoleuca",
		"ibervillea",
		386185
	],
	[
		"s386186",
		"Ibervillea lindheimeri",
		"ibervillea",
		386186
	],
	[
		"s386249",
		"Ibervillea macdougalii",
		"ibervillea",
		386249
	],
	[
		"s386164",
		"Ibervillea maxima",
		"ibervillea",
		386164
	],
	[
		"s386187",
		"Ibervillea millspaughii",
		"ibervillea",
		386187
	],
	[
		"s354617",
		"Ibervillea sonorae",
		"ibervillea",
		354617
	],
	[
		"s386188",
		"Ibervillea tenuisecta",
		"ibervillea",
		386188
	],
	[
		"s1343735",
		"Indofevillea jiroi",
		"indofevillea",
		1343735
	],
	[
		"s383665",
		"Indofevillea khasiana",
		"indofevillea",
		383665
	],
	[
		"s886956",
		"Indomelothria blumei",
		"indomelothria",
		886956
	],
	[
		"s418464",
		"Indomelothria chlorocarpa",
		"indomelothria",
		418464
	],
	[
		"s85716",
		"Kedrostis africana",
		"kedrostis",
		85716
	],
	[
		"s1672018",
		"Kedrostis capensis",
		"kedrostis",
		1672018
	],
	[
		"s3832357",
		"Kedrostis cogniauxii",
		"kedrostis",
		3832357
	],
	[
		"s2913521",
		"Kedrostis courtallensis",
		"kedrostis",
		2913521
	],
	[
		"s3832358",
		"Kedrostis crassirostrata",
		"kedrostis",
		3832358
	],
	[
		"s3832359",
		"Kedrostis dissecta",
		"kedrostis",
		3832359
	],
	[
		"s2895378",
		"Kedrostis elongata",
		"kedrostis",
		2895378
	],
	[
		"s519329",
		"Kedrostis foetidissima",
		"kedrostis",
		519329
	],
	[
		"s3832360",
		"Kedrostis heterophylla",
		"kedrostis",
		3832360
	],
	[
		"s3832361",
		"Kedrostis hirta",
		"kedrostis",
		3832361
	],
	[
		"s3832362",
		"Kedrostis lanuginosa",
		"kedrostis",
		3832362
	],
	[
		"s3832363",
		"Kedrostis laxa",
		"kedrostis",
		3832363
	],
	[
		"s3832364",
		"Kedrostis limpompensis",
		"kedrostis",
		3832364
	],
	[
		"s3832365",
		"Kedrostis monosperma",
		"kedrostis",
		3832365
	],
	[
		"s85219",
		"Kedrostis nana",
		"kedrostis",
		85219
	],
	[
		"s3832366",
		"Kedrostis perrieri",
		"kedrostis",
		3832366
	],
	[
		"s3832367",
		"Kedrostis psammophila",
		"kedrostis",
		3832367
	],
	[
		"s2894257",
		"Kedrostis pseudogijef",
		"kedrostis",
		2894257
	],
	[
		"s3832368",
		"Kedrostis punctulata",
		"kedrostis",
		3832368
	],
	[
		"s2895379",
		"Khmeriosicyos harmandii",
		"khmeriosicyos",
		2895379
	],
	[
		"s2984661",
		"Lagenaria abyssinica",
		"lagenaria",
		2984661
	],
	[
		"s254159",
		"Lagenaria breviflora",
		"lagenaria",
		254159
	],
	[
		"s519330",
		"Lagenaria guineensis",
		"lagenaria",
		519330
	],
	[
		"s519331",
		"Lagenaria rufa",
		"lagenaria",
		519331
	],
	[
		"s3668",
		"Lagenaria siceraria",
		"lagenaria",
		3668
	],
	[
		"s254057",
		"Lagenaria sphaerica",
		"lagenaria",
		254057
	],
	[
		"s383667",
		"Lemurosicyos variegatus",
		"lemurosicyos",
		383667
	],
	[
		"s386243",
		"Linnaeosicyos amara",
		"linnaeosicyos",
		386243
	],
	[
		"s56866",
		"Luffa acutangula",
		"luffa",
		56866
	],
	[
		"s3670",
		"Luffa aegyptiaca",
		"luffa",
		3670
	],
	[
		"s1462710",
		"Luffa astorii",
		"luffa",
		1462710
	],
	[
		"s252535",
		"Luffa echinata",
		"luffa",
		252535
	],
	[
		"s252536",
		"Luffa graveolens",
		"luffa",
		252536
	],
	[
		"s1301513",
		"Luffa hermaphrodita",
		"luffa",
		1301513
	],
	[
		"s388295",
		"Luffa operculata",
		"luffa",
		388295
	],
	[
		"s1301514",
		"Luffa pentandra",
		"luffa",
		1301514
	],
	[
		"s34295",
		"Luffa quinquefida",
		"luffa",
		34295
	],
	[
		"s1462711",
		"Luffa saccata",
		"luffa",
		1462711
	],
	[
		"s2806834",
		"Luffa sepium",
		"luffa",
		2806834
	],
	[
		"s329128",
		"Marah fabacea",
		"marah",
		329128
	],
	[
		"s3089712",
		"Marah gilensis",
		"marah",
		3089712
	],
	[
		"s3089713",
		"Marah guadalupensis",
		"marah",
		3089713
	],
	[
		"s48242",
		"Marah macrocarpa",
		"marah",
		48242
	],
	[
		"s3799205",
		"Marah micrantha",
		"marah",
		3799205
	],
	[
		"s252534",
		"Marah oregana",
		"marah",
		252534
	],
	[
		"s2919121",
		"Marah watsonii",
		"marah",
		2919121
	],
	[
		"s386190",
		"Melothria campestris",
		"melothria",
		386190
	],
	[
		"s886969",
		"Melothria candolleana",
		"melothria",
		886969
	],
	[
		"s1001134",
		"Melothria crassifolia",
		"melothria",
		1001134
	],
	[
		"s3848390",
		"Melothria cucumis",
		"melothria",
		3848390
	],
	[
		"s515864",
		"Melothria dulcis",
		"melothria",
		515864
	],
	[
		"s418466",
		"Melothria guadalupensis",
		"melothria",
		418466
	],
	[
		"s3848391",
		"Melothria hirsuta",
		"melothria",
		3848391
	],
	[
		"s1079400",
		"Melothria longituba",
		"melothria",
		1079400
	],
	[
		"s386192",
		"Melothria pendula",
		"melothria",
		386192
	],
	[
		"s3089731",
		"Melothria pringlei",
		"melothria",
		3089731
	],
	[
		"s886970",
		"Melothria scabra",
		"melothria",
		886970
	],
	[
		"s3848392",
		"Melothria schulziana",
		"melothria",
		3848392
	],
	[
		"s271697",
		"Melothria sphaerocarpa",
		"melothria",
		271697
	],
	[
		"s2849216",
		"Melothria tomentosa",
		"melothria",
		2849216
	],
	[
		"s1127085",
		"Melothria trilobata",
		"melothria",
		1127085
	],
	[
		"s2895627",
		"Melothria warmingii",
		"melothria",
		2895627
	],
	[
		"s388297",
		"Melothrianthus smilacifolius",
		"melothrianthus",
		388297
	],
	[
		"s383669",
		"Microlagenaria africana",
		"microlagenaria",
		383669
	],
	[
		"s931235",
		"Microsechium gonzalo-palomae",
		"microsechium",
		931235
	],
	[
		"s2912526",
		"Microsechium palmatum",
		"microsechium",
		2912526
	],
	[
		"s1132102",
		"Microsechium ruderale",
		"microsechium",
		1132102
	],
	[
		"s703353",
		"Momordica angolensis",
		"momordica",
		703353
	],
	[
		"s519332",
		"Momordica angustisepala",
		"momordica",
		519332
	],
	[
		"s703354",
		"Momordica anigosantha",
		"momordica",
		703354
	],
	[
		"s3851845",
		"Momordica argillicola",
		"momordica",
		3851845
	],
	[
		"s3672",
		"Momordica balsamina",
		"momordica",
		3672
	],
	[
		"s703355",
		"Momordica boivinii",
		"momordica",
		703355
	],
	[
		"s3851846",
		"Momordica breteleri",
		"momordica",
		3851846
	],
	[
		"s519333",
		"Momordica cabrae",
		"momordica",
		519333
	],
	[
		"s388893",
		"Momordica calantha",
		"momordica",
		388893
	],
	[
		"s703357",
		"Momordica camerounensis",
		"momordica",
		703357
	],
	[
		"s703358",
		"Momordica cardiospermoides",
		"momordica",
		703358
	],
	[
		"s3673",
		"Momordica charantia",
		"momordica",
		3673
	],
	[
		"s519336",
		"Momordica cissoides",
		"momordica",
		519336
	],
	[
		"s703359",
		"Momordica clarkeana",
		"momordica",
		703359
	],
	[
		"s3674",
		"Momordica cochinchinensis",
		"momordica",
		3674
	],
	[
		"s3851847",
		"Momordica cordata",
		"momordica",
		3851847
	],
	[
		"s703360",
		"Momordica corymbifera",
		"momordica",
		703360
	],
	[
		"s654834",
		"Momordica cymbalaria",
		"momordica",
		654834
	],
	[
		"s703361",
		"Momordica denticulata",
		"momordica",
		703361
	],
	[
		"s703362",
		"Momordica denudata",
		"momordica",
		703362
	],
	[
		"s654836",
		"Momordica dioica",
		"momordica",
		654836
	],
	[
		"s703363",
		"Momordica dissecta",
		"momordica",
		703363
	],
	[
		"s703364",
		"Momordica enneaphylla",
		"momordica",
		703364
	],
	[
		"s386195",
		"Momordica foetida",
		"momordica",
		386195
	],
	[
		"s703365",
		"Momordica friesiorum",
		"momordica",
		703365
	],
	[
		"s703366",
		"Momordica gilgiana",
		"momordica",
		703366
	],
	[
		"s703367",
		"Momordica glabra",
		"momordica",
		703367
	],
	[
		"s703368",
		"Momordica henriquesii",
		"momordica",
		703368
	],
	[
		"s703369",
		"Momordica humilis",
		"momordica",
		703369
	],
	[
		"s703370",
		"Momordica involucrata",
		"momordica",
		703370
	],
	[
		"s3851848",
		"Momordica janarthanamii",
		"momordica",
		3851848
	],
	[
		"s703371",
		"Momordica jeffreyana",
		"momordica",
		703371
	],
	[
		"s703372",
		"Momordica kirkii",
		"momordica",
		703372
	],
	[
		"s703373",
		"Momordica laotica",
		"momordica",
		703373
	],
	[
		"s703374",
		"Momordica leiocarpa",
		"momordica",
		703374
	],
	[
		"s703375",
		"Momordica littorea",
		"momordica",
		703375
	],
	[
		"s703376",
		"Momordica macrophylla",
		"momordica",
		703376
	],
	[
		"s3851849",
		"Momordica macrosperma",
		"momordica",
		3851849
	],
	[
		"s703377",
		"Momordica mossambica",
		"momordica",
		703377
	],
	[
		"s703378",
		"Momordica multiflora",
		"momordica",
		703378
	],
	[
		"s709324",
		"Momordica nuda (nom. ined.)",
		"momordica",
		709324
	],
	[
		"s703380",
		"Momordica obtusisepala",
		"momordica",
		703380
	],
	[
		"s703381",
		"Momordica parvifolia",
		"momordica",
		703381
	],
	[
		"s703382",
		"Momordica peteri",
		"momordica",
		703382
	],
	[
		"s703383",
		"Momordica pterocarpa",
		"momordica",
		703383
	],
	[
		"s3851850",
		"Momordica racemiflora",
		"momordica",
		3851850
	],
	[
		"s3675",
		"Momordica repens",
		"momordica",
		3675
	],
	[
		"s703386",
		"Momordica rostrata",
		"momordica",
		703386
	],
	[
		"s703384",
		"Momordica runssorica",
		"momordica",
		703384
	],
	[
		"s1719625",
		"Momordica sahyadrica",
		"momordica",
		1719625
	],
	[
		"s703387",
		"Momordica sessilifolia",
		"momordica",
		703387
	],
	[
		"s703388",
		"Momordica silvatica",
		"momordica",
		703388
	],
	[
		"s703389",
		"Momordica sphaeroidea",
		"momordica",
		703389
	],
	[
		"s703390",
		"Momordica spinosa",
		"momordica",
		703390
	],
	[
		"s703391",
		"Momordica subangulata",
		"momordica",
		703391
	],
	[
		"s703392",
		"Momordica suringarii",
		"momordica",
		703392
	],
	[
		"s703393",
		"Momordica trifolia",
		"momordica",
		703393
	],
	[
		"s703394",
		"Momordica trifoliolata",
		"momordica",
		703394
	],
	[
		"s703395",
		"Momordica welwitschii",
		"momordica",
		703395
	],
	[
		"s515865",
		"Muellerargia jeffreyana",
		"muellerargia",
		515865
	],
	[
		"s386197",
		"Muellerargia timorensis",
		"muellerargia",
		386197
	],
	[
		"s425375",
		"Neoachmandra capillacea",
		"neoachmandra",
		425375
	],
	[
		"s1743011",
		"Neoachmandra cordifolia",
		"neoachmandra",
		1743011
	],
	[
		"s452815",
		"Neoachmandra cunninghamii",
		"neoachmandra",
		452815
	],
	[
		"s424443",
		"Neoachmandra deltoidea",
		"neoachmandra",
		424443
	],
	[
		"s425376",
		"Neoachmandra gilletii",
		"neoachmandra",
		425376
	],
	[
		"s425382",
		"Neoachmandra hallii",
		"neoachmandra",
		425382
	],
	[
		"s386275",
		"Neoachmandra indica",
		"neoachmandra",
		386275
	],
	[
		"s386276",
		"Neoachmandra japonica",
		"neoachmandra",
		386276
	],
	[
		"s418473",
		"Neoachmandra samoensis",
		"neoachmandra",
		418473
	],
	[
		"s418474",
		"Neoachmandra sphaerosperma",
		"neoachmandra",
		418474
	],
	[
		"s515866",
		"Neoalsomitra angustipetala",
		"neoalsomitra",
		515866
	],
	[
		"s3854805",
		"Neoalsomitra balansae",
		"neoalsomitra",
		3854805
	],
	[
		"s427671",
		"Neoalsomitra capricornica",
		"neoalsomitra",
		427671
	],
	[
		"s388300",
		"Neoalsomitra clavigera",
		"neoalsomitra",
		388300
	],
	[
		"s3854806",
		"Neoalsomitra hederifolia",
		"neoalsomitra",
		3854806
	],
	[
		"s447128",
		"Neoalsomitra integrifoliola",
		"neoalsomitra",
		447128
	],
	[
		"s3402871",
		"Neoalsomitra pilosa",
		"neoalsomitra",
		3402871
	],
	[
		"s515867",
		"Neoalsomitra plena",
		"neoalsomitra",
		515867
	],
	[
		"s48238",
		"Neoalsomitra sarcophylla",
		"neoalsomitra",
		48238
	],
	[
		"s427674",
		"Neoalsomitra schefferiana",
		"neoalsomitra",
		427674
	],
	[
		"s3854807",
		"Neoalsomitra schultzei",
		"neoalsomitra",
		3854807
	],
	[
		"s3854808",
		"Neoalsomitra simplex",
		"neoalsomitra",
		3854808
	],
	[
		"s515868",
		"Neoalsomitra stephensiana",
		"neoalsomitra",
		515868
	],
	[
		"s515869",
		"Neoalsomitra trifoliolata",
		"neoalsomitra",
		515869
	],
	[
		"s386201",
		"Nothoalsomitra suberosa",
		"nothoalsomitra",
		386201
	],
	[
		"s34298",
		"Octomeles sumatrana",
		"octomeles",
		34298
	],
	[
		"s3749610",
		"Papuasicyos arfakensis",
		"papuasicyos",
		3749610
	],
	[
		"s418478",
		"Papuasicyos belensis",
		"papuasicyos",
		418478
	],
	[
		"s931240",
		"Papuasicyos carrii",
		"papuasicyos",
		931240
	],
	[
		"s3749611",
		"Papuasicyos hippocrepicus",
		"papuasicyos",
		3749611
	],
	[
		"s543290",
		"Papuasicyos papuanus",
		"papuasicyos",
		543290
	],
	[
		"s3749612",
		"Papuasicyos parviflorus",
		"papuasicyos",
		3749612
	],
	[
		"s3749613",
		"Papuasicyos viridis",
		"papuasicyos",
		3749613
	],
	[
		"s386203",
		"Parasicyos dieterleae",
		"parasicyos",
		386203
	],
	[
		"s1132103",
		"Parasicyos maculatus",
		"parasicyos",
		1132103
	],
	[
		"s386132",
		"Penelopeia sphaerica",
		"penelopeia",
		386132
	],
	[
		"s386205",
		"Penelopeia suburceolata",
		"penelopeia",
		386205
	],
	[
		"s3863459",
		"Peponium betsiliense",
		"peponium",
		3863459
	],
	[
		"s387134",
		"Peponium caledonicum",
		"peponium",
		387134
	],
	[
		"s3863460",
		"Peponium chirindense",
		"peponium",
		3863460
	],
	[
		"s2569943",
		"Peponium cienkowskii",
		"peponium",
		2569943
	],
	[
		"s2766527",
		"Peponium elgonense",
		"peponium",
		2766527
	],
	[
		"s3863461",
		"Peponium grandidieri",
		"peponium",
		3863461
	],
	[
		"s3863462",
		"Peponium hirtellum",
		"peponium",
		3863462
	],
	[
		"s3863463",
		"Peponium humbertii",
		"peponium",
		3863463
	],
	[
		"s3863464",
		"Peponium laceratum",
		"peponium",
		3863464
	],
	[
		"s3863465",
		"Peponium lagenarioides",
		"peponium",
		3863465
	],
	[
		"s3863466",
		"Peponium leucanthum",
		"peponium",
		3863466
	],
	[
		"s3089779",
		"Peponium mackenii",
		"peponium",
		3089779
	],
	[
		"s3863467",
		"Peponium pageanum",
		"peponium",
		3863467
	],
	[
		"s3863468",
		"Peponium perrieri",
		"peponium",
		3863468
	],
	[
		"s2896046",
		"Peponium poissonii",
		"peponium",
		2896046
	],
	[
		"s3863469",
		"Peponium racemosum",
		"peponium",
		3863469
	],
	[
		"s3863470",
		"Peponium seyrigii",
		"peponium",
		3863470
	],
	[
		"s418476",
		"Peponium sublitorale",
		"peponium",
		418476
	],
	[
		"s387135",
		"Peponium vogelii",
		"peponium",
		387135
	],
	[
		"s386207",
		"Peponopsis adhaerens",
		"peponopsis",
		386207
	],
	[
		"s301899",
		"Pilostyles aethiopica",
		"pilostyles",
		301899
	],
	[
		"s866782",
		"Pilostyles berteroi",
		"pilostyles",
		866782
	],
	[
		"s1501699",
		"Pilostyles blanchetii",
		"pilostyles",
		1501699
	],
	[
		"s2740449",
		"Pilostyles boyacensis",
		"pilostyles",
		2740449
	],
	[
		"s518627",
		"Pilostyles coccoidea",
		"pilostyles",
		518627
	],
	[
		"s448042",
		"Pilostyles collina",
		"pilostyles",
		448042
	],
	[
		"s448041",
		"Pilostyles hamiltonii",
		"pilostyles",
		448041
	],
	[
		"s866783",
		"Pilostyles haussknechtii",
		"pilostyles",
		866783
	],
	[
		"s2723229",
		"Pilostyles maya",
		"pilostyles",
		2723229
	],
	[
		"s1501700",
		"Pilostyles mexicana",
		"pilostyles",
		1501700
	],
	[
		"s51500",
		"Pilostyles thurberi",
		"pilostyles",
		51500
	],
	[
		"s328749",
		"Poga oleosa",
		"poga",
		328749
	],
	[
		"s386209",
		"Polyclathra cucumerina",
		"polyclathra",
		386209
	],
	[
		"s328751",
		"Polygonanthus amazonicus",
		"polygonanthus",
		328751
	],
	[
		"s3836454",
		"Polygonanthus punctulatus",
		"polygonanthus",
		3836454
	],
	[
		"s427673",
		"Pseudocyclanthera australis",
		"pseudocyclanthera",
		427673
	],
	[
		"s501918",
		"Psiguria bignoniacea",
		"psiguria",
		501918
	],
	[
		"s540786",
		"Psiguria pedata",
		"psiguria",
		540786
	],
	[
		"s386213",
		"Psiguria racemosa",
		"psiguria",
		386213
	],
	[
		"s627489",
		"Psiguria ternata",
		"psiguria",
		627489
	],
	[
		"s540787",
		"Psiguria triphylla",
		"psiguria",
		540787
	],
	[
		"s386214",
		"Psiguria umbrosa",
		"psiguria",
		386214
	],
	[
		"s501919",
		"Psiguria warscewiczii",
		"psiguria",
		501919
	],
	[
		"s515871",
		"Pteropepon acariaeanthus",
		"pteropepon",
		515871
	],
	[
		"s2894645",
		"Pteropepon deltoideus",
		"pteropepon",
		2894645
	],
	[
		"s3871488",
		"Pteropepon monospermus",
		"pteropepon",
		3871488
	],
	[
		"s3871489",
		"Pteropepon oleiferum",
		"pteropepon",
		3871489
	],
	[
		"s386216",
		"Pteropepon parodii",
		"pteropepon",
		386216
	],
	[
		"s2896533",
		"Raphidiocystis brachypoda",
		"raphidiocystis",
		2896533
	],
	[
		"s519337",
		"Raphidiocystis caillei",
		"raphidiocystis",
		519337
	],
	[
		"s515872",
		"Raphidiocystis chrysocoma",
		"raphidiocystis",
		515872
	],
	[
		"s3874000",
		"Raphidiocystis jeffreyana",
		"raphidiocystis",
		3874e3
	],
	[
		"s3091720",
		"Raphidiocystis mannii",
		"raphidiocystis",
		3091720
	],
	[
		"s386218",
		"Raphidiocystis phyllocalyx",
		"raphidiocystis",
		386218
	],
	[
		"s515873",
		"Ruthalicia eglandulosa",
		"ruthalicia",
		515873
	],
	[
		"s386220",
		"Ruthalicia longipes",
		"ruthalicia",
		386220
	],
	[
		"s387137",
		"Rytidostylis ciliata",
		"rytidostylis",
		387137
	],
	[
		"s627491",
		"Rytidostylis gracilis",
		"rytidostylis",
		627491
	],
	[
		"s3878838",
		"Schizocarpum attenuatum",
		"schizocarpum",
		3878838
	],
	[
		"s3091896",
		"Schizocarpum dieterleae",
		"schizocarpum",
		3091896
	],
	[
		"s386222",
		"Schizocarpum filiforme",
		"schizocarpum",
		386222
	],
	[
		"s3091897",
		"Schizocarpum liebmannii",
		"schizocarpum",
		3091897
	],
	[
		"s3091898",
		"Schizocarpum longisepalum",
		"schizocarpum",
		3091898
	],
	[
		"s386223",
		"Schizocarpum palmeri",
		"schizocarpum",
		386223
	],
	[
		"s3091899",
		"Schizocarpum parviflorum",
		"schizocarpum",
		3091899
	],
	[
		"s3878839",
		"Schizocarpum pilosum",
		"schizocarpum",
		3878839
	],
	[
		"s386224",
		"Schizocarpum reflexum",
		"schizocarpum",
		386224
	],
	[
		"s3091900",
		"Schizocarpum tripodum",
		"schizocarpum",
		3091900
	],
	[
		"s3878887",
		"Schizopepon bicirrhosus",
		"schizopepon",
		3878887
	],
	[
		"s328388",
		"Schizopepon bryoniifolius",
		"schizopepon",
		328388
	],
	[
		"s2306261",
		"Schizopepon dioicus",
		"schizopepon",
		2306261
	],
	[
		"s3878888",
		"Schizopepon macranthus",
		"schizopepon",
		3878888
	],
	[
		"s2726059",
		"Schizopepon monoicus",
		"schizopepon",
		2726059
	],
	[
		"s424444",
		"Scopellaria diversifolia",
		"scopellaria",
		424444
	],
	[
		"s386278",
		"Scopellaria marginata",
		"scopellaria",
		386278
	],
	[
		"s1132104",
		"Sechiopsis diptera",
		"sechiopsis",
		1132104
	],
	[
		"s3777214",
		"Sechiopsis distincta",
		"sechiopsis",
		3777214
	],
	[
		"s1132105",
		"Sechiopsis laciniata",
		"sechiopsis",
		1132105
	],
	[
		"s386226",
		"Sechiopsis tetraptera",
		"sechiopsis",
		386226
	],
	[
		"s1132106",
		"Sechiopsis triqueter",
		"sechiopsis",
		1132106
	],
	[
		"s1132107",
		"Sechium chinantlense",
		"sechium",
		1132107
	],
	[
		"s1132108",
		"Sechium compositum",
		"sechium",
		1132108
	],
	[
		"s1132109",
		"Sechium hintonii",
		"sechium",
		1132109
	],
	[
		"s931236",
		"Sechium mexicanum",
		"sechium",
		931236
	],
	[
		"s2896558",
		"Seyrigia gracilis",
		"seyrigia",
		2896558
	],
	[
		"s244770",
		"Seyrigia humbertii",
		"seyrigia",
		244770
	],
	[
		"s386230",
		"Sicana odorifera",
		"sicana",
		386230
	],
	[
		"s1504208",
		"Sicydium coriaceum",
		"sicydium",
		1504208
	],
	[
		"s386232",
		"Sicydium diffusum",
		"sicydium",
		386232
	],
	[
		"s3091927",
		"Sicydium gracile",
		"sicydium",
		3091927
	],
	[
		"s3015759",
		"Sicydium schiedeanum",
		"sicydium",
		3015759
	],
	[
		"s386148",
		"Sicydium synantherum",
		"sicydium",
		386148
	],
	[
		"s386233",
		"Sicydium tamnifolium",
		"sicydium",
		386233
	],
	[
		"s3091928",
		"Sicydium tuerckheimii",
		"sicydium",
		3091928
	],
	[
		"s1132111",
		"Sicyocaulis pentagonus",
		"sicyocaulis",
		1132111
	],
	[
		"s1132112",
		"Sicyos acarieanthus",
		"sicyos",
		1132112
	],
	[
		"s1132113",
		"Sicyos albus",
		"sicyos",
		1132113
	],
	[
		"s1132114",
		"Sicyos ampelophyllus",
		"sicyos",
		1132114
	],
	[
		"s1132115",
		"Sicyos andreanus",
		"sicyos",
		1132115
	],
	[
		"s64232",
		"Sicyos angulatus",
		"sicyos",
		64232
	],
	[
		"s1132116",
		"Sicyos anunu",
		"sicyos",
		1132116
	],
	[
		"s340140",
		"Sicyos australis",
		"sicyos",
		340140
	],
	[
		"s386234",
		"Sicyos baderoa",
		"sicyos",
		386234
	],
	[
		"s1132117",
		"Sicyos barbatus",
		"sicyos",
		1132117
	],
	[
		"s3091929",
		"Sicyos bogotensis",
		"sicyos",
		3091929
	],
	[
		"s1132118",
		"Sicyos bulbosus",
		"sicyos",
		1132118
	],
	[
		"s1132094",
		"Sicyos chiriquensis",
		"sicyos",
		1132094
	],
	[
		"s1132119",
		"Sicyos collinus",
		"sicyos",
		1132119
	],
	[
		"s1132120",
		"Sicyos cucumerinus",
		"sicyos",
		1132120
	],
	[
		"s1132121",
		"Sicyos davilae",
		"sicyos",
		1132121
	],
	[
		"s1132122",
		"Sicyos debilis",
		"sicyos",
		1132122
	],
	[
		"s1132123",
		"Sicyos dieterleae",
		"sicyos",
		1132123
	],
	[
		"s184140",
		"Sicyos edulis",
		"sicyos",
		184140
	],
	[
		"s1132124",
		"Sicyos erostratus",
		"sicyos",
		1132124
	],
	[
		"s1132125",
		"Sicyos galeottii",
		"sicyos",
		1132125
	],
	[
		"s1132126",
		"Sicyos glaber",
		"sicyos",
		1132126
	],
	[
		"s1132127",
		"Sicyos guatemalensis",
		"sicyos",
		1132127
	],
	[
		"s1132128",
		"Sicyos herbstii",
		"sicyos",
		1132128
	],
	[
		"s515874",
		"Sicyos hillebrandii",
		"sicyos",
		515874
	],
	[
		"s1132129",
		"Sicyos hispidus",
		"sicyos",
		1132129
	],
	[
		"s1132130",
		"Sicyos laciniatus",
		"sicyos",
		1132130
	],
	[
		"s1132131",
		"Sicyos lanceoloideus",
		"sicyos",
		1132131
	],
	[
		"s1132132",
		"Sicyos lasiocephalus",
		"sicyos",
		1132132
	],
	[
		"s1132133",
		"Sicyos lirae",
		"sicyos",
		1132133
	],
	[
		"s1132134",
		"Sicyos longisepalus",
		"sicyos",
		1132134
	],
	[
		"s1132135",
		"Sicyos longisetosus",
		"sicyos",
		1132135
	],
	[
		"s1132136",
		"Sicyos macrocarpus",
		"sicyos",
		1132136
	],
	[
		"s1132137",
		"Sicyos macrophyllus",
		"sicyos",
		1132137
	],
	[
		"s1132138",
		"Sicyos malvifolius",
		"sicyos",
		1132138
	],
	[
		"s1134497",
		"Sicyos mawhai",
		"sicyos",
		1134497
	],
	[
		"s1132140",
		"Sicyos maximowiczii",
		"sicyos",
		1132140
	],
	[
		"s1132141",
		"Sicyos mcvaughii",
		"sicyos",
		1132141
	],
	[
		"s1132142",
		"Sicyos microphyllus",
		"sicyos",
		1132142
	],
	[
		"s1132143",
		"Sicyos montanus",
		"sicyos",
		1132143
	],
	[
		"s1132144",
		"Sicyos motozintlensis",
		"sicyos",
		1132144
	],
	[
		"s3091930",
		"Sicyos odonellii",
		"sicyos",
		3091930
	],
	[
		"s515875",
		"Sicyos pachycarpus",
		"sicyos",
		515875
	],
	[
		"s1132145",
		"Sicyos palmatilobus",
		"sicyos",
		1132145
	],
	[
		"s1132146",
		"Sicyos parviflorus",
		"sicyos",
		1132146
	],
	[
		"s1132147",
		"Sicyos peninsularis",
		"sicyos",
		1132147
	],
	[
		"s3091931",
		"Sicyos polyacanthos",
		"sicyos",
		3091931
	],
	[
		"s931237",
		"Sicyos polyacanthus",
		"sicyos",
		931237
	],
	[
		"s1132148",
		"Sicyos quinquelobatus",
		"sicyos",
		1132148
	],
	[
		"s1132149",
		"Sicyos sertulifer",
		"sicyos",
		1132149
	],
	[
		"s1134498",
		"Sicyos undara",
		"sicyos",
		1134498
	],
	[
		"s931238",
		"Sicyos villosus",
		"sicyos",
		931238
	],
	[
		"s1132151",
		"Sicyos waimanaloensis",
		"sicyos",
		1132151
	],
	[
		"s1132152",
		"Sicyos warmingii",
		"sicyos",
		1132152
	],
	[
		"s1132153",
		"Sicyos weberbaueri",
		"sicyos",
		1132153
	],
	[
		"s386236",
		"Sicyosperma gracile",
		"sicyosperma",
		386236
	],
	[
		"s3880460",
		"Sinobaijiania decipiens",
		"sinobaijiania",
		3880460
	],
	[
		"s3880461",
		"Sinobaijiania frondosa",
		"sinobaijiania",
		3880461
	],
	[
		"s3880462",
		"Sinobaijiania smitinandii",
		"sinobaijiania",
		3880462
	],
	[
		"s2806871",
		"Sinobaijiania yunnanensis",
		"sinobaijiania",
		2806871
	],
	[
		"s386238",
		"Siolmatra brasiliensis",
		"siolmatra",
		386238
	],
	[
		"s2726060",
		"Siolmatra pentaphylla",
		"siolmatra",
		2726060
	],
	[
		"s190515",
		"Siraitia grosvenorii",
		"siraitia",
		190515
	],
	[
		"s2695833",
		"Siraitia siamensis",
		"siraitia",
		2695833
	],
	[
		"s714502",
		"Solena amplexicaulis",
		"solena",
		714502
	],
	[
		"s3832115",
		"Solena delavayi",
		"solena",
		3832115
	],
	[
		"s386240",
		"Solena heterophylla",
		"solena",
		386240
	],
	[
		"s3832116",
		"Solena umbellata",
		"solena",
		3832116
	],
	[
		"s386242",
		"Tecunumania quetzalteca",
		"tecunumania",
		386242
	],
	[
		"s2731237",
		"Tecunumania stothertiae",
		"tecunumania",
		2731237
	],
	[
		"s3886795",
		"Telfairia batesii",
		"telfairia",
		3886795
	],
	[
		"s383670",
		"Telfairia occidentalis",
		"telfairia",
		383670
	],
	[
		"s370898",
		"Telfairia pedata",
		"telfairia",
		370898
	],
	[
		"s34299",
		"Tetrameles nudiflora",
		"tetrameles",
		34299
	],
	[
		"s3035259",
		"Thladiantha angustisepala",
		"thladiantha",
		3035259
	],
	[
		"s3035650",
		"Thladiantha calcarata",
		"thladiantha",
		3035650
	],
	[
		"s1045180",
		"Thladiantha capitata",
		"thladiantha",
		1045180
	],
	[
		"s703396",
		"Thladiantha cordifolia",
		"thladiantha",
		703396
	],
	[
		"s387138",
		"Thladiantha davidii",
		"thladiantha",
		387138
	],
	[
		"s1045181",
		"Thladiantha dentata",
		"thladiantha",
		1045181
	],
	[
		"s3035260",
		"Thladiantha dimorphantha",
		"thladiantha",
		3035260
	],
	[
		"s210344",
		"Thladiantha dubia",
		"thladiantha",
		210344
	],
	[
		"s2726061",
		"Thladiantha globicarpa",
		"thladiantha",
		2726061
	],
	[
		"s1045182",
		"Thladiantha grandisepala",
		"thladiantha",
		1045182
	],
	[
		"s1045183",
		"Thladiantha henryi",
		"thladiantha",
		1045183
	],
	[
		"s383671",
		"Thladiantha hookeri",
		"thladiantha",
		383671
	],
	[
		"s3035261",
		"Thladiantha indochinensis",
		"thladiantha",
		3035261
	],
	[
		"s866784",
		"Thladiantha lijiangensis",
		"thladiantha",
		866784
	],
	[
		"s3035262",
		"Thladiantha longifolia",
		"thladiantha",
		3035262
	],
	[
		"s3888462",
		"Thladiantha longipedicellata",
		"thladiantha",
		3888462
	],
	[
		"s1045184",
		"Thladiantha longisepala",
		"thladiantha",
		1045184
	],
	[
		"s1045185",
		"Thladiantha maculata",
		"thladiantha",
		1045185
	],
	[
		"s3035263",
		"Thladiantha medogensis",
		"thladiantha",
		3035263
	],
	[
		"s1045186",
		"Thladiantha montana",
		"thladiantha",
		1045186
	],
	[
		"s703397",
		"Thladiantha nudiflora",
		"thladiantha",
		703397
	],
	[
		"s1045187",
		"Thladiantha oliveri",
		"thladiantha",
		1045187
	],
	[
		"s2726062",
		"Thladiantha punctata",
		"thladiantha",
		2726062
	],
	[
		"s703398",
		"Thladiantha pustulata",
		"thladiantha",
		703398
	],
	[
		"s3035265",
		"Thladiantha sessilifolia",
		"thladiantha",
		3035265
	],
	[
		"s3035266",
		"Thladiantha setispina",
		"thladiantha",
		3035266
	],
	[
		"s3888463",
		"Thladiantha subglobosa",
		"thladiantha",
		3888463
	],
	[
		"s1045188",
		"Thladiantha villosula",
		"thladiantha",
		1045188
	],
	[
		"s1144426",
		"Trichosanthes adhaerens",
		"trichosanthes",
		1144426
	],
	[
		"s3889962",
		"Trichosanthes anaimalaiensis",
		"trichosanthes",
		3889962
	],
	[
		"s50544",
		"Trichosanthes anguina",
		"trichosanthes",
		50544
	],
	[
		"s1144427",
		"Trichosanthes auriculata",
		"trichosanthes",
		1144427
	],
	[
		"s1054457",
		"Trichosanthes baviensis",
		"trichosanthes",
		1054457
	],
	[
		"s1144428",
		"Trichosanthes beccariana",
		"trichosanthes",
		1144428
	],
	[
		"s1144429",
		"Trichosanthes borneensis",
		"trichosanthes",
		1144429
	],
	[
		"s486425",
		"Trichosanthes bracteata",
		"trichosanthes",
		486425
	],
	[
		"s685052",
		"Trichosanthes cavalerei",
		"trichosanthes",
		685052
	],
	[
		"s1144430",
		"Trichosanthes celebica",
		"trichosanthes",
		1144430
	],
	[
		"s3889963",
		"Trichosanthes conferta",
		"trichosanthes",
		3889963
	],
	[
		"s1713838",
		"Trichosanthes cordata",
		"trichosanthes",
		1713838
	],
	[
		"s3889964",
		"Trichosanthes coriacea",
		"trichosanthes",
		3889964
	],
	[
		"s2888448",
		"Trichosanthes costata",
		"trichosanthes",
		2888448
	],
	[
		"s685053",
		"Trichosanthes crenulata",
		"trichosanthes",
		685053
	],
	[
		"s50543",
		"Trichosanthes cucumerina",
		"trichosanthes",
		50543
	],
	[
		"s685054",
		"Trichosanthes cucumeroides",
		"trichosanthes",
		685054
	],
	[
		"s3889965",
		"Trichosanthes cycloopensis",
		"trichosanthes",
		3889965
	],
	[
		"s685055",
		"Trichosanthes dafangensis",
		"trichosanthes",
		685055
	],
	[
		"s3889966",
		"Trichosanthes densiflora",
		"trichosanthes",
		3889966
	],
	[
		"s1144431",
		"Trichosanthes dentifera",
		"trichosanthes",
		1144431
	],
	[
		"s3889967",
		"Trichosanthes dieniensis",
		"trichosanthes",
		3889967
	],
	[
		"s320667",
		"Trichosanthes dioica",
		"trichosanthes",
		320667
	],
	[
		"s3889968",
		"Trichosanthes dolichosperma",
		"trichosanthes",
		3889968
	],
	[
		"s1054458",
		"Trichosanthes dunniana",
		"trichosanthes",
		1054458
	],
	[
		"s1144432",
		"Trichosanthes edulis",
		"trichosanthes",
		1144432
	],
	[
		"s3889969",
		"Trichosanthes ellipsoidea",
		"trichosanthes",
		3889969
	],
	[
		"s1144433",
		"Trichosanthes elmeri",
		"trichosanthes",
		1144433
	],
	[
		"s3889970",
		"Trichosanthes emarginata",
		"trichosanthes",
		3889970
	],
	[
		"s3889971",
		"Trichosanthes epibracteata",
		"trichosanthes",
		3889971
	],
	[
		"s3889972",
		"Trichosanthes erosa",
		"trichosanthes",
		3889972
	],
	[
		"s1144463",
		"Trichosanthes fissibracteata",
		"trichosanthes",
		1144463
	],
	[
		"s3889973",
		"Trichosanthes floresana",
		"trichosanthes",
		3889973
	],
	[
		"s3889974",
		"Trichosanthes fusca",
		"trichosanthes",
		3889974
	],
	[
		"s1144434",
		"Trichosanthes globosa",
		"trichosanthes",
		1144434
	],
	[
		"s685056",
		"Trichosanthes guizhouensis",
		"trichosanthes",
		685056
	],
	[
		"s3889975",
		"Trichosanthes hastata",
		"trichosanthes",
		3889975
	],
	[
		"s1144435",
		"Trichosanthes holtzei",
		"trichosanthes",
		1144435
	],
	[
		"s1144436",
		"Trichosanthes homophylla",
		"trichosanthes",
		1144436
	],
	[
		"s3889976",
		"Trichosanthes hosokawae",
		"trichosanthes",
		3889976
	],
	[
		"s2478897",
		"Trichosanthes hupehensis",
		"trichosanthes",
		2478897
	],
	[
		"s1144437",
		"Trichosanthes hylonoma",
		"trichosanthes",
		1144437
	],
	[
		"s1144438",
		"Trichosanthes intermedia",
		"trichosanthes",
		1144438
	],
	[
		"s1144439",
		"Trichosanthes inthanonensis",
		"trichosanthes",
		1144439
	],
	[
		"s3889977",
		"Trichosanthes ishigakiensis",
		"trichosanthes",
		3889977
	],
	[
		"s685057",
		"Trichosanthes jinggangshanica",
		"trichosanthes",
		685057
	],
	[
		"s3889978",
		"Trichosanthes jonesii",
		"trichosanthes",
		3889978
	],
	[
		"s1144441",
		"Trichosanthes kerrii",
		"trichosanthes",
		1144441
	],
	[
		"s3889979",
		"Trichosanthes khasiana",
		"trichosanthes",
		3889979
	],
	[
		"s486426",
		"Trichosanthes kinabaluensis",
		"trichosanthes",
		486426
	],
	[
		"s3677",
		"Trichosanthes kirilowii",
		"trichosanthes",
		3677
	],
	[
		"s3889980",
		"Trichosanthes kostermansii",
		"trichosanthes",
		3889980
	],
	[
		"s676243",
		"Trichosanthes laceribractea",
		"trichosanthes",
		676243
	],
	[
		"s1144442",
		"Trichosanthes laeoica",
		"trichosanthes",
		1144442
	],
	[
		"s282652",
		"Trichosanthes lepiniana",
		"trichosanthes",
		282652
	],
	[
		"s3889981",
		"Trichosanthes leuserensis",
		"trichosanthes",
		3889981
	],
	[
		"s2613913",
		"Trichosanthes lobata",
		"trichosanthes",
		2613913
	],
	[
		"s3889982",
		"Trichosanthes longispicata",
		"trichosanthes",
		3889982
	],
	[
		"s3889983",
		"Trichosanthes mianyangensis",
		"trichosanthes",
		3889983
	],
	[
		"s1144443",
		"Trichosanthes miyagii",
		"trichosanthes",
		1144443
	],
	[
		"s486427",
		"Trichosanthes montana",
		"trichosanthes",
		486427
	],
	[
		"s1288325",
		"Trichosanthes morrisii",
		"trichosanthes",
		1288325
	],
	[
		"s1144446",
		"Trichosanthes mucronata",
		"trichosanthes",
		1144446
	],
	[
		"s1144447",
		"Trichosanthes multiloba",
		"trichosanthes",
		1144447
	],
	[
		"s3889984",
		"Trichosanthes neoguineana",
		"trichosanthes",
		3889984
	],
	[
		"s1144448",
		"Trichosanthes nervifolia",
		"trichosanthes",
		1144448
	],
	[
		"s1144449",
		"Trichosanthes obscura",
		"trichosanthes",
		1144449
	],
	[
		"s3889985",
		"Trichosanthes obtusa",
		"trichosanthes",
		3889985
	],
	[
		"s1144450",
		"Trichosanthes odontosperma",
		"trichosanthes",
		1144450
	],
	[
		"s386244",
		"Trichosanthes ovigera",
		"trichosanthes",
		386244
	],
	[
		"s1144451",
		"Trichosanthes pallida",
		"trichosanthes",
		1144451
	],
	[
		"s931239",
		"Trichosanthes papuana",
		"trichosanthes",
		931239
	],
	[
		"s2888450",
		"Trichosanthes parviflora",
		"trichosanthes",
		2888450
	],
	[
		"s1144452",
		"Trichosanthes pedata",
		"trichosanthes",
		1144452
	],
	[
		"s3889986",
		"Trichosanthes pedicellata",
		"trichosanthes",
		3889986
	],
	[
		"s486428",
		"Trichosanthes pendula",
		"trichosanthes",
		486428
	],
	[
		"s486429",
		"Trichosanthes pentaphylla",
		"trichosanthes",
		486429
	],
	[
		"s3889987",
		"Trichosanthes philippinensis",
		"trichosanthes",
		3889987
	],
	[
		"s1144453",
		"Trichosanthes phonsenae",
		"trichosanthes",
		1144453
	],
	[
		"s1144454",
		"Trichosanthes pilosa",
		"trichosanthes",
		1144454
	],
	[
		"s3889988",
		"Trichosanthes planiglans",
		"trichosanthes",
		3889988
	],
	[
		"s486430",
		"Trichosanthes postarii",
		"trichosanthes",
		486430
	],
	[
		"s459632",
		"Trichosanthes pubera",
		"trichosanthes",
		459632
	],
	[
		"s3889989",
		"Trichosanthes pulleana",
		"trichosanthes",
		3889989
	],
	[
		"s1144458",
		"Trichosanthes quinquangulata",
		"trichosanthes",
		1144458
	],
	[
		"s1144459",
		"Trichosanthes quinquefolia",
		"trichosanthes",
		1144459
	],
	[
		"s3889990",
		"Trichosanthes refracta",
		"trichosanthes",
		3889990
	],
	[
		"s386245",
		"Trichosanthes reticulinervis",
		"trichosanthes",
		386245
	],
	[
		"s676073",
		"Trichosanthes rosthornii",
		"trichosanthes",
		676073
	],
	[
		"s3889991",
		"Trichosanthes rotundifolia",
		"trichosanthes",
		3889991
	],
	[
		"s3889992",
		"Trichosanthes rugatisemina",
		"trichosanthes",
		3889992
	],
	[
		"s3889993",
		"Trichosanthes samarensis",
		"trichosanthes",
		3889993
	],
	[
		"s685058",
		"Trichosanthes schizostroma",
		"trichosanthes",
		685058
	],
	[
		"s486431",
		"Trichosanthes schlechteri",
		"trichosanthes",
		486431
	],
	[
		"s1144460",
		"Trichosanthes sepilokensis",
		"trichosanthes",
		1144460
	],
	[
		"s2726063",
		"Trichosanthes sericeifolia",
		"trichosanthes",
		2726063
	],
	[
		"s3889994",
		"Trichosanthes siamensis",
		"trichosanthes",
		3889994
	],
	[
		"s1144461",
		"Trichosanthes smilacifolia",
		"trichosanthes",
		1144461
	],
	[
		"s685059",
		"Trichosanthes stylopodifera",
		"trichosanthes",
		685059
	],
	[
		"s2888446",
		"Trichosanthes subrosea",
		"trichosanthes",
		2888446
	],
	[
		"s486432",
		"Trichosanthes subvelutina",
		"trichosanthes",
		486432
	],
	[
		"s2801064",
		"Trichosanthes sunhangii",
		"trichosanthes",
		2801064
	],
	[
		"s3889995",
		"Trichosanthes taiwanensis",
		"trichosanthes",
		3889995
	],
	[
		"s2888447",
		"Trichosanthes tetragonosperma",
		"trichosanthes",
		2888447
	],
	[
		"s3889996",
		"Trichosanthes thailandensis",
		"trichosanthes",
		3889996
	],
	[
		"s654837",
		"Trichosanthes tricuspidata",
		"trichosanthes",
		654837
	],
	[
		"s2888449",
		"Trichosanthes tridentata",
		"trichosanthes",
		2888449
	],
	[
		"s685060",
		"Trichosanthes truncata",
		"trichosanthes",
		685060
	],
	[
		"s1144424",
		"Trichosanthes tubiflora",
		"trichosanthes",
		1144424
	],
	[
		"s3889997",
		"Trichosanthes unicirrata",
		"trichosanthes",
		3889997
	],
	[
		"s3889998",
		"Trichosanthes valida",
		"trichosanthes",
		3889998
	],
	[
		"s475764",
		"Trichosanthes villosa",
		"trichosanthes",
		475764
	],
	[
		"s1144464",
		"Trichosanthes wallichiana",
		"trichosanthes",
		1144464
	],
	[
		"s1144465",
		"Trichosanthes wawrae",
		"trichosanthes",
		1144465
	],
	[
		"s3890962",
		"Trochomeria baumiana",
		"trochomeria",
		3890962
	],
	[
		"s1932179",
		"Trochomeria debilis",
		"trochomeria",
		1932179
	],
	[
		"s1932180",
		"Trochomeria hookeri",
		"trochomeria",
		1932180
	],
	[
		"s213603",
		"Trochomeria macrocarpa",
		"trochomeria",
		213603
	],
	[
		"s1932177",
		"Trochomeria nigrescens",
		"trochomeria",
		1932177
	],
	[
		"s515876",
		"Trochomeria polymorpha",
		"trochomeria",
		515876
	],
	[
		"s1932181",
		"Trochomeria sagittata",
		"trochomeria",
		1932181
	],
	[
		"s3890963",
		"Trochomeria subglabra",
		"trochomeria",
		3890963
	],
	[
		"s3073152",
		"Trochomeria wyleyana",
		"trochomeria",
		3073152
	],
	[
		"s386247",
		"Trochomeriopsis diversifolia",
		"trochomeriopsis",
		386247
	],
	[
		"s418482",
		"Urceodiscus scabridulus",
		"urceodiscus",
		418482
	],
	[
		"s3091602",
		"Vaseyanthus brandegeei",
		"vaseyanthus",
		3091602
	],
	[
		"s703182",
		"Wilbrandia ebracteata",
		"wilbrandia",
		703182
	],
	[
		"s3894001",
		"Wilbrandia glaziovii",
		"wilbrandia",
		3894001
	],
	[
		"s2726064",
		"Wilbrandia hibiscoides",
		"wilbrandia",
		2726064
	],
	[
		"s703183",
		"Wilbrandia longisepala",
		"wilbrandia",
		703183
	],
	[
		"s386253",
		"Wilbrandia verticillata",
		"wilbrandia",
		386253
	],
	[
		"s85297",
		"Xerosicyos danguyi",
		"xerosicyos",
		85297
	],
	[
		"s48240",
		"Xerosicyos decaryi",
		"xerosicyos",
		48240
	],
	[
		"s3128659",
		"Xerosicyos hirtellus",
		"xerosicyos",
		3128659
	],
	[
		"s515877",
		"Xerosicyos perrieri",
		"xerosicyos",
		515877
	],
	[
		"s388302",
		"Xerosicyos pubescens",
		"xerosicyos",
		388302
	],
	[
		"s386256",
		"Xerosicyos tripartitus",
		"xerosicyos",
		386256
	],
	[
		"s3894525",
		"Zanonia angulata",
		"zanonia",
		3894525
	],
	[
		"s515879",
		"Zanonia indica",
		"zanonia",
		515879
	],
	[
		"s3894612",
		"Zehneria alba",
		"zehneria",
		3894612
	],
	[
		"s3894613",
		"Zehneria angolensis",
		"zehneria",
		3894613
	],
	[
		"s529364",
		"Zehneria anomala",
		"zehneria",
		529364
	],
	[
		"s3894614",
		"Zehneria backeri",
		"zehneria",
		3894614
	],
	[
		"s418483",
		"Zehneria baueriana",
		"zehneria",
		418483
	],
	[
		"s386254",
		"Zehneria bodinieri",
		"zehneria",
		386254
	],
	[
		"s418468",
		"Zehneria boholensis",
		"zehneria",
		418468
	],
	[
		"s3894615",
		"Zehneria brevirostris",
		"zehneria",
		3894615
	],
	[
		"s3894616",
		"Zehneria clemensiae",
		"zehneria",
		3894616
	],
	[
		"s3894617",
		"Zehneria elbertii",
		"zehneria",
		3894617
	],
	[
		"s418494",
		"Zehneria emirnensis",
		"zehneria",
		418494
	],
	[
		"s1743014",
		"Zehneria erythrobacca",
		"zehneria",
		1743014
	],
	[
		"s418484",
		"Zehneria erythrocarpa",
		"zehneria",
		418484
	],
	[
		"s418469",
		"Zehneria filipes",
		"zehneria",
		418469
	],
	[
		"s2082888",
		"Zehneria gilletii",
		"zehneria",
		2082888
	],
	[
		"s2750859",
		"Zehneria grandibracteata",
		"zehneria",
		2750859
	],
	[
		"s424442",
		"Zehneria grayana",
		"zehneria",
		424442
	],
	[
		"s2082889",
		"Zehneria guamensis",
		"zehneria",
		2082889
	],
	[
		"s2082890",
		"Zehneria hermaphrodita",
		"zehneria",
		2082890
	],
	[
		"s3894618",
		"Zehneria idenburgensis",
		"zehneria",
		3894618
	],
	[
		"s3894619",
		"Zehneria immarginata",
		"zehneria",
		3894619
	],
	[
		"s418485",
		"Zehneria keayana",
		"zehneria",
		418485
	],
	[
		"s3894620",
		"Zehneria lancifolia",
		"zehneria",
		3894620
	],
	[
		"s418470",
		"Zehneria leucocarpa",
		"zehneria",
		418470
	],
	[
		"s2750840",
		"Zehneria longiflora",
		"zehneria",
		2750840
	],
	[
		"s3894621",
		"Zehneria macrantha",
		"zehneria",
		3894621
	],
	[
		"s515851",
		"Zehneria macrosepala",
		"zehneria",
		515851
	],
	[
		"s3894622",
		"Zehneria madagascariensis",
		"zehneria",
		3894622
	],
	[
		"s418486",
		"Zehneria marlothii",
		"zehneria",
		418486
	],
	[
		"s3894623",
		"Zehneria martinez-crovettoi",
		"zehneria",
		3894623
	],
	[
		"s2082891",
		"Zehneria maysorensis",
		"zehneria",
		2082891
	],
	[
		"s2082892",
		"Zehneria microsperma",
		"zehneria",
		2082892
	],
	[
		"s418487",
		"Zehneria minutiflora",
		"zehneria",
		418487
	],
	[
		"s2750841",
		"Zehneria monocarpa",
		"zehneria",
		2750841
	],
	[
		"s3894624",
		"Zehneria morobensis",
		"zehneria",
		3894624
	],
	[
		"s418488",
		"Zehneria mucronata",
		"zehneria",
		418488
	],
	[
		"s418489",
		"Zehneria neocaledonica",
		"zehneria",
		418489
	],
	[
		"s2849023",
		"Zehneria neorensis",
		"zehneria",
		2849023
	],
	[
		"s418471",
		"Zehneria nesophila",
		"zehneria",
		418471
	],
	[
		"s2082907",
		"Zehneria odorata",
		"zehneria",
		2082907
	],
	[
		"s2750842",
		"Zehneria oligosperma",
		"zehneria",
		2750842
	],
	[
		"s418490",
		"Zehneria pallidinervia",
		"zehneria",
		418490
	],
	[
		"s2884877",
		"Zehneria palmatiloba",
		"zehneria",
		2884877
	],
	[
		"s418491",
		"Zehneria parvifolia",
		"zehneria",
		418491
	],
	[
		"s3894625",
		"Zehneria pedicellata",
		"zehneria",
		3894625
	],
	[
		"s2849217",
		"Zehneria peneyana",
		"zehneria",
		2849217
	],
	[
		"s418472",
		"Zehneria pentaphylla",
		"zehneria",
		418472
	],
	[
		"s2082893",
		"Zehneria perpusilla",
		"zehneria",
		2082893
	],
	[
		"s2082894",
		"Zehneria perrieri",
		"zehneria",
		2082894
	],
	[
		"s418492",
		"Zehneria pisifera",
		"zehneria",
		418492
	],
	[
		"s3894626",
		"Zehneria platysperma",
		"zehneria",
		3894626
	],
	[
		"s2082895",
		"Zehneria polycarpa",
		"zehneria",
		2082895
	],
	[
		"s2082896",
		"Zehneria racemosa",
		"zehneria",
		2082896
	],
	[
		"s3894627",
		"Zehneria repanda",
		"zehneria",
		3894627
	],
	[
		"s3894628",
		"Zehneria rizalensis",
		"zehneria",
		3894628
	],
	[
		"s2849218",
		"Zehneria rutenbergiana",
		"zehneria",
		2849218
	],
	[
		"s3894629",
		"Zehneria scaberrima",
		"zehneria",
		3894629
	],
	[
		"s378900",
		"Zehneria scabra",
		"zehneria",
		378900
	],
	[
		"s2082898",
		"Zehneria scrobiculata",
		"zehneria",
		2082898
	],
	[
		"s3894630",
		"Zehneria somalensis",
		"zehneria",
		3894630
	],
	[
		"s3894631",
		"Zehneria subcoriacea",
		"zehneria",
		3894631
	],
	[
		"s2082900",
		"Zehneria tahitensis",
		"zehneria",
		2082900
	],
	[
		"s3894632",
		"Zehneria tenuispica",
		"zehneria",
		3894632
	],
	[
		"s519340",
		"Zehneria thwaitesii",
		"zehneria",
		519340
	],
	[
		"s3894633",
		"Zehneria trichocarpa",
		"zehneria",
		3894633
	],
	[
		"s2082901",
		"Zehneria tridactyla",
		"zehneria",
		2082901
	],
	[
		"s3894634",
		"Zehneria trullifolia",
		"zehneria",
		3894634
	],
	[
		"s2750843",
		"Zehneria tuberifera",
		"zehneria",
		2750843
	],
	[
		"s418493",
		"Zehneria viridifolia",
		"zehneria",
		418493
	],
	[
		"s418475",
		"Zehneria wallichii",
		"zehneria",
		418475
	]
];
var SUBSPECIES = [
	[
		"u2593451",
		"Amelanchier ovalis subsp. embergeri",
		"s1000415",
		2593451
	],
	[
		"u1170807",
		"Ficus tinctoria subsp. gibbosa",
		"s100577",
		1170807
	],
	[
		"u2767352",
		"Ficus tinctoria subsp. parasitica",
		"s100577",
		2767352
	],
	[
		"u1179237",
		"Ficus tinctoria subsp. swinhoei",
		"s100577",
		1179237
	],
	[
		"u403489",
		"Fragaria chiloensis subsp. chiloensis",
		"s101007",
		403489
	],
	[
		"u101009",
		"Fragaria chiloensis subsp. lucida",
		"s101007",
		101009
	],
	[
		"u101008",
		"Fragaria chiloensis subsp. pacifica",
		"s101007",
		101008
	],
	[
		"u674466",
		"Fragaria chiloensis subsp. sandwicensis",
		"s101007",
		674466
	],
	[
		"u101016",
		"Fragaria virginiana subsp. glauca",
		"s101015",
		101016
	],
	[
		"u1238183",
		"Fragaria virginiana subsp. grayana",
		"s101015",
		1238183
	],
	[
		"u101017",
		"Fragaria virginiana subsp. platypetala",
		"s101015",
		101017
	],
	[
		"u101018",
		"Fragaria virginiana subsp. virginiana",
		"s101015",
		101018
	],
	[
		"u2900645",
		"Rhamnus davurica subsp. nipponica",
		"s105902",
		2900645
	],
	[
		"u1345278",
		"Frangula alnus subsp. alnus",
		"s106677",
		1345278
	],
	[
		"u280011",
		"Frangula alnus subsp. baetica",
		"s106677",
		280011
	],
	[
		"u325283",
		"Trymalium odoratissimum subsp. trifidum",
		"s106717",
		325283
	],
	[
		"u1506682",
		"Ficus subpisocarpa subsp. pubipoda",
		"s1118427",
		1506682
	],
	[
		"u1211603",
		"Prunus spinosa subsp. spinosa",
		"s114937",
		1211603
	],
	[
		"u1891442",
		"Alchemilla filicaulis subsp. filicaulis",
		"s1155247",
		1891442
	],
	[
		"u1891443",
		"Alchemilla filicaulis subsp. vestita",
		"s1155247",
		1891443
	],
	[
		"u2592371",
		"Aphanes australis subsp. australis",
		"s1155250",
		2592371
	],
	[
		"u1937441",
		"Pourouma melinonii subsp. melinonii",
		"s1186179",
		1937441
	],
	[
		"u1191353",
		"Ficus chlamydocarpa subsp. fernandesiana",
		"s1191352",
		1191353
	],
	[
		"u2984681",
		"Lasiodiscus pervillei subsp. ferrugineus",
		"s1237608",
		2984681
	],
	[
		"u1237609",
		"Lasiodiscus pervillei subsp. pervillei",
		"s1237608",
		1237609
	],
	[
		"u1853090",
		"Urtica laetevirens subsp. laetevirens",
		"s1303699",
		1853090
	],
	[
		"u1399761",
		"Urtica triangularis subsp. pinnatifida",
		"s1303701",
		1399761
	],
	[
		"u1853103",
		"Urtica triangularis subsp. triangularis",
		"s1303701",
		1853103
	],
	[
		"u1470444",
		"Urtica triangularis subsp. trichocarpa",
		"s1303701",
		1470444
	],
	[
		"u1303702",
		"Urtica thunbergiana subsp. dentata",
		"s1303703",
		1303702
	],
	[
		"u2067464",
		"Urtica thunbergiana subsp. silvatica",
		"s1303703",
		2067464
	],
	[
		"u2067465",
		"Urtica thunbergiana subsp. thunbergiana",
		"s1303703",
		2067465
	],
	[
		"u550916",
		"Cliffortia nitidula subsp. pilosa",
		"s137439",
		550916
	],
	[
		"u1891589",
		"Sanguisorba canadensis subsp. latifolia",
		"s137455",
		1891589
	],
	[
		"u1533366",
		"Sanguisorba minor subsp. balearica",
		"s137456",
		1533366
	],
	[
		"u2770951",
		"Sanguisorba minor subsp. lasiocarpa",
		"s137456",
		2770951
	],
	[
		"u2602087",
		"Sanguisorba minor subsp. minor",
		"s137456",
		2602087
	],
	[
		"u2770950",
		"Sanguisorba minor subsp. muricata",
		"s137456",
		2770950
	],
	[
		"u1399713",
		"Oreocnide frutescens subsp. frutescens",
		"s1399712",
		1399713
	],
	[
		"u1399714",
		"Oreocnide frutescens subsp. occidentalis",
		"s1399712",
		1399714
	],
	[
		"u1399721",
		"Pilea angulata subsp. petiolaris",
		"s1399720",
		1399721
	],
	[
		"u1399723",
		"Pilea cavaleriei subsp. cavaleriei",
		"s1399722",
		1399723
	],
	[
		"u2901852",
		"Prunus apetala subsp. pilosa",
		"s140662",
		2901852
	],
	[
		"u1435569",
		"Urtica gracilis subsp. aquatica",
		"s1435576",
		1435569
	],
	[
		"u1470445",
		"Urtica gracilis subsp. gracilis",
		"s1435576",
		1470445
	],
	[
		"u1435577",
		"Urtica gracilis subsp. holosericea",
		"s1435576",
		1435577
	],
	[
		"u1471899",
		"Urtica gracilis subsp. incaica",
		"s1435576",
		1471899
	],
	[
		"u1435589",
		"Urtica gracilis subsp. mollis",
		"s1435576",
		1435589
	],
	[
		"u1546345",
		"Rubus leucandrus subsp. belgicus",
		"s1546344",
		1546345
	],
	[
		"u1814965",
		"Frangula rubra subsp. obtusissima",
		"s1813046",
		1814965
	],
	[
		"u3144259",
		"Rhamnus pallasii subsp. pallasii",
		"s1813065",
		3144259
	],
	[
		"u309324",
		"Ficus macrophylla subsp. columnaris",
		"s182117",
		309324
	],
	[
		"u672074",
		"Ficus sycomorus subsp. gnaphalocarpa",
		"s182129",
		672074
	],
	[
		"u2675993",
		"Artocarpus teysmannii subsp. subglabrus",
		"s1856020",
		2675993
	],
	[
		"u2675534",
		"Artocarpus gomezianus subsp. gomezianus",
		"s1867283",
		2675534
	],
	[
		"u193527",
		"Hippophae rhamnoides subsp. carpatica",
		"s193516",
		193527
	],
	[
		"u1185385",
		"Hippophae rhamnoides subsp. caucasica",
		"s193516",
		1185385
	],
	[
		"u193517",
		"Hippophae rhamnoides subsp. fluviatilis",
		"s193516",
		193517
	],
	[
		"u193528",
		"Hippophae rhamnoides subsp. mongolica",
		"s193516",
		193528
	],
	[
		"u193529",
		"Hippophae rhamnoides subsp. rhamnoides",
		"s193516",
		193529
	],
	[
		"u193530",
		"Hippophae rhamnoides subsp. turkestanica",
		"s193516",
		193530
	],
	[
		"u193526",
		"Hippophae rhamnoides subsp. wolongensis",
		"s193516",
		193526
	],
	[
		"u193518",
		"Hippophae rhamnoides subsp. yunnanensis",
		"s193516",
		193518
	],
	[
		"u193524",
		"Hippophae neurocarpa subsp. neurocarpa",
		"s193523",
		193524
	],
	[
		"u193525",
		"Hippophae neurocarpa subsp. stellatopilosa",
		"s193523",
		193525
	],
	[
		"u2732293",
		"Brosimum alicastrum subsp. alicastrum",
		"s194253",
		2732293
	],
	[
		"u2732300",
		"Brosimum alicastrum subsp. bolivarense",
		"s194253",
		2732300
	],
	[
		"u3021869",
		"Prunus microcarpa subsp. microcarpa",
		"s194546",
		3021869
	],
	[
		"u2137835",
		"Ficus trichocerasa subsp. pleioclada",
		"s2137834",
		2137835
	],
	[
		"u140656",
		"Prunus ilicifolia subsp. ilicifolia",
		"s23206",
		140656
	],
	[
		"u140655",
		"Prunus ilicifolia subsp. lyonii",
		"s23206",
		140655
	],
	[
		"u907223",
		"Prunus serotina subsp. capuli",
		"s23207",
		907223
	],
	[
		"u1170643",
		"Prunus serotina subsp. eximia",
		"s23207",
		1170643
	],
	[
		"u1170644",
		"Prunus serotina subsp. serotina",
		"s23207",
		1170644
	],
	[
		"u141004",
		"Pyrus communis subsp. caucasica",
		"s23211",
		141004
	],
	[
		"u3116859",
		"Pyrus communis subsp. communis",
		"s23211",
		3116859
	],
	[
		"u1211443",
		"Celtis australis subsp. australis",
		"s236733",
		1211443
	],
	[
		"u1867277",
		"Antiaris toxicaria subsp. madagascariensis",
		"s241857",
		1867277
	],
	[
		"u3048752",
		"Naucleopsis ulei subsp. amara",
		"s241900",
		3048752
	],
	[
		"u3048680",
		"Perebea guianensis subsp. guianensis",
		"s241905",
		3048680
	],
	[
		"u3048753",
		"Perebea guianensis subsp. hirsuta",
		"s241905",
		3048753
	],
	[
		"u1937440",
		"Perebea mollis subsp. mollis",
		"s241907",
		1937440
	],
	[
		"u2732294",
		"Sorocea muriculata subsp. muriculata",
		"s241923",
		2732294
	],
	[
		"u2732308",
		"Sorocea muriculata subsp. uaupensis",
		"s241923",
		2732308
	],
	[
		"u2732309",
		"Sorocea pubivena subsp. hirtella",
		"s241924",
		2732309
	],
	[
		"u2732310",
		"Sorocea pubivena subsp. oligotricha",
		"s241924",
		2732310
	],
	[
		"u2732295",
		"Sorocea pubivena subsp. pubivena",
		"s241924",
		2732295
	],
	[
		"u2487661",
		"Rubus rugosus subsp. thwaitesii",
		"s2487660",
		2487661
	],
	[
		"u2605003",
		"Dorstenia ramosa subsp. dolichocaula",
		"s2605002",
		2605003
	],
	[
		"u2605004",
		"Dorstenia ramosa subsp. ramosa",
		"s2605002",
		2605004
	],
	[
		"u262085",
		"Ulmus minor subsp. canescens",
		"s262084",
		262085
	],
	[
		"u1211621",
		"Ulmus minor subsp. minor",
		"s262084",
		1211621
	],
	[
		"u1533349",
		"Rosa caesia subsp. glauca",
		"s267233",
		1533349
	],
	[
		"u2675509",
		"Artocarpus longifolius subsp. adpressus",
		"s2675508",
		2675509
	],
	[
		"u2675540",
		"Artocarpus longifolius subsp. longifolius",
		"s2675508",
		2675540
	],
	[
		"u2739279",
		"Pilea aquarum subsp. acutidentata",
		"s2739278",
		2739279
	],
	[
		"u2803930",
		"Pilea aquarum subsp. brevicornuta",
		"s2739278",
		2803930
	],
	[
		"u1161925",
		"Elaeagnus glabra subsp. oxyphylla",
		"s276777",
		1161925
	],
	[
		"u3091428",
		"Rhamnus crocea subsp. pilosa",
		"s280019",
		3091428
	],
	[
		"u935872",
		"Rhamnus crocea subsp. pirifolia",
		"s280019",
		935872
	],
	[
		"u2602077",
		"Oreoherzogia pumila subsp. pumila",
		"s280023",
		2602077
	],
	[
		"u1813073",
		"Rhamnus saxatilis subsp. tinctoria",
		"s280025",
		1813073
	],
	[
		"u281874",
		"Acaena pinnatifida subsp. grandiflora",
		"s281873",
		281874
	],
	[
		"u281889",
		"Polylepis besseri subsp. besseri",
		"s281888",
		281889
	],
	[
		"u281907",
		"Polylepis tomentella subsp. tomentella",
		"s281906",
		281907
	],
	[
		"u2904942",
		"Rubus pinnatus subsp. pinnatus",
		"s2904923",
		2904942
	],
	[
		"u2906008",
		"Agrimonia noguchii subsp. hakonensis",
		"s2906007",
		2906008
	],
	[
		"u538383",
		"Rosa dumalis subsp. dumalis",
		"s291166",
		538383
	],
	[
		"u2928710",
		"Girardinia suborbiculata subsp. grammata",
		"s2928709",
		2928710
	],
	[
		"u2952664",
		"Girardinia suborbiculata subsp. suborbiculata",
		"s2928709",
		2952664
	],
	[
		"u2945651",
		"Spyridium bifidum subsp. wanillae",
		"s2945635",
		2945651
	],
	[
		"u2945666",
		"Spyridium stenophyllum subsp. renovatum",
		"s2945649",
		2945666
	],
	[
		"u2945682",
		"Spyridium stenophyllum subsp. stenophyllum",
		"s2945649",
		2945682
	],
	[
		"u2985851",
		"Cryptandra minutifolia subsp. brevistyla",
		"s2985850",
		2985851
	],
	[
		"u2985961",
		"Cryptandra minutifolia subsp. minutifolia",
		"s2985850",
		2985961
	],
	[
		"u2985962",
		"Cryptandra pogonoloba subsp. pogonoloba",
		"s2985857",
		2985962
	],
	[
		"u2985858",
		"Cryptandra pogonoloba subsp. septentrionalis",
		"s2985857",
		2985858
	],
	[
		"u2986153",
		"Cryptandra propinqua subsp. maranoa",
		"s2985859",
		2986153
	],
	[
		"u2985963",
		"Cryptandra propinqua subsp. propinqua",
		"s2985859",
		2985963
	],
	[
		"u2985966",
		"Cryptandra speciosa subsp. speciosa",
		"s2985862",
		2985966
	],
	[
		"u2985863",
		"Cryptandra speciosa subsp. strigosa",
		"s2985862",
		2985863
	],
	[
		"u298645",
		"Crataegus azarolus subsp. aronia",
		"s298644",
		298645
	],
	[
		"u298647",
		"Crataegus sinaica subsp. sinaica",
		"s298646",
		298647
	],
	[
		"u226087",
		"Boehmeria virgata subsp. macrophylla",
		"s3017779",
		226087
	],
	[
		"u3144231",
		"Rhamnus erythroxyloides subsp. erythroxyloides",
		"s3091430",
		3144231
	],
	[
		"u3144260",
		"Rhamnus erythroxyloides subsp. iranica",
		"s3091430",
		3144260
	],
	[
		"u3091431",
		"Rhamnus erythroxyloides subsp. sintenisii",
		"s3091430",
		3091431
	],
	[
		"u947067",
		"Ficus cordata subsp. cordata",
		"s309266",
		947067
	],
	[
		"u106724",
		"Ficus cordata subsp. salicifolia",
		"s309266",
		106724
	],
	[
		"u1465309",
		"Ficus americana subsp. americana",
		"s309276",
		1465309
	],
	[
		"u669029",
		"Ficus americana subsp. guianensis",
		"s309276",
		669029
	],
	[
		"u669032",
		"Ficus lingua subsp. lingua",
		"s309306",
		669032
	],
	[
		"u672072",
		"Ficus natalensis subsp. graniticola",
		"s309307",
		672072
	],
	[
		"u309308",
		"Ficus natalensis subsp. leprieurii",
		"s309307",
		309308
	],
	[
		"u1001079",
		"Ficus natalensis subsp. natalensis",
		"s309307",
		1001079
	],
	[
		"u672071",
		"Ficus ottoniifolia subsp. lucanda",
		"s309317",
		672071
	],
	[
		"u309318",
		"Ficus ottoniifolia subsp. macrosyce",
		"s309317",
		309318
	],
	[
		"u669033",
		"Ficus ottoniifolia subsp. ottoniifolia",
		"s309317",
		669033
	],
	[
		"u672073",
		"Ficus sansibarica subsp. macrosperma",
		"s309319",
		672073
	],
	[
		"u669036",
		"Ficus sansibarica subsp. sansibarica",
		"s309319",
		669036
	],
	[
		"u140648",
		"Lyonothamnus floribundus subsp. aspleniifolius",
		"s32233",
		140648
	],
	[
		"u140649",
		"Lyonothamnus floribundus subsp. floribundus",
		"s32233",
		140649
	],
	[
		"u684368",
		"Dasiphora fruticosa subsp. floribunda",
		"s32239",
		684368
	],
	[
		"u3126972",
		"Rosa woodsii subsp. gratissima",
		"s32246",
		3126972
	],
	[
		"u59501",
		"Rubus idaeus subsp. idaeus",
		"s32247",
		59501
	],
	[
		"u2953672",
		"Rubus idaeus subsp. nipponicus",
		"s32247",
		2953672
	],
	[
		"u59503",
		"Rubus idaeus subsp. strigosus",
		"s32247",
		59503
	],
	[
		"u2675843",
		"Vauquelinia corymbosa subsp. heterodon",
		"s32250",
		2675843
	],
	[
		"u323239",
		"Rosa elliptica subsp. inodora",
		"s323240",
		323239
	],
	[
		"u2945684",
		"Spyridium mucronatum subsp. mucronatum",
		"s323967",
		2945684
	],
	[
		"u2945662",
		"Spyridium mucronatum subsp. multiflorum",
		"s323967",
		2945662
	],
	[
		"u2945663",
		"Spyridium mucronatum subsp. recurvum",
		"s323967",
		2945663
	],
	[
		"u3419900",
		"Parietaria judaica subsp. judaica",
		"s33127",
		3419900
	],
	[
		"u1399673",
		"Droguetia iners subsp. urticoides",
		"s344765",
		1399673
	],
	[
		"u1237854",
		"Ziziphus mucronata subsp. rhodesica",
		"s345811",
		1237854
	],
	[
		"u1302822",
		"Cannabis sativa subsp. indica",
		"s3483",
		1302822
	],
	[
		"u1678924",
		"Cannabis sativa subsp. sativa",
		"s3483",
		1678924
	],
	[
		"u1435599",
		"Urtica dioica subsp. dioica",
		"s3501",
		1435599
	],
	[
		"u2704053",
		"Urtica dioica subsp. kurdistanica",
		"s3501",
		2704053
	],
	[
		"u1211622",
		"Urtica dioica subsp. pubescens",
		"s3501",
		1211622
	],
	[
		"u1435578",
		"Urtica dioica subsp. sondenii",
		"s3501",
		1435578
	],
	[
		"u1435579",
		"Urtica dioica subsp. subinermis",
		"s3501",
		1435579
	],
	[
		"u2306709",
		"Urtica dioica subsp. xingjiangensis",
		"s3501",
		2306709
	],
	[
		"u1891594",
		"Sorbus aucuparia subsp. aucuparia",
		"s36599",
		1891594
	],
	[
		"u1891595",
		"Sorbus aucuparia subsp. glabrata",
		"s36599",
		1891595
	],
	[
		"u691238",
		"Sorbus aucuparia subsp. pohuashanensis",
		"s36599",
		691238
	],
	[
		"u2675842",
		"Vauquelinia californica subsp. sonorensis",
		"s36600",
		2675842
	],
	[
		"u674470",
		"Fragaria x ananassa subsp. ananassa",
		"s3747",
		674470
	],
	[
		"u674471",
		"Fragaria x ananassa subsp. cuneifolia",
		"s3747",
		674471
	],
	[
		"u1457994",
		"Malus domestica subsp. chinensis",
		"s3750",
		1457994
	],
	[
		"u2950755",
		"Prunus domestica subsp. domestica",
		"s3758",
		2950755
	],
	[
		"u114939",
		"Prunus domestica subsp. insititia",
		"s3758",
		114939
	],
	[
		"u2950751",
		"Prunus domestica subsp. italica",
		"s3758",
		2950751
	],
	[
		"u1617442",
		"Prunus domestica subsp. syriaca",
		"s3758",
		1617442
	],
	[
		"u378012",
		"Ficus ardisioides subsp. camptoneura",
		"s378011",
		378012
	],
	[
		"u378028",
		"Ficus polita subsp. polita",
		"s378027",
		378028
	],
	[
		"u378031",
		"Ficus reflexa subsp. reflexa",
		"s378030",
		378031
	],
	[
		"u1937439",
		"Perebea rubra subsp. rubra",
		"s382337",
		1937439
	],
	[
		"u1301412",
		"Potentilla hyparctica subsp. elatior",
		"s395303",
		1301412
	],
	[
		"u1534662",
		"Spiraea decumbens subsp. tomentosa",
		"s409508",
		1534662
	],
	[
		"u1211601",
		"Prunus avium subsp. avium",
		"s42229",
		1211601
	],
	[
		"u2926118",
		"Ficus crassiramea subsp. crassiramea",
		"s463847",
		2926118
	],
	[
		"u3108585",
		"Ficus nervosa subsp. nervosa",
		"s463862",
		3108585
	],
	[
		"u3048738",
		"Ficus nervosa subsp. pubinervis",
		"s463862",
		3048738
	],
	[
		"u1303706",
		"Girardinia diversifolia subsp. diversifolia",
		"s471946",
		1303706
	],
	[
		"u1303708",
		"Girardinia diversifolia subsp. triloba",
		"s471946",
		1303708
	],
	[
		"u1750583",
		"Alchemilla fischeri subsp. camerunensis",
		"s478308",
		1750583
	],
	[
		"u1506676",
		"Ficus glaberrima subsp. siamensis",
		"s479800",
		1506676
	],
	[
		"u2979718",
		"Crataegus orientalis subsp. orientalis",
		"s510734",
		2979718
	],
	[
		"u3141226",
		"Potentilla recta subsp. obscura",
		"s538583",
		3141226
	],
	[
		"u2602054",
		"Potentilla recta subsp. recta",
		"s538583",
		2602054
	],
	[
		"u3127347",
		"Frangula purshiana subsp. ultramafica",
		"s55262",
		3127347
	],
	[
		"u2592362",
		"Agrimonia eupatoria subsp. eupatoria",
		"s57912",
		2592362
	],
	[
		"u3371086",
		"Filipendula ulmaria subsp. picbaueri",
		"s57917",
		3371086
	],
	[
		"u2593497",
		"Filipendula ulmaria subsp. ulmaria",
		"s57917",
		2593497
	],
	[
		"u101019",
		"Fragaria vesca subsp. americana",
		"s57918",
		101019
	],
	[
		"u157670",
		"Fragaria vesca subsp. bracteata",
		"s57918",
		157670
	],
	[
		"u1595992",
		"Fragaria vesca subsp. californica",
		"s57918",
		1595992
	],
	[
		"u101020",
		"Fragaria vesca subsp. vesca",
		"s57918",
		101020
	],
	[
		"u2602053",
		"Potentilla erecta subsp. erecta",
		"s57940",
		2602053
	],
	[
		"u2593483",
		"Dryas octopetala subsp. octopetala",
		"s57948",
		2593483
	],
	[
		"u2602051",
		"Potentilla aurea subsp. aurea",
		"s581249",
		2602051
	],
	[
		"u1851387",
		"Potentilla aurea subsp. chrysocraspeda",
		"s581249",
		1851387
	],
	[
		"u1781624",
		"Pourouma tomentosa subsp. apiculata",
		"s597389",
		1781624
	],
	[
		"u2483622",
		"Pourouma tomentosa subsp. persecta",
		"s597389",
		2483622
	],
	[
		"u2602052",
		"Potentilla caulescens subsp. caulescens",
		"s637897",
		2602052
	],
	[
		"u2593498",
		"Fragaria viridis subsp. viridis",
		"s64942",
		2593498
	],
	[
		"u2602049",
		"Potentilla anglica subsp. anglica",
		"s660070",
		2602049
	],
	[
		"u2654680",
		"Phippsiomeles microcarpa subsp. hintonii",
		"s661347",
		2654680
	],
	[
		"u670306",
		"Potentilla hirta subsp. laeta",
		"s667256",
		670306
	],
	[
		"u1042676",
		"Potentilla supina subsp. paradoxa",
		"s667287",
		1042676
	],
	[
		"u667371",
		"Potentilla supina subsp. supina",
		"s667287",
		667371
	],
	[
		"u2071454",
		"Dryas ajanensis subsp. beringensis",
		"s669668",
		2071454
	],
	[
		"u1301410",
		"Potentilla arenosa subsp. arenosa",
		"s669784",
		1301410
	],
	[
		"u741070",
		"Potentilla egedei subsp. egedei",
		"s669785",
		741070
	],
	[
		"u1867298",
		"Maclura tinctoria subsp. mora",
		"s681456",
		1867298
	],
	[
		"u1867299",
		"Maclura tinctoria subsp. tinctoria",
		"s681456",
		1867299
	],
	[
		"u3048749",
		"Maquira guianensis subsp. costaricana",
		"s681459",
		3048749
	],
	[
		"u2828836",
		"Cotoneaster dammeri subsp. songmingensis",
		"s690315",
		2828836
	],
	[
		"u669800",
		"Rubus arcticus subsp. acaulis",
		"s70741",
		669800
	],
	[
		"u190231",
		"Rubus arcticus subsp. stellatus",
		"s70741",
		190231
	],
	[
		"u1867280",
		"Artocarpus anisophyllus subsp. anisophyllus",
		"s709036",
		1867280
	],
	[
		"u2675539",
		"Artocarpus lanceifolius subsp. lanceifolius",
		"s709049",
		2675539
	],
	[
		"u709054",
		"Artocarpus nitidus subsp. borneensis",
		"s709053",
		709054
	],
	[
		"u709055",
		"Artocarpus nitidus subsp. griffithii",
		"s709053",
		709055
	],
	[
		"u709056",
		"Artocarpus nitidus subsp. humilis",
		"s709053",
		709056
	],
	[
		"u709057",
		"Artocarpus nitidus subsp. lingnanensis",
		"s709053",
		709057
	],
	[
		"u2675504",
		"Artocarpus nitidus subsp. nitidus",
		"s709053",
		2675504
	],
	[
		"u2675512",
		"Artocarpus rigidus subsp. asperulus",
		"s709061",
		2675512
	],
	[
		"u2675541",
		"Artocarpus rigidus subsp. rigidus",
		"s709061",
		2675541
	],
	[
		"u944278",
		"Ceanothus divergens subsp. occidentalis",
		"s73677",
		944278
	],
	[
		"u161505",
		"Rosa stellata subsp. mirifica",
		"s74655",
		161505
	],
	[
		"u3091442",
		"Rubus ulmifolius subsp. heteromorphus",
		"s75099",
		3091442
	],
	[
		"u472367",
		"Rubus ursinus subsp. macropetalus",
		"s75100",
		472367
	],
	[
		"u2732311",
		"Sorocea sprucei subsp. saxicola",
		"s872017",
		2732311
	],
	[
		"u1533310",
		"Prunus padus subsp. borealis",
		"s97307",
		1533310
	],
	[
		"u2602056",
		"Prunus padus subsp. padus",
		"s97307",
		2602056
	],
	[
		"u319933",
		"Dorstenia cayapia subsp. asaroides",
		"s984798",
		319933
	],
	[
		"u2604983",
		"Dorstenia cayapia subsp. cayapia",
		"s984798",
		2604983
	],
	[
		"u984799",
		"Dorstenia cayapia subsp. paraguariensis",
		"s984798",
		984799
	],
	[
		"u984800",
		"Dorstenia cayapia subsp. vitifolia",
		"s984798",
		984800
	],
	[
		"u985673",
		"Crataegus rosei subsp. parryana",
		"s985672",
		985673
	],
	[
		"u985674",
		"Crataegus rosei subsp. rosei",
		"s985672",
		985674
	],
	[
		"u79768",
		"Begonia grandis subsp. evansiana",
		"s79767",
		79768
	],
	[
		"u200078",
		"Begonia grandis subsp. grandis",
		"s79767",
		200078
	],
	[
		"u189422",
		"Begonia grandis subsp. holostyla",
		"s79767",
		189422
	],
	[
		"u694482",
		"Begonia grandis subsp. sinensis",
		"s79767",
		694482
	],
	[
		"u200080",
		"Begonia loranthoides subsp. rhopalocarpa",
		"s200023",
		200080
	],
	[
		"u200081",
		"Begonia quadrialata subsp. quadrialata",
		"s200040",
		200081
	],
	[
		"u200079",
		"Begonia silletensis subsp. mengyangensis",
		"s172102",
		200079
	],
	[
		"u3652",
		"Bryonia cretica subsp. dioica",
		"s61884",
		3652
	],
	[
		"u2787746",
		"Citrullus lanatus subsp. cordophanus",
		"s3654",
		2787746
	],
	[
		"u95447",
		"Corynocarpus rupestris subsp. arborescens",
		"s95446",
		95447
	],
	[
		"u95647",
		"Corynocarpus rupestris subsp. rupestris",
		"s95446",
		95647
	],
	[
		"u217619",
		"Cucumis melo subsp. agrestis",
		"s3656",
		217619
	],
	[
		"u412675",
		"Cucumis melo subsp. melo",
		"s3656",
		412675
	],
	[
		"u2081797",
		"Cucumis melo subsp. meloides",
		"s3656",
		2081797
	],
	[
		"u396996",
		"Cucumis prophetarum subsp. prophetarum",
		"s217627",
		396996
	],
	[
		"u869948",
		"Cucumis rumphianus subsp. rumphianus",
		"s424441",
		869948
	],
	[
		"u869947",
		"Cucumis rumphianus subsp. tomentosus",
		"s424441",
		869947
	],
	[
		"u1094858",
		"Cucurbita argyrosperma subsp. argyrosperma",
		"s34294",
		1094858
	],
	[
		"u37648",
		"Cucurbita argyrosperma subsp. sororia",
		"s34294",
		37648
	],
	[
		"u61888",
		"Cucurbita maxima subsp. andreana",
		"s3661",
		61888
	],
	[
		"u1979246",
		"Cucurbita maxima subsp. maxima",
		"s3661",
		1979246
	],
	[
		"u184141",
		"Cucurbita melopepo subsp. melopepo",
		"s3665",
		184141
	],
	[
		"u300824",
		"Cucurbita melopepo subsp. melopepo x subsp. texana var. fraterna",
		"s3665",
		300824
	],
	[
		"u2726055",
		"Cucurbita melopepo subsp. texana",
		"s3665",
		2726055
	],
	[
		"u184138",
		"Cucurbita okeechobeensis subsp. martinezii",
		"s184137",
		184138
	],
	[
		"u1094863",
		"Cucurbita okeechobeensis subsp. okeechobeensis",
		"s184137",
		1094863
	],
	[
		"u3664",
		"Cucurbita pepo subsp. pepo",
		"s3663",
		3664
	],
	[
		"u463187",
		"Ecballium elaterium subsp. dioicum",
		"s3679",
		463187
	],
	[
		"u463188",
		"Ecballium elaterium subsp. elaterium",
		"s3679",
		463188
	],
	[
		"u1743013",
		"Indomelothria chlorocarpa subsp. chlorocarpa",
		"s418464",
		1743013
	],
	[
		"u519334",
		"Momordica charantia subsp. charantia",
		"s3673",
		519334
	],
	[
		"u519335",
		"Momordica charantia subsp. macroloba",
		"s3673",
		519335
	],
	[
		"u2713437",
		"Momordica sahyadrica subsp. anamalayana",
		"s1719625",
		2713437
	],
	[
		"u703385",
		"Momordica subangulata subsp. renigera",
		"s703391",
		703385
	],
	[
		"u388301",
		"Neoalsomitra schefferiana subsp. podagrica",
		"s427674",
		388301
	],
	[
		"u1144445",
		"Trichosanthes montana subsp. crassipes",
		"s486427",
		1144445
	],
	[
		"u1144444",
		"Trichosanthes montana subsp. montana",
		"s486427",
		1144444
	],
	[
		"u459633",
		"Trichosanthes pubera subsp. rubriflos",
		"s459632",
		459633
	],
	[
		"u1144937",
		"Trichosanthes tricuspidata subsp. javanica",
		"s654837",
		1144937
	],
	[
		"u1144462",
		"Trichosanthes tricuspidata subsp. tricuspidata",
		"s654837",
		1144462
	]
];
var RANK_LABEL = {
	reino: "Reino",
	divisao: "Divisão",
	classe: "Classe",
	ordem: "Ordem",
	familia: "Família",
	genero: "Gênero",
	especie: "Espécie",
	subespecie: "Subespécie"
};
function lowerTaxa(rows, rank) {
	return rows.map(([id, scientific, parentId, ncbiId]) => ({
		id,
		rank,
		scientific,
		parentId,
		ncbiId
	}));
}
var TAXA = [
	...[
		{
			id: "rosales",
			rank: "ordem",
			scientific: "Rosales",
			parentId: null,
			ncbiId: 3744,
			summary: "Ordem Rosales no NCBI Taxonomy, com as famílias, gêneros, espécies e subespécies. Sem subfamílias nem tribos."
		},
		{
			id: "barbeyaceae",
			rank: "familia",
			scientific: "Barbeyaceae",
			parentId: "rosales",
			ncbiId: 48389,
			summary: "Família de Rosales no NCBI Taxonomy. Os gêneros abaixo são os de Barbeyaceae, sem subfamílias nem tribos."
		},
		{
			id: "barbeya",
			rank: "genero",
			scientific: "Barbeya",
			parentId: "barbeyaceae",
			ncbiId: 48390,
			summary: "Gênero de Barbeyaceae no NCBI Taxonomy."
		},
		{
			id: "cannabaceae",
			rank: "familia",
			scientific: "Cannabaceae",
			parentId: "rosales",
			ncbiId: 3481,
			summary: "Família de Rosales no NCBI Taxonomy. Os gêneros abaixo são os de Cannabaceae, sem subfamílias nem tribos."
		},
		{
			id: "aphananthe",
			rank: "genero",
			scientific: "Aphananthe",
			parentId: "cannabaceae",
			ncbiId: 63050,
			summary: "Gênero de Cannabaceae no NCBI Taxonomy."
		},
		{
			id: "cannabis",
			rank: "genero",
			scientific: "Cannabis",
			parentId: "cannabaceae",
			ncbiId: 3482,
			summary: "Gênero de Cannabaceae no NCBI Taxonomy."
		},
		{
			id: "celtis",
			rank: "genero",
			scientific: "Celtis",
			parentId: "cannabaceae",
			ncbiId: 13408,
			summary: "Gênero de Cannabaceae no NCBI Taxonomy."
		},
		{
			id: "gironniera",
			rank: "genero",
			scientific: "Gironniera",
			parentId: "cannabaceae",
			ncbiId: 63059,
			summary: "Gênero de Cannabaceae no NCBI Taxonomy."
		},
		{
			id: "humulus",
			rank: "genero",
			scientific: "Humulus",
			parentId: "cannabaceae",
			ncbiId: 3484,
			summary: "Gênero de Cannabaceae no NCBI Taxonomy."
		},
		{
			id: "lozanella",
			rank: "genero",
			scientific: "Lozanella",
			parentId: "cannabaceae",
			ncbiId: 194263,
			summary: "Gênero de Cannabaceae no NCBI Taxonomy."
		},
		{
			id: "parasponia",
			rank: "genero",
			scientific: "Parasponia",
			parentId: "cannabaceae",
			ncbiId: 3475,
			summary: "Gênero de Cannabaceae no NCBI Taxonomy."
		},
		{
			id: "parasponia-x-trema",
			rank: "genero",
			scientific: "Parasponia x Trema",
			parentId: "cannabaceae",
			ncbiId: 2005747,
			summary: "Gênero de Cannabaceae no NCBI Taxonomy."
		},
		{
			id: "pteroceltis",
			rank: "genero",
			scientific: "Pteroceltis",
			parentId: "cannabaceae",
			ncbiId: 63061,
			summary: "Gênero de Cannabaceae no NCBI Taxonomy."
		},
		{
			id: "trema",
			rank: "genero",
			scientific: "Trema",
			parentId: "cannabaceae",
			ncbiId: 3479,
			summary: "Gênero de Cannabaceae no NCBI Taxonomy."
		},
		{
			id: "dirachmaceae",
			rank: "familia",
			scientific: "Dirachmaceae",
			parentId: "rosales",
			ncbiId: 113358,
			summary: "Família de Rosales no NCBI Taxonomy. Os gêneros abaixo são os de Dirachmaceae, sem subfamílias nem tribos."
		},
		{
			id: "dirachma",
			rank: "genero",
			scientific: "Dirachma",
			parentId: "dirachmaceae",
			ncbiId: 72159,
			summary: "Gênero de Dirachmaceae no NCBI Taxonomy."
		},
		{
			id: "elaeagnaceae",
			rank: "familia",
			scientific: "Elaeagnaceae",
			parentId: "rosales",
			ncbiId: 25996,
			summary: "Família de Rosales no NCBI Taxonomy. Os gêneros abaixo são os de Elaeagnaceae, sem subfamílias nem tribos."
		},
		{
			id: "elaeagnus",
			rank: "genero",
			scientific: "Elaeagnus",
			parentId: "elaeagnaceae",
			ncbiId: 36776,
			summary: "Gênero de Elaeagnaceae no NCBI Taxonomy."
		},
		{
			id: "hippophae",
			rank: "genero",
			scientific: "Hippophae",
			parentId: "elaeagnaceae",
			ncbiId: 48233,
			summary: "Gênero de Elaeagnaceae no NCBI Taxonomy."
		},
		{
			id: "shepherdia",
			rank: "genero",
			scientific: "Shepherdia",
			parentId: "elaeagnaceae",
			ncbiId: 36904,
			summary: "Gênero de Elaeagnaceae no NCBI Taxonomy."
		},
		{
			id: "moraceae",
			rank: "familia",
			scientific: "Moraceae",
			parentId: "rosales",
			ncbiId: 3487,
			summary: "Família das figueiras e amoreiras. Os gêneros abaixo são os que o NCBI Taxonomy coloca em Moraceae, sem subfamílias nem tribos."
		},
		{
			id: "afromorus",
			rank: "genero",
			scientific: "Afromorus",
			parentId: "moraceae",
			ncbiId: 3054367,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "allaeanthus",
			rank: "genero",
			scientific: "Allaeanthus",
			parentId: "moraceae",
			ncbiId: 2604959,
			summary: "Gênero de Moraceae no NCBI Taxonomy. Espécies ainda não incluídas."
		},
		{
			id: "ampalis",
			rank: "genero",
			scientific: "Ampalis",
			parentId: "moraceae",
			ncbiId: 3054912,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "antiaris",
			rank: "genero",
			scientific: "Antiaris",
			parentId: "moraceae",
			ncbiId: 241856,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "antiaropsis",
			rank: "genero",
			scientific: "Antiaropsis",
			parentId: "moraceae",
			ncbiId: 241858,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "artocarpus",
			rank: "genero",
			scientific: "Artocarpus",
			parentId: "moraceae",
			ncbiId: 3488,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "bagassa",
			rank: "genero",
			scientific: "Bagassa",
			parentId: "moraceae",
			ncbiId: 241861,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "batocarpus",
			rank: "genero",
			scientific: "Batocarpus",
			parentId: "moraceae",
			ncbiId: 241863,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "bleekrodea",
			rank: "genero",
			scientific: "Bleekrodea",
			parentId: "moraceae",
			ncbiId: 241866,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "bosqueiopsis",
			rank: "genero",
			scientific: "Bosqueiopsis",
			parentId: "moraceae",
			ncbiId: 1899164,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "brosimum",
			rank: "genero",
			scientific: "Brosimum",
			parentId: "moraceae",
			ncbiId: 194252,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "broussonetia",
			rank: "genero",
			scientific: "Broussonetia",
			parentId: "moraceae",
			ncbiId: 66379,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "calaunia",
			rank: "genero",
			scientific: "Calaunia",
			parentId: "moraceae",
			ncbiId: 3704653,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "castilla",
			rank: "genero",
			scientific: "Castilla",
			parentId: "moraceae",
			ncbiId: 194256,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "clarisia",
			rank: "genero",
			scientific: "Clarisia",
			parentId: "moraceae",
			ncbiId: 241873,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "dorstenia",
			rank: "genero",
			scientific: "Dorstenia",
			parentId: "moraceae",
			ncbiId: 106722,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "fatoua",
			rank: "genero",
			scientific: "Fatoua",
			parentId: "moraceae",
			ncbiId: 66389,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "ficus",
			rank: "genero",
			scientific: "Ficus",
			parentId: "moraceae",
			ncbiId: 3493,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "helicostylis",
			rank: "genero",
			scientific: "Helicostylis",
			parentId: "moraceae",
			ncbiId: 241884,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "hijmania",
			rank: "genero",
			scientific: "Hijmania",
			parentId: "moraceae",
			ncbiId: 3453196,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "hullettia",
			rank: "genero",
			scientific: "Hullettia",
			parentId: "moraceae",
			ncbiId: 709067,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "maclura",
			rank: "genero",
			scientific: "Maclura",
			parentId: "moraceae",
			ncbiId: 3495,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "maillardia",
			rank: "genero",
			scientific: "Maillardia",
			parentId: "moraceae",
			ncbiId: 2807049,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "malaisia",
			rank: "genero",
			scientific: "Malaisia",
			parentId: "moraceae",
			ncbiId: 1745977,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "maquira",
			rank: "genero",
			scientific: "Maquira",
			parentId: "moraceae",
			ncbiId: 241888,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "mesogyne",
			rank: "genero",
			scientific: "Mesogyne",
			parentId: "moraceae",
			ncbiId: 241891,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "milicia",
			rank: "genero",
			scientific: "Milicia",
			parentId: "moraceae",
			ncbiId: 58663,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "morus",
			rank: "genero",
			scientific: "Morus",
			parentId: "moraceae",
			ncbiId: 3497,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "naucleopsis",
			rank: "genero",
			scientific: "Naucleopsis",
			parentId: "moraceae",
			ncbiId: 241894,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "parartocarpus",
			rank: "genero",
			scientific: "Parartocarpus",
			parentId: "moraceae",
			ncbiId: 241901,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "paratrophis",
			rank: "genero",
			scientific: "Paratrophis",
			parentId: "moraceae",
			ncbiId: 3054368,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "perebea",
			rank: "genero",
			scientific: "Perebea",
			parentId: "moraceae",
			ncbiId: 241903,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "poulsenia",
			rank: "genero",
			scientific: "Poulsenia",
			parentId: "moraceae",
			ncbiId: 241909,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "prainea",
			rank: "genero",
			scientific: "Prainea",
			parentId: "moraceae",
			ncbiId: 241911,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "pseudolmedia",
			rank: "genero",
			scientific: "Pseudolmedia",
			parentId: "moraceae",
			ncbiId: 241914,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "pseudomorus",
			rank: "genero",
			scientific: "Pseudomorus",
			parentId: "moraceae",
			ncbiId: 2887221,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "pseudostreblus",
			rank: "genero",
			scientific: "Pseudostreblus",
			parentId: "moraceae",
			ncbiId: 3054927,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "scyphosyce",
			rank: "genero",
			scientific: "Scyphosyce",
			parentId: "moraceae",
			ncbiId: 2605019,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "sloetia",
			rank: "genero",
			scientific: "Sloetia",
			parentId: "moraceae",
			ncbiId: 2604995,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "sloetiopsis",
			rank: "genero",
			scientific: "Sloetiopsis",
			parentId: "moraceae",
			ncbiId: 3054913,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "sorocea",
			rank: "genero",
			scientific: "Sorocea",
			parentId: "moraceae",
			ncbiId: 241919,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "sparattosyce",
			rank: "genero",
			scientific: "Sparattosyce",
			parentId: "moraceae",
			ncbiId: 241925,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "streblus",
			rank: "genero",
			scientific: "Streblus",
			parentId: "moraceae",
			ncbiId: 194260,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "taxotrophis",
			rank: "genero",
			scientific: "Taxotrophis",
			parentId: "moraceae",
			ncbiId: 1745980,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "treculia",
			rank: "genero",
			scientific: "Treculia",
			parentId: "moraceae",
			ncbiId: 709071,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "trilepisium",
			rank: "genero",
			scientific: "Trilepisium",
			parentId: "moraceae",
			ncbiId: 241930,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "trophis",
			rank: "genero",
			scientific: "Trophis",
			parentId: "moraceae",
			ncbiId: 241932,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "utsetela",
			rank: "genero",
			scientific: "Utsetela",
			parentId: "moraceae",
			ncbiId: 241939,
			summary: "Gênero de Moraceae no NCBI Taxonomy."
		},
		{
			id: "rhamnaceae",
			rank: "familia",
			scientific: "Rhamnaceae",
			parentId: "rosales",
			ncbiId: 3608,
			summary: "Família de Rosales no NCBI Taxonomy. Os gêneros abaixo são os de Rhamnaceae, sem subfamílias nem tribos."
		},
		{
			id: "adolphia",
			rank: "genero",
			scientific: "Adolphia",
			parentId: "rhamnaceae",
			ncbiId: 73669,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "alphitonia",
			rank: "genero",
			scientific: "Alphitonia",
			parentId: "rhamnaceae",
			ncbiId: 106657,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "alvimiantha",
			rank: "genero",
			scientific: "Alvimiantha",
			parentId: "rhamnaceae",
			ncbiId: 325295,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "ampelozizyphus",
			rank: "genero",
			scientific: "Ampelozizyphus",
			parentId: "rhamnaceae",
			ncbiId: 106659,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "araracuara",
			rank: "genero",
			scientific: "Araracuara",
			parentId: "rhamnaceae",
			ncbiId: 3704793,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "auerodendron",
			rank: "genero",
			scientific: "Auerodendron",
			parentId: "rhamnaceae",
			ncbiId: 325314,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "bathiorhamnus",
			rank: "genero",
			scientific: "Bathiorhamnus",
			parentId: "rhamnaceae",
			ncbiId: 106661,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "berchemia",
			rank: "genero",
			scientific: "Berchemia",
			parentId: "rhamnaceae",
			ncbiId: 72167,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "berchemiella",
			rank: "genero",
			scientific: "Berchemiella",
			parentId: "rhamnaceae",
			ncbiId: 325277,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "blackallia",
			rank: "genero",
			scientific: "Blackallia",
			parentId: "rhamnaceae",
			ncbiId: 323938,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "ceanothus",
			rank: "genero",
			scientific: "Ceanothus",
			parentId: "rhamnaceae",
			ncbiId: 22922,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "colletia",
			rank: "genero",
			scientific: "Colletia",
			parentId: "rhamnaceae",
			ncbiId: 3612,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "colubrina",
			rank: "genero",
			scientific: "Colubrina",
			parentId: "rhamnaceae",
			ncbiId: 106663,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "conalma",
			rank: "genero",
			scientific: "Conalma",
			parentId: "rhamnaceae",
			ncbiId: 3704682,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "condalia",
			rank: "genero",
			scientific: "Condalia",
			parentId: "rhamnaceae",
			ncbiId: 106666,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "condaliopsis",
			rank: "genero",
			scientific: "Condaliopsis",
			parentId: "rhamnaceae",
			ncbiId: 3704683,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "crumenaria",
			rank: "genero",
			scientific: "Crumenaria",
			parentId: "rhamnaceae",
			ncbiId: 106668,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "cryptandra",
			rank: "genero",
			scientific: "Cryptandra",
			parentId: "rhamnaceae",
			ncbiId: 106670,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "dallachya",
			rank: "genero",
			scientific: "Dallachya",
			parentId: "rhamnaceae",
			ncbiId: 325315,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "discaria",
			rank: "genero",
			scientific: "Discaria",
			parentId: "rhamnaceae",
			ncbiId: 48243,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "doerpfeldia",
			rank: "genero",
			scientific: "Doerpfeldia",
			parentId: "rhamnaceae",
			ncbiId: 106672,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "emmenosperma",
			rank: "genero",
			scientific: "Emmenosperma",
			parentId: "rhamnaceae",
			ncbiId: 106674,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "fenghwaia",
			rank: "genero",
			scientific: "Fenghwaia",
			parentId: "rhamnaceae",
			ncbiId: 2815115,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "frangula",
			rank: "genero",
			scientific: "Frangula",
			parentId: "rhamnaceae",
			ncbiId: 106676,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "gouania",
			rank: "genero",
			scientific: "Gouania",
			parentId: "rhamnaceae",
			ncbiId: 106678,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "granitites",
			rank: "genero",
			scientific: "Granitites",
			parentId: "rhamnaceae",
			ncbiId: 155901,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "helinus",
			rank: "genero",
			scientific: "Helinus",
			parentId: "rhamnaceae",
			ncbiId: 106680,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "hovenia",
			rank: "genero",
			scientific: "Hovenia",
			parentId: "rhamnaceae",
			ncbiId: 99291,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "jaffrea",
			rank: "genero",
			scientific: "Jaffrea",
			parentId: "rhamnaceae",
			ncbiId: 1737409,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "johnstonalia",
			rank: "genero",
			scientific: "Johnstonalia",
			parentId: "rhamnaceae",
			ncbiId: 3704794,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "karwinskia",
			rank: "genero",
			scientific: "Karwinskia",
			parentId: "rhamnaceae",
			ncbiId: 106682,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "kentrothamnus",
			rank: "genero",
			scientific: "Kentrothamnus",
			parentId: "rhamnaceae",
			ncbiId: 262938,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "krugiodendron",
			rank: "genero",
			scientific: "Krugiodendron",
			parentId: "rhamnaceae",
			ncbiId: 106684,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "lasiodiscus",
			rank: "genero",
			scientific: "Lasiodiscus",
			parentId: "rhamnaceae",
			ncbiId: 106686,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "maesopsis",
			rank: "genero",
			scientific: "Maesopsis",
			parentId: "rhamnaceae",
			ncbiId: 106688,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "nesiota",
			rank: "genero",
			scientific: "Nesiota",
			parentId: "rhamnaceae",
			ncbiId: 72161,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "noltea",
			rank: "genero",
			scientific: "Noltea",
			parentId: "rhamnaceae",
			ncbiId: 106690,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "ochetophila",
			rank: "genero",
			scientific: "Ochetophila",
			parentId: "rhamnaceae",
			ncbiId: 1967156,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "oreoherzogia",
			rank: "genero",
			scientific: "Oreoherzogia",
			parentId: "rhamnaceae",
			ncbiId: 1948872,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "paliurus",
			rank: "genero",
			scientific: "Paliurus",
			parentId: "rhamnaceae",
			ncbiId: 106692,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "papistylus",
			rank: "genero",
			scientific: "Papistylus",
			parentId: "rhamnaceae",
			ncbiId: 587194,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "phylica",
			rank: "genero",
			scientific: "Phylica",
			parentId: "rhamnaceae",
			ncbiId: 72163,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "phyllogeiton",
			rank: "genero",
			scientific: "Phyllogeiton",
			parentId: "rhamnaceae",
			ncbiId: 3103835,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "polianthion",
			rank: "genero",
			scientific: "Polianthion",
			parentId: "rhamnaceae",
			ncbiId: 456987,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "pomaderris",
			rank: "genero",
			scientific: "Pomaderris",
			parentId: "rhamnaceae",
			ncbiId: 106697,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "pseudoziziphus",
			rank: "genero",
			scientific: "Pseudoziziphus",
			parentId: "rhamnaceae",
			ncbiId: 1948873,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "reissekia",
			rank: "genero",
			scientific: "Reissekia",
			parentId: "rhamnaceae",
			ncbiId: 106699,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "retanilla",
			rank: "genero",
			scientific: "Retanilla",
			parentId: "rhamnaceae",
			ncbiId: 262940,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "reynosia",
			rank: "genero",
			scientific: "Reynosia",
			parentId: "rhamnaceae",
			ncbiId: 106701,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "rhamnella",
			rank: "genero",
			scientific: "Rhamnella",
			parentId: "rhamnaceae",
			ncbiId: 106703,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "rhamnidium",
			rank: "genero",
			scientific: "Rhamnidium",
			parentId: "rhamnaceae",
			ncbiId: 106705,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "rhamnus",
			rank: "genero",
			scientific: "Rhamnus",
			parentId: "rhamnaceae",
			ncbiId: 3609,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "sageretia",
			rank: "genero",
			scientific: "Sageretia",
			parentId: "rhamnaceae",
			ncbiId: 72165,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "sarcomphalus",
			rank: "genero",
			scientific: "Sarcomphalus",
			parentId: "rhamnaceae",
			ncbiId: 1948874,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "schistocarpaea",
			rank: "genero",
			scientific: "Schistocarpaea",
			parentId: "rhamnaceae",
			ncbiId: 106707,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "scutia",
			rank: "genero",
			scientific: "Scutia",
			parentId: "rhamnaceae",
			ncbiId: 106709,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "serichonus",
			rank: "genero",
			scientific: "Serichonus",
			parentId: "rhamnaceae",
			ncbiId: 2033030,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "siegfriedia",
			rank: "genero",
			scientific: "Siegfriedia",
			parentId: "rhamnaceae",
			ncbiId: 106711,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "smythea",
			rank: "genero",
			scientific: "Smythea",
			parentId: "rhamnaceae",
			ncbiId: 325316,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "spyridium",
			rank: "genero",
			scientific: "Spyridium",
			parentId: "rhamnaceae",
			ncbiId: 73715,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "stenanthemum",
			rank: "genero",
			scientific: "Stenanthemum",
			parentId: "rhamnaceae",
			ncbiId: 323940,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "trevoa",
			rank: "genero",
			scientific: "Trevoa",
			parentId: "rhamnaceae",
			ncbiId: 48246,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "trichocephalus",
			rank: "genero",
			scientific: "Trichocephalus",
			parentId: "rhamnaceae",
			ncbiId: 378917,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "trymalium",
			rank: "genero",
			scientific: "Trymalium",
			parentId: "rhamnaceae",
			ncbiId: 106716,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "ventia",
			rank: "genero",
			scientific: "Ventia",
			parentId: "rhamnaceae",
			ncbiId: 1948875,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "ventilago",
			rank: "genero",
			scientific: "Ventilago",
			parentId: "rhamnaceae",
			ncbiId: 106719,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "ziziphus",
			rank: "genero",
			scientific: "Ziziphus",
			parentId: "rhamnaceae",
			ncbiId: 72171,
			summary: "Gênero de Rhamnaceae no NCBI Taxonomy."
		},
		{
			id: "rosaceae",
			rank: "familia",
			scientific: "Rosaceae",
			parentId: "rosales",
			ncbiId: 3745,
			summary: "Família das rosas, macieiras, ameixeiras e morangueiros. Os gêneros abaixo são os que o NCBI Taxonomy coloca em Rosaceae, sem subfamílias nem tribos."
		},
		{
			id: "acaena",
			rank: "genero",
			scientific: "Acaena",
			parentId: "rosaceae",
			ncbiId: 137429,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "adenostoma",
			rank: "genero",
			scientific: "Adenostoma",
			parentId: "rosaceae",
			ncbiId: 23136,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "agrimonia",
			rank: "genero",
			scientific: "Agrimonia",
			parentId: "rosaceae",
			ncbiId: 23137,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "alchemilla",
			rank: "genero",
			scientific: "Alchemilla",
			parentId: "rosaceae",
			ncbiId: 23138,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "alniaria",
			rank: "genero",
			scientific: "Alniaria",
			parentId: "rosaceae",
			ncbiId: 2912036,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "amelanchier",
			rank: "genero",
			scientific: "Amelanchier",
			parentId: "rosaceae",
			ncbiId: 23139,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "aphanes",
			rank: "genero",
			scientific: "Aphanes",
			parentId: "rosaceae",
			ncbiId: 57944,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "aremonia",
			rank: "genero",
			scientific: "Aremonia",
			parentId: "rosaceae",
			ncbiId: 57913,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "argentina",
			rank: "genero",
			scientific: "Argentina",
			parentId: "rosaceae",
			ncbiId: 3131914,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "aria",
			rank: "genero",
			scientific: "Aria",
			parentId: "rosaceae",
			ncbiId: 36601,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "aronia",
			rank: "genero",
			scientific: "Aronia",
			parentId: "rosaceae",
			ncbiId: 193297,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "aruncus",
			rank: "genero",
			scientific: "Aruncus",
			parentId: "rosaceae",
			ncbiId: 23143,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "bencomia",
			rank: "genero",
			scientific: "Bencomia",
			parentId: "rosaceae",
			ncbiId: 137432,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "cercocarpus",
			rank: "genero",
			scientific: "Cercocarpus",
			parentId: "rosaceae",
			ncbiId: 23146,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "chaenomeles",
			rank: "genero",
			scientific: "Chaenomeles",
			parentId: "rosaceae",
			ncbiId: 36603,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "chamaebatia",
			rank: "genero",
			scientific: "Chamaebatia",
			parentId: "rosaceae",
			ncbiId: 140995,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "chamaebatiaria",
			rank: "genero",
			scientific: "Chamaebatiaria",
			parentId: "rosaceae",
			ncbiId: 23149,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "chamaecallis",
			rank: "genero",
			scientific: "Chamaecallis",
			parentId: "rosaceae",
			ncbiId: 1570116,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "chamaemeles",
			rank: "genero",
			scientific: "Chamaemeles",
			parentId: "rosaceae",
			ncbiId: 397656,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "chamaemespilus",
			rank: "genero",
			scientific: "Chamaemespilus",
			parentId: "rosaceae",
			ncbiId: 193299,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "chamaerhodos",
			rank: "genero",
			scientific: "Chamaerhodos",
			parentId: "rosaceae",
			ncbiId: 57915,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "cliffortia",
			rank: "genero",
			scientific: "Cliffortia",
			parentId: "rosaceae",
			ncbiId: 137437,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "coleogyne",
			rank: "genero",
			scientific: "Coleogyne",
			parentId: "rosaceae",
			ncbiId: 401068,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "coluria",
			rank: "genero",
			scientific: "Coluria",
			parentId: "rosaceae",
			ncbiId: 148886,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "comarum",
			rank: "genero",
			scientific: "Comarum",
			parentId: "rosaceae",
			ncbiId: 395100,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "cormus",
			rank: "genero",
			scientific: "Cormus",
			parentId: "rosaceae",
			ncbiId: 36605,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "cotoneaster",
			rank: "genero",
			scientific: "Cotoneaster",
			parentId: "rosaceae",
			ncbiId: 36607,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "crataegus",
			rank: "genero",
			scientific: "Crataegus",
			parentId: "rosaceae",
			ncbiId: 23159,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "cydonia",
			rank: "genero",
			scientific: "Cydonia",
			parentId: "rosaceae",
			ncbiId: 36609,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "dalibarda",
			rank: "genero",
			scientific: "Dalibarda",
			parentId: "rosaceae",
			ncbiId: 75060,
			summary: "Gênero de Rosaceae no NCBI Taxonomy. Espécies ainda não incluídas."
		},
		{
			id: "dasiphora",
			rank: "genero",
			scientific: "Dasiphora",
			parentId: "rosaceae",
			ncbiId: 637889,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "dendriopoterium",
			rank: "genero",
			scientific: "Dendriopoterium",
			parentId: "rosaceae",
			ncbiId: 137440,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "dichotomanthes",
			rank: "genero",
			scientific: "Dichotomanthes",
			parentId: "rosaceae",
			ncbiId: 193302,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "dryas",
			rank: "genero",
			scientific: "Dryas",
			parentId: "rosaceae",
			ncbiId: 48230,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "drymocallis",
			rank: "genero",
			scientific: "Drymocallis",
			parentId: "rosaceae",
			ncbiId: 637892,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "dunnaria",
			rank: "genero",
			scientific: "Dunnaria",
			parentId: "rosaceae",
			ncbiId: 2912037,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "eriobotrya",
			rank: "genero",
			scientific: "Eriobotrya",
			parentId: "rosaceae",
			ncbiId: 23166,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "eriolobus",
			rank: "genero",
			scientific: "Eriolobus",
			parentId: "rosaceae",
			ncbiId: 193306,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "exochorda",
			rank: "genero",
			scientific: "Exochorda",
			parentId: "rosaceae",
			ncbiId: 23168,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "fallugia",
			rank: "genero",
			scientific: "Fallugia",
			parentId: "rosaceae",
			ncbiId: 23169,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "farinopsis",
			rank: "genero",
			scientific: "Farinopsis",
			parentId: "rosaceae",
			ncbiId: 667211,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "filipendula",
			rank: "genero",
			scientific: "Filipendula",
			parentId: "rosaceae",
			ncbiId: 23170,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "fragaria",
			rank: "genero",
			scientific: "Fragaria",
			parentId: "rosaceae",
			ncbiId: 3746,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "geum",
			rank: "genero",
			scientific: "Geum",
			parentId: "rosaceae",
			ncbiId: 3761,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "gillenia",
			rank: "genero",
			scientific: "Gillenia",
			parentId: "rosaceae",
			ncbiId: 141001,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "griffitharia",
			rank: "genero",
			scientific: "Griffitharia",
			parentId: "rosaceae",
			ncbiId: 2912038,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "hagenia",
			rank: "genero",
			scientific: "Hagenia",
			parentId: "rosaceae",
			ncbiId: 57920,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "hedlundia",
			rank: "genero",
			scientific: "Hedlundia",
			parentId: "rosaceae",
			ncbiId: 2666035,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "hesperomeles",
			rank: "genero",
			scientific: "Hesperomeles",
			parentId: "rosaceae",
			ncbiId: 690340,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "heteromeles",
			rank: "genero",
			scientific: "Heteromeles",
			parentId: "rosaceae",
			ncbiId: 36611,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "holodiscus",
			rank: "genero",
			scientific: "Holodiscus",
			parentId: "rosaceae",
			ncbiId: 23176,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "horkelia",
			rank: "genero",
			scientific: "Horkelia",
			parentId: "rosaceae",
			ncbiId: 57922,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "horkeliella",
			rank: "genero",
			scientific: "Horkeliella",
			parentId: "rosaceae",
			ncbiId: 654628,
			summary: "Gênero de Rosaceae no NCBI Taxonomy. Espécies ainda não incluídas."
		},
		{
			id: "ivesia",
			rank: "genero",
			scientific: "Ivesia",
			parentId: "rosaceae",
			ncbiId: 57924,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "kageneckia",
			rank: "genero",
			scientific: "Kageneckia",
			parentId: "rosaceae",
			ncbiId: 23180,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "karpatiosorbus",
			rank: "genero",
			scientific: "Karpatiosorbus",
			parentId: "rosaceae",
			ncbiId: 2912042,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "kelseya",
			rank: "genero",
			scientific: "Kelseya",
			parentId: "rosaceae",
			ncbiId: 401070,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "kerria",
			rank: "genero",
			scientific: "Kerria",
			parentId: "rosaceae",
			ncbiId: 120384,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "lachemilla",
			rank: "genero",
			scientific: "Lachemilla",
			parentId: "rosaceae",
			ncbiId: 478358,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "leucosidea",
			rank: "genero",
			scientific: "Leucosidea",
			parentId: "rosaceae",
			ncbiId: 137444,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "lindleya",
			rank: "genero",
			scientific: "Lindleya",
			parentId: "rosaceae",
			ncbiId: 23184,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "lindleyella",
			rank: "genero",
			scientific: "Lindleyella",
			parentId: "rosaceae",
			ncbiId: 2201422,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "luetkea",
			rank: "genero",
			scientific: "Luetkea",
			parentId: "rosaceae",
			ncbiId: 357458,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "lyonothamnus",
			rank: "genero",
			scientific: "Lyonothamnus",
			parentId: "rosaceae",
			ncbiId: 23186,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "macromeles",
			rank: "genero",
			scientific: "Macromeles",
			parentId: "rosaceae",
			ncbiId: 2913980,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "majovskya",
			rank: "genero",
			scientific: "Majovskya",
			parentId: "rosaceae",
			ncbiId: 2912043,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "malacomeles",
			rank: "genero",
			scientific: "Malacomeles",
			parentId: "rosaceae",
			ncbiId: 36613,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "malus",
			rank: "genero",
			scientific: "Malus",
			parentId: "rosaceae",
			ncbiId: 3749,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "malus-x-pyrus",
			rank: "genero",
			scientific: "Malus x Pyrus",
			parentId: "rosaceae",
			ncbiId: 2587781,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "marcetella",
			rank: "genero",
			scientific: "Marcetella",
			parentId: "rosaceae",
			ncbiId: 137446,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "margyricarpus",
			rank: "genero",
			scientific: "Margyricarpus",
			parentId: "rosaceae",
			ncbiId: 281855,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "mespilus",
			rank: "genero",
			scientific: "Mespilus",
			parentId: "rosaceae",
			ncbiId: 36615,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "micromeles",
			rank: "genero",
			scientific: "Micromeles",
			parentId: "rosaceae",
			ncbiId: 2201384,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "neillia",
			rank: "genero",
			scientific: "Neillia",
			parentId: "rosaceae",
			ncbiId: 23191,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "neviusia",
			rank: "genero",
			scientific: "Neviusia",
			parentId: "rosaceae",
			ncbiId: 23192,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "normeyera",
			rank: "genero",
			scientific: "Normeyera",
			parentId: "rosaceae",
			ncbiId: 2912044,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "oemleria",
			rank: "genero",
			scientific: "Oemleria",
			parentId: "rosaceae",
			ncbiId: 133199,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "oncostylus",
			rank: "genero",
			scientific: "Oncostylus",
			parentId: "rosaceae",
			ncbiId: 148903,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "osteomeles",
			rank: "genero",
			scientific: "Osteomeles",
			parentId: "rosaceae",
			ncbiId: 36617,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "pentactina",
			rank: "genero",
			scientific: "Pentactina",
			parentId: "rosaceae",
			ncbiId: 519532,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "peraphyllum",
			rank: "genero",
			scientific: "Peraphyllum",
			parentId: "rosaceae",
			ncbiId: 36619,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "petrophytum",
			rank: "genero",
			scientific: "Petrophytum",
			parentId: "rosaceae",
			ncbiId: 457878,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "phippsiomeles",
			rank: "genero",
			scientific: "Phippsiomeles",
			parentId: "rosaceae",
			ncbiId: 2654658,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "photinia",
			rank: "genero",
			scientific: "Photinia",
			parentId: "rosaceae",
			ncbiId: 23199,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "physocarpus",
			rank: "genero",
			scientific: "Physocarpus",
			parentId: "rosaceae",
			ncbiId: 23201,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "polylepis",
			rank: "genero",
			scientific: "Polylepis",
			parentId: "rosaceae",
			ncbiId: 137449,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "potaninia",
			rank: "genero",
			scientific: "Potaninia",
			parentId: "rosaceae",
			ncbiId: 393622,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "potentilla",
			rank: "genero",
			scientific: "Potentilla",
			parentId: "rosaceae",
			ncbiId: 23204,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "poteridium",
			rank: "genero",
			scientific: "Poteridium",
			parentId: "rosaceae",
			ncbiId: 1755486,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "pourthiaea",
			rank: "genero",
			scientific: "Pourthiaea",
			parentId: "rosaceae",
			ncbiId: 2201386,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "prinsepia",
			rank: "genero",
			scientific: "Prinsepia",
			parentId: "rosaceae",
			ncbiId: 23205,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "prunus",
			rank: "genero",
			scientific: "Prunus",
			parentId: "rosaceae",
			ncbiId: 3754,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "pseudocydonia",
			rank: "genero",
			scientific: "Pseudocydonia",
			parentId: "rosaceae",
			ncbiId: 36621,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "purshia",
			rank: "genero",
			scientific: "Purshia",
			parentId: "rosaceae",
			ncbiId: 23209,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "pygeum",
			rank: "genero",
			scientific: "Pygeum",
			parentId: "rosaceae",
			ncbiId: 401066,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "pyracantha",
			rank: "genero",
			scientific: "Pyracantha",
			parentId: "rosaceae",
			ncbiId: 144561,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "pyrus",
			rank: "genero",
			scientific: "Pyrus",
			parentId: "rosaceae",
			ncbiId: 3766,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "rhaphiolepis",
			rank: "genero",
			scientific: "Rhaphiolepis",
			parentId: "rosaceae",
			ncbiId: 36623,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "rhodotypos",
			rank: "genero",
			scientific: "Rhodotypos",
			parentId: "rosaceae",
			ncbiId: 23214,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "rosa",
			rank: "genero",
			scientific: "Rosa",
			parentId: "rosaceae",
			ncbiId: 3764,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "rubus",
			rank: "genero",
			scientific: "Rubus",
			parentId: "rosaceae",
			ncbiId: 23216,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "sanguisorba",
			rank: "genero",
			scientific: "Sanguisorba",
			parentId: "rosaceae",
			ncbiId: 57937,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "sarcopoterium",
			rank: "genero",
			scientific: "Sarcopoterium",
			parentId: "rosaceae",
			ncbiId: 137459,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "scandosorbus",
			rank: "genero",
			scientific: "Scandosorbus",
			parentId: "rosaceae",
			ncbiId: 2912040,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "sibbaldia",
			rank: "genero",
			scientific: "Sibbaldia",
			parentId: "rosaceae",
			ncbiId: 57946,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "sibbaldianthe",
			rank: "genero",
			scientific: "Sibbaldianthe",
			parentId: "rosaceae",
			ncbiId: 637903,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "sibiraea",
			rank: "genero",
			scientific: "Sibiraea",
			parentId: "rosaceae",
			ncbiId: 310217,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "sieversia",
			rank: "genero",
			scientific: "Sieversia",
			parentId: "rosaceae",
			ncbiId: 148906,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "sorbaria",
			rank: "genero",
			scientific: "Sorbaria",
			parentId: "rosaceae",
			ncbiId: 23221,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "sorbus",
			rank: "genero",
			scientific: "Sorbus",
			parentId: "rosaceae",
			ncbiId: 23222,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "spenceria",
			rank: "genero",
			scientific: "Spenceria",
			parentId: "rosaceae",
			ncbiId: 398530,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "spiraea",
			rank: "genero",
			scientific: "Spiraea",
			parentId: "rosaceae",
			ncbiId: 23224,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "spiraeanthus",
			rank: "genero",
			scientific: "Spiraeanthus",
			parentId: "rosaceae",
			ncbiId: 398528,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "stranvaesia",
			rank: "genero",
			scientific: "Stranvaesia",
			parentId: "rosaceae",
			ncbiId: 193311,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "taihangia",
			rank: "genero",
			scientific: "Taihangia",
			parentId: "rosaceae",
			ncbiId: 148909,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "tetraglochin",
			rank: "genero",
			scientific: "Tetraglochin",
			parentId: "rosaceae",
			ncbiId: 2024733,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "thomsonaria",
			rank: "genero",
			scientific: "Thomsonaria",
			parentId: "rosaceae",
			ncbiId: 2912039,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "torminalis",
			rank: "genero",
			scientific: "Torminalis",
			parentId: "rosaceae",
			ncbiId: 193502,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "vauquelinia",
			rank: "genero",
			scientific: "Vauquelinia",
			parentId: "rosaceae",
			ncbiId: 23231,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "waldsteinia",
			rank: "genero",
			scientific: "Waldsteinia",
			parentId: "rosaceae",
			ncbiId: 23232,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "weniomeles",
			rank: "genero",
			scientific: "Weniomeles",
			parentId: "rosaceae",
			ncbiId: 3704613,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "wilsonaria",
			rank: "genero",
			scientific: "Wilsonaria",
			parentId: "rosaceae",
			ncbiId: 2913904,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "x-amelasorbus",
			rank: "genero",
			scientific: "x Amelasorbus",
			parentId: "rosaceae",
			ncbiId: 2080237,
			summary: "Notogênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "x-comagaria",
			rank: "genero",
			scientific: "x Comagaria",
			parentId: "rosaceae",
			ncbiId: 2841009,
			summary: "Notogênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "x-crataemespilus",
			rank: "genero",
			scientific: "x Crataemespilus",
			parentId: "rosaceae",
			ncbiId: 356581,
			summary: "Notogênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "x-pyronia",
			rank: "genero",
			scientific: "x Pyronia",
			parentId: "rosaceae",
			ncbiId: 343457,
			summary: "Notogênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "x-sorbaronia",
			rank: "genero",
			scientific: "x Sorbaronia",
			parentId: "rosaceae",
			ncbiId: 1577863,
			summary: "Notogênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "x-sorbocotoneaster",
			rank: "genero",
			scientific: "x Sorbocotoneaster",
			parentId: "rosaceae",
			ncbiId: 1530593,
			summary: "Notogênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "xerospiraea",
			rank: "genero",
			scientific: "Xerospiraea",
			parentId: "rosaceae",
			ncbiId: 409524,
			summary: "Gênero de Rosaceae no NCBI Taxonomy."
		},
		{
			id: "ulmaceae",
			rank: "familia",
			scientific: "Ulmaceae",
			parentId: "rosales",
			ncbiId: 3474,
			summary: "Família de Rosales no NCBI Taxonomy. Os gêneros abaixo são os de Ulmaceae, sem subfamílias nem tribos."
		},
		{
			id: "ampelocera",
			rank: "genero",
			scientific: "Ampelocera",
			parentId: "ulmaceae",
			ncbiId: 63063,
			summary: "Gênero de Ulmaceae no NCBI Taxonomy."
		},
		{
			id: "chaetachme",
			rank: "genero",
			scientific: "Chaetachme",
			parentId: "ulmaceae",
			ncbiId: 63055,
			summary: "Gênero de Ulmaceae no NCBI Taxonomy."
		},
		{
			id: "hemiptelea",
			rank: "genero",
			scientific: "Hemiptelea",
			parentId: "ulmaceae",
			ncbiId: 63067,
			summary: "Gênero de Ulmaceae no NCBI Taxonomy."
		},
		{
			id: "holoptelea",
			rank: "genero",
			scientific: "Holoptelea",
			parentId: "ulmaceae",
			ncbiId: 63065,
			summary: "Gênero de Ulmaceae no NCBI Taxonomy."
		},
		{
			id: "phyllostylon",
			rank: "genero",
			scientific: "Phyllostylon",
			parentId: "ulmaceae",
			ncbiId: 1428765,
			summary: "Gênero de Ulmaceae no NCBI Taxonomy."
		},
		{
			id: "planera",
			rank: "genero",
			scientific: "Planera",
			parentId: "ulmaceae",
			ncbiId: 1428767,
			summary: "Gênero de Ulmaceae no NCBI Taxonomy."
		},
		{
			id: "ulmus",
			rank: "genero",
			scientific: "Ulmus",
			parentId: "ulmaceae",
			ncbiId: 24735,
			summary: "Gênero de Ulmaceae no NCBI Taxonomy."
		},
		{
			id: "zelkova",
			rank: "genero",
			scientific: "Zelkova",
			parentId: "ulmaceae",
			ncbiId: 45186,
			summary: "Gênero de Ulmaceae no NCBI Taxonomy."
		},
		{
			id: "urticaceae",
			rank: "familia",
			scientific: "Urticaceae",
			parentId: "rosales",
			ncbiId: 3499,
			summary: "Família das urtigas e das embaúbas. Os gêneros abaixo são os que o NCBI Taxonomy coloca em Urticaceae, sem subfamílias nem tribos."
		},
		{
			id: "achudemia",
			rank: "genero",
			scientific: "Achudemia",
			parentId: "urticaceae",
			ncbiId: 2739262,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "archiboehmeria",
			rank: "genero",
			scientific: "Archiboehmeria",
			parentId: "urticaceae",
			ncbiId: 1399654,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "astrothalamus",
			rank: "genero",
			scientific: "Astrothalamus",
			parentId: "urticaceae",
			ncbiId: 1399656,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "australina",
			rank: "genero",
			scientific: "Australina",
			parentId: "urticaceae",
			ncbiId: 1399658,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "boehmeria",
			rank: "genero",
			scientific: "Boehmeria",
			parentId: "urticaceae",
			ncbiId: 83905,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "capsulea",
			rank: "genero",
			scientific: "Capsulea",
			parentId: "urticaceae",
			ncbiId: 3705042,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "cecropia",
			rank: "genero",
			scientific: "Cecropia",
			parentId: "urticaceae",
			ncbiId: 77071,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "chamabainia",
			rank: "genero",
			scientific: "Chamabainia",
			parentId: "urticaceae",
			ncbiId: 1204771,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "coussapoa",
			rank: "genero",
			scientific: "Coussapoa",
			parentId: "urticaceae",
			ncbiId: 194322,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "cypholophus",
			rank: "genero",
			scientific: "Cypholophus",
			parentId: "urticaceae",
			ncbiId: 344760,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "debregeasia",
			rank: "genero",
			scientific: "Debregeasia",
			parentId: "urticaceae",
			ncbiId: 210329,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "dendrocnide",
			rank: "genero",
			scientific: "Dendrocnide",
			parentId: "urticaceae",
			ncbiId: 647262,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "didymodoxa",
			rank: "genero",
			scientific: "Didymodoxa",
			parentId: "urticaceae",
			ncbiId: 378932,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "discocnide",
			rank: "genero",
			scientific: "Discocnide",
			parentId: "urticaceae",
			ncbiId: 344762,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "droguetia",
			rank: "genero",
			scientific: "Droguetia",
			parentId: "urticaceae",
			ncbiId: 344764,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "elatostema",
			rank: "genero",
			scientific: "Elatostema",
			parentId: "urticaceae",
			ncbiId: 226089,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "elatostematoides",
			rank: "genero",
			scientific: "Elatostematoides",
			parentId: "urticaceae",
			ncbiId: 2564011,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "forsskaolea",
			rank: "genero",
			scientific: "Forsskaolea",
			parentId: "urticaceae",
			ncbiId: 344766,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "gesnouinia",
			rank: "genero",
			scientific: "Gesnouinia",
			parentId: "urticaceae",
			ncbiId: 344768,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "gibbsia",
			rank: "genero",
			scientific: "Gibbsia",
			parentId: "urticaceae",
			ncbiId: 2306680,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "girardinia",
			rank: "genero",
			scientific: "Girardinia",
			parentId: "urticaceae",
			ncbiId: 471945,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "gonostegia",
			rank: "genero",
			scientific: "Gonostegia",
			parentId: "urticaceae",
			ncbiId: 647271,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "gyrotaenia",
			rank: "genero",
			scientific: "Gyrotaenia",
			parentId: "urticaceae",
			ncbiId: 1399691,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "haroldiella",
			rank: "genero",
			scientific: "Haroldiella",
			parentId: "urticaceae",
			ncbiId: 2807046,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "hemistylus",
			rank: "genero",
			scientific: "Hemistylus",
			parentId: "urticaceae",
			ncbiId: 1399695,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "hesperocnide",
			rank: "genero",
			scientific: "Hesperocnide",
			parentId: "urticaceae",
			ncbiId: 194266,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "laportea",
			rank: "genero",
			scientific: "Laportea",
			parentId: "urticaceae",
			ncbiId: 194268,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "lecanthus",
			rank: "genero",
			scientific: "Lecanthus",
			parentId: "urticaceae",
			ncbiId: 344770,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "leucosyke",
			rank: "genero",
			scientific: "Leucosyke",
			parentId: "urticaceae",
			ncbiId: 241849,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "maoutia",
			rank: "genero",
			scientific: "Maoutia",
			parentId: "urticaceae",
			ncbiId: 647275,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "metapilea",
			rank: "genero",
			scientific: "Metapilea",
			parentId: "urticaceae",
			ncbiId: 3705043,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "metatrophis",
			rank: "genero",
			scientific: "Metatrophis",
			parentId: "urticaceae",
			ncbiId: 2807264,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "musanga",
			rank: "genero",
			scientific: "Musanga",
			parentId: "urticaceae",
			ncbiId: 1317685,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "myrianthus",
			rank: "genero",
			scientific: "Myrianthus",
			parentId: "urticaceae",
			ncbiId: 1220083,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "myriocarpa",
			rank: "genero",
			scientific: "Myriocarpa",
			parentId: "urticaceae",
			ncbiId: 226094,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "nanocnide",
			rank: "genero",
			scientific: "Nanocnide",
			parentId: "urticaceae",
			ncbiId: 1399703,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "neodistemon",
			rank: "genero",
			scientific: "Neodistemon",
			parentId: "urticaceae",
			ncbiId: 1399706,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "neraudia",
			rank: "genero",
			scientific: "Neraudia",
			parentId: "urticaceae",
			ncbiId: 1399708,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "nothocnide",
			rank: "genero",
			scientific: "Nothocnide",
			parentId: "urticaceae",
			ncbiId: 647277,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "obetia",
			rank: "genero",
			scientific: "Obetia",
			parentId: "urticaceae",
			ncbiId: 992407,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "oreocnide",
			rank: "genero",
			scientific: "Oreocnide",
			parentId: "urticaceae",
			ncbiId: 647279,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "parietaria",
			rank: "genero",
			scientific: "Parietaria",
			parentId: "urticaceae",
			ncbiId: 13186,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "parsana",
			rank: "genero",
			scientific: "Parsana",
			parentId: "urticaceae",
			ncbiId: 3705039,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "pellionia",
			rank: "genero",
			scientific: "Pellionia",
			parentId: "urticaceae",
			ncbiId: 194271,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "petelotiella",
			rank: "genero",
			scientific: "Petelotiella",
			parentId: "urticaceae",
			ncbiId: 3089780,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "phenax",
			rank: "genero",
			scientific: "Phenax",
			parentId: "urticaceae",
			ncbiId: 858902,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "pilea",
			rank: "genero",
			scientific: "Pilea",
			parentId: "urticaceae",
			ncbiId: 24775,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "pipturus",
			rank: "genero",
			scientific: "Pipturus",
			parentId: "urticaceae",
			ncbiId: 309431,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "poikilospermum",
			rank: "genero",
			scientific: "Poikilospermum",
			parentId: "urticaceae",
			ncbiId: 194276,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "pourouma",
			rank: "genero",
			scientific: "Pourouma",
			parentId: "urticaceae",
			ncbiId: 241851,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "pouzolzia",
			rank: "genero",
			scientific: "Pouzolzia",
			parentId: "urticaceae",
			ncbiId: 344861,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "procris",
			rank: "genero",
			scientific: "Procris",
			parentId: "urticaceae",
			ncbiId: 226092,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "rousselia",
			rank: "genero",
			scientific: "Rousselia",
			parentId: "urticaceae",
			ncbiId: 1399743,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "sarcochlamys",
			rank: "genero",
			scientific: "Sarcochlamys",
			parentId: "urticaceae",
			ncbiId: 1399745,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "sarcopilea",
			rank: "genero",
			scientific: "Sarcopilea",
			parentId: "urticaceae",
			ncbiId: 1198267,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "scepocarpus",
			rank: "genero",
			scientific: "Scepocarpus",
			parentId: "urticaceae",
			ncbiId: 3705040,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "soleirolia",
			rank: "genero",
			scientific: "Soleirolia",
			parentId: "urticaceae",
			ncbiId: 1399747,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "touchardia",
			rank: "genero",
			scientific: "Touchardia",
			parentId: "urticaceae",
			ncbiId: 1399749,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "urera",
			rank: "genero",
			scientific: "Urera",
			parentId: "urticaceae",
			ncbiId: 194274,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "urtica",
			rank: "genero",
			scientific: "Urtica",
			parentId: "urticaceae",
			ncbiId: 3500,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "zhengyia",
			rank: "genero",
			scientific: "Zhengyia",
			parentId: "urticaceae",
			ncbiId: 1312522,
			summary: "Gênero de Urticaceae no NCBI Taxonomy."
		},
		{
			id: "cucurbitales",
			rank: "ordem",
			scientific: "Cucurbitales",
			parentId: null,
			ncbiId: 71239,
			summary: "Ordem Cucurbitales no NCBI Taxonomy, com as famílias, gêneros, espécies e subespécies. Sem subfamílias nem tribos."
		},
		{
			id: "anisophylleaceae",
			rank: "familia",
			scientific: "Anisophylleaceae",
			parentId: "cucurbitales",
			ncbiId: 61129,
			summary: "Família de Cucurbitales no NCBI Taxonomy. Os gêneros abaixo são os de Anisophylleaceae, sem subfamílias nem tribos."
		},
		{
			id: "anisophyllea",
			rank: "genero",
			scientific: "Anisophyllea",
			parentId: "anisophylleaceae",
			ncbiId: 68823,
			summary: "Gênero de Anisophylleaceae no NCBI Taxonomy."
		},
		{
			id: "combretocarpus",
			rank: "genero",
			scientific: "Combretocarpus",
			parentId: "anisophylleaceae",
			ncbiId: 61130,
			summary: "Gênero de Anisophylleaceae no NCBI Taxonomy."
		},
		{
			id: "poga",
			rank: "genero",
			scientific: "Poga",
			parentId: "anisophylleaceae",
			ncbiId: 328748,
			summary: "Gênero de Anisophylleaceae no NCBI Taxonomy."
		},
		{
			id: "polygonanthus",
			rank: "genero",
			scientific: "Polygonanthus",
			parentId: "anisophylleaceae",
			ncbiId: 328750,
			summary: "Gênero de Anisophylleaceae no NCBI Taxonomy."
		},
		{
			id: "apodanthaceae",
			rank: "familia",
			scientific: "Apodanthaceae",
			parentId: "cucurbitales",
			ncbiId: 301900,
			summary: "Família de Cucurbitales no NCBI Taxonomy. Os gêneros abaixo são os de Apodanthaceae, sem subfamílias nem tribos."
		},
		{
			id: "apodanthes",
			rank: "genero",
			scientific: "Apodanthes",
			parentId: "apodanthaceae",
			ncbiId: 301891,
			summary: "Gênero de Apodanthaceae no NCBI Taxonomy."
		},
		{
			id: "pilostyles",
			rank: "genero",
			scientific: "Pilostyles",
			parentId: "apodanthaceae",
			ncbiId: 51499,
			summary: "Gênero de Apodanthaceae no NCBI Taxonomy."
		},
		{
			id: "begoniaceae",
			rank: "familia",
			scientific: "Begoniaceae",
			parentId: "cucurbitales",
			ncbiId: 3680,
			summary: "Família de Cucurbitales no NCBI Taxonomy. Os gêneros abaixo são os de Begoniaceae, sem subfamílias nem tribos."
		},
		{
			id: "begonia",
			rank: "genero",
			scientific: "Begonia",
			parentId: "begoniaceae",
			ncbiId: 3681,
			summary: "Gênero de Begoniaceae no NCBI Taxonomy."
		},
		{
			id: "hillebrandia",
			rank: "genero",
			scientific: "Hillebrandia",
			parentId: "begoniaceae",
			ncbiId: 48235,
			summary: "Gênero de Begoniaceae no NCBI Taxonomy."
		},
		{
			id: "coriariaceae",
			rank: "familia",
			scientific: "Coriariaceae",
			parentId: "cucurbitales",
			ncbiId: 3458,
			summary: "Família de Cucurbitales no NCBI Taxonomy. Os gêneros abaixo são os de Coriariaceae, sem subfamílias nem tribos."
		},
		{
			id: "coriaria",
			rank: "genero",
			scientific: "Coriaria",
			parentId: "coriariaceae",
			ncbiId: 3459,
			summary: "Gênero de Coriariaceae no NCBI Taxonomy."
		},
		{
			id: "corynocarpaceae",
			rank: "familia",
			scientific: "Corynocarpaceae",
			parentId: "cucurbitales",
			ncbiId: 4310,
			summary: "Família de Cucurbitales no NCBI Taxonomy. Os gêneros abaixo são os de Corynocarpaceae, sem subfamílias nem tribos."
		},
		{
			id: "corynocarpus",
			rank: "genero",
			scientific: "Corynocarpus",
			parentId: "corynocarpaceae",
			ncbiId: 4311,
			summary: "Gênero de Corynocarpaceae no NCBI Taxonomy."
		},
		{
			id: "cucurbitaceae",
			rank: "familia",
			scientific: "Cucurbitaceae",
			parentId: "cucurbitales",
			ncbiId: 3650,
			summary: "Família de Cucurbitales no NCBI Taxonomy. Os gêneros abaixo são os de Cucurbitaceae, sem subfamílias nem tribos."
		},
		{
			id: "abobra",
			rank: "genero",
			scientific: "Abobra",
			parentId: "cucurbitaceae",
			ncbiId: 44761,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "acanthosicyos",
			rank: "genero",
			scientific: "Acanthosicyos",
			parentId: "cucurbitaceae",
			ncbiId: 252527,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "actinostemma",
			rank: "genero",
			scientific: "Actinostemma",
			parentId: "cucurbitaceae",
			ncbiId: 381646,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "alsomitra",
			rank: "genero",
			scientific: "Alsomitra",
			parentId: "cucurbitaceae",
			ncbiId: 386129,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "ampelosycios",
			rank: "genero",
			scientific: "Ampelosycios",
			parentId: "cucurbitaceae",
			ncbiId: 386638,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "anisosperma",
			rank: "genero",
			scientific: "Anisosperma",
			parentId: "cucurbitaceae",
			ncbiId: 1003892,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "apodanthera",
			rank: "genero",
			scientific: "Apodanthera",
			parentId: "cucurbitaceae",
			ncbiId: 386135,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "austrobryonia",
			rank: "genero",
			scientific: "Austrobryonia",
			parentId: "cucurbitaceae",
			ncbiId: 452816,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "baijiania",
			rank: "genero",
			scientific: "Baijiania",
			parentId: "cucurbitaceae",
			ncbiId: 381648,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "bambekea",
			rank: "genero",
			scientific: "Bambekea",
			parentId: "cucurbitaceae",
			ncbiId: 386137,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "bayabusua",
			rank: "genero",
			scientific: "Bayabusua",
			parentId: "cucurbitaceae",
			ncbiId: 387123,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "benincasa",
			rank: "genero",
			scientific: "Benincasa",
			parentId: "cucurbitaceae",
			ncbiId: 102210,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "blastania",
			rank: "genero",
			scientific: "Blastania",
			parentId: "cucurbitaceae",
			ncbiId: 1932175,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "bolbostemma",
			rank: "genero",
			scientific: "Bolbostemma",
			parentId: "cucurbitaceae",
			ncbiId: 381651,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "borneosicyos",
			rank: "genero",
			scientific: "Borneosicyos",
			parentId: "cucurbitaceae",
			ncbiId: 388287,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "brandegea",
			rank: "genero",
			scientific: "Brandegea",
			parentId: "cucurbitaceae",
			ncbiId: 386139,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "bryonia",
			rank: "genero",
			scientific: "Bryonia",
			parentId: "cucurbitaceae",
			ncbiId: 3651,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "calycophysum",
			rank: "genero",
			scientific: "Calycophysum",
			parentId: "cucurbitaceae",
			ncbiId: 386141,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "cayaponia",
			rank: "genero",
			scientific: "Cayaponia",
			parentId: "cucurbitaceae",
			ncbiId: 386143,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "cephalopentandra",
			rank: "genero",
			scientific: "Cephalopentandra",
			parentId: "cucurbitaceae",
			ncbiId: 213596,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "ceratosanthes",
			rank: "genero",
			scientific: "Ceratosanthes",
			parentId: "cucurbitaceae",
			ncbiId: 386145,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "cionosicys",
			rank: "genero",
			scientific: "Cionosicys",
			parentId: "cucurbitaceae",
			ncbiId: 386149,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "citrullus",
			rank: "genero",
			scientific: "Citrullus",
			parentId: "cucurbitaceae",
			ncbiId: 3653,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "coccinia",
			rank: "genero",
			scientific: "Coccinia",
			parentId: "cucurbitaceae",
			ncbiId: 213598,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "cogniauxia",
			rank: "genero",
			scientific: "Cogniauxia",
			parentId: "cucurbitaceae",
			ncbiId: 386152,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "corallocarpus",
			rank: "genero",
			scientific: "Corallocarpus",
			parentId: "cucurbitaceae",
			ncbiId: 62975,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "cucumella",
			rank: "genero",
			scientific: "Cucumella",
			parentId: "cucurbitaceae",
			ncbiId: 309179,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "cucumis",
			rank: "genero",
			scientific: "Cucumis",
			parentId: "cucurbitaceae",
			ncbiId: 3655,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "cucumisxcucurbita",
			rank: "genero",
			scientific: "Cucumis x Cucurbita",
			parentId: "cucurbitaceae",
			ncbiId: 454232,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "cucurbita",
			rank: "genero",
			scientific: "Cucurbita",
			parentId: "cucurbitaceae",
			ncbiId: 3660,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "cucurbitella",
			rank: "genero",
			scientific: "Cucurbitella",
			parentId: "cucurbitaceae",
			ncbiId: 386156,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "cyclanthera",
			rank: "genero",
			scientific: "Cyclanthera",
			parentId: "cucurbitaceae",
			ncbiId: 61891,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "cyclantheropsis",
			rank: "genero",
			scientific: "Cyclantheropsis",
			parentId: "cucurbitaceae",
			ncbiId: 387128,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "dactyliandra",
			rank: "genero",
			scientific: "Dactyliandra",
			parentId: "cucurbitaceae",
			ncbiId: 386158,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "dendrosicyos",
			rank: "genero",
			scientific: "Dendrosicyos",
			parentId: "cucurbitaceae",
			ncbiId: 229693,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "diplocyclos",
			rank: "genero",
			scientific: "Diplocyclos",
			parentId: "cucurbitaceae",
			ncbiId: 252524,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "doyerea",
			rank: "genero",
			scientific: "Doyerea",
			parentId: "cucurbitaceae",
			ncbiId: 388289,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "ecballium",
			rank: "genero",
			scientific: "Ecballium",
			parentId: "cucurbitaceae",
			ncbiId: 3678,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "echinocystis",
			rank: "genero",
			scientific: "Echinocystis",
			parentId: "cucurbitaceae",
			ncbiId: 252532,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "echinopepon",
			rank: "genero",
			scientific: "Echinopepon",
			parentId: "cucurbitaceae",
			ncbiId: 61883,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "eureiandra",
			rank: "genero",
			scientific: "Eureiandra",
			parentId: "cucurbitaceae",
			ncbiId: 386168,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "fevillea",
			rank: "genero",
			scientific: "Fevillea",
			parentId: "cucurbitaceae",
			ncbiId: 386170,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "frantzia",
			rank: "genero",
			scientific: "Frantzia",
			parentId: "cucurbitaceae",
			ncbiId: 515859,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "gerrardanthus",
			rank: "genero",
			scientific: "Gerrardanthus",
			parentId: "cucurbitaceae",
			ncbiId: 386172,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "gomphogyne",
			rank: "genero",
			scientific: "Gomphogyne",
			parentId: "cucurbitaceae",
			ncbiId: 447108,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "gurania",
			rank: "genero",
			scientific: "Gurania",
			parentId: "cucurbitaceae",
			ncbiId: 213600,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "gymnopetalum",
			rank: "genero",
			scientific: "Gymnopetalum",
			parentId: "cucurbitaceae",
			ncbiId: 386177,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "gynostemma",
			rank: "genero",
			scientific: "Gynostemma",
			parentId: "cucurbitaceae",
			ncbiId: 182083,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "halosicyos",
			rank: "genero",
			scientific: "Halosicyos",
			parentId: "cucurbitaceae",
			ncbiId: 388293,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "hanburia",
			rank: "genero",
			scientific: "Hanburia",
			parentId: "cucurbitaceae",
			ncbiId: 386179,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "helmontia",
			rank: "genero",
			scientific: "Helmontia",
			parentId: "cucurbitaceae",
			ncbiId: 383662,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "hemsleya",
			rank: "genero",
			scientific: "Hemsleya",
			parentId: "cucurbitaceae",
			ncbiId: 64233,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "herpetospermum",
			rank: "genero",
			scientific: "Herpetospermum",
			parentId: "cucurbitaceae",
			ncbiId: 386181,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "hodgsonia",
			rank: "genero",
			scientific: "Hodgsonia",
			parentId: "cucurbitaceae",
			ncbiId: 386183,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "ibervillea",
			rank: "genero",
			scientific: "Ibervillea",
			parentId: "cucurbitaceae",
			ncbiId: 354616,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "indofevillea",
			rank: "genero",
			scientific: "Indofevillea",
			parentId: "cucurbitaceae",
			ncbiId: 383664,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "indomelothria",
			rank: "genero",
			scientific: "Indomelothria",
			parentId: "cucurbitaceae",
			ncbiId: 418463,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "kedrostis",
			rank: "genero",
			scientific: "Kedrostis",
			parentId: "cucurbitaceae",
			ncbiId: 85218,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "khmeriosicyos",
			rank: "genero",
			scientific: "Khmeriosicyos",
			parentId: "cucurbitaceae",
			ncbiId: 1003894,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "lagenaria",
			rank: "genero",
			scientific: "Lagenaria",
			parentId: "cucurbitaceae",
			ncbiId: 3667,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "lemurosicyos",
			rank: "genero",
			scientific: "Lemurosicyos",
			parentId: "cucurbitaceae",
			ncbiId: 383666,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "linnaeosicyos",
			rank: "genero",
			scientific: "Linnaeosicyos",
			parentId: "cucurbitaceae",
			ncbiId: 1132100,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "luffa",
			rank: "genero",
			scientific: "Luffa",
			parentId: "cucurbitaceae",
			ncbiId: 3669,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "marah",
			rank: "genero",
			scientific: "Marah",
			parentId: "cucurbitaceae",
			ncbiId: 48241,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "melothria",
			rank: "genero",
			scientific: "Melothria",
			parentId: "cucurbitaceae",
			ncbiId: 386191,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "melothrianthus",
			rank: "genero",
			scientific: "Melothrianthus",
			parentId: "cucurbitaceae",
			ncbiId: 388296,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "microlagenaria",
			rank: "genero",
			scientific: "Microlagenaria",
			parentId: "cucurbitaceae",
			ncbiId: 383668,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "microsechium",
			rank: "genero",
			scientific: "Microsechium",
			parentId: "cucurbitaceae",
			ncbiId: 386193,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "momordica",
			rank: "genero",
			scientific: "Momordica",
			parentId: "cucurbitaceae",
			ncbiId: 3671,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "muellerargia",
			rank: "genero",
			scientific: "Muellerargia",
			parentId: "cucurbitaceae",
			ncbiId: 386196,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "neoachmandra",
			rank: "genero",
			scientific: "Neoachmandra",
			parentId: "cucurbitaceae",
			ncbiId: 386274,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "neoalsomitra",
			rank: "genero",
			scientific: "Neoalsomitra",
			parentId: "cucurbitaceae",
			ncbiId: 48237,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "nothoalsomitra",
			rank: "genero",
			scientific: "Nothoalsomitra",
			parentId: "cucurbitaceae",
			ncbiId: 386200,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "papuasicyos",
			rank: "genero",
			scientific: "Papuasicyos",
			parentId: "cucurbitaceae",
			ncbiId: 543289,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "parasicyos",
			rank: "genero",
			scientific: "Parasicyos",
			parentId: "cucurbitaceae",
			ncbiId: 386202,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "penelopeia",
			rank: "genero",
			scientific: "Penelopeia",
			parentId: "cucurbitaceae",
			ncbiId: 386204,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "peponium",
			rank: "genero",
			scientific: "Peponium",
			parentId: "cucurbitaceae",
			ncbiId: 387133,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "peponopsis",
			rank: "genero",
			scientific: "Peponopsis",
			parentId: "cucurbitaceae",
			ncbiId: 386206,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "polyclathra",
			rank: "genero",
			scientific: "Polyclathra",
			parentId: "cucurbitaceae",
			ncbiId: 386208,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "pseudocyclanthera",
			rank: "genero",
			scientific: "Pseudocyclanthera",
			parentId: "cucurbitaceae",
			ncbiId: 427672,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "psiguria",
			rank: "genero",
			scientific: "Psiguria",
			parentId: "cucurbitaceae",
			ncbiId: 386212,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "pteropepon",
			rank: "genero",
			scientific: "Pteropepon",
			parentId: "cucurbitaceae",
			ncbiId: 386215,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "raphidiocystis",
			rank: "genero",
			scientific: "Raphidiocystis",
			parentId: "cucurbitaceae",
			ncbiId: 386217,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "ruthalicia",
			rank: "genero",
			scientific: "Ruthalicia",
			parentId: "cucurbitaceae",
			ncbiId: 386219,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "rytidostylis",
			rank: "genero",
			scientific: "Rytidostylis",
			parentId: "cucurbitaceae",
			ncbiId: 387136,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "schizocarpum",
			rank: "genero",
			scientific: "Schizocarpum",
			parentId: "cucurbitaceae",
			ncbiId: 386221,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "schizopepon",
			rank: "genero",
			scientific: "Schizopepon",
			parentId: "cucurbitaceae",
			ncbiId: 328387,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "scopellaria",
			rank: "genero",
			scientific: "Scopellaria",
			parentId: "cucurbitaceae",
			ncbiId: 386277,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "sechiopsis",
			rank: "genero",
			scientific: "Sechiopsis",
			parentId: "cucurbitaceae",
			ncbiId: 386225,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "sechium",
			rank: "genero",
			scientific: "Sechium",
			parentId: "cucurbitaceae",
			ncbiId: 184139,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "seyrigia",
			rank: "genero",
			scientific: "Seyrigia",
			parentId: "cucurbitaceae",
			ncbiId: 244768,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "sicana",
			rank: "genero",
			scientific: "Sicana",
			parentId: "cucurbitaceae",
			ncbiId: 386229,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "sicydium",
			rank: "genero",
			scientific: "Sicydium",
			parentId: "cucurbitaceae",
			ncbiId: 386231,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "sicyocaulis",
			rank: "genero",
			scientific: "Sicyocaulis",
			parentId: "cucurbitaceae",
			ncbiId: 1132110,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "sicyos",
			rank: "genero",
			scientific: "Sicyos",
			parentId: "cucurbitaceae",
			ncbiId: 64231,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "sicyosperma",
			rank: "genero",
			scientific: "Sicyosperma",
			parentId: "cucurbitaceae",
			ncbiId: 386235,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "sinobaijiania",
			rank: "genero",
			scientific: "Sinobaijiania",
			parentId: "cucurbitaceae",
			ncbiId: 2806740,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "siolmatra",
			rank: "genero",
			scientific: "Siolmatra",
			parentId: "cucurbitaceae",
			ncbiId: 386237,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "siraitia",
			rank: "genero",
			scientific: "Siraitia",
			parentId: "cucurbitaceae",
			ncbiId: 190522,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "solena",
			rank: "genero",
			scientific: "Solena",
			parentId: "cucurbitaceae",
			ncbiId: 386239,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "tecunumania",
			rank: "genero",
			scientific: "Tecunumania",
			parentId: "cucurbitaceae",
			ncbiId: 386241,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "telfairia",
			rank: "genero",
			scientific: "Telfairia",
			parentId: "cucurbitaceae",
			ncbiId: 370897,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "thladiantha",
			rank: "genero",
			scientific: "Thladiantha",
			parentId: "cucurbitaceae",
			ncbiId: 210343,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "trichosanthes",
			rank: "genero",
			scientific: "Trichosanthes",
			parentId: "cucurbitaceae",
			ncbiId: 3676,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "trochomeria",
			rank: "genero",
			scientific: "Trochomeria",
			parentId: "cucurbitaceae",
			ncbiId: 213602,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "trochomeriopsis",
			rank: "genero",
			scientific: "Trochomeriopsis",
			parentId: "cucurbitaceae",
			ncbiId: 386246,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "urceodiscus",
			rank: "genero",
			scientific: "Urceodiscus",
			parentId: "cucurbitaceae",
			ncbiId: 418477,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "vaseyanthus",
			rank: "genero",
			scientific: "Vaseyanthus",
			parentId: "cucurbitaceae",
			ncbiId: 386250,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "wilbrandia",
			rank: "genero",
			scientific: "Wilbrandia",
			parentId: "cucurbitaceae",
			ncbiId: 386252,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "xerosicyos",
			rank: "genero",
			scientific: "Xerosicyos",
			parentId: "cucurbitaceae",
			ncbiId: 48239,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "zanonia",
			rank: "genero",
			scientific: "Zanonia",
			parentId: "cucurbitaceae",
			ncbiId: 515878,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "zehneria",
			rank: "genero",
			scientific: "Zehneria",
			parentId: "cucurbitaceae",
			ncbiId: 378899,
			summary: "Gênero de Cucurbitaceae no NCBI Taxonomy."
		},
		{
			id: "datiscaceae",
			rank: "familia",
			scientific: "Datiscaceae",
			parentId: "cucurbitales",
			ncbiId: 25931,
			summary: "Família de Cucurbitales no NCBI Taxonomy. Os gêneros abaixo são os de Datiscaceae, sem subfamílias nem tribos."
		},
		{
			id: "datisca",
			rank: "genero",
			scientific: "Datisca",
			parentId: "datiscaceae",
			ncbiId: 25932,
			summary: "Gênero de Datiscaceae no NCBI Taxonomy."
		},
		{
			id: "tetramelaceae",
			rank: "familia",
			scientific: "Tetramelaceae",
			parentId: "cucurbitales",
			ncbiId: 196028,
			summary: "Família de Cucurbitales no NCBI Taxonomy. Os gêneros abaixo são os de Tetramelaceae, sem subfamílias nem tribos."
		},
		{
			id: "octomeles",
			rank: "genero",
			scientific: "Octomeles",
			parentId: "tetramelaceae",
			ncbiId: 25933,
			summary: "Gênero de Tetramelaceae no NCBI Taxonomy."
		},
		{
			id: "tetrameles",
			rank: "genero",
			scientific: "Tetrameles",
			parentId: "tetramelaceae",
			ncbiId: 25934,
			summary: "Gênero de Tetramelaceae no NCBI Taxonomy."
		}
	],
	...lowerTaxa(SPECIES, "especie"),
	...lowerTaxa(SUBSPECIES, "subespecie")
];
var byIdMap = new Map(TAXA.map((taxon) => [taxon.id, taxon]));
function taxonById(id) {
	const taxon = byIdMap.get(id);
	if (!taxon) throw new Error(`Táxon desconhecido: ${id}`);
	return taxon;
}
var childrenMap = /* @__PURE__ */ new Map();
for (const taxon of TAXA) {
	if (!taxon.parentId) continue;
	const list = childrenMap.get(taxon.parentId);
	if (list) list.push(taxon);
	else childrenMap.set(taxon.parentId, [taxon]);
}
var byScientific = /* @__PURE__ */ new Map();
for (const taxon of TAXA) if (!byScientific.has(taxon.scientific)) byScientific.set(taxon.scientific, taxon);
function taxonByScientific(name) {
	return byScientific.get(name);
}
function childrenOf(id) {
	return childrenMap.get(id) ?? [];
}
function lineageOf(id) {
	const chain = [];
	let current = taxonById(id);
	while (current) {
		chain.push(current);
		current = current.parentId ? taxonById(current.parentId) : void 0;
	}
	return chain.reverse();
}
function treeOrder() {
	const walk = (id) => {
		return [taxonById(id), ...childrenOf(id).flatMap((child) => walk(child.id))];
	};
	return TAXA.filter((taxon) => taxon.parentId === null).flatMap((root) => walk(root.id));
}
function isItalicRank(rank) {
	return rank === "genero" || rank === "especie" || rank === "subespecie";
}
var GENUS_COUNT = TAXA.filter((taxon) => taxon.rank === "genero").length;
var SPECIES_COUNT = SPECIES.length;
var SUBSPECIES_COUNT = SUBSPECIES.length;
var cache = /* @__PURE__ */ new Map();
function NcbiRecord({ taxid, onOpen }) {
	const [profile, setProfile] = (0, import_react.useState)(() => cache.get(taxid) ?? null);
	const [status, setStatus] = (0, import_react.useState)(() => cache.has(taxid) ? "ready" : "loading");
	(0, import_react.useEffect)(() => {
		const cached = cache.get(taxid);
		if (cached) {
			setProfile(cached);
			setStatus("ready");
			return;
		}
		let cancel = false;
		setProfile(null);
		setStatus("loading");
		getNcbiProfile({ data: taxid }).then((next) => {
			cache.set(taxid, next);
			if (!cancel) {
				setProfile(next);
				setStatus("ready");
			}
		}).catch(() => {
			if (!cancel) setStatus("error");
		});
		return () => {
			cancel = true;
		};
	}, [taxid]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "font-display text-lg font-medium",
			children: "Registro no NCBI"
		}),
		status === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: "Buscando sinônimos e vínculos…"
		}) : null,
		status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: "O NCBI não respondeu agora. Os vínculos abaixo continuam válidos."
		}) : null,
		profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileBody, {
			profile,
			onOpen
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-4 flex flex-col gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkRow, {
					href: taxonomyUrl(taxid),
					label: "Ficha no NCBI Taxonomy"
				}),
				profile?.akaTaxIds.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkRow, {
					href: taxonomyUrl(id),
					label: `Outro taxid · ${id}`
				}, id)),
				profile?.citations.map((citation) => {
					const href = citation.url && !/pubmed\.ncbi/i.test(citation.url) ? citation.url : null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-ink",
						children: href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href,
							target: "_blank",
							rel: "noreferrer",
							className: "underline decoration-line underline-offset-2 hover:text-moss",
							children: citation.text
						}) : citation.text
					}, citation.text);
				})
			]
		}),
		profile?.updated ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-xs text-subtle",
			children: [
				"Registro atualizado em ",
				profile.updated,
				"."
			]
		}) : null
	] });
}
function ProfileBody({ profile, onOpen }) {
	const groups = [
		profile.authority ? {
			title: "Autoridade",
			names: [profile.authority],
			note: null
		} : null,
		profile.basionym ? {
			title: "Basiónimo",
			names: [profile.basionym],
			note: "O autor entre parênteses no nome aceito, quando o NCBI tem um único nome correspondente."
		} : null,
		profile.synonyms.length ? {
			title: "Sinônimos",
			names: profile.synonyms,
			note: null
		} : null,
		profile.equivalent.length ? {
			title: "Nomes equivalentes",
			names: profile.equivalent,
			note: null
		} : null,
		profile.misspellings.length ? {
			title: "Grafias incorretas",
			names: profile.misspellings,
			note: null
		} : null,
		profile.commonNames.length ? {
			title: "Nomes populares",
			names: profile.commonNames,
			note: null
		} : null,
		profile.includes.length ? {
			title: "Nomes incluídos neste táxon",
			names: profile.includes,
			note: null
		} : null,
		profile.inPart.length ? {
			title: "Em parte",
			names: profile.inPart,
			note: null
		} : null
	].filter((group) => Boolean(group));
	const extra = /* @__PURE__ */ new Map();
	for (const item of profile.other) {
		const list = extra.get(item.label) ?? [];
		list.push(item.name);
		extra.set(item.label, list);
	}
	const empty = groups.length === 0 && extra.size === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 space-y-5",
		children: [
			empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Sem sinônimos nem basiónimo neste registro."
			}) : null,
			groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NameGroup, {
				title: group.title,
				names: group.names,
				note: group.note,
				onOpen
			}, group.title)),
			[...extra.entries()].map(([title, names]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NameGroup, {
				title,
				names,
				note: null,
				onOpen
			}, title))
		]
	});
}
function NameGroup({ title, names, note, onOpen }) {
	const latin = title !== "Nomes populares";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
			className: "text-xs font-medium tracking-wide text-subtle",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 divide-y divide-line border-y border-line",
			children: names.map((name) => {
				const linked = latin ? taxonByScientific(bareName(name)) : void 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "py-2 text-sm text-ink",
					children: linked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onOpen(linked.id),
						className: "text-left underline decoration-line underline-offset-2 hover:text-moss focus-visible:ring-2 focus-visible:ring-moss focus-visible:outline-none",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NameText, {
							value: name,
							latin
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NameText, {
						value: name,
						latin
					})
				}, name);
			})
		}),
		note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-subtle",
			children: note
		}) : null
	] });
}
function NameText({ value, latin }) {
	if (!latin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: value });
	const split = splitAuthor(value);
	if (!split) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificBits, { name: value });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificBits, { name: split.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "text-muted",
		children: [" ", split.author]
	})] });
}
function splitAuthor(value) {
	const match = value.match(/^(.*?)(\s+\([^)]+\)\s+.+|\s+[A-Z](?:[A-Za-z.\-]+|\.)(?:,\s*\d{4})?.*)$/);
	if (!match) return null;
	const name = match[1].trim();
	const author = match[2].trim();
	if (!name || !author || author.length > name.length + 40) return null;
	return {
		name,
		author
	};
}
function ScientificBits({ name }) {
	const parts = name.split(/(\s+(?:subsp\.|ssp\.|var\.|f\.|subg\.|nothosubsp\.)\s+)/);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "font-display text-taxon",
		children: parts.map((part, index) => /subsp\.|ssp\.|var\.|f\.|subg\.|nothosubsp\./.test(part) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: part }, index) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "italic",
			children: part
		}, index))
	});
}
function bareName(value) {
	return splitAuthor(value)?.name ?? value;
}
function LinkRow({ href, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		target: "_blank",
		rel: "noreferrer",
		className: "text-sm text-moss underline decoration-line underline-offset-2 hover:text-ink",
		children: label
	}) });
}
function taxonomyUrl(taxid) {
	return `https://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?id=${taxid}`;
}
var FILTERS = [
	{
		id: "especie",
		label: "Espécies"
	},
	{
		id: "subespecie",
		label: "Subespécies"
	},
	{
		id: "genero",
		label: "Gêneros"
	},
	{
		id: "familia",
		label: "Famílias"
	},
	{
		id: "ordem",
		label: "Ordens"
	},
	{
		id: "tudo",
		label: "Tudo"
	}
];
var INDENT = {
	reino: "pl-3",
	divisao: "pl-4",
	classe: "pl-5",
	ordem: "pl-6",
	familia: "pl-7",
	genero: "pl-8",
	especie: "pl-9",
	subespecie: "pl-10"
};
function normalize(value) {
	return value.toLocaleLowerCase("pt-BR");
}
var SEARCH_LIMIT = 40;
function hitRank(taxon, query) {
	const name = normalize(taxon.scientific);
	if (name === query) return 0;
	if (name.startsWith(query)) return 1;
	if (name.includes(query)) return 2;
	return 3;
}
function matchesQuery(taxon, query) {
	if (!query) return true;
	return normalize([
		taxon.scientific,
		taxon.vernacular,
		taxon.ncbiId ? String(taxon.ncbiId) : ""
	].filter(Boolean).join(" ")).includes(query);
}
function ScientificName({ taxon, className = "" }) {
	if (taxon.rank === "subespecie") {
		const parts = taxon.scientific.split(/\s+subsp\.\s+/);
		if (parts.length === 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `font-display text-taxon ${className}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "italic",
					children: parts[0]
				}),
				" subsp. ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "italic",
					children: parts[1]
				})
			]
		});
	}
	const italic = isItalicRank(taxon.rank);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `${italic ? "font-display italic" : "font-display"} text-taxon ${className}`,
		children: taxon.scientific
	});
}
function FloraCatalog() {
	const [selectedId, setSelectedId] = (0, import_react.useState)("rosa");
	const [rankFilter, setRankFilter] = (0, import_react.useState)("genero");
	const [query, setQuery] = (0, import_react.useState)("");
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const needle = normalize(query.trim());
	const ordered = (0, import_react.useMemo)(() => treeOrder(), []);
	const visible = (0, import_react.useMemo)(() => {
		if (needle) return ordered.filter((taxon) => matchesQuery(taxon, needle)).sort((a, b) => hitRank(a, needle) - hitRank(b, needle));
		if (rankFilter === "especie" || rankFilter === "subespecie") return [];
		if (rankFilter === "tudo") return ordered.filter((taxon) => taxon.rank !== "especie" && taxon.rank !== "subespecie");
		return ordered.filter((taxon) => taxon.rank === rankFilter);
	}, [
		ordered,
		rankFilter,
		needle
	]);
	const shown = needle ? visible.slice(0, SEARCH_LIMIT) : visible;
	const selected = taxonById(selectedId);
	const plant = selected.rank === "especie" || selected.rank === "subespecie";
	const lineage = lineageOf(selectedId);
	const children = childrenOf(selectedId);
	const related = (selected.relatedIds ?? []).map((id) => taxonById(id));
	function openFromList(id) {
		setSelectedId(id);
		setMobileOpen(true);
	}
	function openFromDossier(id) {
		setSelectedId(id);
		setMobileOpen(true);
		setRankFilter("tudo");
		setQuery("");
	}
	const listHidden = mobileOpen ? "hidden md:flex" : "flex";
	const dossierHidden = mobileOpen ? "flex" : "hidden md:flex";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "shrink-0 border-b border-line bg-bg-elevated",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-4 px-4 py-4 md:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-moss",
					children: "Taxonomia botânica"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-medium tracking-tight text-ink md:text-3xl",
					children: "Herbário"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "hidden max-w-sm text-right text-sm text-muted sm:block",
					children: [
						GENUS_COUNT,
						" gêneros, ",
						SPECIES_COUNT,
						" espécies e ",
						SUBSPECIES_COUNT,
						" subespécies."
					]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: `${listHidden} min-h-0 w-full min-w-0 shrink-0 flex-col border-line md:w-96 md:border-r`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "shrink-0 space-y-3 border-b border-line px-4 py-3 md:px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "relative block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Buscar táxon"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								"aria-hidden": true,
								className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: query,
								onChange: (event) => setQuery(event.target.value),
								placeholder: "Nome científico ou popular",
								suppressHydrationWarning: true,
								className: "h-11 w-full rounded-md border border-line bg-bg-elevated pr-3 pl-10 text-sm text-ink outline-none placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-moss"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 overflow-x-auto pb-1",
						role: "tablist",
						"aria-label": "Filtrar por categoria",
						children: FILTERS.map((filter) => {
							const active = rankFilter === filter.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "tab",
								"aria-selected": !needle && active,
								onClick: () => {
									setRankFilter(filter.id);
									setQuery("");
								},
								className: `h-9 shrink-0 rounded-full px-3 text-sm font-medium focus-visible:ring-2 focus-visible:ring-moss focus-visible:outline-none ${!needle && active ? "bg-moss text-bg" : "bg-paper text-ink"}`,
								children: filter.label
							}, filter.id);
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1 overflow-y-auto",
					children: [
						needle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-4 pt-3 text-xs text-subtle",
							children: "A busca olha todos os táxons, sem o filtro."
						}) : null,
						shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-4 py-8 text-sm text-muted",
							children: needle ? "Nenhum táxon com esse nome." : rankFilter === "especie" || rankFilter === "subespecie" ? "Busque o nome científico. Esta lista não abre as espécies de uma vez." : "Nenhum táxon neste filtro."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: shown.map((taxon) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaxonRow, {
							taxon,
							selected: taxon.id === selectedId,
							showRank: Boolean(needle),
							indent: !needle && rankFilter === "tudo" ? INDENT[taxon.rank] : void 0,
							onSelect: () => openFromList(taxon.id)
						}, taxon.id)) }),
						visible.length > shown.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "px-4 py-3 text-xs text-subtle",
							children: [
								shown.length,
								" de ",
								visible.length,
								". Continue o nome para afunilar."
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-4 py-4 text-xs text-subtle",
							children: "Rosales e Cucurbitales no NCBI Taxonomy: famílias, gêneros, espécies e subespécies. Sem subfamílias nem tribos."
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: `${dossierHidden} min-h-0 min-w-0 flex-1 flex-col overflow-y-auto bg-bg`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "dossier-enter mx-auto w-full max-w-5xl px-4 py-5 md:px-8 md:py-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setMobileOpen(false),
							className: "mb-4 inline-flex h-11 items-center gap-2 text-sm font-medium text-moss focus-visible:ring-2 focus-visible:ring-moss focus-visible:outline-none md:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
								"aria-hidden": true,
								className: "size-4"
							}), "Voltar à lista"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-medium tracking-wide text-moss",
							children: [RANK_LABEL[selected.rank], selected.sheet ? ` · ficha ${selected.sheet}` : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-1 font-display text-3xl font-medium tracking-tight text-ink md:text-4xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificName, { taxon: selected }), selected.authority ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 font-sans text-base font-normal text-muted not-italic",
								children: selected.authority
							}) : null]
						}),
						plant || selected.vernacular ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `mt-1 text-lg ${selected.vernacular ? "text-muted" : "text-subtle"}`,
							children: selected.vernacular ?? "sem informação"
						}) : null,
						selected.ncbiId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `https://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?id=${selected.ncbiId}`,
								target: "_blank",
								rel: "noreferrer",
								className: "underline decoration-line underline-offset-2 hover:text-ink",
								children: ["NCBI Taxonomy · ", selected.ncbiId]
							})
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							"aria-label": "Linhagem taxonômica",
							className: "mt-5 flex flex-wrap items-center gap-x-2 gap-y-1",
							children: lineage.map((taxon, index) => {
								const current = taxon.id === selected.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-2",
									children: [index > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-subtle",
										children: "/"
									}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => openFromDossier(taxon.id),
										disabled: current,
										className: `text-sm focus-visible:ring-2 focus-visible:ring-moss focus-visible:outline-none disabled:cursor-default ${current ? "font-medium text-ink" : "text-muted hover:text-ink"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-xs tracking-wide text-subtle",
											children: RANK_LABEL[taxon.rank]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificName, { taxon })]
									})]
								}, taxon.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `mt-8 grid gap-8 ${plant || selected.image ? "lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)]" : ""}`,
							children: [plant || selected.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
								className: "overflow-hidden rounded-lg border border-line bg-bg-elevated",
								children: [selected.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: selected.image,
									alt: `Prancha botânica de ${selected.scientific}`,
									width: 1200,
									height: 1600,
									className: "h-auto w-full bg-paper"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex aspect-[3/4] items-center justify-center px-6 text-center text-sm text-subtle",
									children: "sem informação"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
									className: "border-t border-line px-4 py-3 text-xs text-muted",
									children: ["Prancha de herbário", selected.sheet ? ` · ${selected.sheet}` : ""]
								})]
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 space-y-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `max-w-prose text-base ${selected.summary ? "text-ink" : "text-subtle"}`,
										children: selected.summary ?? (plant ? "sem informação" : selected.rank === "subespecie" ? "Subespécie no NCBI Taxonomy, colocada direto sob a espécie." : "Espécie no NCBI Taxonomy, colocada direto sob o gênero.")
									}),
									plant ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FactGrid, {
										taxon: selected,
										reserve: true
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FactGrid, { taxon: selected }),
									plant || selected.diagnosis ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-lg font-medium",
										children: "Diagnose"
									}), selected.diagnosis && selected.diagnosis.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-3 flex flex-col gap-2 border-l border-line pl-4",
										children: selected.diagnosis.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "text-sm text-ink",
											children: item
										}, item))
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm text-subtle",
										children: "sem informação"
									})] }) : null,
									plant || selected.morphology ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-lg font-medium",
										children: "Morfologia"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
										className: "mt-3 divide-y divide-line border-y border-line",
										children: (plant ? plantMorphology(selected) : selected.morphology ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid gap-1 py-3 sm:grid-cols-[8rem_minmax(0,1fr)] sm:gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-sm font-medium text-muted",
												children: item.label
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: `text-sm ${item.value ? "text-ink" : "text-subtle"}`,
												children: item.value || "sem informação"
											})]
										}, item.label))
									})] }) : null,
									plant || selected.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-lg font-medium",
										children: "Notas"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `mt-3 max-w-prose text-sm ${selected.notes ? "text-ink" : "text-subtle"}`,
										children: selected.notes ?? "sem informação"
									})] }) : null,
									plant || related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-lg font-medium",
										children: "Espécies próximas"
									}), related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-3 divide-y divide-line border-y border-line",
										children: related.map((taxon) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "taxon-row",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildButton, {
												taxon,
												onSelect: () => openFromDossier(taxon.id)
											})
										}, taxon.id))
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm text-subtle",
										children: "sem informação"
									})] }) : null,
									selected.ncbiId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NcbiRecord, {
										taxid: selected.ncbiId,
										onOpen: openFromDossier
									}) : null,
									children.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "font-display text-lg font-medium",
										children: ["Inclui", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "ml-2 font-sans text-sm font-normal text-muted",
											children: [
												children.length,
												" ",
												rankCountLabel(children[0].rank, children.length)
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-3 divide-y divide-line border-y border-line",
										children: children.map((taxon) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "taxon-row",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildButton, {
												taxon,
												onSelect: () => openFromDossier(taxon.id)
											})
										}, taxon.id))
									})] }) : null
								]
							})]
						})
					]
				}, selected.id)
			})]
		})]
	});
}
function rankCountLabel(rank, count) {
	return {
		reino: ["reino", "reinos"],
		divisao: ["divisão", "divisões"],
		classe: ["classe", "classes"],
		ordem: ["ordem", "ordens"],
		familia: ["família", "famílias"],
		genero: ["gênero", "gêneros"],
		especie: ["espécie", "espécies"],
		subespecie: ["subespécie", "subespécies"]
	}[rank][count === 1 ? 0 : 1];
}
function TaxonRow({ taxon, selected, indent, showRank = false, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
		className: "taxon-row",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onSelect,
			"aria-current": selected ? "true" : void 0,
			className: `flex min-h-14 w-full items-center justify-between gap-3 border-l-2 py-2 pr-4 text-left focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-moss focus-visible:outline-none ${indent ?? "pl-4"} ${selected ? "border-moss bg-moss-soft" : "border-transparent hover:bg-paper"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate text-base text-ink",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificName, { taxon })
				}), taxon.vernacular ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate text-sm text-muted",
					children: taxon.vernacular
				}) : null]
			}), taxon.rank === "genero" && !showRank ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shrink-0 text-xs text-subtle",
				children: RANK_LABEL[taxon.rank]
			})]
		})
	});
}
function ChildButton({ taxon, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onSelect,
		className: "flex min-h-14 w-full items-center justify-between gap-3 py-2 text-left focus-visible:ring-2 focus-visible:ring-moss focus-visible:outline-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-base text-ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificName, { taxon })
			}), taxon.vernacular ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-sm text-muted",
				children: taxon.vernacular
			}) : null]
		}), taxon.rank === "genero" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "shrink-0 text-xs text-subtle",
			children: RANK_LABEL[taxon.rank]
		})]
	});
}
var PLANT_MORPHOLOGY = [
	"Porte",
	"Folhas",
	"Flores",
	"Fruto"
];
function plantMorphology(taxon) {
	const known = new Map((taxon.morphology ?? []).map((item) => [item.label, item.value]));
	const reserved = PLANT_MORPHOLOGY.map((label) => ({
		label,
		value: known.get(label) ?? ""
	}));
	const extra = (taxon.morphology ?? []).filter((item) => !PLANT_MORPHOLOGY.includes(item.label));
	return [...reserved, ...extra];
}
function FactGrid({ taxon, reserve = false }) {
	const facts = [
		["Hábito", taxon.habit],
		["Hábitat", taxon.habitat],
		["Distribuição", taxon.distribution],
		["Altitude", taxon.elevation],
		["Fenologia", taxon.phenology],
		["Situação", taxon.status]
	];
	const shown = reserve ? facts : facts.filter((entry) => Boolean(entry[1]));
	if (shown.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
		className: "grid gap-3 sm:grid-cols-2",
		children: shown.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border border-line bg-bg-elevated px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
				className: "text-xs font-medium text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
				className: `mt-1 text-sm ${value ? "text-ink" : "text-subtle"}`,
				children: value || "sem informação"
			})]
		}, label))
	});
}
var SplitComponent = FloraCatalog;
//#endregion
export { SplitComponent as component };
